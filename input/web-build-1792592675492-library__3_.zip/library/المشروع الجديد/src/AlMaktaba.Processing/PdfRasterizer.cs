using System.Globalization;
using AlMaktaba.Core;
using PDFtoImage;
using SkiaSharp;

namespace AlMaktaba.Processing;

public sealed class PdfRasterizer
{
    private const int MaximumPageCount = 1_000;
    private const int MaximumPagesPerBatch = 100;
    private const long MaximumPdfBytes = 512L * 1024 * 1024;
    private const long MaximumRenderedPixelsPerPage = 40_000_000;
    private const long MaximumRenderedPageBytes = 256L * 1024 * 1024;

    public Task<string> RenderPageAsync(
        string pdfPath, int zeroBasedPage, string outputPath, int dpi = 150,
        CancellationToken cancellationToken = default,
        ImageOutputFormat outputFormat = ImageOutputFormat.Png,
        int jpegQuality = 92,
        IProgress<double>? progress = null) =>
        Task.Run(() =>
        {
            if (zeroBasedPage < 0)
                throw new ArgumentOutOfRangeException(nameof(zeroBasedPage));
            ValidateRenderOptions(dpi, outputFormat, jpegQuality);
            cancellationToken.ThrowIfCancellationRequested();
            ValidatePdfEnvelope(pdfPath);
            using var stream = File.OpenRead(pdfPath);
            var pageCount = Conversion.GetPageCount(stream, leaveOpen: true);
            if (pageCount is < 1 or > MaximumPageCount)
                throw new InvalidDataException($"عدد صفحات PDF خارج الحد المدعوم (1–{MaximumPageCount}).");
            if (zeroBasedPage >= pageCount)
                throw new ArgumentOutOfRangeException(nameof(zeroBasedPage), "رقم الصفحة يتجاوز عدد صفحات PDF.");
            var bytes = RenderPageBytes(
                pdfPath, stream, zeroBasedPage, dpi, outputFormat, jpegQuality, cancellationToken);
            WriteOutputAtomically(outputPath, bytes);
            progress?.Report(1);
            return outputPath;
        }, cancellationToken);

    public Task<IReadOnlyList<string>> RenderAllPagesAsync(
        string pdfPath,
        string outputDirectory,
        int dpi = 150,
        IProgress<double>? progress = null,
        CancellationToken cancellationToken = default,
        ImageOutputFormat outputFormat = ImageOutputFormat.Png,
        int jpegQuality = 92) =>
        RenderPageRangeAsync(
            pdfPath, 1, null, outputDirectory, dpi, outputFormat, jpegQuality, progress, cancellationToken);

    public Task<IReadOnlyList<string>> RenderPageRangeAsync(
        string pdfPath,
        int firstPage,
        int? lastPage,
        string outputDirectory,
        int dpi = 150,
        ImageOutputFormat outputFormat = ImageOutputFormat.Png,
        int jpegQuality = 92,
        IProgress<double>? progress = null,
        CancellationToken cancellationToken = default) =>
        Task.Run<IReadOnlyList<string>>(() =>
        {
            if (firstPage < 1 || (lastPage is not null && lastPage < firstPage))
                throw new ArgumentOutOfRangeException(nameof(firstPage), "نطاق الصفحات غير صالح.");
            ValidateRenderOptions(dpi, outputFormat, jpegQuality);
            cancellationToken.ThrowIfCancellationRequested();
            ValidatePdfEnvelope(pdfPath);
            Directory.CreateDirectory(outputDirectory);
            using var stream = File.OpenRead(pdfPath);
            var pageCount = Conversion.GetPageCount(stream, leaveOpen: true);
            if (pageCount is < 1 or > MaximumPageCount)
                throw new InvalidDataException($"عدد صفحات PDF خارج الحد المدعوم (1–{MaximumPageCount}).");
            var effectiveLastPage = lastPage ?? pageCount;
            if (firstPage > pageCount || effectiveLastPage > pageCount)
                throw new ArgumentOutOfRangeException(nameof(lastPage), "نطاق الصفحات يتجاوز عدد صفحات PDF.");
            var pagesToRender = effectiveLastPage - firstPage + 1;
            if (pagesToRender > MaximumPagesPerBatch)
                throw new InvalidDataException($"يمكن تصيير 1–{MaximumPagesPerBatch} صفحة في عملية واحدة.");

            var safeName = SafeFileNames.Sanitize(Path.GetFileNameWithoutExtension(pdfPath));
            var extension = outputFormat == ImageOutputFormat.Jpeg ? ".jpg" : ".png";
            var runId = Guid.NewGuid().ToString("N");
            var outputs = new List<string>(pagesToRender);
            for (var page = firstPage; page <= effectiveLastPage; page++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var path = Path.Combine(outputDirectory, $"{safeName}-page-{page:0000}-{runId}{extension}");
                var bytes = RenderPageBytes(
                    pdfPath, stream, page - 1, dpi, outputFormat, jpegQuality, cancellationToken);
                WriteOutputAtomically(path, bytes);
                outputs.Add(path);
                progress?.Report((page - firstPage + 1d) / pagesToRender);
            }
            return outputs;
        }, cancellationToken);

    private static void ValidateRenderOptions(int dpi, ImageOutputFormat outputFormat, int jpegQuality)
    {
        if (dpi is < 72 or > 300)
            throw new ArgumentOutOfRangeException(nameof(dpi), "اختر دقة بين 72 و300 DPI لتحديد استهلاك الموارد.");
        if (!Enum.IsDefined(outputFormat) || jpegQuality is < 1 or > 100)
            throw new ArgumentOutOfRangeException(nameof(outputFormat), "صيغة الصورة أو جودتها غير صالحة.");
    }

    private static byte[] RenderPageBytes(
        string pdfPath, Stream pdfStream, int pageIndex, int dpi,
        ImageOutputFormat outputFormat, int jpegQuality, CancellationToken cancellationToken)
    {
        cancellationToken.ThrowIfCancellationRequested();
        pdfStream.Position = 0;
        using var pngStream = new MemoryStream();
        Conversion.SavePng(
            pngStream, pdfStream, pageIndex, leaveOpen: true,
            options: new RenderOptions { Dpi = dpi });
        cancellationToken.ThrowIfCancellationRequested();
        if (pngStream.Length is <= 0 or > MaximumRenderedPageBytes)
            throw new InvalidDataException("صورة الصفحة الناتجة أكبر من حد الذاكرة المسموح.");

        var pngBytes = pngStream.ToArray();
        using var bitmap = SKBitmap.Decode(pngBytes)
            ?? throw new InvalidDataException("تعذر فك صورة صفحة PDF الناتجة.");
        if ((long)bitmap.Width * bitmap.Height > MaximumRenderedPixelsPerPage)
            throw new InvalidDataException("أبعاد الصفحة الناتجة تتجاوز الحد الآمن.");
        if (outputFormat == ImageOutputFormat.Png)
            return pngBytes;

        using var opaque = SkiaImageCodec.CreateBitmap(bitmap.Width, bitmap.Height);
        using (var canvas = new SKCanvas(opaque))
        {
            canvas.Clear(SKColors.White);
            canvas.DrawBitmap(bitmap, 0, 0, new SKSamplingOptions(SKFilterMode.Linear), null);
            canvas.Flush();
        }
        using var image = SKImage.FromBitmap(opaque);
        using var jpeg = image.Encode(SKEncodedImageFormat.Jpeg, jpegQuality)
            ?? throw new InvalidDataException("تعذر تحويل الصفحة إلى JPEG.");
        return JpegDpiMetadata.Apply(jpeg.ToArray(), dpi);
    }

    private static void WriteOutputAtomically(string outputPath, byte[] bytes)
    {
        var fullPath = Path.GetFullPath(outputPath);
        var directory = Path.GetDirectoryName(fullPath)!;
        Directory.CreateDirectory(directory);
        var temporaryPath = Path.Combine(directory, $".{Path.GetFileName(fullPath)}.{Guid.NewGuid():N}.tmp");
        try
        {
            using (var output = new FileStream(
                       temporaryPath, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            {
                output.Write(bytes);
                output.Flush(flushToDisk: true);
            }
            File.Move(temporaryPath, fullPath, overwrite: false);
        }
        catch
        {
            if (File.Exists(temporaryPath))
                File.Delete(temporaryPath);
            throw;
        }
    }

    private static void ValidatePdfEnvelope(string pdfPath)
    {
        var info = new FileInfo(pdfPath);
        if (!info.Exists || info.Length < 16 || info.Length > MaximumPdfBytes)
            throw new InvalidDataException("ملف PDF غير موجود أو حجمه خارج الحد الآمن.");

        using var stream = info.OpenRead();
        Span<byte> header = stackalloc byte[8];
        if (stream.Read(header) != header.Length || !header.StartsWith("%PDF-"u8))
            throw new InvalidDataException("توقيع ملف PDF غير صالح.");

        var tailLength = (int)Math.Min(2048, stream.Length);
        var tail = new byte[tailLength];
        stream.Position = stream.Length - tailLength;
        stream.ReadExactly(tail);
        var tailText = System.Text.Encoding.Latin1.GetString(tail);
        var eofIndex = tailText.LastIndexOf("%%EOF", StringComparison.Ordinal);
        var startXrefIndex = eofIndex < 0
            ? -1
            : tailText.LastIndexOf("startxref", eofIndex, StringComparison.Ordinal);
        if (eofIndex < 0 || startXrefIndex < 0)
            throw new InvalidDataException("ملف PDF مبتور أو يفتقد إلى نهاية وبنية الفهرس.");

        var offsetText = tailText[(startXrefIndex + "startxref".Length)..eofIndex].Trim();
        if (!long.TryParse(offsetText, NumberStyles.None, CultureInfo.InvariantCulture, out var xrefOffset) ||
            xrefOffset < header.Length || xrefOffset >= stream.Length)
            throw new InvalidDataException("مرجع فهرس PDF غير صالح.");

        var xrefLength = (int)Math.Min(4096, stream.Length - xrefOffset);
        var xrefBytes = new byte[xrefLength];
        stream.Position = xrefOffset;
        stream.ReadExactly(xrefBytes);
        var xrefText = System.Text.Encoding.Latin1.GetString(xrefBytes).TrimStart();
        var hasClassicXref = xrefText.StartsWith("xref", StringComparison.Ordinal);
        var hasXrefStream = xrefText.Contains("/Type /XRef", StringComparison.Ordinal) ||
                            xrefText.Contains("/Type/XRef", StringComparison.Ordinal);
        if (!hasClassicXref && !hasXrefStream)
            throw new InvalidDataException("تعذر العثور على فهرس صفحات PDF صالح.");
    }
}
