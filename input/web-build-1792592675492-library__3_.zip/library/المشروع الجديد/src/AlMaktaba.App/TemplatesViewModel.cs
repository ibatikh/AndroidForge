using AlMaktaba.Core;
using AlMaktaba.Infrastructure;
using AlMaktaba.Processing;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Extensions.Logging;

namespace AlMaktaba.App;

public partial class TemplatesViewModel(
    IImageProcessor processor, ImagePdfWriter pdfWriter, ILocalLibraryService library, AppPaths paths,
    LocalJobQueue jobs, ILogger<TemplatesViewModel> logger)
    : ObservableObject
{
    public IReadOnlyList<PhotoTemplate> Templates => PhotoTemplates.All;
    public List<string> PhotoPaths { get; } = [];

    [ObservableProperty] private PhotoTemplate selectedTemplate = PhotoTemplates.ThreeByFour;
    [ObservableProperty] private string status = "اختر قالبًا وصورة أو أكثر.";
    [ObservableProperty] private bool isBusy;
    [ObservableProperty] private int dpi = 300;
    [ObservableProperty] private PhotoCropAnchor cropAnchor = PhotoCropAnchor.Center;
    [ObservableProperty] private ImageOutputFormat outputFormat = ImageOutputFormat.Png;
    [ObservableProperty] private int jpegQuality = 92;
    [ObservableProperty] private double progress;
    [ObservableProperty] private string? previewPath;
    private CancellationTokenSource? _currentOperation;
    public bool CanRun => !IsBusy && PhotoPaths.Count > 0;
    public bool CanCancel => IsBusy;
    public bool CanExportPdf => !IsBusy && !string.IsNullOrWhiteSpace(PreviewPath) && File.Exists(PreviewPath);

    partial void OnIsBusyChanged(bool value)
    {
        OnPropertyChanged(nameof(CanRun));
        OnPropertyChanged(nameof(CanCancel));
        OnPropertyChanged(nameof(CanExportPdf));
    }

    partial void OnPreviewPathChanged(string? value) =>
        OnPropertyChanged(nameof(CanExportPdf));

    public void SetPhotos(IEnumerable<string> photoPaths)
    {
        PhotoPaths.Clear();
        PhotoPaths.AddRange(photoPaths);
        PreviewPath = null;
        OnPropertyChanged(nameof(CanRun));
        Status = $"الصور: {PhotoPaths.Count}";
    }

    [RelayCommand]
    public Task PreviewAsync() => RenderAsync(saveToLibrary: false);

    [RelayCommand]
    public Task GenerateAsync() => RenderAsync(saveToLibrary: true);

    [RelayCommand]
    public async Task ExportPdfAsync()
    {
        var imagePath = PreviewPath;
        if (string.IsNullOrWhiteSpace(imagePath) || !File.Exists(imagePath))
        {
            Status = "أنشئ معاينة القالب الحالية قبل تصدير PDF.";
            return;
        }

        var template = SelectedTemplate;
        ImagePdfPaperSize pageSize;
        if (Math.Abs(template.PaperWidthCm - 10) < 0.01 &&
            Math.Abs(template.PaperHeightCm - 15) < 0.01)
            pageSize = ImagePdfPaperSize.Photo10x15Cm;
        else if (Math.Abs(template.PaperWidthCm - 21) < 0.01 &&
                 Math.Abs(template.PaperHeightCm - 29.7) < 0.01)
            pageSize = ImagePdfPaperSize.A4;
        else
        {
            _currentOperation = null;
            IsBusy = false;
            Status = "حجم ورق هذا القالب غير مدعوم للتصدير المباشر إلى PDF.";
            return;
        }

        IsBusy = true;
        Progress = 0;
        using var cancellation = new CancellationTokenSource();
        _currentOperation = cancellation;
        var output = Path.Combine(paths.Generated,
            $"{template.Id}-print-{DateTime.Now:yyyyMMdd-HHmmss}-{Guid.NewGuid():N}.pdf");
        try
        {
            Directory.CreateDirectory(paths.Generated);
            var uiProgress = new Progress<double>(value => Progress = value);
            await jobs.RunAsync("تصدير قالب الطباعة إلى PDF", imagePath, async (jobProgress, token) =>
            {
                var operationProgress = new Progress<double>(value =>
                {
                    var bounded = Math.Clamp(value, 0, 1);
                    jobProgress.Report(bounded);
                    uiProgress.Report(bounded);
                });
                await pdfWriter.WriteAsync(
                    [imagePath], output,
                    new ImagePdfOptions(pageSize, ImagePdfOrientation.Portrait),
                    operationProgress, token);
                await library.ImportAsync(output, $"Template PDF: {template.Id}", token);
                return output;
            }, cancellation.Token);
            Status = $"تم حفظ PDF بمقاس {template.PaperWidthCm:0.##} × {template.PaperHeightCm:0.##} سم في المكتبة.";
            Progress = 1;
        }
        catch (OperationCanceledException)
        {
            Status = "أُلغيت عملية تصدير PDF.";
        }
        catch (Exception exception)
        {
            logger.LogError(exception, "Template PDF export failed.");
            Status = "تعذر تصدير القالب إلى PDF. راجع إعدادات القالب.";
        }
        finally
        {
            _currentOperation = null;
            IsBusy = false;
        }
    }

    [RelayCommand]
    private void CancelOperation() => _currentOperation?.Cancel();

    private async Task RenderAsync(bool saveToLibrary)
    {
        if (PhotoPaths.Count == 0) { Status = "اختر صورة واحدة على الأقل."; return; }
        IsBusy = true;
        Progress = 0;
        using var cancellation = new CancellationTokenSource();
        _currentOperation = cancellation;
        try
        {
            var template = SelectedTemplate with { Dpi = Dpi };
            var cropAnchor = CropAnchor;
            var outputFormat = OutputFormat;
            var jpegQuality = JpegQuality;
            var directory = saveToLibrary ? paths.Generated : paths.Temp;
            Directory.CreateDirectory(directory);
            var extension = outputFormat == ImageOutputFormat.Jpeg ? ".jpg" : ".png";
            var output = Path.Combine(directory,
                $"{template.Id}-{DateTime.Now:yyyyMMdd-HHmmss}-{Guid.NewGuid():N}{extension}");
            var uiProgress = new Progress<double>(value => Progress = value);
            output = await jobs.RunAsync(
                saveToLibrary ? "إنشاء قالب صور" : "معاينة قالب صور",
                PhotoPaths[0],
                async (jobProgress, token) =>
                {
                    var operationProgress = new Progress<double>(value =>
                    {
                        jobProgress.Report(value);
                        uiProgress.Report(value);
                    });
                    await processor.CreateTemplateAsync(
                        PhotoPaths, template, output, operationProgress, token,
                        cropAnchor, outputFormat, jpegQuality);
                    if (saveToLibrary)
                        await library.ImportAsync(output, $"Template: {template.Id}", token);
                    return output;
                },
                cancellation.Token);
            PreviewPath = output;
            if (saveToLibrary)
            {
                Status = $"تم حفظ القالب بمقاس {template.PixelWidth} × {template.PixelHeight} بكسل عند {Dpi} DPI.";
            }
            else
            {
                Status = $"معاينة محلية جاهزة — {template.PixelWidth} × {template.PixelHeight} بكسل عند {Dpi} DPI.";
            }
            Progress = 1;
        }
        catch (OperationCanceledException)
        {
            Status = "أُلغيت العملية.";
        }
        catch (Exception exception)
        {
            logger.LogError(exception, "Template generation failed.");
            Status = "تعذر إنشاء القالب. تحقق من الصور ومقاس DPI.";
        }
        finally
        {
            _currentOperation = null;
            IsBusy = false;
        }
    }
}
