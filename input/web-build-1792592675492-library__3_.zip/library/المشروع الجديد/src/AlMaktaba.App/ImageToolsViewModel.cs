using AlMaktaba.Core;
using AlMaktaba.Infrastructure;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Extensions.Logging;

namespace AlMaktaba.App;

public partial class ImageToolsViewModel(
    IImageProcessor processor, ILocalLibraryService library, AppPaths paths,
    LocalJobQueue jobs, ILogger<ImageToolsViewModel> logger)
    : ObservableObject
{
    [ObservableProperty] private string status = "اختر صورة لبدء المعالجة المحلية.";
    [ObservableProperty] private double progress;
    [ObservableProperty] private bool isBusy;
    [ObservableProperty] private string? whiteSpacePreviewPath;
    [ObservableProperty] private double whitening = 0.15;
    [ObservableProperty] private double brightness;
    [ObservableProperty] private double contrast = 1;
    [ObservableProperty] private double saturation = 1;
    [ObservableProperty] private double sharpen = 0.1;
    [ObservableProperty] private double retouch = 0.1;
    [ObservableProperty] private double noiseReduction;
    private readonly List<string> _inputPaths = [];
    private CancellationTokenSource? _currentOperation;

    public IReadOnlyList<string> InputPaths => _inputPaths;
    public bool CanRun => !IsBusy && _inputPaths.Count > 0;
    public bool CanCancel => IsBusy;
    public bool CanSaveWhiteSpace => !IsBusy && !string.IsNullOrWhiteSpace(WhiteSpacePreviewPath);

    partial void OnIsBusyChanged(bool value)
    {
        OnPropertyChanged(nameof(CanRun));
        OnPropertyChanged(nameof(CanCancel));
        OnPropertyChanged(nameof(CanSaveWhiteSpace));
    }

    partial void OnWhiteSpacePreviewPathChanged(string? value) =>
        OnPropertyChanged(nameof(CanSaveWhiteSpace));

    public void SetInput(string path) => SetInputs([path]);

    public void SetInputs(IEnumerable<string> paths)
    {
        DiscardWhiteSpacePreview();
        _inputPaths.Clear();
        _inputPaths.AddRange(paths.Where(File.Exists).Distinct(StringComparer.OrdinalIgnoreCase));
        Status = _inputPaths.Count == 0
            ? "اختر صورة لبدء المعالجة المحلية."
            : $"الصور المحددة: {_inputPaths.Count}";
        OnPropertyChanged(nameof(InputPaths));
        OnPropertyChanged(nameof(CanRun));
    }

    public async Task PreviewWhiteSpaceAsync(ImageMargins margins)
    {
        var inputs = _inputPaths.Where(File.Exists).ToArray();
        if (inputs.Length == 0)
        {
            Status = "اختر صورة موجودة على الجهاز أولًا.";
            return;
        }

        DiscardWhiteSpacePreview();
        IsBusy = true;
        Progress = 0;
        var output = Path.Combine(paths.Temp, $"white-space-preview-{Guid.NewGuid():N}.png");
        using var cancellation = new CancellationTokenSource();
        _currentOperation = cancellation;
        try
        {
            Directory.CreateDirectory(paths.Temp);
            var uiProgress = new Progress<double>(value => Progress = value);
            await jobs.RunAsync("معاينة المساحة البيضاء", inputs[0], async (jobProgress, token) =>
            {
                var combinedProgress = new Progress<double>(value =>
                {
                    var bounded = Math.Clamp(value, 0, 1);
                    jobProgress.Report(bounded);
                    uiProgress.Report(bounded);
                });
                await processor.AddWhiteSpaceAsync(inputs[0], output, margins, combinedProgress, token);
                return output;
            }, cancellation.Token);
            WhiteSpacePreviewPath = output;
            Status = "المعاينة جاهزة. راجعها قبل حفظ النتيجة في المكتبة.";
            Progress = 1;
        }
        catch (OperationCanceledException)
        {
            Status = "أُلغيت المعاينة.";
            TryDeletePreview(output);
        }
        catch (Exception exception)
        {
            logger.LogError(exception, "White-space preview failed.");
            Status = "تعذر إنشاء المعاينة. تحقق من الصورة وقيم الهوامش.";
            TryDeletePreview(output);
        }
        finally
        {
            _currentOperation = null;
            IsBusy = false;
        }
    }

    public async Task SaveWhiteSpaceAsync(ImageMargins margins)
    {
        if (string.IsNullOrWhiteSpace(WhiteSpacePreviewPath) || !File.Exists(WhiteSpacePreviewPath))
        {
            Status = "أنشئ معاينة جديدة قبل حفظ النتيجة.";
            return;
        }

        await RunOperationAsync("إضافة مساحة بيضاء", (input, progress, token) =>
            processor.AddWhiteSpaceAsync(input, NextOutput(input, "-white-space", ".png"),
                margins, progress, token));
        if (Status.StartsWith("اكتملت", StringComparison.Ordinal))
            DiscardWhiteSpacePreview();
    }

    public void DiscardWhiteSpacePreview()
    {
        var previousPath = WhiteSpacePreviewPath;
        WhiteSpacePreviewPath = null;
        if (string.IsNullOrWhiteSpace(previousPath))
            return;

        var tempRoot = Path.GetFullPath(paths.Temp) + Path.DirectorySeparatorChar;
        var fullPath = Path.GetFullPath(previousPath);
        if (fullPath.StartsWith(tempRoot, StringComparison.OrdinalIgnoreCase))
            TryDeletePreview(fullPath);
    }

    [RelayCommand]
    public async Task AdjustAsync()
    {
        await RunOperationAsync("تحسين محلي", (input, progress, token) =>
            processor.AdjustAsync(input, NextOutput(input, "-adjusted", ".png"),
                new ImageAdjustments(
                    (float)Brightness, (float)Contrast, (float)Saturation, (float)Sharpen,
                    (float)Whitening, (float)Retouch, (float)NoiseReduction),
                progress, token));
    }

    [RelayCommand]
    private void CancelOperation() => _currentOperation?.Cancel();

    private async Task RunOperationAsync(
        string title,
        Func<string, IProgress<double>, CancellationToken, Task<string>> operation)
    {
        var inputs = _inputPaths.Where(File.Exists).ToArray();
        if (inputs.Length == 0)
        {
            Status = "اختر صورة موجودة على الجهاز أولًا.";
            return;
        }

        IsBusy = true;
        Progress = 0;
        using var cancellation = new CancellationTokenSource();
        _currentOperation = cancellation;
        try
        {
            var uiProgress = new Progress<double>(value => Progress = value);
            await jobs.RunAsync(title, inputs[0], async (jobProgress, token) =>
            {
                string? lastOutput = null;
                for (var index = 0; index < inputs.Length; index++)
                {
                    token.ThrowIfCancellationRequested();
                    var currentIndex = index;
                    var progress = new Progress<double>(value =>
                    {
                        var overall = (currentIndex + Math.Clamp(value, 0, 1)) / inputs.Length;
                        jobProgress.Report(overall);
                        uiProgress.Report(overall);
                    });
                    lastOutput = await operation(inputs[index], progress, token);
                    await library.ImportAsync(lastOutput, title, token);
                }
                return lastOutput ?? throw new InvalidOperationException("لم تُنتج العملية ملفًا.");
            }, cancellation.Token);
            Status = inputs.Length == 1
                ? "اكتملت المعالجة محليًا وحُفظت النتيجة في المكتبة."
                : $"اكتملت المعالجة المحلية وحُفظت {inputs.Length} نتائج في المكتبة.";
            Progress = 1;
        }
        catch (OperationCanceledException)
        {
            Status = "أُلغيت المعالجة. قد تبقى نتائج الملفات التي اكتملت قبل الإلغاء في المكتبة.";
        }
        catch (Exception exception)
        {
            logger.LogError(exception, "Image processing operation failed.");
            Status = "تعذر إكمال المعالجة. راجع الإعدادات للتفاصيل التقنية.";
        }
        finally
        {
            _currentOperation = null;
            IsBusy = false;
        }
    }

    private string NextOutput(string source, string suffix, string extension)
    {
        Directory.CreateDirectory(paths.Generated);
        return Path.Combine(paths.Generated,
            $"{Path.GetFileNameWithoutExtension(source)}{suffix}-{DateTime.Now:yyyyMMdd-HHmmss}-{Guid.NewGuid():N}{extension}");
    }

    private static void TryDeletePreview(string path)
    {
        try
        {
            if (File.Exists(path))
                File.Delete(path);
        }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }
}
