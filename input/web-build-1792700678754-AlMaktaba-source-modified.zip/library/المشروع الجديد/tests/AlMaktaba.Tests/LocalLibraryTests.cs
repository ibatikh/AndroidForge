using AlMaktaba.Core;
using AlMaktaba.Infrastructure;
using Microsoft.Extensions.Logging.Abstractions;

namespace AlMaktaba.Tests;

public sealed class LocalLibraryTests
{
    private const string OnePixelPng =
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/dN8AAAAASUVORK5CYII=";

    [Fact]
    public async Task ImportSearchFavoriteRenameAndDeleteWorkWithArabicFilenames()
    {
        using var workspace = new TemporaryWorkspace();
        var paths = new AppPaths(workspace.Path);
        paths.EnsureCreated();
        var repository = new SqliteFileRepository(paths);
        await repository.InitializeAsync();
        var library = new LocalLibraryService(paths, repository, NullLogger<LocalLibraryService>.Instance);
        var source = Path.Combine(workspace.Path, "صورة شخصية ١.png");
        await File.WriteAllBytesAsync(source, Convert.FromBase64String(OnePixelPng));

        var imported = await library.ImportAsync(source, "test");

        Assert.Equal("صورة شخصية ١.png", imported.OriginalName);
        Assert.Equal(LibraryFileKind.Image, imported.Kind);
        Assert.Equal(64, imported.Checksum?.Length ?? 0);
        Assert.True(File.Exists(Path.Combine(paths.Library, imported.RelativePath)));
        Assert.Single(await library.SearchAsync(new LibraryQuery(Search: "شخصية")));

        await library.SetFavoriteAsync(imported.Id, true);
        Assert.True(Assert.Single(await library.SearchAsync(new LibraryQuery(FavoritesOnly: true))).IsFavorite);

        await library.RenameAsync(imported.Id, "بطاقة جديدة.png");
        Assert.Equal("بطاقة جديدة.png", (await repository.GetAsync(imported.Id))?.OriginalName);
        await Assert.ThrowsAsync<InvalidDataException>(() => library.RenameAsync(imported.Id, "بطاقة جديدة.pdf"));

        await library.DeleteAsync(imported.Id);
        Assert.Null(await repository.GetAsync(imported.Id));
        Assert.Empty(await library.SearchAsync(new LibraryQuery()));
    }

    [Fact]
    public async Task CategoriesRecentFilesAndOperationHistoryAreStoredLocally()
    {
        using var workspace = new TemporaryWorkspace();
        var paths = new AppPaths(workspace.Path);
        paths.EnsureCreated();
        var repository = new SqliteFileRepository(paths);
        await repository.InitializeAsync();
        var library = new LocalLibraryService(paths, repository, NullLogger<LocalLibraryService>.Instance);
        var source = Path.Combine(workspace.Path, "portrait.png");
        await File.WriteAllBytesAsync(source, Convert.FromBase64String(OnePixelPng));
        var file = await library.ImportAsync(source);

        await library.SetCategoryAsync(file.Id, "صور شخصية");
        await library.RecordOpenedAsync(file.Id);

        var filtered = Assert.Single(await library.SearchAsync(
            new LibraryQuery(Category: "صور شخصية", SortBy: "recent")));
        Assert.Equal(file.Id, filtered.Id);
        Assert.Equal("صور شخصية", filtered.Category);
        Assert.NotNull(filtered.LastOpenedAt);
        Assert.Empty(await library.SearchAsync(new LibraryQuery(Category: "مستندات")));

        var operations = await library.GetRecentOperationsAsync(10);
        Assert.Contains(operations, operation => operation.Operation == "Import");
        Assert.Contains(operations, operation => operation.Operation == "SetCategory");
        Assert.Contains(operations, operation => operation.Operation == "Open");
    }

    [Fact]
    public async Task CategoryNamesCannotBecomeFileSystemPaths()
    {
        using var workspace = new TemporaryWorkspace();
        var paths = new AppPaths(workspace.Path);
        paths.EnsureCreated();
        var repository = new SqliteFileRepository(paths);
        await repository.InitializeAsync();
        var library = new LocalLibraryService(paths, repository, NullLogger<LocalLibraryService>.Instance);
        var source = Path.Combine(workspace.Path, "portrait.png");
        await File.WriteAllBytesAsync(source, Convert.FromBase64String(OnePixelPng));
        var file = await library.ImportAsync(source);

        await Assert.ThrowsAsync<InvalidDataException>(() =>
            library.SetCategoryAsync(file.Id, "../outside"));

        Assert.Equal("", (await repository.GetAsync(file.Id))?.Category);
    }

    [Fact]
    public async Task LibraryFiltersAndSortOptionsReturnExpectedFiles()
    {
        using var workspace = new TemporaryWorkspace();
        var paths = new AppPaths(workspace.Path);
        paths.EnsureCreated();
        var repository = new SqliteFileRepository(paths);
        await repository.InitializeAsync();
        var library = new LocalLibraryService(paths, repository, NullLogger<LocalLibraryService>.Instance);

        var firstPath = Path.Combine(workspace.Path, "Bravo.png");
        var secondPath = Path.Combine(workspace.Path, "alpha.png");
        var literalWildcardPath = Path.Combine(workspace.Path, "100%.png");
        foreach (var path in new[] { firstPath, secondPath, literalWildcardPath })
            await File.WriteAllBytesAsync(path, Convert.FromBase64String(OnePixelPng));
        var first = await library.ImportAsync(firstPath);
        var second = await library.ImportAsync(secondPath);
        var wildcard = await library.ImportAsync(literalWildcardPath);
        await library.SetCategoryAsync(first.Id, "صور");
        await library.SetCategoryAsync(second.Id, "صور");
        await library.SetFavoriteAsync(first.Id, true);
        await library.RecordOpenedAsync(second.Id);

        var names = await library.SearchAsync(new LibraryQuery(
            Kind: LibraryFileKind.Image, SortBy: "name", Descending: false));
        Assert.Equal(new[] { "100%.png", "alpha.png", "Bravo.png" },
            names.Select(file => file.OriginalName));
        Assert.Equal(wildcard.Id,
            Assert.Single(await library.SearchAsync(new LibraryQuery(Search: "%"))).Id);
        Assert.Equal(first.Id, Assert.Single(await library.SearchAsync(
            new LibraryQuery(Category: "صور", FavoritesOnly: true))).Id);
        Assert.Equal(second.Id,
            (await library.SearchAsync(new LibraryQuery(SortBy: "recent"))).First().Id);
        Assert.Equal(3, (await library.SearchAsync(new LibraryQuery(SortBy: "not-a-column"))).Count);
    }

    [Fact]
    public async Task ThumbnailMetadataIsRestrictedToItsOwnedCacheFileAndDeletedWithItem()
    {
        using var workspace = new TemporaryWorkspace();
        var paths = new AppPaths(workspace.Path);
        paths.EnsureCreated();
        var repository = new SqliteFileRepository(paths);
        await repository.InitializeAsync();
        var library = new LocalLibraryService(paths, repository, NullLogger<LocalLibraryService>.Instance);
        var source = Path.Combine(workspace.Path, "portrait.png");
        await File.WriteAllBytesAsync(source, Convert.FromBase64String(OnePixelPng));
        var item = await library.ImportAsync(source);
        var thumbnail = Path.Combine(paths.Thumbnails, item.Id + ".jpg");
        await File.WriteAllBytesAsync(thumbnail, [1, 2, 3]);
        var relative = Path.GetRelativePath(paths.Root, thumbnail);

        await library.SetThumbnailPathAsync(item.Id, relative);
        await Assert.ThrowsAsync<InvalidDataException>(() =>
            library.SetThumbnailPathAsync(item.Id, Path.Combine("cache", "thumbnails", "another.jpg")));
        Assert.Equal(relative, (await repository.GetAsync(item.Id))?.ThumbnailPath);

        await library.DeleteAsync(item.Id);
        Assert.False(File.Exists(thumbnail));
    }

    [Fact]
    public async Task DeletingFileNeverFollowsThumbnailSymlinkOutsideCache()
    {
        using var workspace = new TemporaryWorkspace();
        var paths = new AppPaths(workspace.Path);
        paths.EnsureCreated();
        var repository = new SqliteFileRepository(paths);
        await repository.InitializeAsync();
        var library = new LocalLibraryService(paths, repository, NullLogger<LocalLibraryService>.Instance);
        var source = Path.Combine(workspace.Path, "portrait.png");
        await File.WriteAllBytesAsync(source, Convert.FromBase64String(OnePixelPng));
        var item = await library.ImportAsync(source);
        var thumbnail = Path.Combine(paths.Thumbnails, item.Id + ".jpg");
        await File.WriteAllBytesAsync(thumbnail, [1, 2, 3]);
        await library.SetThumbnailPathAsync(item.Id, Path.GetRelativePath(paths.Root, thumbnail));
        var outside = Path.Combine(workspace.Path, "outside");
        Directory.CreateDirectory(outside);
        var outsideThumbnail = Path.Combine(outside, item.Id + ".jpg");
        File.Move(thumbnail, outsideThumbnail);
        Directory.Delete(paths.Thumbnails);
        try
        {
            Directory.CreateSymbolicLink(paths.Thumbnails, outside);
        }
        catch (Exception exception) when (
            exception is IOException or UnauthorizedAccessException or PlatformNotSupportedException)
        {
            return;
        }

        await library.DeleteAsync(item.Id);

        Assert.Null(await repository.GetAsync(item.Id));
        Assert.True(File.Exists(outsideThumbnail));
    }

    [Fact]
    public async Task ImportRejectsMismatchedKnownFileExtensions()
    {
        using var workspace = new TemporaryWorkspace();
        var paths = new AppPaths(workspace.Path);
        paths.EnsureCreated();
        var repository = new SqliteFileRepository(paths);
        await repository.InitializeAsync();
        var library = new LocalLibraryService(paths, repository, NullLogger<LocalLibraryService>.Instance);
        var source = Path.Combine(workspace.Path, "not-a-pdf.pdf");
        await File.WriteAllTextAsync(source, "this is not a PDF");

        await Assert.ThrowsAsync<InvalidDataException>(() => library.ImportAsync(source));
        Assert.Empty(await repository.SearchAsync(new LibraryQuery()));
        Assert.Empty(Directory.EnumerateFiles(paths.Pdf));
    }

    [Fact]
    public async Task ImportRejectsFilesLargerThanTheConfiguredLimit()
    {
        using var workspace = new TemporaryWorkspace();
        var paths = new AppPaths(workspace.Path);
        paths.EnsureCreated();
        var repository = new SqliteFileRepository(paths);
        await repository.InitializeAsync();
        var library = new LocalLibraryService(paths, repository, NullLogger<LocalLibraryService>.Instance);
        var source = Path.Combine(workspace.Path, "too-large.bin");
        await using (var stream = new FileStream(source, FileMode.CreateNew))
        {
            stream.SetLength(500L * 1024 * 1024 + 1);
        }

        await Assert.ThrowsAsync<InvalidDataException>(() => library.ImportAsync(source));
        Assert.Empty(await repository.SearchAsync(new LibraryQuery()));
    }

    [Fact]
    public async Task DeleteRejectsSymlinkedLibraryDirectoryWithoutTouchingOutsideFile()
    {
        using var workspace = new TemporaryWorkspace();
        var paths = new AppPaths(workspace.Path);
        paths.EnsureCreated();
        var repository = new SqliteFileRepository(paths);
        await repository.InitializeAsync();
        var library = new LocalLibraryService(paths, repository, NullLogger<LocalLibraryService>.Instance);
        var source = Path.Combine(workspace.Path, "صورة.png");
        await File.WriteAllBytesAsync(source, Convert.FromBase64String(OnePixelPng));
        var imported = await library.ImportAsync(source);
        var outsideDirectory = Path.Combine(workspace.Path, "outside");
        Directory.CreateDirectory(outsideDirectory);
        var storedPath = Path.Combine(paths.Library, imported.RelativePath);
        var outsidePath = Path.Combine(outsideDirectory, imported.StoredName);
        File.Move(storedPath, outsidePath);
        Directory.Delete(paths.Images);

        try
        {
            Directory.CreateSymbolicLink(paths.Images, outsideDirectory);
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or PlatformNotSupportedException)
        {
            return;
        }

        await Assert.ThrowsAsync<InvalidDataException>(() => library.DeleteAsync(imported.Id));

        Assert.True(File.Exists(outsidePath));
        Assert.NotNull(await repository.GetAsync(imported.Id));
    }

    private sealed class TemporaryWorkspace : IDisposable
    {
        public string Path { get; } = System.IO.Path.Combine(
            System.IO.Path.GetTempPath(), "AlMaktaba.Tests", Guid.NewGuid().ToString("N"));

        public void Dispose()
        {
            try { Directory.Delete(Path, recursive: true); }
            catch (DirectoryNotFoundException) { }
        }
    }
}
