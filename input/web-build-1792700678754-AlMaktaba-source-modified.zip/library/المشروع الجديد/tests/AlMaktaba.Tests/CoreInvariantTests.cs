using AlMaktaba.Core;

namespace AlMaktaba.Tests;

public sealed class CoreInvariantTests
{
    [Theory]
    [InlineData(10, 300, 1181)]
    [InlineData(15, 300, 1772)]
    [InlineData(3, 300, 354)]
    [InlineData(4.5, 300, 531)]
    public void CentimetersConvertToRoundedPixels(double centimeters, int dpi, int expected)
    {
        Assert.Equal(expected, PhysicalUnits.CentimetersToPixels(centimeters, dpi));
    }

    [Theory]
    [InlineData(0, 300)]
    [InlineData(-1, 300)]
    [InlineData(double.NaN, 300)]
    [InlineData(1, 71)]
    [InlineData(1, 1201)]
    public void InvalidPhysicalDimensionsAreRejected(double centimeters, int dpi)
    {
        Assert.Throws<ArgumentOutOfRangeException>(
            () => PhysicalUnits.CentimetersToPixels(centimeters, dpi));
    }

    [Fact]
    public void BuiltInTemplatesPreserveRequiredPrintLayouts()
    {
        Assert.Equal((3, 3, 9), (
            PhotoTemplates.ThreeByFour.Columns,
            PhotoTemplates.ThreeByFour.Rows,
            PhotoTemplates.ThreeByFour.PhotoCount));
        Assert.Equal((2, 3, 6), (
            PhotoTemplates.ThreePointFiveByFourPointFive.Columns,
            PhotoTemplates.ThreePointFiveByFourPointFive.Rows,
            PhotoTemplates.ThreePointFiveByFourPointFive.PhotoCount));
        Assert.Equal((6, 3, 18), (
            PhotoTemplates.MultiSixByThree.Columns,
            PhotoTemplates.MultiSixByThree.Rows,
            PhotoTemplates.MultiSixByThree.PhotoCount));
        Assert.Equal((5, 4, 20), (
            PhotoTemplates.MultiFiveByFour.Columns,
            PhotoTemplates.MultiFiveByFour.Rows,
            PhotoTemplates.MultiFiveByFour.PhotoCount));
        Assert.All(PhotoTemplates.All, template => Assert.Equal(300, template.Dpi));
    }

    [Fact]
    public void ArabicNamesAndSpacesSurviveSafeNameHandling()
    {
        Assert.Equal("بطاقة الهوية ١.png", SafeFileNames.Sanitize("../مجلد/بطاقة الهوية ١.png"));
    }

    [Fact]
    public void UnsafeSeparatorsAndControlCharactersAreRemoved()
    {
        var cleaned = SafeFileNames.Sanitize("folder\\name\nreport.pdf");
        Assert.DoesNotContain("/", cleaned);
        Assert.DoesNotContain("\\", cleaned);
        Assert.DoesNotContain('\n', cleaned);
        Assert.EndsWith(".pdf", cleaned, StringComparison.OrdinalIgnoreCase);
    }

    [Fact]
    public void EmptyNamesAreRejected()
    {
        Assert.Throws<ArgumentException>(() => SafeFileNames.Sanitize("  "));
    }

    [Fact]
    public void LongNamesStayWithinTheConfiguredLimit()
    {
        var result = SafeFileNames.Sanitize(new string('أ', 300) + ".jpg");
        Assert.True(result.Length <= SafeFileNames.MaxNameLength);
        Assert.EndsWith(".jpg", result, StringComparison.OrdinalIgnoreCase);
    }
}
