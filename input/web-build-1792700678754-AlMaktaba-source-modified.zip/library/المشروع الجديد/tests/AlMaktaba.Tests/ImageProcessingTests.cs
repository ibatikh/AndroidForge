using AlMaktaba.Core;
using AlMaktaba.Processing;
using SkiaSharp;
using System.Buffers.Binary;

namespace AlMaktaba.Tests;

public sealed class ImageProcessingTests
{
    [Fact]
    public async Task WhiteSpaceAddsRequestedMarginsAndKeepsPixels()
    {
        using var workspace = new TemporaryWorkspace();
        var sourcePath = Path.Combine(workspace.Path, "source.png");
        var outputPath = Path.Combine(workspace.Path, "result.png");
        await SaveImageAsync(sourcePath, 1, 1, new SKColor(30, 60, 90));

        var processor = new ImageProcessingService();
        await processor.AddWhiteSpaceAsync(sourcePath, outputPath, new ImageMargins(2, 1, 3, 4));

        using var result = SKBitmap.Decode(outputPath)!;
        Assert.Equal((8, 4), (result.Width, result.Height));
        Assert.Equal(SKColors.White, result.GetPixel(0, 0));
        Assert.Equal(new SKColor(30, 60, 90), result.GetPixel(3, 2));
    }

    [Fact]
    public async Task NoiseReductionRemovesImpulseNoiseWithoutChangingUniformNeighbors()
    {
        using var workspace = new TemporaryWorkspace();
        var sourcePath = Path.Combine(workspace.Path, "noisy.png");
        var outputPath = Path.Combine(workspace.Path, "denoised.png");
        using (var source = new SKBitmap(new SKImageInfo(5, 5, SKColorType.Rgba8888, SKAlphaType.Unpremul)))
        {
            source.Erase(new SKColor(120, 120, 120));
            source.SetPixel(2, 2, SKColors.Black);
            await SaveBitmapAsync(sourcePath, source);
        }

        await new ImageProcessingService().AdjustAsync(
            sourcePath, outputPath, new ImageAdjustments(NoiseReduction: 1));

        using var result = SKBitmap.Decode(outputPath)!;
        Assert.Equal(new SKColor(120, 120, 120), result.GetPixel(2, 2));
        Assert.Equal(new SKColor(120, 120, 120), result.GetPixel(1, 1));
    }

    [Fact]
    public async Task RetouchSmoothsLikelySkinAndLeavesBluePixelsUnchanged()
    {
        using var workspace = new TemporaryWorkspace();
        var sourcePath = Path.Combine(workspace.Path, "skin.png");
        var outputPath = Path.Combine(workspace.Path, "retouched.png");
        var skin = new SKColor(200, 150, 100);
        using (var source = new SKBitmap(new SKImageInfo(7, 7, SKColorType.Rgba8888, SKAlphaType.Unpremul)))
        {
            source.Erase(skin);
            source.SetPixel(3, 3, new SKColor(240, 190, 140));
            source.SetPixel(2, 2, SKColors.Blue);
            await SaveBitmapAsync(sourcePath, source);
        }

        await new ImageProcessingService().AdjustAsync(
            sourcePath, outputPath, new ImageAdjustments(Retouch: 1));

        using var result = SKBitmap.Decode(outputPath)!;
        var originalCenter = new SKColor(240, 190, 140);
        var outputCenter = result.GetPixel(3, 3);
        Assert.True(outputCenter.Red < originalCenter.Red);
        Assert.Equal(SKColors.Blue, result.GetPixel(2, 2));
    }

    [Fact]
    public async Task TemplateOutputUsesPhysicalDimensionsAndCanBeCancelled()
    {
        using var workspace = new TemporaryWorkspace();
        var sourcePath = Path.Combine(workspace.Path, "source.png");
        var outputPath = Path.Combine(workspace.Path, "template.png");
        await SaveImageAsync(sourcePath, 2, 2, new SKColor(10, 20, 30));

        var template = new PhotoTemplate("test", "test", 1, 1, 1, 1, 2, 2, 72);
        var processor = new ImageProcessingService();
        await processor.CreateTemplateAsync([sourcePath], template, outputPath);

        using var result = SKBitmap.Decode(outputPath)!;
        Assert.Equal((57, 57), (result.Width, result.Height));
        var pngBytes = await File.ReadAllBytesAsync(outputPath);
        Assert.True(pngBytes.AsSpan().IndexOf("pHYs"u8) >= 0);

        using var cancelled = new CancellationTokenSource();
        cancelled.Cancel();
        await Assert.ThrowsAnyAsync<OperationCanceledException>(() =>
            processor.AddWhiteSpaceAsync(sourcePath, Path.Combine(workspace.Path, "cancelled.png"),
                new ImageMargins(1), cancellationToken: cancelled.Token));
    }

    [Fact]
    public async Task TemplateCropAnchorAndJpegExportPreservePhysicalDpi()
    {
        using var workspace = new TemporaryWorkspace();
        var sourcePath = Path.Combine(workspace.Path, "color-stripes.png");
        using (var source = new SKBitmap(new SKImageInfo(4, 2, SKColorType.Rgba8888, SKAlphaType.Unpremul)))
        {
            for (var y = 0; y < 2; y++)
            for (var x = 0; x < 4; x++)
                source.SetPixel(x, y, x < 2 ? SKColors.Red : SKColors.Blue);
            using var image = SKImage.FromBitmap(source);
            using var encoded = image.Encode(SKEncodedImageFormat.Png, 100)!;
            await File.WriteAllBytesAsync(sourcePath, encoded.ToArray());
        }

        var processor = new ImageProcessingService();
        var cropTemplate = new PhotoTemplate("crop", "crop", 1, 2, 1, 1, 1, 2, 72);
        var leftPath = Path.Combine(workspace.Path, "left.png");
        var rightPath = Path.Combine(workspace.Path, "right.png");
        await processor.CreateTemplateAsync(
            [sourcePath], cropTemplate, leftPath, cropAnchor: PhotoCropAnchor.Left);
        await processor.CreateTemplateAsync(
            [sourcePath], cropTemplate, rightPath, cropAnchor: PhotoCropAnchor.Right);
        using var left = SKBitmap.Decode(leftPath)!;
        using var right = SKBitmap.Decode(rightPath)!;
        Assert.True(left.GetPixel(left.Width / 2, left.Height / 2).Red >
                    left.GetPixel(left.Width / 2, left.Height / 2).Blue);
        Assert.True(right.GetPixel(right.Width / 2, right.Height / 2).Blue >
                    right.GetPixel(right.Width / 2, right.Height / 2).Red);

        var jpegTemplate = new PhotoTemplate("jpeg", "jpeg", 3, 4, 1, 1, 3, 4, 300);
        var jpegPath = Path.Combine(workspace.Path, "print.jpg");
        await processor.CreateTemplateAsync(
            [sourcePath], jpegTemplate, jpegPath,
            outputFormat: ImageOutputFormat.Jpeg, jpegQuality: 92);

        using var jpeg = SKBitmap.Decode(jpegPath)!;
        Assert.Equal((354, 472), (jpeg.Width, jpeg.Height));
        var jpegBytes = await File.ReadAllBytesAsync(jpegPath);
        Assert.Equal((byte)0xFF, jpegBytes[2]);
        Assert.Equal((byte)0xE0, jpegBytes[3]);
        Assert.Equal((ushort)300, BinaryPrimitives.ReadUInt16BigEndian(jpegBytes.AsSpan(14, 2)));
        Assert.Equal((ushort)300, BinaryPrimitives.ReadUInt16BigEndian(jpegBytes.AsSpan(16, 2)));
    }

    [Fact]
    public async Task ImageToPdfWritesCompletePdfWithOnePagePerImage()
    {
        using var workspace = new TemporaryWorkspace();
        var sourcePath = Path.Combine(workspace.Path, "source.png");
        var outputPath = Path.Combine(workspace.Path, "images.pdf");
        await SaveImageAsync(sourcePath, 1, 1, new SKColor(255, 0, 0));

        await new ImagePdfWriter().WriteAsync([sourcePath, sourcePath], outputPath);

        var bytes = await File.ReadAllBytesAsync(outputPath);
        var pdfText = System.Text.Encoding.Latin1.GetString(bytes);
        Assert.StartsWith("%PDF-1.7", pdfText, StringComparison.Ordinal);
        Assert.Contains("/Count 2", pdfText, StringComparison.Ordinal);
        Assert.EndsWith("%%EOF", pdfText, StringComparison.Ordinal);
    }

    [Fact]
    public async Task ImageToPdfSupportsPaperOrientationOrderingAndJpegQuality()
    {
        using var workspace = new TemporaryWorkspace();
        var firstByName = Path.Combine(workspace.Path, "a-portrait.png");
        var secondByName = Path.Combine(workspace.Path, "z-landscape.png");
        var outputPath = Path.Combine(workspace.Path, "custom.pdf");
        await SaveImageAsync(firstByName, 2, 4, new SKColor(255, 0, 0));
        await SaveImageAsync(secondByName, 4, 2, new SKColor(0, 0, 255));
        var updates = new List<double>();
        var progress = new ImmediateProgress<double>(updates.Add);

        await new ImagePdfWriter().WriteAsync(
            [secondByName, firstByName],
            outputPath,
            new ImagePdfOptions(
                ImagePdfPaperSize.Letter,
                ImagePdfOrientation.Automatic,
                ImagePdfOrdering.NameAscending,
                ImagePdfQuality.High),
            progress);

        var pdfText = System.Text.Encoding.Latin1.GetString(await File.ReadAllBytesAsync(outputPath));
        var firstPage = pdfText.IndexOf("/MediaBox [0 0 612 792]", StringComparison.Ordinal);
        var secondPage = pdfText.IndexOf("/MediaBox [0 0 792 612]", StringComparison.Ordinal);
        Assert.True(firstPage >= 0 && secondPage > firstPage);
        Assert.Contains("/Filter /DCTDecode", pdfText, StringComparison.Ordinal);
        Assert.Equal(1, updates[^1]);
    }

    [Fact]
    public async Task ImageToPdfSupportsPhysicalPhotoPaperSize()
    {
        using var workspace = new TemporaryWorkspace();
        var imagePath = Path.Combine(workspace.Path, "photo-template.png");
        var outputPath = Path.Combine(workspace.Path, "photo-template.pdf");
        await SaveImageAsync(imagePath, 354, 531, new SKColor(30, 60, 90));

        await new ImagePdfWriter().WriteAsync(
            [imagePath], outputPath,
            new ImagePdfOptions(
                ImagePdfPaperSize.Photo10x15Cm,
                ImagePdfOrientation.Portrait,
                ImagePdfOrdering.Selection,
                ImagePdfQuality.Lossless));

        var pdfText = System.Text.Encoding.Latin1.GetString(await File.ReadAllBytesAsync(outputPath));
        Assert.Contains("/MediaBox [0 0 283.465 425.197]", pdfText, StringComparison.Ordinal);
    }

    [Fact]
    public async Task PdfRasterizerExportsEveryPageSequentially()
    {
        using var workspace = new TemporaryWorkspace();
        var firstImage = Path.Combine(workspace.Path, "first.png");
        var secondImage = Path.Combine(workspace.Path, "second.png");
        var pdfPath = Path.Combine(workspace.Path, "two-pages.pdf");
        var outputDirectory = Path.Combine(workspace.Path, "rendered");
        await SaveImageAsync(firstImage, 2, 2, new SKColor(255, 0, 0));
        await SaveImageAsync(secondImage, 2, 2, new SKColor(0, 0, 255));
        await new ImagePdfWriter().WriteAsync([firstImage, secondImage], pdfPath);

        var rendered = await new PdfRasterizer().RenderAllPagesAsync(pdfPath, outputDirectory, dpi: 72);

        Assert.Equal(2, rendered.Count);
        Assert.All(rendered, path => Assert.True(File.Exists(path)));
        using var firstPage = SKBitmap.Decode(rendered[0])!;
        using var secondPage = SKBitmap.Decode(rendered[1])!;
        Assert.Equal((595, 841), (firstPage.Width, firstPage.Height));
        Assert.Equal((595, 841), (secondPage.Width, secondPage.Height));
    }

    [Fact]
    public async Task PdfRasterizerExportsPageRangesAsJpegAndProtectsExistingFiles()
    {
        using var workspace = new TemporaryWorkspace();
        var imagePath = Path.Combine(workspace.Path, "source.png");
        var pdfPath = Path.Combine(workspace.Path, "two-pages.pdf");
        var outputDirectory = Path.Combine(workspace.Path, "exported");
        await SaveImageAsync(imagePath, 2, 2, new SKColor(10, 80, 190));
        await new ImagePdfWriter().WriteAsync([imagePath, imagePath], pdfPath);
        var progressValues = new List<double>();
        var progress = new ImmediateProgress<double>(progressValues.Add);

        var rendered = await new PdfRasterizer().RenderPageRangeAsync(
            pdfPath, 2, 2, outputDirectory, 72, ImageOutputFormat.Jpeg, 88, progress);

        var output = Assert.Single(rendered);
        Assert.EndsWith(".jpg", output, StringComparison.OrdinalIgnoreCase);
        var bytes = await File.ReadAllBytesAsync(output);
        Assert.Equal((byte)0xFF, bytes[0]);
        Assert.Equal((byte)0xD8, bytes[1]);
        Assert.Equal((ushort)72, BinaryPrimitives.ReadUInt16BigEndian(bytes.AsSpan(14, 2)));
        Assert.Equal(1, progressValues[^1]);
        using var bitmap = SKBitmap.Decode(output)!;
        Assert.Equal((595, 841), (bitmap.Width, bitmap.Height));

        await Assert.ThrowsAsync<ArgumentOutOfRangeException>(() =>
            new PdfRasterizer().RenderPageRangeAsync(
                pdfPath, 3, 4, outputDirectory, 72));
        var protectedPath = Path.Combine(outputDirectory, "already-there.png");
        await File.WriteAllBytesAsync(protectedPath, [9, 8, 7]);
        await Assert.ThrowsAsync<IOException>(() =>
            new PdfRasterizer().RenderPageAsync(pdfPath, 0, protectedPath, dpi: 72));
        Assert.Equal(new byte[] { 9, 8, 7 }, await File.ReadAllBytesAsync(protectedPath));
    }

    [Fact]
    public async Task CorruptImageIsRejectedWithoutCreatingAnOutput()
    {
        using var workspace = new TemporaryWorkspace();
        var inputPath = Path.Combine(workspace.Path, "corrupt.png");
        var outputPath = Path.Combine(workspace.Path, "result.png");
        await File.WriteAllBytesAsync(inputPath, [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0x00]);

        await Assert.ThrowsAsync<InvalidDataException>(() =>
            new ImageProcessingService().AdjustAsync(inputPath, outputPath, new ImageAdjustments()));

        Assert.False(File.Exists(outputPath));
    }

    [Fact]
    public async Task CorruptPdfIsRejectedWithoutCreatingRenderedPage()
    {
        using var workspace = new TemporaryWorkspace();
        var pdfPath = Path.Combine(workspace.Path, "corrupt.pdf");
        var outputPath = Path.Combine(workspace.Path, "page.png");
        await File.WriteAllTextAsync(pdfPath, "%PDF-1.7\nnot a valid PDF document\n");

        await Assert.ThrowsAnyAsync<Exception>(() =>
            new PdfRasterizer().RenderPageAsync(pdfPath, 0, outputPath, dpi: 72));

        Assert.False(File.Exists(outputPath));
    }

    [Fact]
    public async Task ThumbnailGeneratorCreatesAConsistentLocalPreview()
    {
        using var workspace = new TemporaryWorkspace();
        var sourcePath = Path.Combine(workspace.Path, "source.png");
        await SaveImageAsync(sourcePath, 640, 320, new SKColor(30, 60, 90));

        var paths = new AppPaths(Path.Combine(workspace.Path, "app"));
        paths.EnsureCreated();
        var outputPath = Path.Combine(paths.Thumbnails, "preview.jpg");
        var result = await new ImageThumbnailService(paths).CreateAsync(sourcePath, outputPath);

        Assert.Equal(outputPath, result);
        using var thumbnail = SKBitmap.Decode(result);
        Assert.NotNull(thumbnail);
        Assert.Equal((320, 240), (thumbnail.Width, thumbnail.Height));
    }

    [Fact]
    public async Task ThumbnailGeneratorRejectsSymlinkedCacheDirectory()
    {
        using var workspace = new TemporaryWorkspace();
        var sourcePath = Path.Combine(workspace.Path, "source.png");
        await SaveImageAsync(sourcePath, 4, 4, new SKColor(30, 60, 90));
        var paths = new AppPaths(Path.Combine(workspace.Path, "app"));
        paths.EnsureCreated();
        var outside = Path.Combine(workspace.Path, "outside");
        Directory.CreateDirectory(outside);
        Directory.Delete(paths.Thumbnails);
        try
        {
            Directory.CreateSymbolicLink(paths.Thumbnails, outside);
        }
        catch (Exception exception) when (
            exception is IOException or UnauthorizedAccessException or PlatformNotSupportedException)
        {
            return;
        }

        await Assert.ThrowsAsync<InvalidDataException>(() =>
            new ImageThumbnailService(paths).CreateAsync(
                sourcePath, Path.Combine(paths.Thumbnails, "preview.jpg")));
        Assert.Empty(Directory.EnumerateFileSystemEntries(outside));
    }

    private static async Task SaveImageAsync(string path, int width, int height, SKColor color)
    {
        using var bitmap = new SKBitmap(new SKImageInfo(width, height, SKColorType.Rgba8888, SKAlphaType.Unpremul));
        bitmap.Erase(color);
        using var image = SKImage.FromBitmap(bitmap);
        using var data = image.Encode(SKEncodedImageFormat.Png, 100)!;
        await File.WriteAllBytesAsync(path, data.ToArray());
    }

    private static async Task SaveBitmapAsync(string path, SKBitmap bitmap)
    {
        using var image = SKImage.FromBitmap(bitmap);
        using var data = image.Encode(SKEncodedImageFormat.Png, 100)!;
        await File.WriteAllBytesAsync(path, data.ToArray());
    }

    private sealed class ImmediateProgress<T>(Action<T> report) : IProgress<T>
    {
        public void Report(T value) => report(value);
    }

    private sealed class TemporaryWorkspace : IDisposable
    {
        public string Path { get; } = System.IO.Path.Combine(
            System.IO.Path.GetTempPath(), "AlMaktaba.Tests", Guid.NewGuid().ToString("N"));

        public TemporaryWorkspace() => Directory.CreateDirectory(Path);

        public void Dispose()
        {
            try { Directory.Delete(Path, recursive: true); }
            catch (DirectoryNotFoundException) { }
        }
    }
}
