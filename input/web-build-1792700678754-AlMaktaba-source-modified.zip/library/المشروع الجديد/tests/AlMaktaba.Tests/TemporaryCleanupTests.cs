using AlMaktaba.Core;
using AlMaktaba.Infrastructure;
using Microsoft.Extensions.Logging.Abstractions;

namespace AlMaktaba.Tests;

public sealed class TemporaryCleanupTests
{
    [Fact]
    public async Task CleanupRemovesOldTempButKeepsRecentAndPendingDeleteFiles()
    {
        using var workspace = new TemporaryWorkspace();
        var paths = new AppPaths(workspace.Path);
        paths.EnsureCreated();
        var oldDirectory = Path.Combine(paths.Temp, "old-preview");
        var recentFile = Path.Combine(paths.Temp, "recent-preview.png");
        var pendingDirectory = Path.Combine(paths.Temp, "pending-delete");
        Directory.CreateDirectory(oldDirectory);
        Directory.CreateDirectory(pendingDirectory);
        var oldFile = Path.Combine(oldDirectory, "preview.png");
        var pendingFile = Path.Combine(pendingDirectory, "recovery.bin");
        await File.WriteAllTextAsync(oldFile, "old data");
        await File.WriteAllTextAsync(recentFile, "recent data");
        await File.WriteAllTextAsync(pendingFile, "retain until delete recovery is safe");
        var old = DateTime.UtcNow.AddDays(-3);
        File.SetLastWriteTimeUtc(oldFile, old);
        Directory.SetLastWriteTimeUtc(oldDirectory, old);
        File.SetLastWriteTimeUtc(recentFile, DateTime.UtcNow);

        var summary = await new TemporaryFilesCleanupService(
            paths, NullLogger<TemporaryFilesCleanupService>.Instance)
            .CleanStaleAsync(TimeSpan.FromHours(24));

        Assert.Equal(1, summary.RemovedItems);
        Assert.False(Directory.Exists(oldDirectory));
        Assert.True(File.Exists(recentFile));
        Assert.True(File.Exists(pendingFile));
    }

    [Fact]
    public async Task CleanupDoesNotFollowOrRemoveSymlinkedTempDirectories()
    {
        using var workspace = new TemporaryWorkspace();
        var paths = new AppPaths(workspace.Path);
        paths.EnsureCreated();
        var outsideDirectory = Path.Combine(workspace.Path, "outside");
        Directory.CreateDirectory(outsideDirectory);
        var outsideFile = Path.Combine(outsideDirectory, "important.bin");
        await File.WriteAllTextAsync(outsideFile, "keep outside the temp tree");
        var old = DateTime.UtcNow.AddDays(-3);
        File.SetLastWriteTimeUtc(outsideFile, old);
        Directory.SetLastWriteTimeUtc(outsideDirectory, old);
        var linkedDirectory = Path.Combine(paths.Temp, "linked-work");
        try
        {
            Directory.CreateSymbolicLink(linkedDirectory, outsideDirectory);
        }
        catch (Exception exception) when (
            exception is IOException or UnauthorizedAccessException or PlatformNotSupportedException)
        {
            return;
        }

        var summary = await new TemporaryFilesCleanupService(
            paths, NullLogger<TemporaryFilesCleanupService>.Instance)
            .CleanStaleAsync(TimeSpan.FromHours(24));

        Assert.Equal(0, summary.RemovedItems);
        Assert.True(Directory.Exists(linkedDirectory));
        Assert.Equal("keep outside the temp tree", await File.ReadAllTextAsync(outsideFile));
    }

    private sealed class TemporaryWorkspace : IDisposable
    {
        public string Path { get; } = System.IO.Path.Combine(
            System.IO.Path.GetTempPath(), "AlMaktaba.Tests", Guid.NewGuid().ToString("N"));

        public TemporaryWorkspace() => Directory.CreateDirectory(Path);

        public void Dispose()
        {
            try { Directory.Delete(Path, recursive: true); }
            catch (DirectoryNotFoundException) { }
        }
    }
}
