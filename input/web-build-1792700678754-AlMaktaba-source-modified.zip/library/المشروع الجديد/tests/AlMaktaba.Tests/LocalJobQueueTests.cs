using System.Collections.Concurrent;
using AlMaktaba.Core;
using AlMaktaba.Infrastructure;
using Microsoft.Extensions.Logging.Abstractions;

namespace AlMaktaba.Tests;

public sealed class LocalJobQueueTests
{
    [Fact]
    public async Task RunAsyncReturnsOutputAndRetainsProgressAndFinalState()
    {
        using var workspace = new TemporaryWorkspace();
        var repository = await CreateRepositoryAsync(workspace.Path);
        await using var queue = new LocalJobQueue(repository, NullLogger<LocalJobQueue>.Instance);
        await queue.InitializeAsync();
        var observed = new ConcurrentQueue<ProcessingJob>();
        queue.JobChanged += (_, job) => observed.Enqueue(job);

        var output = await queue.RunAsync("تحويل", "input.pdf", async (progress, token) =>
        {
            progress.Report(0.4);
            await Task.Delay(10, token);
            return "output.png";
        });

        Assert.Equal("output.png", output);
        var final = Assert.Single(queue.Snapshot());
        Assert.Equal(JobState.Completed, final.State);
        Assert.Equal(1, final.Progress);
        Assert.Equal("output.png", final.OutputPath);
        Assert.Contains(observed, job => job.State == JobState.Queued);
        Assert.Contains(observed, job => job.State == JobState.Processing);
        Assert.Contains(observed, job => job.Progress == 0.4);
        Assert.Contains(observed, job => job.State == JobState.Completed);
    }

    [Fact]
    public async Task RunAsyncPropagatesFailureAndStoresSafeFailureState()
    {
        using var workspace = new TemporaryWorkspace();
        var repository = await CreateRepositoryAsync(workspace.Path);
        await using var queue = new LocalJobQueue(repository, NullLogger<LocalJobQueue>.Instance);
        await queue.InitializeAsync();

        await Assert.ThrowsAsync<InvalidDataException>(() => queue.RunAsync(
            "تحويل", "input.pdf",
            (_, _) => throw new InvalidDataException("bad input")));

        var final = Assert.Single(queue.Snapshot());
        Assert.Equal(JobState.Failed, final.State);
        Assert.Equal("bad input", final.Error);
    }

    [Fact]
    public async Task CompletedJobHistoryIsRestoredFromSqliteOnNextQueueInitialization()
    {
        using var workspace = new TemporaryWorkspace();
        var repository = await CreateRepositoryAsync(workspace.Path);

        await using (var firstQueue = new LocalJobQueue(repository, NullLogger<LocalJobQueue>.Instance))
        {
            await firstQueue.InitializeAsync();
            await firstQueue.RunAsync("تحويل PDF", "input.pdf",
                (_, _) => Task.FromResult("output.png"));
        }

        await using var nextQueue = new LocalJobQueue(repository, NullLogger<LocalJobQueue>.Instance);
        await nextQueue.InitializeAsync();

        var restored = Assert.Single(nextQueue.Snapshot());
        Assert.Equal("تحويل PDF", restored.Name);
        Assert.Equal(JobState.Completed, restored.State);
        Assert.Equal("output.png", restored.OutputPath);
        Assert.Equal(1, restored.Progress);
    }

    [Fact]
    public async Task JobsLeftQueuedOrProcessingAreMarkedInterruptedAtStartup()
    {
        using var workspace = new TemporaryWorkspace();
        var repository = await CreateRepositoryAsync(workspace.Path);
        var queued = CreateJob("queued", JobState.Queued);
        var processing = CreateJob("processing", JobState.Processing);
        await repository.SaveJobAsync(queued);
        await repository.SaveJobAsync(processing);

        await using var queue = new LocalJobQueue(repository, NullLogger<LocalJobQueue>.Instance);
        await queue.InitializeAsync();

        Assert.All(queue.Snapshot(), job =>
        {
            Assert.Equal(JobState.Failed, job.State);
            Assert.Contains("لم يتم استئنافها", job.Error);
            Assert.NotNull(job.CompletedAt);
        });
    }

    private static async Task<SqliteFileRepository> CreateRepositoryAsync(string root)
    {
        var paths = new AppPaths(root);
        var repository = new SqliteFileRepository(paths);
        await repository.InitializeAsync();
        return repository;
    }

    private static ProcessingJob CreateJob(string id, JobState state) =>
        new(id, id, $"{id}.pdf", null, state, 0.5, null, DateTimeOffset.UtcNow, null);

    private sealed class TemporaryWorkspace : IDisposable
    {
        public string Path { get; } =
            System.IO.Path.Combine(System.IO.Path.GetTempPath(), "almaktaba-jobs-" + Guid.NewGuid().ToString("N"));

        public TemporaryWorkspace() => Directory.CreateDirectory(Path);

        public void Dispose()
        {
            try { Directory.Delete(Path, recursive: true); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }
    }
}
