using AlMaktaba.Core;
using AlMaktaba.Infrastructure;
using Microsoft.Data.Sqlite;

namespace AlMaktaba.Tests;

public sealed class DatabaseMigrationTests
{
    [Fact]
    public async Task FreshDatabaseMigratesOnceAndRemainsVersioned()
    {
        using var workspace = new TemporaryWorkspace();
        var paths = new AppPaths(workspace.Path);
        var repository = new SqliteFileRepository(paths);

        await repository.InitializeAsync();
        await repository.InitializeAsync();

        await using var connection = new SqliteConnection(
            new SqliteConnectionStringBuilder { DataSource = paths.Database, Mode = SqliteOpenMode.ReadOnly }.ToString());
        await connection.OpenAsync();
        await using var command = connection.CreateCommand();
        command.CommandText = "PRAGMA user_version;";
        Assert.Equal(2L, (long)(await command.ExecuteScalarAsync())!);
    }

    [Fact]
    public async Task VersionOneDatabaseUpgradesCategoryAndRecentFieldsWithoutLosingFiles()
    {
        using var workspace = new TemporaryWorkspace();
        var paths = new AppPaths(workspace.Path);
        paths.EnsureCreated();
        await using (var connection = new SqliteConnection(
                         new SqliteConnectionStringBuilder
                         {
                             DataSource = paths.Database,
                             Mode = SqliteOpenMode.ReadWriteCreate
                         }.ToString()))
        {
            await connection.OpenAsync();
            await using var command = connection.CreateCommand();
            command.CommandText = """
                CREATE TABLE files (
                    id TEXT PRIMARY KEY,
                    original_name TEXT NOT NULL,
                    stored_name TEXT NOT NULL,
                    relative_path TEXT NOT NULL UNIQUE,
                    mime_type TEXT NOT NULL,
                    file_type TEXT NOT NULL,
                    size_bytes INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    modified_at TEXT NOT NULL,
                    source_operation TEXT NULL,
                    thumbnail_path TEXT NULL,
                    checksum TEXT NULL,
                    is_favorite INTEGER NOT NULL DEFAULT 0
                );
                CREATE TABLE operations (
                    id TEXT PRIMARY KEY,
                    operation TEXT NOT NULL,
                    input_path TEXT NULL,
                    output_path TEXT NULL,
                    status TEXT NOT NULL,
                    error_message TEXT NULL,
                    created_at TEXT NOT NULL,
                    completed_at TEXT NULL
                );
                INSERT INTO files (id, original_name, stored_name, relative_path, mime_type, file_type,
                    size_bytes, created_at, modified_at, is_favorite)
                VALUES ('old-file', 'قديم.png', 'old.png', 'images/old.png', 'image/png', 'Image',
                    12, '2026-01-01T00:00:00.0000000+00:00', '2026-01-01T00:00:00.0000000+00:00', 1);
                PRAGMA user_version = 1;
                """;
            await command.ExecuteNonQueryAsync();
        }

        var repository = new SqliteFileRepository(paths);
        await repository.InitializeAsync();

        var file = Assert.Single(await repository.SearchAsync(new LibraryQuery(FavoritesOnly: true)));
        Assert.Equal("old-file", file.Id);
        Assert.Equal("", file.Category);
        Assert.Null(file.LastOpenedAt);
        Assert.Empty(await repository.GetRecentOperationsAsync());
    }

    [Fact]
    public async Task NewerDatabaseSchemaIsRejectedWithoutDowngrade()
    {
        using var workspace = new TemporaryWorkspace();
        var paths = new AppPaths(workspace.Path);
        paths.EnsureCreated();
        await using (var connection = new SqliteConnection(
                         new SqliteConnectionStringBuilder
                         {
                             DataSource = paths.Database,
                             Mode = SqliteOpenMode.ReadWriteCreate
                         }.ToString()))
        {
            await connection.OpenAsync();
            await using var command = connection.CreateCommand();
            command.CommandText = "PRAGMA user_version = 77;";
            await command.ExecuteNonQueryAsync();
        }

        await Assert.ThrowsAsync<InvalidOperationException>(() =>
            new SqliteFileRepository(paths).InitializeAsync());

        await using var verify = new SqliteConnection(
            new SqliteConnectionStringBuilder { DataSource = paths.Database, Mode = SqliteOpenMode.ReadOnly }.ToString());
        await verify.OpenAsync();
        await using var version = verify.CreateCommand();
        version.CommandText = "PRAGMA user_version;";
        Assert.Equal(77L, (long)(await version.ExecuteScalarAsync())!);
    }

    private sealed class TemporaryWorkspace : IDisposable
    {
        public string Path { get; } = System.IO.Path.Combine(
            System.IO.Path.GetTempPath(), "AlMaktaba.Tests", Guid.NewGuid().ToString("N"));

        public TemporaryWorkspace() => Directory.CreateDirectory(Path);

        public void Dispose()
        {
            SqliteConnection.ClearAllPools();
            try { Directory.Delete(Path, recursive: true); }
            catch (DirectoryNotFoundException) { }
        }
    }
}
