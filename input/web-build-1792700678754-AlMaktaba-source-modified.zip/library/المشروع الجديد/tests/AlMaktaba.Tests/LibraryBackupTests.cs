using System.IO.Compression;
using AlMaktaba.Core;
using AlMaktaba.Infrastructure;
using Microsoft.Extensions.Logging.Abstractions;

namespace AlMaktaba.Tests;

public sealed class LibraryBackupTests
{
    private const string OnePixelPng =
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/dN8AAAAASUVORK5CYII=";

    [Fact]
    public async Task BackupRoundTripRestoresDatabaseAndLibraryFiles()
    {
        using var workspace = new TemporaryWorkspace();
        var sourcePaths = await CreateLibraryWithImageAsync(Path.Combine(workspace.Path, "source"));
        var backupPath = Path.Combine(workspace.Path, "library.zip");
        await new LibraryBackupService(sourcePaths.Paths).ExportAsync(backupPath);

        var restoredPaths = new AppPaths(Path.Combine(workspace.Path, "restored"));
        restoredPaths.EnsureCreated();
        var restoredRepository = new SqliteFileRepository(restoredPaths);
        await restoredRepository.InitializeAsync();
        await new LibraryBackupService(restoredPaths).ImportAsync(backupPath);

        var restored = Assert.Single(await restoredRepository.SearchAsync(new LibraryQuery()));
        Assert.Equal(sourcePaths.File.Id, restored.Id);
        Assert.Equal(sourcePaths.File.Checksum, restored.Checksum);
        Assert.True(File.Exists(Path.Combine(restoredPaths.Library, restored.RelativePath)));
    }

    [Fact]
    public async Task TruncatedBackupLeavesExistingDatabaseAndLibraryUntouched()
    {
        using var workspace = new TemporaryWorkspace();
        var source = await CreateLibraryWithImageAsync(Path.Combine(workspace.Path, "source"));
        var completeBackup = Path.Combine(workspace.Path, "complete.zip");
        var truncatedBackup = Path.Combine(workspace.Path, "truncated.zip");
        await new LibraryBackupService(source.Paths).ExportAsync(completeBackup);
        var archiveBytes = await File.ReadAllBytesAsync(completeBackup);
        await File.WriteAllBytesAsync(truncatedBackup, archiveBytes[..(archiveBytes.Length / 2)]);

        var destination = await CreateLibraryWithImageAsync(Path.Combine(workspace.Path, "destination"));
        await Assert.ThrowsAnyAsync<Exception>(() =>
            new LibraryBackupService(destination.Paths).ImportAsync(truncatedBackup));

        var retained = Assert.Single(await destination.Repository.SearchAsync(new LibraryQuery()));
        Assert.Equal(destination.File.Id, retained.Id);
        Assert.True(File.Exists(Path.Combine(destination.Paths.Library, retained.RelativePath)));
        Assert.Empty(Directory.EnumerateFileSystemEntries(destination.Paths.Temp));
    }

    [Fact]
    public async Task BackupExcludesModelsAndConfigFiles()
    {
        using var workspace = new TemporaryWorkspace();
        var source = await CreateLibraryWithImageAsync(Path.Combine(workspace.Path, "source"));
        var modelPath = Path.Combine(source.Paths.Models, "background_removal", "weights.onnx");
        var credentialPath = Path.Combine(source.Paths.Config, "credentials.json");
        await File.WriteAllTextAsync(modelPath, "model weights");
        await File.WriteAllTextAsync(credentialPath, "{\"token\":\"must not be backed up\"}");
        var backupPath = Path.Combine(workspace.Path, "backup.zip");

        await new LibraryBackupService(source.Paths).ExportAsync(backupPath);

        using var archive = ZipFile.OpenRead(backupPath);
        Assert.DoesNotContain(archive.Entries, entry =>
            entry.FullName.StartsWith("models/", StringComparison.OrdinalIgnoreCase) ||
            entry.FullName.StartsWith("config/", StringComparison.OrdinalIgnoreCase));
        using var manifestReader = new StreamReader(archive.GetEntry("backup.json")!.Open());
        var manifest = await manifestReader.ReadToEndAsync();
        Assert.Contains("\"credentials\"", manifest, StringComparison.Ordinal);
        Assert.Contains("\"models\"", manifest, StringComparison.Ordinal);
    }

    [Fact]
    public async Task ExportRejectsBackupDestinationInsideLibrary()
    {
        using var workspace = new TemporaryWorkspace();
        var source = await CreateLibraryWithImageAsync(Path.Combine(workspace.Path, "source"));
        var backupPath = Path.Combine(source.Paths.Library, "backup.zip");

        await Assert.ThrowsAsync<InvalidDataException>(() =>
            new LibraryBackupService(source.Paths).ExportAsync(backupPath));

        Assert.False(File.Exists(backupPath));
    }

    [Fact]
    public async Task ExportRejectsSymlinkedLibraryDirectoryWithoutLeavingPartialArchive()
    {
        using var workspace = new TemporaryWorkspace();
        var source = await CreateLibraryWithImageAsync(Path.Combine(workspace.Path, "source"));
        var outsideDirectory = Path.Combine(workspace.Path, "outside");
        Directory.CreateDirectory(outsideDirectory);
        var file = Assert.Single(Directory.EnumerateFiles(source.Paths.Images));
        File.Move(file, Path.Combine(outsideDirectory, Path.GetFileName(file)));
        Directory.Delete(source.Paths.Images);
        try
        {
            Directory.CreateSymbolicLink(source.Paths.Images, outsideDirectory);
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or PlatformNotSupportedException)
        {
            return;
        }

        var backupPath = Path.Combine(workspace.Path, "backup.zip");
        await Assert.ThrowsAsync<InvalidDataException>(() =>
            new LibraryBackupService(source.Paths).ExportAsync(backupPath));

        Assert.False(File.Exists(backupPath));
    }

    [Fact]
    public async Task ConflictingLibraryFilePreventsAnyRestoreChanges()
    {
        using var workspace = new TemporaryWorkspace();
        var source = await CreateLibraryWithImageAsync(Path.Combine(workspace.Path, "source"));
        var backupPath = Path.Combine(workspace.Path, "library.zip");
        await new LibraryBackupService(source.Paths).ExportAsync(backupPath);

        var destinationPaths = new AppPaths(Path.Combine(workspace.Path, "destination"));
        destinationPaths.EnsureCreated();
        var destinationRepository = new SqliteFileRepository(destinationPaths);
        await destinationRepository.InitializeAsync();
        var conflictingFile = Path.Combine(destinationPaths.Library, source.File.RelativePath);
        Directory.CreateDirectory(Path.GetDirectoryName(conflictingFile)!);
        await File.WriteAllTextAsync(conflictingFile, "different content");

        await Assert.ThrowsAsync<InvalidDataException>(() =>
            new LibraryBackupService(destinationPaths).ImportAsync(backupPath));

        Assert.Empty(await destinationRepository.SearchAsync(new LibraryQuery()));
        Assert.Equal("different content", await File.ReadAllTextAsync(conflictingFile));
    }

    [Fact]
    public async Task ImportRejectsZipSlipEntriesBeforeWritingOutsideStaging()
    {
        using var workspace = new TemporaryWorkspace();
        var paths = new AppPaths(Path.Combine(workspace.Path, "app"));
        var zipPath = Path.Combine(workspace.Path, "malicious.zip");
        await using (var file = new FileStream(zipPath, FileMode.CreateNew))
        using (var archive = new ZipArchive(file, ZipArchiveMode.Create))
        {
            var entry = archive.CreateEntry("../../escaped.txt");
            await using var output = entry.Open();
            await output.WriteAsync("must not escape"u8.ToArray());
        }

        await Assert.ThrowsAsync<InvalidDataException>(() =>
            new LibraryBackupService(paths).ImportAsync(zipPath));
        Assert.False(File.Exists(Path.Combine(workspace.Path, "escaped.txt")));
        Assert.False(File.Exists(paths.Database));
    }

    [Fact]
    public async Task ImportRejectsDuplicateArchivePaths()
    {
        using var workspace = new TemporaryWorkspace();
        var paths = new AppPaths(Path.Combine(workspace.Path, "app"));
        var zipPath = Path.Combine(workspace.Path, "duplicate.zip");
        await using (var file = new FileStream(zipPath, FileMode.CreateNew))
        using (var archive = new ZipArchive(file, ZipArchiveMode.Create))
        {
            foreach (var _ in Enumerable.Range(0, 2))
            {
                var entry = archive.CreateEntry("backup.json");
                await using var output = entry.Open();
                await output.WriteAsync("{}"u8.ToArray());
            }
        }

        await Assert.ThrowsAsync<InvalidDataException>(() =>
            new LibraryBackupService(paths).ImportAsync(zipPath));
        Assert.False(File.Exists(paths.Database));
    }

    [Fact]
    public async Task ImportRejectsBackupMissingAReferencedLibraryFileWithoutChangingDatabase()
    {
        using var workspace = new TemporaryWorkspace();
        var source = await CreateLibraryWithImageAsync(Path.Combine(workspace.Path, "source"));
        var completeBackup = Path.Combine(workspace.Path, "complete.zip");
        var incompleteBackup = Path.Combine(workspace.Path, "incomplete.zip");
        await new LibraryBackupService(source.Paths).ExportAsync(completeBackup);

        using (var input = ZipFile.OpenRead(completeBackup))
        await using (var outputFile = new FileStream(incompleteBackup, FileMode.CreateNew))
        using (var output = new ZipArchive(outputFile, ZipArchiveMode.Create))
        {
            foreach (var sourceEntry in input.Entries.Where(entry =>
                         !entry.FullName.StartsWith("library/", StringComparison.OrdinalIgnoreCase)))
            {
                var targetEntry = output.CreateEntry(sourceEntry.FullName, CompressionLevel.Optimal);
                await using var sourceStream = sourceEntry.Open();
                await using var targetStream = targetEntry.Open();
                await sourceStream.CopyToAsync(targetStream);
            }
        }

        var destinationPaths = new AppPaths(Path.Combine(workspace.Path, "destination"));
        destinationPaths.EnsureCreated();
        var destinationRepository = new SqliteFileRepository(destinationPaths);
        await destinationRepository.InitializeAsync();

        await Assert.ThrowsAsync<InvalidDataException>(() =>
            new LibraryBackupService(destinationPaths).ImportAsync(incompleteBackup));

        Assert.Empty(await destinationRepository.SearchAsync(new LibraryQuery()));
        Assert.Empty(Directory.EnumerateFiles(destinationPaths.Library, "*", SearchOption.AllDirectories));
    }

    [Fact]
    public async Task InvalidBackupDatabaseLeavesExistingDatabaseAndLibraryUntouched()
    {
        using var workspace = new TemporaryWorkspace();
        var source = await CreateLibraryWithImageAsync(Path.Combine(workspace.Path, "source"));
        var completeBackup = Path.Combine(workspace.Path, "complete.zip");
        var invalidBackup = Path.Combine(workspace.Path, "invalid-database.zip");
        await new LibraryBackupService(source.Paths).ExportAsync(completeBackup);

        using (var input = ZipFile.OpenRead(completeBackup))
        await using (var outputStream = new FileStream(invalidBackup, FileMode.CreateNew))
        using (var output = new ZipArchive(outputStream, ZipArchiveMode.Create))
        {
            foreach (var sourceEntry in input.Entries)
            {
                var targetEntry = output.CreateEntry(sourceEntry.FullName, CompressionLevel.Optimal);
                await using var target = targetEntry.Open();
                if (sourceEntry.FullName.Equals("database/app.db", StringComparison.OrdinalIgnoreCase))
                {
                    await target.WriteAsync("not a SQLite database"u8.ToArray());
                    continue;
                }

                await using var sourceStream = sourceEntry.Open();
                await sourceStream.CopyToAsync(target);
            }
        }

        var destination = await CreateLibraryWithImageAsync(Path.Combine(workspace.Path, "destination"));
        await Assert.ThrowsAsync<InvalidDataException>(() =>
            new LibraryBackupService(destination.Paths).ImportAsync(invalidBackup));

        var retained = Assert.Single(await destination.Repository.SearchAsync(new LibraryQuery()));
        Assert.Equal(destination.File.Id, retained.Id);
        Assert.True(File.Exists(Path.Combine(destination.Paths.Library, retained.RelativePath)));
    }

    [Fact]
    public async Task CancellationAfterDatabaseReplacementRollsBackDatabaseAndCopiedFiles()
    {
        using var workspace = new TemporaryWorkspace();
        var source = await CreateLibraryWithImageAsync(Path.Combine(workspace.Path, "source"));
        var backupPath = Path.Combine(workspace.Path, "library.zip");
        await new LibraryBackupService(source.Paths).ExportAsync(backupPath);

        var destination = await CreateLibraryWithImageAsync(Path.Combine(workspace.Path, "destination"));
        using var cancellation = new CancellationTokenSource();
        var progress = new InlineProgress<BackupRestoreProgress>(update =>
        {
            if (update.Stage == BackupRestoreStage.DatabaseReplaced)
                cancellation.Cancel();
        });

        await Assert.ThrowsAnyAsync<OperationCanceledException>(() =>
            new LibraryBackupService(destination.Paths).ImportAsync(
                backupPath, cancellation.Token, progress));

        var retained = Assert.Single(await destination.Repository.SearchAsync(new LibraryQuery()));
        Assert.Equal(destination.File.Id, retained.Id);
        Assert.True(File.Exists(Path.Combine(destination.Paths.Library, retained.RelativePath)));
        Assert.False(File.Exists(Path.Combine(destination.Paths.Library, source.File.RelativePath)));
        Assert.Empty(Directory.EnumerateFileSystemEntries(destination.Paths.Temp));
    }

    [Fact]
    public async Task ImportRejectsSymlinkedLibraryDirectoryBeforeCopyingFiles()
    {
        using var workspace = new TemporaryWorkspace();
        var source = await CreateLibraryWithImageAsync(Path.Combine(workspace.Path, "source"));
        var backupPath = Path.Combine(workspace.Path, "library.zip");
        await new LibraryBackupService(source.Paths).ExportAsync(backupPath);

        var destinationPaths = new AppPaths(Path.Combine(workspace.Path, "destination"));
        destinationPaths.EnsureCreated();
        var repository = new SqliteFileRepository(destinationPaths);
        await repository.InitializeAsync();

        var outsideDirectory = Path.Combine(workspace.Path, "outside");
        Directory.CreateDirectory(outsideDirectory);
        Directory.Delete(destinationPaths.Images);
        try
        {
            Directory.CreateSymbolicLink(destinationPaths.Images, outsideDirectory);
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or PlatformNotSupportedException)
        {
            return;
        }

        await Assert.ThrowsAsync<InvalidDataException>(() =>
            new LibraryBackupService(destinationPaths).ImportAsync(backupPath));

        Assert.Empty(await repository.SearchAsync(new LibraryQuery()));
        Assert.Empty(Directory.EnumerateFileSystemEntries(outsideDirectory));
    }

    private static async Task<(AppPaths Paths, SqliteFileRepository Repository, LibraryFile File)> CreateLibraryWithImageAsync(string root)
    {
        var paths = new AppPaths(root);
        paths.EnsureCreated();
        var repository = new SqliteFileRepository(paths);
        await repository.InitializeAsync();
        var library = new LocalLibraryService(paths, repository, NullLogger<LocalLibraryService>.Instance);
        var sourcePath = Path.Combine(root, "photo.png");
        await File.WriteAllBytesAsync(sourcePath, Convert.FromBase64String(OnePixelPng));
        var file = await library.ImportAsync(sourcePath);
        return (paths, repository, file);
    }

    private sealed class InlineProgress<T>(Action<T> report) : IProgress<T>
    {
        public void Report(T value) => report(value);
    }

    private sealed class TemporaryWorkspace : IDisposable
    {
        public string Path { get; } = System.IO.Path.Combine(
            System.IO.Path.GetTempPath(), "AlMaktaba.Tests", Guid.NewGuid().ToString("N"));

        public TemporaryWorkspace() => Directory.CreateDirectory(Path);

        public void Dispose()
        {
            try { Directory.Delete(Path, recursive: true); }
            catch (DirectoryNotFoundException) { }
        }
    }
}
