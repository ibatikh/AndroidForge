using System.IO.Compression;
using System.Text;
using AlMaktaba.Processing;

namespace AlMaktaba.Tests;

public sealed class DocumentProcessingTests
{
    [Fact]
    public async Task LibreOfficeTimeoutStopsTheProcessAndDoesNotLeaveAnOutput()
    {
        if (!OperatingSystem.IsLinux())
            return;

        using var workspace = new TemporaryWorkspace();
        var input = CreateDocx(workspace.Path);
        var outputDirectory = Directory.CreateDirectory(Path.Combine(workspace.Path, "output")).FullName;
        var executable = CreateConverter(workspace.Path, "sleep 10\n");
        var service = new DocumentProcessingService(executable);

        var error = await Assert.ThrowsAsync<TimeoutException>(() =>
            service.ConvertDocxToPdfAsync(
                input, outputDirectory, TimeSpan.FromMilliseconds(250)));

        Assert.Contains("انتهت مهلة", error.Message);
        Assert.Empty(Directory.EnumerateFiles(outputDirectory));
    }

    [Fact]
    public async Task UserCancellationStopsLibreOfficeAndDoesNotLeaveAnOutput()
    {
        if (!OperatingSystem.IsLinux())
            return;

        using var workspace = new TemporaryWorkspace();
        var input = CreateDocx(workspace.Path);
        var outputDirectory = Directory.CreateDirectory(Path.Combine(workspace.Path, "output")).FullName;
        var executable = CreateConverter(workspace.Path, "sleep 10\n");
        using var cancellation = new CancellationTokenSource(TimeSpan.FromMilliseconds(250));
        var service = new DocumentProcessingService(executable);

        await Assert.ThrowsAnyAsync<OperationCanceledException>(() =>
            service.ConvertDocxToPdfAsync(
                input, outputDirectory, cancellationToken: cancellation.Token));

        Assert.Empty(Directory.EnumerateFiles(outputDirectory));
    }

    [Fact]
    public async Task LibreOfficeFailureIncludesBoundedUsefulDiagnostics()
    {
        if (!OperatingSystem.IsLinux())
            return;

        using var workspace = new TemporaryWorkspace();
        var input = CreateDocx(workspace.Path);
        var outputDirectory = Directory.CreateDirectory(Path.Combine(workspace.Path, "output")).FullName;
        var executable = CreateConverter(workspace.Path, "echo 'conversion failed locally' >&2\nexit 9\n");
        var service = new DocumentProcessingService(executable);

        var error = await Assert.ThrowsAsync<InvalidOperationException>(() =>
            service.ConvertDocxToPdfAsync(input, outputDirectory));

        Assert.Contains("conversion failed locally", error.Message);
        Assert.DoesNotContain("stack trace", error.Message, StringComparison.OrdinalIgnoreCase);
        Assert.Empty(Directory.EnumerateFiles(outputDirectory));
    }

    private static string CreateConverter(string directory, string command)
    {
        var path = Path.Combine(directory, "fake-soffice.sh");
        File.WriteAllText(path, "#!/bin/sh\n" + command, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
        if (OperatingSystem.IsLinux())
        {
            File.SetUnixFileMode(path,
                UnixFileMode.UserRead | UnixFileMode.UserWrite | UnixFileMode.UserExecute);
        }
        return path;
    }

    private static string CreateDocx(string directory)
    {
        var path = Path.Combine(directory, "sample.docx");
        using var file = new FileStream(path, FileMode.CreateNew, FileAccess.ReadWrite, FileShare.None);
        using var archive = new ZipArchive(file, ZipArchiveMode.Create);
        AddEntry(archive, "[Content_Types].xml", """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
              <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
              <Default Extension="xml" ContentType="application/xml"/>
              <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
            </Types>
            """);
        AddEntry(archive, "_rels/.rels", """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
              <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
            </Relationships>
            """);
        AddEntry(archive, "word/document.xml", """
            <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
            <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
              <w:body><w:p><w:r><w:t>Sample document</w:t></w:r></w:p><w:sectPr/></w:body>
            </w:document>
            """);
        return path;
    }

    private static void AddEntry(ZipArchive archive, string name, string content)
    {
        var entry = archive.CreateEntry(name);
        using var stream = entry.Open();
        using var writer = new StreamWriter(stream, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
        writer.Write(content);
    }

    private sealed class TemporaryWorkspace : IDisposable
    {
        public string Path { get; } =
            System.IO.Path.Combine(System.IO.Path.GetTempPath(), "almaktaba-docx-" + Guid.NewGuid().ToString("N"));

        public TemporaryWorkspace() => Directory.CreateDirectory(Path);

        public void Dispose()
        {
            try { Directory.Delete(Path, recursive: true); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }
    }
}
