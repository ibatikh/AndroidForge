namespace AlMaktaba.Core;

public sealed class AppPaths
{
    public string Root { get; }
    public string Database => Path.Combine(Root, "database", "app.db");
    public string Library => Path.Combine(Root, "library");
    public string Images => Path.Combine(Library, "images");
    public string Documents => Path.Combine(Library, "documents");
    public string Pdf => Path.Combine(Library, "pdf");
    public string Templates => Path.Combine(Library, "templates");
    public string Generated => Path.Combine(Library, "generated");
    public string Temp => Path.Combine(Root, "temp");
    public string Models => Path.Combine(Root, "models");
    public string Backups => Path.Combine(Root, "backups");
    public string Logs => Path.Combine(Root, "logs");
    public string Cache => Path.Combine(Root, "cache");
    public string Thumbnails => Path.Combine(Cache, "thumbnails");
    public string Config => Path.Combine(Root, "config");

    public AppPaths(string? root = null)
    {
        Root = root ?? Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "AlMaktaba");
    }

    public void EnsureCreated()
    {
        foreach (var directory in new[]
        {
            Path.GetDirectoryName(Database)!, Images, Documents, Pdf, Templates,
            Generated, Temp, Path.Combine(Models, "background_removal"),
            Path.Combine(Models, "enhancement"), Path.Combine(Models, "optional_ai"),
            Backups, Logs, Cache, Thumbnails, Config
        })
        {
            Directory.CreateDirectory(directory);
        }
    }
}
