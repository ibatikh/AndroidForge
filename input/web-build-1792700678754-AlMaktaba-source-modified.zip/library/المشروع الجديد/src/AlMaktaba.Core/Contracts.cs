namespace AlMaktaba.Core;

public interface IFileRepository
{
    Task InitializeAsync(CancellationToken cancellationToken = default);
    Task<IReadOnlyList<LibraryFile>> SearchAsync(LibraryQuery query, CancellationToken cancellationToken = default);
    Task<LibraryFile?> GetAsync(string id, CancellationToken cancellationToken = default);
    Task AddAsync(LibraryFile file, CancellationToken cancellationToken = default);
    Task RenameAsync(string id, string originalName, CancellationToken cancellationToken = default);
    Task SetFavoriteAsync(string id, bool favorite, CancellationToken cancellationToken = default);
    Task SetCategoryAsync(string id, string category, CancellationToken cancellationToken = default);
    Task SetThumbnailPathAsync(string id, string? thumbnailPath, CancellationToken cancellationToken = default);
    Task RecordOpenedAsync(string id, DateTimeOffset openedAt, CancellationToken cancellationToken = default);
    Task RecordOperationAsync(LibraryOperation operation, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<LibraryOperation>> GetRecentOperationsAsync(int limit = 100, CancellationToken cancellationToken = default);
    Task RemoveAsync(string id, CancellationToken cancellationToken = default);
}

public interface IJobRepository
{
    Task SaveJobAsync(ProcessingJob job, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<ProcessingJob>> GetRecentJobsAsync(
        int limit = 100, CancellationToken cancellationToken = default);
    Task MarkInterruptedJobsAsync(
        DateTimeOffset completedAt, CancellationToken cancellationToken = default);
}

public interface ILocalLibraryService
{
    Task<LibraryFile> ImportAsync(string sourcePath, string? sourceOperation = null, CancellationToken cancellationToken = default);
    Task RenameAsync(string id, string newName, CancellationToken cancellationToken = default);
    Task DeleteAsync(string id, CancellationToken cancellationToken = default);
    Task SetFavoriteAsync(string id, bool favorite, CancellationToken cancellationToken = default);
    Task SetCategoryAsync(string id, string category, CancellationToken cancellationToken = default);
    Task SetThumbnailPathAsync(string id, string? thumbnailPath, CancellationToken cancellationToken = default);
    Task RecordOpenedAsync(string id, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<LibraryOperation>> GetRecentOperationsAsync(int limit = 100, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<LibraryFile>> SearchAsync(LibraryQuery query, CancellationToken cancellationToken = default);
    string GetAbsolutePath(LibraryFile file);
}

public interface IImageProcessor
{
    Task<string> AdjustAsync(string inputPath, string outputPath, ImageAdjustments adjustments, IProgress<double>? progress = null, CancellationToken cancellationToken = default);
    Task<string> AddWhiteSpaceAsync(string inputPath, string outputPath, ImageMargins margins, IProgress<double>? progress = null, CancellationToken cancellationToken = default);
    Task<string> CreateTemplateAsync(
        IReadOnlyList<string> photoPaths, PhotoTemplate template, string outputPath,
        IProgress<double>? progress = null, CancellationToken cancellationToken = default,
        PhotoCropAnchor cropAnchor = PhotoCropAnchor.Center,
        ImageOutputFormat outputFormat = ImageOutputFormat.Png,
        int jpegQuality = 92);
}

public interface IModelCatalog
{
    Task<IReadOnlyList<LocalModel>> ListAsync(CancellationToken cancellationToken = default);
    Task<LocalModel> ImportAsync(string modelPath, LocalModelPurpose purpose, CancellationToken cancellationToken = default);
    Task DeleteAsync(string id, CancellationToken cancellationToken = default);
}

public sealed record ImageAdjustments(
    float Brightness = 0,
    float Contrast = 1,
    float Saturation = 1,
    float Sharpen = 0,
    float Whitening = 0,
    float Retouch = 0,
    float NoiseReduction = 0);

public sealed record ImageMargins(int Top, int Bottom = 0, int Left = 0, int Right = 0);

public enum PhotoCropAnchor { Center, Top, Bottom, Left, Right }
public enum ImageOutputFormat { Png, Jpeg }
public enum ImagePdfPaperSize { A4, A3, A5, Letter, Legal, Photo10x15Cm }
public enum ImagePdfOrientation { Automatic, Portrait, Landscape }
public enum ImagePdfOrdering { Selection, NameAscending, NameDescending }
public enum ImagePdfQuality { Lossless, High, Compact }

public sealed record ImagePdfOptions(
    ImagePdfPaperSize PaperSize = ImagePdfPaperSize.A4,
    ImagePdfOrientation Orientation = ImagePdfOrientation.Automatic,
    ImagePdfOrdering Ordering = ImagePdfOrdering.Selection,
    ImagePdfQuality Quality = ImagePdfQuality.Lossless);

public enum LocalModelPurpose { BackgroundRemoval, Enhancement, OptionalAi }

public sealed record LocalModel(
    string Id,
    string FileName,
    LocalModelPurpose Purpose,
    string Path,
    long SizeBytes,
    string Sha256,
    string Status,
    DateTimeOffset ImportedAt);
