using System.Text;

namespace AlMaktaba.Core;

public static class SafeFileNames
{
    public const int MaxNameLength = 160;

    public static string Sanitize(string name)
    {
        var clean = Path.GetFileName(name).Normalize(NormalizationForm.FormC);
        var invalid = Path.GetInvalidFileNameChars().ToHashSet();
        var builder = new StringBuilder(clean.Length);
        foreach (var ch in clean)
        {
            if (!invalid.Contains(ch) && !char.IsControl(ch) && ch is not '/' and not '\\')
                builder.Append(ch);
        }

        var value = builder.ToString().Trim().TrimEnd('.');
        if (string.IsNullOrWhiteSpace(value) || value is "." or "..")
            throw new ArgumentException("اسم الملف غير صالح.", nameof(name));
        if (value.Length > MaxNameLength)
        {
            var extension = Path.GetExtension(value);
            value = value[..Math.Max(1, MaxNameLength - extension.Length)] + extension;
        }
        return value;
    }
}
