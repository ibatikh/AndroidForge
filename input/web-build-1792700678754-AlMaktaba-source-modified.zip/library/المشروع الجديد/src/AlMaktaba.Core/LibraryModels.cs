namespace AlMaktaba.Core;

public enum LibraryFileKind { Image, Document, Pdf, Other }

public sealed record LibraryFile(
    string Id,
    string OriginalName,
    string StoredName,
    string RelativePath,
    string MimeType,
    LibraryFileKind Kind,
    long SizeBytes,
    DateTimeOffset CreatedAt,
    DateTimeOffset ModifiedAt,
    string? SourceOperation = null,
    string? ThumbnailPath = null,
    string? Checksum = null,
    bool IsFavorite = false,
    string Category = "",
    DateTimeOffset? LastOpenedAt = null);

public sealed record LibraryQuery(
    string? Search = null,
    LibraryFileKind? Kind = null,
    bool FavoritesOnly = false,
    string SortBy = "created",
    bool Descending = true,
    string? Category = null);

public sealed record LibraryOperation(
    string Id,
    string Operation,
    string? InputPath,
    string? OutputPath,
    string Status,
    string? ErrorMessage,
    DateTimeOffset CreatedAt,
    DateTimeOffset? CompletedAt);

public enum JobState { Queued, Processing, Completed, Failed, Cancelled }

public sealed record ProcessingJob(
    string Id,
    string Name,
    string InputPath,
    string? OutputPath,
    JobState State,
    double Progress,
    string? Error,
    DateTimeOffset CreatedAt,
    DateTimeOffset? CompletedAt);

public sealed record PhotoTemplate(
    string Id,
    string Name,
    double PhotoWidthCm,
    double PhotoHeightCm,
    int Columns,
    int Rows,
    double PaperWidthCm,
    double PaperHeightCm,
    int Dpi)
{
    public int PixelWidth => PhysicalUnits.CentimetersToPixels(PaperWidthCm, Dpi);
    public int PixelHeight => PhysicalUnits.CentimetersToPixels(PaperHeightCm, Dpi);
    public int PhotoPixelWidth => PhysicalUnits.CentimetersToPixels(PhotoWidthCm, Dpi);
    public int PhotoPixelHeight => PhysicalUnits.CentimetersToPixels(PhotoHeightCm, Dpi);
    public int PhotoCount => Columns * Rows;
}

public static class PhysicalUnits
{
    public static int CentimetersToPixels(double centimeters, int dpi)
    {
        if (!double.IsFinite(centimeters) || centimeters <= 0)
            throw new ArgumentOutOfRangeException(nameof(centimeters));
        if (dpi is < 72 or > 1200)
            throw new ArgumentOutOfRangeException(nameof(dpi));

        return checked((int)Math.Round(centimeters / 2.54 * dpi, MidpointRounding.AwayFromZero));
    }
}

public static class PhotoTemplates
{
    public static readonly PhotoTemplate ThreeByFour = new(
        "photo-3x4", "٣ × ٤ سم — ٩ صور", 3, 4, 3, 3, 10, 15, 300);

    public static readonly PhotoTemplate ThreePointFiveByFourPointFive = new(
        "photo-35x45", "٣٫٥ × ٤٫٥ سم — ٦ صور", 3.5, 4.5, 2, 3, 10, 15, 300);

    public static readonly PhotoTemplate MultiSixByThree = new(
        "multi-6x3", "متعدد الأشخاص — ٦ × ٣", 3, 4, 6, 3, 21, 29.7, 300);

    public static readonly PhotoTemplate MultiFiveByFour = new(
        "multi-5x4", "متعدد الأشخاص — ٥ × ٤", 3, 4, 5, 4, 21, 29.7, 300);

    public static IReadOnlyList<PhotoTemplate> All { get; } =
        [ThreeByFour, ThreePointFiveByFourPointFive, MultiSixByThree, MultiFiveByFour];
}
