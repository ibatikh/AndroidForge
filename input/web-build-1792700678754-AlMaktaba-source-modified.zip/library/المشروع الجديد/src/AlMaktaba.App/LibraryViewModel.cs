using System.Collections.ObjectModel;
using System.Diagnostics;
using AlMaktaba.Core;
using AlMaktaba.Processing;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Extensions.Logging;

namespace AlMaktaba.App;

public partial class LibraryViewModel(
    ILocalLibraryService library,
    AppPaths paths,
    ImageThumbnailService thumbnails,
    ILogger<LibraryViewModel> logger)
    : ObservableObject
{
    public ObservableCollection<LibraryFile> Files { get; } = [];
    public ObservableCollection<LibraryOperation> RecentOperations { get; } = [];

    [ObservableProperty] private string searchText = "";
    [ObservableProperty] private string categoryFilter = "";
    [ObservableProperty] private string sortBy = "created";
    [ObservableProperty] private LibraryFileKind? selectedKind;
    [ObservableProperty] private bool favoritesOnly;
    [ObservableProperty] private bool descending = true;
    [ObservableProperty] private string status = "المكتبة محلية؛ لا يتم رفع الملفات.";
    [ObservableProperty] private bool isBusy;

    [RelayCommand]
    public async Task RefreshAsync()
    {
        IsBusy = true;
        try
        {
            var files = await library.SearchAsync(new LibraryQuery(
                Search: SearchText,
                Kind: SelectedKind,
                FavoritesOnly: FavoritesOnly,
                SortBy: SortBy,
                Descending: Descending,
                Category: string.IsNullOrWhiteSpace(CategoryFilter) ? null : CategoryFilter.Trim()));
            Files.Clear();
            foreach (var file in files)
                Files.Add(await EnsureThumbnailAsync(file));
            var operations = await library.GetRecentOperationsAsync(100);
            RecentOperations.Clear();
            foreach (var operation in operations)
                RecentOperations.Add(operation);
            Status = $"عدد الملفات: {Files.Count}";
        }
        catch (Exception exception)
        {
            logger.LogError(exception, "Unable to load local library.");
            Status = "تعذر قراءة المكتبة. افتح الإعدادات للتفاصيل التقنية.";
        }
        finally { IsBusy = false; }
    }

    [RelayCommand]
    public async Task ImportAsync(IEnumerable<string> pathsToImport)
    {
        IsBusy = true;
        var imported = 0;
        foreach (var path in pathsToImport)
        {
            try
            {
                await library.ImportAsync(path, "Import");
                imported++;
            }
            catch (Exception exception)
            {
                logger.LogWarning(exception, "A file was not imported.");
            }
        }
        await RefreshAsync();
        Status = imported > 0 ? $"تم استيراد {imported} ملفًا إلى الجهاز." : "لم يتم استيراد أي ملف.";
        IsBusy = false;
    }

    [RelayCommand]
    public async Task DeleteAsync(LibraryFile file)
    {
        await library.DeleteAsync(file.Id);
        await RefreshAsync();
    }

    [RelayCommand]
    public async Task ToggleFavoriteAsync(LibraryFile file)
    {
        await library.SetFavoriteAsync(file.Id, !file.IsFavorite);
        await RefreshAsync();
    }

    [RelayCommand]
    public async Task RenameAsync((LibraryFile File, string NewName) request)
    {
        await library.RenameAsync(request.File.Id, request.NewName);
        await RefreshAsync();
    }

    public async Task SetCategoryAsync((LibraryFile File, string Category) request)
    {
        await library.SetCategoryAsync(request.File.Id, request.Category);
        await RefreshAsync();
    }

    public string GetFullPath(LibraryFile file) => library.GetAbsolutePath(file);

    public async Task OpenFileAsync(LibraryFile file)
    {
        try
        {
            var path = GetFullPath(file);
            if (!File.Exists(path))
            {
                Status = "الملف غير موجود على الجهاز.";
                return;
            }
            Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
            await library.RecordOpenedAsync(file.Id);
            await RefreshAsync();
        }
        catch (Exception exception)
        {
            logger.LogWarning(exception, "Could not open a local library file.");
            Status = "تعذر فتح الملف في التطبيق الافتراضي.";
        }
    }

    public void RevealFile(LibraryFile file)
    {
        var path = GetFullPath(file);
        if (File.Exists(path))
            Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{path}\"") { UseShellExecute = true });
    }

    public string? GetThumbnailPath(LibraryFile file)
    {
        if (string.IsNullOrWhiteSpace(file.ThumbnailPath) || Path.IsPathRooted(file.ThumbnailPath) ||
            file.ThumbnailPath.Split(['/', '\\'], StringSplitOptions.None)
                .Any(segment => segment is "" or "." or ".."))
            return null;
        var thumbnailRoot = Path.GetFullPath(paths.Thumbnails);
        var candidate = Path.GetFullPath(Path.Combine(paths.Root, file.ThumbnailPath));
        var prefix = Path.EndsInDirectorySeparator(thumbnailRoot)
            ? thumbnailRoot
            : thumbnailRoot + Path.DirectorySeparatorChar;
        var expected = Path.GetFullPath(Path.Combine(thumbnailRoot, file.Id + ".jpg"));
        if (!candidate.Equals(expected,
            OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal)
            || HasReparsePointInPath(Path.GetFullPath(paths.Root), candidate))
            return null;
        return candidate;
    }

    private async Task<LibraryFile> EnsureThumbnailAsync(LibraryFile file)
    {
        if (file.Kind != LibraryFileKind.Image)
            return file;
        var existing = GetThumbnailPath(file);
        if (existing is not null && File.Exists(existing))
            return file;

        var thumbnailPath = Path.Combine(paths.Thumbnails, file.Id + ".jpg");
        try
        {
            await thumbnails.CreateAsync(library.GetAbsolutePath(file), thumbnailPath);
            var relative = Path.GetRelativePath(paths.Root, thumbnailPath);
            await library.SetThumbnailPathAsync(file.Id, relative);
            return file with { ThumbnailPath = relative };
        }
        catch (Exception exception) when (exception is not OperationCanceledException)
        {
            logger.LogWarning(exception, "Could not create a local thumbnail.");
            return file;
        }
    }

    private static bool HasReparsePointInPath(string root, string target)
    {
        var current = root;
        if (IsReparsePoint(current))
            return true;
        foreach (var segment in Path.GetRelativePath(root, target).Split(
                     [Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar],
                     StringSplitOptions.RemoveEmptyEntries))
        {
            current = Path.Combine(current, segment);
            if (IsReparsePoint(current))
                return true;
            if (!File.Exists(current) && !Directory.Exists(current))
                return false;
        }
        return false;
    }

    private static bool IsReparsePoint(string path)
    {
        try { return (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0; }
        catch (FileNotFoundException) { return false; }
        catch (DirectoryNotFoundException) { return false; }
    }
}
