using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;

namespace AlMaktaba.App;

public sealed partial class ModelsPage : Page
{
    public ModelsViewModel ViewModel { get; } = App.Services.GetRequiredService<ModelsViewModel>();

    public ModelsPage()
    {
        InitializeComponent();
        DataContext = ViewModel;
        Loaded += async (_, _) => await ViewModel.RefreshAsync();
    }

    private async void ImportModel_Click(object sender, RoutedEventArgs e)
    {
        var paths = await PickerService.PickFilesAsync(".onnx");
        if (paths.Count > 0)
            await ViewModel.ImportAsync(paths[0]);
    }

    private void PurposeSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (PurposeSelector.SelectedItem is ComboBoxItem item &&
            Enum.TryParse<AlMaktaba.Core.LocalModelPurpose>(item.Tag?.ToString(), out var purpose))
            ViewModel.SelectedPurpose = purpose;
    }

    private async void DeleteModel_Click(object sender, RoutedEventArgs e)
    {
        var id = (sender as FrameworkElement)?.Tag as string;
        var model = ViewModel.Models.FirstOrDefault(item => item.Id == id);
        if (model is null) return;

        var dialog = new ContentDialog
        {
            XamlRoot = Content.XamlRoot,
            Title = "حذف النموذج المحلي؟",
            Content = $"سيُحذف الملف «{model.FileName}» من مجلد النماذج.",
            PrimaryButtonText = "حذف",
            CloseButtonText = "إلغاء",
            DefaultButton = ContentDialogButton.Close
        };
        if (await dialog.ShowAsync() == ContentDialogResult.Primary)
            await ViewModel.DeleteAsync(model);
    }

    private async void Refresh_Click(object sender, RoutedEventArgs e) => await ViewModel.RefreshAsync();
}
