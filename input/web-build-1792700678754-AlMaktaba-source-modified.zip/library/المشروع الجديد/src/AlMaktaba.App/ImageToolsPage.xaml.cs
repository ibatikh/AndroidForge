using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Windows.ApplicationModel.DataTransfer;
using Windows.Storage;
using AlMaktaba.Core;
using System.Globalization;

namespace AlMaktaba.App;

public sealed partial class ImageToolsPage : Page
{
    public ImageToolsViewModel ViewModel { get; } = App.Services.GetRequiredService<ImageToolsViewModel>();

    public ImageToolsPage()
    {
        InitializeComponent();
        DataContext = ViewModel;
    }

    private async void ChooseImage_Click(object sender, RoutedEventArgs e)
    {
        var paths = await PickerService.PickFilesAsync(".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff");
        if (paths.Count > 0)
        {
            ViewModel.SetInputs(paths);
            SelectedFile.Text = paths.Count == 1 ? paths[0] : $"تم اختيار {paths.Count} صورة";
            ClearWhiteSpacePreviewUi();
        }
    }

    private void Page_DragOver(object sender, DragEventArgs e)
    {
        if (!ViewModel.CanRun)
        {
            e.AcceptedOperation = DataPackageOperation.None;
            return;
        }
        e.AcceptedOperation = DataPackageOperation.Copy;
        e.DragUIOverride.Caption = "معالجة الصور محليًا";
    }

    private async void Page_Drop(object sender, DragEventArgs e)
    {
        if (!ViewModel.CanRun) return;
        if (!e.DataView.Contains(StandardDataFormats.StorageItems)) return;
        var items = await e.DataView.GetStorageItemsAsync();
        var paths = items.OfType<StorageFile>()
            .Where(file => new[] { ".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff" }
                .Contains(Path.GetExtension(file.Name), StringComparer.OrdinalIgnoreCase))
            .Select(file => file.Path)
            .ToList();
        ViewModel.SetInputs(paths);
        SelectedFile.Text = paths.Count == 0
            ? "لم تُسقط صورة مدعومة"
            : paths.Count == 1 ? paths[0] : $"تم إسقاط {paths.Count} صورة";
        ClearWhiteSpacePreviewUi();
    }

    private void WhiteSpaceMargin_TextChanged(object sender, TextChangedEventArgs e)
    {
        ViewModel.DiscardWhiteSpacePreview();
        ClearWhiteSpacePreviewUi();
    }

    private async void PreviewWhiteSpace_Click(object sender, RoutedEventArgs e)
    {
        if (!TryReadMargins(out var margins))
        {
            ViewModel.Status = "أدخل أعدادًا صحيحة من 0 إلى 10000 بكسل لكل جانب.";
            return;
        }

        await ViewModel.PreviewWhiteSpaceAsync(margins);
        await DisplayWhiteSpacePreviewAsync();
    }

    private async void SaveWhiteSpace_Click(object sender, RoutedEventArgs e)
    {
        if (!TryReadMargins(out var margins))
        {
            ViewModel.Status = "أدخل أعدادًا صحيحة من 0 إلى 10000 بكسل لكل جانب.";
            return;
        }

        await ViewModel.SaveWhiteSpaceAsync(margins);
        await DisplayWhiteSpacePreviewAsync();
    }

    private bool TryReadMargins(out ImageMargins margins)
    {
        margins = new ImageMargins(0);
        if (!TryReadMargin(TopMarginInput, out var top) ||
            !TryReadMargin(BottomMarginInput, out var bottom) ||
            !TryReadMargin(LeftMarginInput, out var left) ||
            !TryReadMargin(RightMarginInput, out var right))
            return false;

        margins = new ImageMargins(top, bottom, left, right);
        return true;
    }

    private static bool TryReadMargin(TextBox input, out int value) =>
        int.TryParse(input.Text, NumberStyles.Integer, CultureInfo.CurrentCulture, out value) &&
        value is >= 0 and <= 10000;

    private async Task DisplayWhiteSpacePreviewAsync()
    {
        var path = ViewModel.WhiteSpacePreviewPath;
        if (string.IsNullOrWhiteSpace(path) || !System.IO.File.Exists(path))
        {
            ClearWhiteSpacePreviewUi();
            return;
        }

        var file = await StorageFile.GetFileFromPathAsync(path);
        using var stream = await file.OpenReadAsync();
        var bitmap = new Microsoft.UI.Xaml.Media.Imaging.BitmapImage();
        await bitmap.SetSourceAsync(stream);
        WhiteSpacePreviewImage.Source = bitmap;
        WhiteSpacePreviewImage.Visibility = Visibility.Visible;
    }

    private void ClearWhiteSpacePreviewUi()
    {
        WhiteSpacePreviewImage.Source = null;
        WhiteSpacePreviewImage.Visibility = Visibility.Collapsed;
    }
}
