using AlMaktaba.Core;
using AlMaktaba.Infrastructure;
using AlMaktaba.Processing;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Extensions.Logging;

namespace AlMaktaba.App;

public partial class PdfToolsViewModel(
    ImagePdfWriter pdfWriter,
    PdfRasterizer rasterizer,
    DocumentProcessingService documentService,
    ILocalLibraryService library,
    AppPaths paths,
    LocalJobQueue jobs,
    ILogger<PdfToolsViewModel> logger) : ObservableObject
{
    public List<string> ImagePaths { get; } = [];
    [ObservableProperty] private string? selectedPdfPath;
    [ObservableProperty] private string? selectedDocxPath;
    [ObservableProperty] private int pageNumber = 1;
    [ObservableProperty] private int dpi = 150;
    [ObservableProperty] private ImageOutputFormat outputFormat = ImageOutputFormat.Png;
    [ObservableProperty] private int jpegQuality = 92;
    [ObservableProperty] private string? selectedOutputDirectory;
    [ObservableProperty] private ImagePdfPaperSize imagePdfPaperSize = ImagePdfPaperSize.A4;
    [ObservableProperty] private ImagePdfOrientation imagePdfOrientation = ImagePdfOrientation.Automatic;
    [ObservableProperty] private ImagePdfOrdering imagePdfOrdering = ImagePdfOrdering.Selection;
    [ObservableProperty] private ImagePdfQuality imagePdfQuality = ImagePdfQuality.Lossless;
    [ObservableProperty] private string status = "أدوات PDF تعمل محليًا على هذا الجهاز.";
    [ObservableProperty] private bool isBusy;
    [ObservableProperty] private double progress;
    [ObservableProperty] private string? pdfPreviewPath;
    private CancellationTokenSource? _currentOperation;
    public bool CanRun => !IsBusy;
    public bool CanCancel => IsBusy;
    public string OutputLocationSummary => string.IsNullOrWhiteSpace(SelectedOutputDirectory)
        ? "الموقع الحالي: المكتبة المحلية"
        : $"موقع التصدير: {SelectedOutputDirectory}";

    partial void OnIsBusyChanged(bool value)
    {
        OnPropertyChanged(nameof(CanRun));
        OnPropertyChanged(nameof(CanCancel));
    }

    public void SetPdf(string path)
    {
        DiscardPdfPreview();
        SelectedPdfPath = path;
        Status = Path.GetFileName(path);
    }
    public void SetDocx(string path) { SelectedDocxPath = path; Status = Path.GetFileName(path); }
    public void SetPdfPage(int page)
    {
        if (PageNumber != page)
            DiscardPdfPreview();
        PageNumber = page;
    }
    public void SetOutputDirectory(string? path)
    {
        SelectedOutputDirectory = string.IsNullOrWhiteSpace(path) ? null : Path.GetFullPath(path);
        OnPropertyChanged(nameof(OutputLocationSummary));
    }

    public void SetImages(IEnumerable<string> pathsToAdd)
    {
        ImagePaths.Clear();
        ImagePaths.AddRange(pathsToAdd.Where(File.Exists));
        Status = $"الصور المحددة: {ImagePaths.Count}";
    }

    public async Task PreviewPdfPageAsync()
    {
        var pdfPath = SelectedPdfPath;
        var page = PageNumber;
        if (string.IsNullOrWhiteSpace(pdfPath) || !File.Exists(pdfPath))
        {
            Status = "اختر ملف PDF أولًا.";
            return;
        }
        if (page < 1)
        {
            Status = "رقم الصفحة يبدأ من 1.";
            return;
        }

        DiscardPdfPreview();
        IsBusy = true;
        Progress = 0;
        var output = Path.Combine(paths.Temp, $"pdf-preview-{Guid.NewGuid():N}.png");
        using var cancellation = new CancellationTokenSource();
        _currentOperation = cancellation;
        try
        {
            Directory.CreateDirectory(paths.Temp);
            var previewDpi = Math.Clamp(Dpi, 72, 150);
            IProgress<double> uiProgress = new Progress<double>(value => Progress = value);
            await jobs.RunAsync("معاينة صفحة PDF", pdfPath, async (jobProgress, token) =>
            {
                IProgress<double> operationProgress = new Progress<double>(value =>
                {
                    var bounded = Math.Clamp(value, 0, 1);
                    jobProgress.Report(bounded);
                    uiProgress.Report(bounded);
                });
                await rasterizer.RenderPageAsync(
                    pdfPath, page - 1, output, previewDpi, token,
                    ImageOutputFormat.Png, 100, operationProgress);
                return output;
            }, cancellation.Token);
            PdfPreviewPath = output;
            Status = $"معاينة الصفحة {page} جاهزة داخل التطبيق بدقة {previewDpi} DPI. لم يُصدّر ملف أو يُستورد إلى المكتبة.";
            Progress = 1;
        }
        catch (OperationCanceledException)
        {
            Status = "أُلغيت معاينة صفحة PDF.";
            TryDeletePreview(output);
        }
        catch (Exception exception)
        {
            logger.LogError(exception, "PDF page preview failed.");
            Status = "تعذر عرض الصفحة. تحقق من ملف PDF ورقم الصفحة.";
            TryDeletePreview(output);
        }
        finally
        {
            _currentOperation = null;
            IsBusy = false;
        }
    }

    public void DiscardPdfPreview()
    {
        var previousPath = PdfPreviewPath;
        PdfPreviewPath = null;
        if (string.IsNullOrWhiteSpace(previousPath))
            return;

        var tempRoot = Path.GetFullPath(paths.Temp) + Path.DirectorySeparatorChar;
        var fullPath = Path.GetFullPath(previousPath);
        if (fullPath.StartsWith(tempRoot, StringComparison.OrdinalIgnoreCase))
            TryDeletePreview(fullPath);
    }

    [RelayCommand]
    private void CancelOperation() => _currentOperation?.Cancel();

    [RelayCommand]
    public async Task CreatePdfAsync()
    {
        if (ImagePaths.Count == 0) { Status = "اختر صورة واحدة على الأقل."; return; }
        var images = ImagePaths.ToArray();
        var firstImage = images[0];
        var options = new ImagePdfOptions(
            ImagePdfPaperSize, ImagePdfOrientation, ImagePdfOrdering, ImagePdfQuality);
        await RunOperationAsync("تعذر إنشاء PDF.", "Images to PDF", firstImage, async (progress, token) =>
        {
            Directory.CreateDirectory(paths.Generated);
            var output = Path.Combine(paths.Generated, $"images-{DateTime.Now:yyyyMMdd-HHmmss}-{Guid.NewGuid():N}.pdf");
            await pdfWriter.WriteAsync(images, output, options, progress, token);
            await library.ImportAsync(output, "Images to PDF", token);
            return (output,
                $"تم إنشاء PDF محليًا ({options.PaperSize}، {options.Orientation}، {options.Quality}) وحفظه في المكتبة: {Path.GetFileName(output)}");
        });
    }

    [RelayCommand]
    public async Task RenderPdfPageAsync()
    {
        var pdfPath = SelectedPdfPath;
        var page = PageNumber;
        if (string.IsNullOrWhiteSpace(pdfPath) || !File.Exists(pdfPath))
        { Status = "اختر ملف PDF أولًا."; return; }
        if (page < 1) { Status = "رقم الصفحة يبدأ من 1."; return; }
        var dpiValue = Dpi;
        var outputFormatValue = OutputFormat;
        var jpegQualityValue = JpegQuality;
        var outputDirectory = string.IsNullOrWhiteSpace(SelectedOutputDirectory)
            ? paths.Generated
            : SelectedOutputDirectory;
        var importToLibrary = string.IsNullOrWhiteSpace(SelectedOutputDirectory);
        await RunOperationAsync("تعذر تصيير الصفحة؛ تحقق من الملف ورقم الصفحة ومكان الحفظ.", "PDF to image", pdfPath,
            async (progress, token) =>
            {
                Directory.CreateDirectory(outputDirectory);
                var extension = GetImageExtension(outputFormatValue);
                var output = Path.Combine(outputDirectory,
                    $"{Path.GetFileNameWithoutExtension(pdfPath)}-page-{page:0000}-{Guid.NewGuid():N}{extension}");
                await rasterizer.RenderPageAsync(
                    pdfPath, page - 1, output, dpiValue, token, outputFormatValue, jpegQualityValue, progress);
                if (importToLibrary)
                    await library.ImportAsync(output, "PDF to image", token);
                var message = importToLibrary
                    ? $"تم تصيير الصفحة {page} وحفظها في المكتبة المحلية."
                    : $"تم تصدير الصفحة {page} إلى المجلد المحدد.";
                return (output, message);
            });
    }

    public async Task RenderPageRangeAsync(int firstPage, int lastPage)
    {
        var pdfPath = SelectedPdfPath;
        if (string.IsNullOrWhiteSpace(pdfPath) || !File.Exists(pdfPath))
        { Status = "اختر ملف PDF أولًا."; return; }
        if (firstPage < 1 || lastPage < firstPage)
        { Status = "أدخل نطاق صفحات صحيحًا يبدأ من 1."; return; }

        await ExportPageRangeAsync(pdfPath, firstPage, lastPage, allPages: false);
    }

    [RelayCommand]
    public async Task RenderAllPagesAsync()
    {
        var pdfPath = SelectedPdfPath;
        if (string.IsNullOrWhiteSpace(pdfPath) || !File.Exists(pdfPath))
        { Status = "اختر ملف PDF أولًا."; return; }
        await ExportPageRangeAsync(pdfPath, 1, null, allPages: true);
    }

    private async Task ExportPageRangeAsync(
        string pdfPath, int firstPage, int? lastPage, bool allPages)
    {
        var dpiValue = Dpi;
        var outputFormatValue = OutputFormat;
        var jpegQualityValue = JpegQuality;
        var selectedDirectory = SelectedOutputDirectory;
        var importToLibrary = string.IsNullOrWhiteSpace(selectedDirectory);
        var temporaryDirectory = importToLibrary
            ? Path.Combine(paths.Temp, "pdf-pages-" + Guid.NewGuid().ToString("N"))
            : selectedDirectory!;
        var operationName = allPages ? "PDF to images" : "PDF page range";
        await RunOperationAsync("تعذر تصيير نطاق صفحات PDF.", operationName, pdfPath,
            async (progress, token) =>
            {
                Directory.CreateDirectory(temporaryDirectory);
                try
                {
                    var rendered = await rasterizer.RenderPageRangeAsync(
                        pdfPath, firstPage, lastPage, temporaryDirectory,
                        dpiValue, outputFormatValue, jpegQualityValue, progress, token);
                    if (!importToLibrary)
                        return (rendered.FirstOrDefault() ??
                                throw new InvalidOperationException("لم تُنتج أي صفحات."),
                            $"تم تصدير {rendered.Count} صفحة إلى المجلد المحدد.");

                    string? firstStoredPath = null;
                    for (var index = 0; index < rendered.Count; index++)
                    {
                        token.ThrowIfCancellationRequested();
                        var imported = await library.ImportAsync(rendered[index], "PDF to images", token);
                        firstStoredPath ??= Path.Combine(paths.Library, imported.RelativePath);
                        progress.Report(0.8 + (index + 1d) / rendered.Count * 0.2);
                    }
                    return (firstStoredPath ?? throw new InvalidOperationException("لم تُنتج أي صفحات."),
                        $"تم تصيير {rendered.Count} صفحة وحفظها في المكتبة المحلية.");
                }
                finally
                {
                    if (importToLibrary)
                    {
                        try { Directory.Delete(temporaryDirectory, recursive: true); }
                        catch (IOException) { }
                    }
                }
            });
    }

    [RelayCommand]
    public async Task ConvertDocxAsync()
    {
        var docxPath = SelectedDocxPath;
        if (string.IsNullOrWhiteSpace(docxPath) || !File.Exists(docxPath))
        { Status = "اختر ملف DOCX أولًا."; return; }
        await RunOperationAsync("تعذر تحويل المستند.", "DOCX to PDF", docxPath, async (_, token) =>
        {
            Directory.CreateDirectory(paths.Generated);
            var output = await documentService.ConvertDocxToPdfAsync(
                docxPath, paths.Generated, cancellationToken: token);
            await library.ImportAsync(output, "DOCX to PDF", token);
            return (output, "تم تحويل المستند محليًا بواسطة LibreOffice.");
        });
    }

    private async Task RunOperationAsync(
        string failureMessage,
        string operationName,
        string inputPath,
        Func<IProgress<double>, CancellationToken, Task<(string OutputPath, string SuccessMessage)>> operation)
    {
        IsBusy = true;
        Progress = 0;
        using var cancellation = new CancellationTokenSource();
        _currentOperation = cancellation;
        try
        {
            IProgress<double> uiProgress = new Progress<double>(value => Progress = value);
            string successMessage = "";
            await jobs.RunAsync(operationName, inputPath, async (jobProgress, token) =>
            {
                IProgress<double> progress = new Progress<double>(value =>
                {
                    jobProgress.Report(value);
                    uiProgress.Report(value);
                });
                progress.Report(0);
                var result = await operation(progress, token);
                successMessage = result.SuccessMessage;
                progress.Report(1);
                return result.OutputPath;
            }, cancellation.Token);
            Status = successMessage;
            Progress = 1;
        }
        catch (OperationCanceledException)
        {
            Status = "أُلغيت العملية.";
        }
        catch (Exception exception)
        {
            logger.LogError(exception, "{Operation} failed.", operationName);
            Status = operationName == "DOCX to PDF" && exception is FileNotFoundException
                ? "يلزم تثبيت LibreOffice محليًا لتحويل DOCX إلى PDF."
                : exception switch
                {
                    InvalidDataException invalidData => invalidData.Message,
                    ArgumentOutOfRangeException => "رقم الصفحة أو نطاقها خارج حدود ملف PDF.",
                    UnauthorizedAccessException => "لا يمكن الكتابة إلى المجلد المحدد. تحقق من صلاحيات الوصول.",
                    IOException => "تعذر حفظ الملفات؛ تحقق من وجود مساحة كافية ومن عدم فتح ملف بنفس الاسم.",
                    _ => failureMessage
                };
        }
        finally
        {
            _currentOperation = null;
            IsBusy = false;
        }
    }

    private static void TryDeletePreview(string path)
    {
        try
        {
            if (File.Exists(path))
                File.Delete(path);
        }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }

    private static string GetImageExtension(ImageOutputFormat format) =>
        format == ImageOutputFormat.Jpeg ? ".jpg" : ".png";
}
