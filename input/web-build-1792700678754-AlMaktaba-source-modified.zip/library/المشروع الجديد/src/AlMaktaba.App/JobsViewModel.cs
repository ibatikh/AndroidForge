using System.Collections.ObjectModel;
using AlMaktaba.Core;
using AlMaktaba.Infrastructure;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;

namespace AlMaktaba.App;

public partial class JobsViewModel : ObservableObject
{
    private readonly LocalJobQueue _queue;

    public ObservableCollection<JobListItem> Jobs { get; } = [];

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(CanCancelSelected))]
    private JobListItem? selectedJob;

    [ObservableProperty]
    private string status = "تُعرض هنا حالة المهام التي تعمل محليًا.";

    public bool CanCancelSelected =>
        SelectedJob?.State is JobState.Queued or JobState.Processing;

    public JobsViewModel(LocalJobQueue queue)
    {
        _queue = queue;
        foreach (var job in queue.Snapshot())
            Jobs.Add(new JobListItem(job));
        Status = Jobs.Count == 0 ? "لا توجد مهام بعد." : $"المهام المسجلة: {Jobs.Count}";
        queue.JobChanged += OnJobChanged;
    }

    [RelayCommand]
    private void CancelSelected()
    {
        if (SelectedJob is null)
            return;
        Status = _queue.Cancel(SelectedJob.Id)
            ? "أُرسل طلب إلغاء المهمة."
            : "انتهت المهمة أو لم تعد قابلة للإلغاء.";
    }

    private void OnJobChanged(object? sender, ProcessingJob job)
    {
        var dispatcher = App.MainWindow?.DispatcherQueue;
        if (dispatcher is null)
            return;
        dispatcher.TryEnqueue(() =>
        {
            var index = -1;
            for (var i = 0; i < Jobs.Count; i++)
            {
                if (Jobs[i].Id == job.Id)
                {
                    index = i;
                    break;
                }
            }

            var item = new JobListItem(job);
            if (index < 0)
                Jobs.Insert(0, item);
            else
            {
                var wasSelected = SelectedJob?.Id == job.Id;
                Jobs[index] = item;
                if (wasSelected)
                    SelectedJob = item;
            }

            Status = Jobs.Count == 0
                ? "لا توجد مهام بعد."
                : $"المهام المسجلة: {Jobs.Count}";
        });
    }
}

public sealed record JobListItem(ProcessingJob Job)
{
    public string Id => Job.Id;
    public string Name => Job.Name;
    public string InputName => Path.GetFileName(Job.InputPath);
    public string? Error => Job.Error;
    public double Progress => Math.Clamp(Job.Progress * 100, 0, 100);
    public JobState State => Job.State;
    public string StateText => Job.State switch
    {
        JobState.Queued => "بانتظار التنفيذ",
        JobState.Processing => "قيد التنفيذ",
        JobState.Completed => "اكتملت",
        JobState.Failed => "فشلت",
        JobState.Cancelled => "أُلغيت",
        _ => "غير معروف"
    };
}
