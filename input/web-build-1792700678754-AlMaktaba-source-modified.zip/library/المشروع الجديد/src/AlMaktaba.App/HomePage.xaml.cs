using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;

namespace AlMaktaba.App;

public sealed partial class HomePage : Page
{
    public HomePage() => InitializeComponent();

    private void OpenLibrary_Click(object sender, RoutedEventArgs e) => App.MainWindow.Navigate("library");
    private void OpenImages_Click(object sender, RoutedEventArgs e) => App.MainWindow.Navigate("images");
    private void OpenTemplates_Click(object sender, RoutedEventArgs e) => App.MainWindow.Navigate("templates");
    private void OpenPdf_Click(object sender, RoutedEventArgs e) => App.MainWindow.Navigate("pdf");
}
