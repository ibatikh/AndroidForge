using System.Collections.ObjectModel;
using AlMaktaba.Core;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Extensions.Logging;

namespace AlMaktaba.App;

public partial class ModelsViewModel(IModelCatalog catalog, ILogger<ModelsViewModel> logger) : ObservableObject
{
    public ObservableCollection<LocalModel> Models { get; } = [];
    [ObservableProperty] private string status = "لا يتم تنزيل النماذج تلقائيًا. استورد ملف ONNX من جهازك.";
    [ObservableProperty] private LocalModelPurpose selectedPurpose = LocalModelPurpose.OptionalAi;

    [RelayCommand]
    public async Task RefreshAsync()
    {
        try
        {
            var models = await catalog.ListAsync();
            Models.Clear();
            foreach (var model in models) Models.Add(model);
        }
        catch (Exception exception)
        {
            logger.LogError(exception, "Model catalog load failed.");
            Status = "تعذر قراءة سجل النماذج.";
        }
    }

    [RelayCommand]
    public async Task ImportAsync(string modelPath)
    {
        try
        {
            var model = await catalog.ImportAsync(modelPath, SelectedPurpose);
            Models.Add(model);
            Status = "تم التحقق من بنية ONNX. لا يفعّل الاستيراد وحده أي ميزة؛ يلزم ملف تعريف مدعوم لكل استخدام.";
        }
        catch (Exception exception)
        {
            logger.LogError(exception, "Model import failed.");
            Status = "تعذر استيراد النموذج؛ تأكد من أنه ONNX صالح ومتوافق.";
        }
    }

    [RelayCommand]
    public async Task DeleteAsync(LocalModel model)
    {
        try
        {
            await catalog.DeleteAsync(model.Id);
            Models.Remove(model);
            Status = "تم حذف النموذج المحلي.";
        }
        catch (Exception exception)
        {
            logger.LogError(exception, "Model deletion failed.");
            Status = "تعذر حذف النموذج.";
        }
    }
}
