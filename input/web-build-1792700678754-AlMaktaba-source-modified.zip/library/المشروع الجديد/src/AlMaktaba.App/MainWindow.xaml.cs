using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;

namespace AlMaktaba.App;

public sealed partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        MainNavigation.SelectedItem = MainNavigation.MenuItems[0];
    }

    private void MainNavigation_Loaded(object sender, RoutedEventArgs e)
    {
        Navigate("home");
    }

    private void MainNavigation_SelectionChanged(NavigationView sender, NavigationViewSelectionChangedEventArgs args)
    {
        var tag = args.SelectedItemContainer?.Tag as string;
        if (args.IsSettingsSelected)
            tag = "settings";
        Navigate(tag ?? "home");
    }

    public void Navigate(string tag)
    {
        var pageType = tag switch
        {
            "library" => typeof(LibraryPage),
            "images" => typeof(ImageToolsPage),
            "templates" => typeof(TemplatesPage),
            "pdf" => typeof(PdfToolsPage),
            "models" => typeof(ModelsPage),
            "jobs" => typeof(JobsPage),
            "settings" => typeof(SettingsPage),
            _ => typeof(HomePage)
        };
        if (ContentFrame.CurrentSourcePageType != pageType)
            ContentFrame.Navigate(pageType);
    }

    public async Task ShowStartupErrorAsync(Exception exception)
    {
        var dialog = new ContentDialog
        {
            XamlRoot = ContentFrame.XamlRoot,
            Title = "تعذر بدء التطبيق",
            Content = new StackPanel
            {
                Spacing = 8,
                Children =
                {
                    new TextBlock { Text = "تعذر تهيئة قاعدة البيانات المحلية. لا حاجة لاتصال بالإنترنت؛ راجع التفاصيل التقنية قبل المتابعة." },
                    new Expander
                    {
                        Header = "التفاصيل التقنية",
                        Content = new TextBlock { Text = exception.Message, TextWrapping = TextWrapping.Wrap }
                    }
                }
            },
            CloseButtonText = "إغلاق",
            DefaultButton = ContentDialogButton.Close
        };
        await dialog.ShowAsync();
    }
}
