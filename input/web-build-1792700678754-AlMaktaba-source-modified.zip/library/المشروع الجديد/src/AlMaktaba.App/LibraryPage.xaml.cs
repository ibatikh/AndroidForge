using AlMaktaba.Core;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media.Imaging;
using Windows.ApplicationModel.DataTransfer;
using Windows.Storage;

namespace AlMaktaba.App;

public sealed partial class LibraryPage : Page
{
    public LibraryViewModel ViewModel { get; } = App.Services.GetRequiredService<LibraryViewModel>();

    public LibraryPage()
    {
        InitializeComponent();
        DataContext = ViewModel;
        Loaded += async (_, _) => await ViewModel.RefreshAsync();
    }

    private async void Import_Click(object sender, RoutedEventArgs e)
    {
        var files = await PickerService.PickFilesAsync(".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif",
            ".tiff", ".pdf", ".docx", ".doc", ".txt", ".rtf", ".xlsx", ".pptx", ".odt");
        if (files.Count > 0)
            await ViewModel.ImportAsync(files);
        UpdateEmptyStates();
    }

    private async void SearchBox_TextChanged(object sender, TextChangedEventArgs e) =>
        await ApplyFiltersAsync();

    private async void FileList_ItemClick(object sender, ItemClickEventArgs e)
    {
        if (e.ClickedItem is LibraryFile file)
            await ViewModel.OpenFileAsync(file);
    }

    private async void Delete_Click(object sender, RoutedEventArgs e)
    {
        if ((sender as FrameworkElement)?.DataContext is not LibraryFile file)
            file = FindFile(sender);
        if (file is null) return;
        var dialog = new ContentDialog
        {
            XamlRoot = RootGrid.XamlRoot,
            Title = "حذف الملف؟",
            Content = $"سيتم حذف «{file.OriginalName}» من الجهاز والمكتبة.",
            PrimaryButtonText = "حذف",
            CloseButtonText = "إلغاء",
            DefaultButton = ContentDialogButton.Close
        };
        if (await dialog.ShowAsync() == ContentDialogResult.Primary)
            await ViewModel.DeleteAsync(file);
        UpdateEmptyStates();
    }

    private async void Category_Click(object sender, RoutedEventArgs e)
    {
        var file = FindFile(sender);
        if (file is null) return;
        var input = new TextBox
        {
            Text = file.Category,
            PlaceholderText = "اكتب تصنيفًا أو اتركه فارغًا",
            MaxLength = 80
        };
        var dialog = new ContentDialog
        {
            XamlRoot = RootGrid.XamlRoot,
            Title = "تصنيف الملف",
            Content = input,
            PrimaryButtonText = "حفظ",
            CloseButtonText = "إلغاء",
            DefaultButton = ContentDialogButton.Primary
        };
        if (await dialog.ShowAsync() == ContentDialogResult.Primary)
            await ViewModel.SetCategoryAsync((file, input.Text));
        UpdateEmptyStates();
    }

    private async void Rename_Click(object sender, RoutedEventArgs e)
    {
        var file = FindFile(sender);
        if (file is null) return;
        var input = new TextBox { Text = file.OriginalName, FlowDirection = FlowDirection.LeftToRight };
        var dialog = new ContentDialog
        {
            XamlRoot = RootGrid.XamlRoot,
            Title = "إعادة تسمية الملف",
            Content = input,
            PrimaryButtonText = "حفظ",
            CloseButtonText = "إلغاء",
            DefaultButton = ContentDialogButton.Primary
        };
        if (await dialog.ShowAsync() == ContentDialogResult.Primary &&
            !string.IsNullOrWhiteSpace(input.Text))
            await ViewModel.RenameAsync((file, input.Text));
    }

    private async void Favorite_Click(object sender, RoutedEventArgs e)
    {
        var file = FindFile(sender);
        if (file is not null)
            await ViewModel.ToggleFavoriteAsync(file);
    }

    private async void Open_Click(object sender, RoutedEventArgs e)
    {
        var file = FindFile(sender);
        if (file is not null) await ViewModel.OpenFileAsync(file);
    }

    private void Reveal_Click(object sender, RoutedEventArgs e)
    {
        var file = FindFile(sender);
        if (file is not null) ViewModel.RevealFile(file);
    }

    private LibraryFile? FindFile(object sender)
    {
        var id = (sender as FrameworkElement)?.Tag as string;
        return ViewModel.Files.FirstOrDefault(file => file.Id == id);
    }

    private void Page_DragOver(object sender, DragEventArgs e)
    {
        e.AcceptedOperation = DataPackageOperation.Copy;
        e.DragUIOverride.Caption = "إضافة إلى المكتبة المحلية";
    }

    private async void Page_Drop(object sender, DragEventArgs e)
    {
        if (!e.DataView.Contains(StandardDataFormats.StorageItems)) return;
        var items = await e.DataView.GetStorageItemsAsync();
        var paths = items.OfType<StorageFile>().Select(file => file.Path).ToList();
        if (paths.Count > 0)
            await ViewModel.ImportAsync(paths);
        UpdateEmptyStates();
    }

    private async void KindFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (KindFilter?.SelectedItem is ComboBoxItem item)
            ViewModel.SelectedKind = Enum.TryParse<LibraryFileKind>(item.Tag?.ToString(), out var kind)
                ? kind
                : null;
        await ApplyFiltersAsync();
    }

    private async void SortFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SortFilter?.SelectedItem is ComboBoxItem item)
            ViewModel.SortBy = item.Tag?.ToString() ?? "created";
        await ApplyFiltersAsync();
    }

    private async void CategoryFilter_TextChanged(object sender, TextChangedEventArgs e) =>
        await ApplyFiltersAsync();

    private async void LibraryFilter_Click(object sender, RoutedEventArgs e) =>
        await ApplyFiltersAsync();

    private void HistoryToggle_Click(object sender, RoutedEventArgs e)
    {
        var showHistory = HistoryList.Visibility != Visibility.Visible;
        FileList.Visibility = showHistory ? Visibility.Collapsed : Visibility.Visible;
        HistoryList.Visibility = showHistory ? Visibility.Visible : Visibility.Collapsed;
        HistoryButton.Content = showHistory ? "العودة إلى المكتبة" : "سجل العمليات";
        UpdateEmptyStates();
    }

    private async void Thumbnail_Loaded(object sender, RoutedEventArgs e)
    {
        if (sender is not Microsoft.UI.Xaml.Controls.Image image ||
            image.DataContext is not LibraryFile file)
            return;
        var path = ViewModel.GetThumbnailPath(file);
        if (path is null || !File.Exists(path))
            return;
        try
        {
            var thumbnailFile = await StorageFile.GetFileFromPathAsync(path);
            using var stream = await thumbnailFile.OpenAsync(FileAccessMode.Read);
            var bitmap = new BitmapImage();
            await bitmap.SetSourceAsync(stream);
            image.Source = bitmap;
        }
        catch (Exception)
        {
            image.Source = null;
        }
    }

    private async Task ApplyFiltersAsync()
    {
        if (SearchBox is null)
            return;
        ViewModel.SearchText = SearchBox.Text;
        ViewModel.CategoryFilter = CategoryFilter.Text;
        ViewModel.FavoritesOnly = FavoriteFilter.IsChecked == true;
        ViewModel.Descending = DescendingFilter.IsChecked == true;
        await ViewModel.RefreshAsync();
        UpdateEmptyStates();
    }

    private void UpdateEmptyStates()
    {
        if (HistoryList.Visibility == Visibility.Visible)
        {
            HistoryEmptyState.Visibility = ViewModel.RecentOperations.Count == 0
                ? Visibility.Visible
                : Visibility.Collapsed;
            EmptyState.Visibility = Visibility.Collapsed;
            return;
        }

        EmptyState.Visibility = ViewModel.Files.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        HistoryEmptyState.Visibility = Visibility.Collapsed;
    }
}
