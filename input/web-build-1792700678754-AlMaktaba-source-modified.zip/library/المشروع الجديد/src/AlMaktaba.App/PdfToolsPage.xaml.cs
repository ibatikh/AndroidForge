using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Windows.ApplicationModel.DataTransfer;
using Windows.Storage;
using AlMaktaba.Core;
using Microsoft.UI.Xaml.Media.Imaging;

namespace AlMaktaba.App;

public sealed partial class PdfToolsPage : Page
{
    public PdfToolsViewModel ViewModel { get; } = App.Services.GetRequiredService<PdfToolsViewModel>();

    public PdfToolsPage()
    {
        InitializeComponent();
        DataContext = ViewModel;
    }

    private async void ChooseImages_Click(object sender, RoutedEventArgs e)
    {
        var paths = await PickerService.PickFilesAsync(".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff");
        ViewModel.SetImages(paths);
        ImagesSummary.Text = paths.Count == 0 ? "لم يتم اختيار صور" : $"تم اختيار {paths.Count} صورة";
        ViewModel.DiscardPdfPreview();
        ClearPdfPreviewUi();
    }

    private void ImagePdfOptions_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (ImagePdfPaperSelector?.SelectedItem is ComboBoxItem paper &&
            Enum.TryParse<ImagePdfPaperSize>(paper.Tag?.ToString(), out var paperSize))
            ViewModel.ImagePdfPaperSize = paperSize;
        if (ImagePdfOrientationSelector?.SelectedItem is ComboBoxItem orientation &&
            Enum.TryParse<ImagePdfOrientation>(orientation.Tag?.ToString(), out var pageOrientation))
            ViewModel.ImagePdfOrientation = pageOrientation;
        if (ImagePdfOrderingSelector?.SelectedItem is ComboBoxItem order &&
            Enum.TryParse<ImagePdfOrdering>(order.Tag?.ToString(), out var ordering))
            ViewModel.ImagePdfOrdering = ordering;
        if (ImagePdfQualitySelector?.SelectedItem is ComboBoxItem quality &&
            Enum.TryParse<ImagePdfQuality>(quality.Tag?.ToString(), out var imageQuality))
            ViewModel.ImagePdfQuality = imageQuality;
    }

    private async void ChoosePdf_Click(object sender, RoutedEventArgs e)
    {
        var paths = await PickerService.PickFilesAsync(".pdf");
        if (paths.Count > 0)
        {
            ViewModel.SetPdf(paths[0]);
            PdfSummary.Text = paths[0];
            ClearPdfPreviewUi();
        }
    }

    private async void ChooseOutputFolder_Click(object sender, RoutedEventArgs e)
    {
        var path = await PickerService.PickFolderAsync();
        if (path is not null)
            ViewModel.SetOutputDirectory(path);
    }

    private void ClearOutputFolder_Click(object sender, RoutedEventArgs e) =>
        ViewModel.SetOutputDirectory(null);

    private void OutputFormat_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (OutputFormatSelector.SelectedItem is ComboBoxItem item &&
            Enum.TryParse<ImageOutputFormat>(item.Tag?.ToString(), out var format))
        {
            ViewModel.OutputFormat = format;
            JpegQualityPanel.Visibility = format == ImageOutputFormat.Jpeg
                ? Visibility.Visible
                : Visibility.Collapsed;
        }
    }

    private void JpegQuality_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (JpegQualitySelector.SelectedItem is ComboBoxItem item &&
            int.TryParse(item.Tag?.ToString(), out var quality))
            ViewModel.JpegQuality = quality;
    }

    private async void ChooseDocx_Click(object sender, RoutedEventArgs e)
    {
        var paths = await PickerService.PickFilesAsync(".docx");
        if (paths.Count > 0)
        {
            ViewModel.SetDocx(paths[0]);
            DocxSummary.Text = paths[0];
            ViewModel.DiscardPdfPreview();
            ClearPdfPreviewUi();
        }
    }

    private async void RenderPage_Click(object sender, RoutedEventArgs e)
    {
        if (!TryGetInteger(PageNumberInput.Value, out var page) || page < 1)
        {
            ViewModel.Status = "أدخل رقم صفحة صحيحًا يبدأ من 1.";
            return;
        }
        ViewModel.SetPdfPage(page);
        await ViewModel.RenderPdfPageCommand.ExecuteAsync(null);
    }

    private async void PreviewPdfPage_Click(object sender, RoutedEventArgs e)
    {
        if (!TryGetInteger(PageNumberInput.Value, out var page) || page < 1)
        {
            ViewModel.Status = "أدخل رقم صفحة صحيحًا يبدأ من 1.";
            return;
        }

        ViewModel.SetPdfPage(page);
        await ViewModel.PreviewPdfPageAsync();
        await DisplayPdfPreviewAsync();
    }

    private void PdfPreviewSettings_ValueChanged(
        NumberBox sender, NumberBoxValueChangedEventArgs args)
    {
        ViewModel.DiscardPdfPreview();
        ClearPdfPreviewUi();
    }

    private async void RenderRange_Click(object sender, RoutedEventArgs e)
    {
        if (!TryGetInteger(RangeStartInput.Value, out var first) ||
            !TryGetInteger(RangeEndInput.Value, out var last) ||
            first < 1 || last < first)
        {
            ViewModel.Status = "أدخل نطاق صفحات صحيحًا يبدأ من 1 وينتهي بعد صفحة البداية أو عندها.";
            return;
        }
        await ViewModel.RenderPageRangeAsync(first, last);
    }

    private static bool TryGetInteger(double value, out int result)
    {
        result = 0;
        if (!double.IsFinite(value) || value < int.MinValue || value > int.MaxValue ||
            Math.Truncate(value) != value)
            return false;
        result = (int)value;
        return true;
    }

    private void Page_DragOver(object sender, DragEventArgs e)
    {
        if (!ViewModel.CanRun)
        {
            e.AcceptedOperation = DataPackageOperation.None;
            return;
        }
        e.AcceptedOperation = DataPackageOperation.Copy;
        e.DragUIOverride.Caption = "فتح أداة المستند المناسبة";
    }

    private async void Page_Drop(object sender, DragEventArgs e)
    {
        if (!ViewModel.CanRun) return;
        if (!e.DataView.Contains(StandardDataFormats.StorageItems)) return;
        ViewModel.DiscardPdfPreview();
        ClearPdfPreviewUi();
        var items = await e.DataView.GetStorageItemsAsync();
        var files = items.OfType<StorageFile>().ToList();
        var images = files.Where(file => new[] { ".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff" }
            .Contains(System.IO.Path.GetExtension(file.Name), StringComparer.OrdinalIgnoreCase)).ToList();
        if (images.Count > 0)
        {
            ViewModel.SetImages(images.Select(file => file.Path));
            ImagesSummary.Text = $"تم إسقاط {images.Count} صورة";
            return;
        }

        var pdf = files.FirstOrDefault(file => System.IO.Path.GetExtension(file.Name).Equals(".pdf", StringComparison.OrdinalIgnoreCase));
        if (pdf is not null)
        {
            ViewModel.SetPdf(pdf.Path);
            PdfSummary.Text = pdf.Path;
            ClearPdfPreviewUi();
            return;
        }

        var docx = files.FirstOrDefault(file => System.IO.Path.GetExtension(file.Name).Equals(".docx", StringComparison.OrdinalIgnoreCase));
        if (docx is not null)
        {
            ViewModel.SetDocx(docx.Path);
            DocxSummary.Text = docx.Path;
            return;
        }

        ViewModel.Status = "نوع الملف غير مدعوم في أدوات PDF وWord.";
    }

    private async Task DisplayPdfPreviewAsync()
    {
        var path = ViewModel.PdfPreviewPath;
        if (string.IsNullOrWhiteSpace(path) || !System.IO.File.Exists(path))
        {
            ClearPdfPreviewUi();
            return;
        }

        var file = await StorageFile.GetFileFromPathAsync(path);
        using var stream = await file.OpenReadAsync();
        var bitmap = new BitmapImage();
        await bitmap.SetSourceAsync(stream);
        PdfPagePreviewImage.Source = bitmap;
        PdfPagePreviewImage.Visibility = Visibility.Visible;
    }

    private void ClearPdfPreviewUi()
    {
        PdfPagePreviewImage.Source = null;
        PdfPagePreviewImage.Visibility = Visibility.Collapsed;
    }
}
