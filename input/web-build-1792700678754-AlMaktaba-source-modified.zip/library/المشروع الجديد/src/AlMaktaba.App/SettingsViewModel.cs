using AlMaktaba.Core;
using AlMaktaba.Infrastructure;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Extensions.Logging;

namespace AlMaktaba.App;

public partial class SettingsViewModel(
    AppPaths paths, IFileRepository repository, IModelCatalog models,
    LibraryBackupService backups, ILogger<SettingsViewModel> logger) : ObservableObject
{
    [ObservableProperty] private string status = "لا توجد خدمات سحابية أو اتصالات شبكة داخل التطبيق.";
    [ObservableProperty] private string storageSummary = "";

    [RelayCommand]
    public async Task RefreshAsync()
    {
        try
        {
            await repository.InitializeAsync();
            var allFiles = await repository.SearchAsync(new LibraryQuery());
            var modelList = await models.ListAsync();
            var bytes = allFiles.Sum(file => file.SizeBytes);
            StorageSummary = $"الملفات: {allFiles.Count} | الحجم: {FormatBytes(bytes)} | النماذج: {modelList.Count}";
            Status = $"قاعدة البيانات: {paths.Database}\nالبيانات المحلية: {paths.Root}";
        }
        catch (Exception exception)
        {
            logger.LogError(exception, "Diagnostics refresh failed.");
            Status = "تعذر قراءة حالة قاعدة البيانات أو المكتبة.";
        }
    }

    [RelayCommand]
    public async Task CreateBackupAsync(string destinationPath)
    {
        try
        {
            var result = await backups.ExportAsync(destinationPath);
            Status = $"تم إنشاء نسخة احتياطية محلية: {result}";
        }
        catch (Exception exception)
        {
            logger.LogError(exception, "Backup export failed.");
            Status = "تعذر إنشاء النسخة الاحتياطية.";
        }
    }

    [RelayCommand]
    public async Task RestoreBackupAsync(string sourcePath)
    {
        try
        {
            var progress = new Progress<BackupRestoreProgress>(update =>
            {
                Status = update.Stage switch
                {
                    BackupRestoreStage.CopyingLibraryFiles =>
                        $"استعادة ملفات المكتبة: {update.CompletedFiles} من {update.TotalFiles}",
                    BackupRestoreStage.DatabaseReplaced => "التحقق من قاعدة البيانات المستعادة…",
                    BackupRestoreStage.Completed => "اكتملت استعادة النسخة الاحتياطية.",
                    _ => Status
                };
            });
            await backups.ImportAsync(sourcePath, progress: progress);
            Status = "تم استيراد النسخة. أعد تشغيل التطبيق لتحديث القائمة.";
        }
        catch (Exception exception)
        {
            logger.LogError(exception, "Backup import failed.");
            Status = "تعذر استيراد النسخة الاحتياطية.";
        }
    }

    private static string FormatBytes(long value)
    {
        string[] units = ["بايت", "ك.ب", "م.ب", "غ.ب"];
        double amount = value;
        var unit = 0;
        while (amount >= 1024 && unit < units.Length - 1) { amount /= 1024; unit++; }
        return $"{amount:0.##} {units[unit]}";
    }
}
