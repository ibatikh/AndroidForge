using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Windows.ApplicationModel.DataTransfer;
using Windows.Storage;
using Microsoft.UI.Xaml.Media.Imaging;
using AlMaktaba.Core;

namespace AlMaktaba.App;

public sealed partial class TemplatesPage : Page
{
    public TemplatesViewModel ViewModel { get; } = App.Services.GetRequiredService<TemplatesViewModel>();

    public TemplatesPage()
    {
        InitializeComponent();
        DataContext = ViewModel;
    }

    private async void ChoosePhotos_Click(object sender, RoutedEventArgs e)
    {
        var paths = await PickerService.PickFilesAsync(".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff");
        ViewModel.SetPhotos(paths);
        PhotoSummary.Text = paths.Count == 0 ? "لم يتم اختيار صور" : $"تم اختيار {paths.Count} صورة";
        PreviewImage.Source = null;
        PreviewImage.Visibility = Visibility.Collapsed;
    }

    private void TemplateSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (TemplateSelector.SelectedItem is AlMaktaba.Core.PhotoTemplate template)
        {
            ViewModel.SelectedTemplate = template;
            ClearPreview();
        }
    }

    private void DpiSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (DpiSelector.SelectedItem is ComboBoxItem item && int.TryParse(item.Tag?.ToString(), out var dpi))
        {
            ViewModel.Dpi = dpi;
            ClearPreview();
        }
    }

    private void CropAnchorSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (CropAnchorSelector.SelectedItem is ComboBoxItem item &&
            Enum.TryParse<PhotoCropAnchor>(item.Tag?.ToString(), out var anchor))
        {
            ViewModel.CropAnchor = anchor;
            ClearPreview();
        }
    }

    private void OutputFormatSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (OutputFormatSelector.SelectedItem is ComboBoxItem item &&
            Enum.TryParse<ImageOutputFormat>(item.Tag?.ToString(), out var format))
        {
            ViewModel.OutputFormat = format;
            JpegQualityPanel.Visibility = format == ImageOutputFormat.Jpeg
                ? Visibility.Visible
                : Visibility.Collapsed;
            ClearPreview();
        }
    }

    private void JpegQualitySelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (JpegQualitySelector.SelectedItem is ComboBoxItem item &&
            int.TryParse(item.Tag?.ToString(), out var quality))
        {
            ViewModel.JpegQuality = quality;
            ClearPreview();
        }
    }

    private void Page_DragOver(object sender, DragEventArgs e)
    {
        if (!ViewModel.CanRun)
        {
            e.AcceptedOperation = DataPackageOperation.None;
            return;
        }
        e.AcceptedOperation = DataPackageOperation.Copy;
        e.DragUIOverride.Caption = "إضافة صور إلى معاينة القالب";
    }

    private async void Page_Drop(object sender, DragEventArgs e)
    {
        if (!ViewModel.CanRun) return;
        if (!e.DataView.Contains(StandardDataFormats.StorageItems)) return;
        var items = await e.DataView.GetStorageItemsAsync();
        var paths = items.OfType<StorageFile>()
            .Where(file => new[] { ".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff" }
                .Contains(System.IO.Path.GetExtension(file.Name), StringComparer.OrdinalIgnoreCase))
            .Select(file => file.Path)
            .ToList();
        ViewModel.SetPhotos(paths);
        PhotoSummary.Text = paths.Count == 0 ? "لم تُسقط صور مدعومة" : $"تم إسقاط {paths.Count} صورة";
        PreviewImage.Source = null;
        PreviewImage.Visibility = Visibility.Collapsed;
    }

    private async void Preview_Click(object sender, RoutedEventArgs e)
    {
        await ViewModel.PreviewCommand.ExecuteAsync(null);
        if (string.IsNullOrWhiteSpace(ViewModel.PreviewPath) || !System.IO.File.Exists(ViewModel.PreviewPath))
            return;
        var file = await StorageFile.GetFileFromPathAsync(ViewModel.PreviewPath);
        using var stream = await file.OpenReadAsync();
        var bitmap = new BitmapImage();
        await bitmap.SetSourceAsync(stream);
        PreviewImage.Source = bitmap;
        PreviewImage.Visibility = Visibility.Visible;
    }

    private void ClearPreview()
    {
        ViewModel.PreviewPath = null;
        PreviewImage.Source = null;
        PreviewImage.Visibility = Visibility.Collapsed;
    }
}
