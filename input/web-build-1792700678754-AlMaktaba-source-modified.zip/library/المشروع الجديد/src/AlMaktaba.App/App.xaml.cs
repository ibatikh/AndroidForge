using AlMaktaba.Core;
using AlMaktaba.Infrastructure;
using AlMaktaba.Processing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.UI.Xaml;

namespace AlMaktaba.App;

public partial class App : Application
{
    public static IServiceProvider Services { get; private set; } = null!;
    public static MainWindow MainWindow { get; private set; } = null!;

    public App()
    {
        InitializeComponent();
        var paths = new AppPaths();
        paths.EnsureCreated();
        var services = new ServiceCollection();
        services.AddSingleton(paths);
        services.AddSingleton<IFileRepository, SqliteFileRepository>();
        services.AddSingleton<IJobRepository>(provider =>
            (IJobRepository)provider.GetRequiredService<IFileRepository>());
        services.AddSingleton<ILocalLibraryService, LocalLibraryService>();
        services.AddSingleton<IModelCatalog, LocalModelCatalog>();
        services.AddSingleton<IImageProcessor, ImageProcessingService>();
        services.AddSingleton<ImagePdfWriter>();
        services.AddSingleton<PdfRasterizer>();
        services.AddSingleton<ImageThumbnailService>();
        services.AddSingleton<DocumentProcessingService>();
        services.AddSingleton<LibraryBackupService>();
        services.AddSingleton<TemporaryFilesCleanupService>();
        services.AddSingleton<LocalJobQueue>();
        services.AddSingleton<LibraryViewModel>();
        services.AddSingleton<ImageToolsViewModel>();
        services.AddSingleton<PdfToolsViewModel>();
        services.AddSingleton<ModelsViewModel>();
        services.AddSingleton<TemplatesViewModel>();
        services.AddSingleton<SettingsViewModel>();
        services.AddSingleton<JobsViewModel>();
        services.AddLogging(builder =>
        {
            builder.SetMinimumLevel(LogLevel.Information);
            builder.AddProvider(new LocalFileLoggerProvider(Path.Combine(paths.Logs, "app.log")));
        });
        Services = services.BuildServiceProvider();
    }

    protected override async void OnLaunched(LaunchActivatedEventArgs args)
    {
        try
        {
            await Services.GetRequiredService<IFileRepository>().InitializeAsync();
            await Services.GetRequiredService<LocalJobQueue>().InitializeAsync();
            await Services.GetRequiredService<TemporaryFilesCleanupService>().CleanStaleAsync();
            MainWindow = new MainWindow();
            MainWindow.Activate();
        }
        catch (Exception exception)
        {
            MainWindow = new MainWindow();
            MainWindow.Activate();
            await MainWindow.ShowStartupErrorAsync(exception);
        }
    }
}
