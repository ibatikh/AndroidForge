using Microsoft.Extensions.DependencyInjection;
using Microsoft.UI.Xaml.Controls;

namespace AlMaktaba.App;

public sealed partial class JobsPage : Page
{
    public JobsViewModel ViewModel { get; }

    public JobsPage()
    {
        InitializeComponent();
        ViewModel = App.Services.GetRequiredService<JobsViewModel>();
    }
}
