using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;

namespace AlMaktaba.App;

public sealed partial class SettingsPage : Page
{
    public SettingsViewModel ViewModel { get; } = App.Services.GetRequiredService<SettingsViewModel>();

    public SettingsPage()
    {
        InitializeComponent();
        DataContext = ViewModel;
        Loaded += async (_, _) => await ViewModel.RefreshAsync();
    }

    private void ThemeSelector_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (ThemeSelector.SelectedItem is not ComboBoxItem item ||
            App.MainWindow.Content is not FrameworkElement root)
            return;
        root.RequestedTheme = item.Tag?.ToString() switch
        {
            "Light" => ElementTheme.Light,
            "Dark" => ElementTheme.Dark,
            _ => ElementTheme.Default
        };
    }

    private async void CreateBackup_Click(object sender, RoutedEventArgs e)
    {
        var path = await PickerService.PickSaveFileAsync(".zip", $"AlMaktaba-backup-{DateTime.Now:yyyyMMdd}");
        if (!string.IsNullOrWhiteSpace(path))
            await ViewModel.CreateBackupAsync(path);
    }

    private async void RestoreBackup_Click(object sender, RoutedEventArgs e)
    {
        var files = await PickerService.PickFilesAsync(".zip");
        if (files.Count == 0) return;
        var confirm = new ContentDialog
        {
            XamlRoot = Content.XamlRoot,
            Title = "استيراد النسخة الاحتياطية؟",
            Content = "ستُدمج ملفات المكتبة، وستُستبدل قاعدة البيانات الحالية. أنشئ نسخة احتياطية قبل المتابعة.",
            PrimaryButtonText = "استيراد",
            CloseButtonText = "إلغاء",
            DefaultButton = ContentDialogButton.Close
        };
        if (await confirm.ShowAsync() == ContentDialogResult.Primary)
            await ViewModel.RestoreBackupAsync(files[0]);
    }

    private async void Refresh_Click(object sender, RoutedEventArgs e) => await ViewModel.RefreshAsync();
}
