using Windows.Storage.Pickers;
using WinRT.Interop;

namespace AlMaktaba.App;

internal static class PickerService
{
    public static async Task<IReadOnlyList<string>> PickFilesAsync(params string[] fileTypes)
    {
        var picker = new FileOpenPicker();
        foreach (var type in fileTypes)
            picker.FileTypeFilter.Add(type);
        InitializeWithWindow.Initialize(picker, WindowNative.GetWindowHandle(App.MainWindow));
        var files = await picker.PickMultipleFilesAsync();
        return files.Select(file => file.Path).ToList();
    }

    public static async Task<string?> PickSaveFileAsync(string extension, string suggestedName)
    {
        var picker = new FileSavePicker();
        picker.SuggestedFileName = suggestedName;
        picker.FileTypeChoices.Add(extension.TrimStart('.').ToUpperInvariant(), [extension]);
        InitializeWithWindow.Initialize(picker, WindowNative.GetWindowHandle(App.MainWindow));
        var file = await picker.PickSaveFileAsync();
        return file?.Path;
    }

    public static async Task<string?> PickFolderAsync()
    {
        var picker = new FolderPicker();
        picker.FileTypeFilter.Add("*");
        InitializeWithWindow.Initialize(picker, WindowNative.GetWindowHandle(App.MainWindow));
        var folder = await picker.PickSingleFolderAsync();
        return folder?.Path;
    }
}
