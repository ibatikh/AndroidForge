using System.Security.Cryptography;
using System.Text.Json;
using AlMaktaba.Core;
using Microsoft.ML.OnnxRuntime;

namespace AlMaktaba.Infrastructure;

public sealed class LocalModelCatalog(AppPaths paths) : IModelCatalog
{
    private string ManifestPath => Path.Combine(paths.Config, "models.json");

    public async Task<IReadOnlyList<LocalModel>> ListAsync(CancellationToken cancellationToken = default)
    {
        paths.EnsureCreated();
        var models = await ReadManifestAsync(cancellationToken);
        return models.Where(model => File.Exists(model.Path)).ToList();
    }

    public async Task<LocalModel> ImportAsync(string modelPath, LocalModelPurpose purpose, CancellationToken cancellationToken = default)
    {
        var source = Path.GetFullPath(modelPath);
        var file = new FileInfo(source);
        if (!file.Exists || !file.Extension.Equals(".onnx", StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("يمكن استيراد ملفات ONNX فقط.");
        if (file.Length <= 0 || file.Length > 2L * 1024 * 1024 * 1024)
            throw new InvalidDataException("حجم النموذج غير مدعوم. الحد الأقصى 2 غيغابايت.");

        // Constructing an ONNX session validates the model graph without contacting a service.
        using (var session = new InferenceSession(source))
        {
            if (session.InputMetadata.Count == 0 || session.OutputMetadata.Count == 0)
                throw new InvalidDataException("النموذج لا يحتوي على مدخلات ومخرجات صالحة.");
        }

        paths.EnsureCreated();
        var destinationDirectory = Path.Combine(paths.Models, purpose switch
        {
            LocalModelPurpose.BackgroundRemoval => "background_removal",
            LocalModelPurpose.Enhancement => "enhancement",
            _ => "optional_ai"
        });
        Directory.CreateDirectory(destinationDirectory);
        var id = Guid.NewGuid().ToString("N");
        var destination = Path.Combine(destinationDirectory, $"{id}.onnx");
        await using (var input = File.OpenRead(source))
        await using (var output = new FileStream(destination, FileMode.CreateNew, FileAccess.Write, FileShare.None, 81920, true))
            await input.CopyToAsync(output, cancellationToken);

        await using var modelStream = File.OpenRead(destination);
        var model = new LocalModel(id, SafeFileNames.Sanitize(file.Name), purpose, destination,
            file.Length, Convert.ToHexString(await SHA256.HashDataAsync(modelStream, cancellationToken)),
            "Validated ONNX graph; feature-specific inference is not enabled until a supported model profile exists.",
            DateTimeOffset.UtcNow);
        var models = (await ReadManifestAsync(cancellationToken)).ToList();
        models.Add(model);
        await WriteManifestAsync(models, cancellationToken);
        return model;
    }

    public async Task DeleteAsync(string id, CancellationToken cancellationToken = default)
    {
        var models = (await ReadManifestAsync(cancellationToken)).ToList();
        var model = models.SingleOrDefault(x => x.Id == id)
            ?? throw new FileNotFoundException("النموذج غير موجود.");
        var full = Path.GetFullPath(model.Path);
        var modelsRoot = Path.GetFullPath(paths.Models) + Path.DirectorySeparatorChar;
        if (!full.StartsWith(modelsRoot, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("مسار النموذج خارج مجلد النماذج.");
        if (File.Exists(full))
            File.Delete(full);
        models.Remove(model);
        await WriteManifestAsync(models, cancellationToken);
    }

    private async Task<IReadOnlyList<LocalModel>> ReadManifestAsync(CancellationToken cancellationToken)
    {
        if (!File.Exists(ManifestPath))
            return [];
        await using var stream = File.OpenRead(ManifestPath);
        return await JsonSerializer.DeserializeAsync<List<LocalModel>>(stream, cancellationToken: cancellationToken) ?? [];
    }

    private async Task WriteManifestAsync(IReadOnlyList<LocalModel> models, CancellationToken cancellationToken)
    {
        Directory.CreateDirectory(paths.Config);
        var temp = ManifestPath + ".tmp";
        await using (var stream = new FileStream(temp, FileMode.Create, FileAccess.Write, FileShare.None, 4096, true))
            await JsonSerializer.SerializeAsync(stream, models, cancellationToken: cancellationToken);
        File.Move(temp, ManifestPath, true);
    }
}
