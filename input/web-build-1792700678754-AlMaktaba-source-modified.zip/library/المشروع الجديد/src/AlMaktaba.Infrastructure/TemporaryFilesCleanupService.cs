using AlMaktaba.Core;
using Microsoft.Extensions.Logging;

namespace AlMaktaba.Infrastructure;

public sealed class TemporaryFilesCleanupService(AppPaths paths, ILogger<TemporaryFilesCleanupService> logger)
{
    private static readonly TimeSpan DefaultRetention = TimeSpan.FromHours(24);

    public Task<TemporaryCleanupSummary> CleanStaleAsync(
        TimeSpan? retention = null,
        CancellationToken cancellationToken = default) =>
        Task.Run(() =>
        {
            paths.EnsureCreated();
            var cutoff = DateTime.UtcNow - (retention ?? DefaultRetention);
            var removed = 0;
            long bytesRemoved = 0;

            foreach (var entry in Directory.EnumerateFileSystemEntries(paths.Temp))
            {
                cancellationToken.ThrowIfCancellationRequested();
                if (Path.GetFileName(entry).Equals("pending-delete", StringComparison.OrdinalIgnoreCase))
                    continue;
                try
                {
                    if ((File.GetAttributes(entry) & FileAttributes.ReparsePoint) != 0)
                        continue;
                    var info = InspectTree(entry);
                    if (info.ContainsReparsePoint || info.LastWriteUtc >= cutoff)
                        continue;
                    if (Directory.Exists(entry))
                        Directory.Delete(entry, recursive: true);
                    else
                        File.Delete(entry);
                    removed++;
                    bytesRemoved = checked(bytesRemoved + info.Bytes);
                }
                catch (Exception exception) when (exception is IOException or UnauthorizedAccessException)
                {
                    logger.LogWarning(exception, "Could not remove a stale temporary item.");
                }
            }

            logger.LogInformation(
                "Temporary cleanup removed {ItemCount} old items and {ByteCount} bytes.",
                removed, bytesRemoved);
            return new TemporaryCleanupSummary(removed, bytesRemoved);
        }, cancellationToken);

    private static TreeInfo InspectTree(string path)
    {
        var latest = File.GetLastWriteTimeUtc(path);
        long bytes = 0;
        var containsReparsePoint = false;
        var stack = new Stack<string>();
        stack.Push(path);
        while (stack.Count > 0)
        {
            var current = stack.Pop();
            var attributes = File.GetAttributes(current);
            if ((attributes & FileAttributes.ReparsePoint) != 0)
            {
                containsReparsePoint = true;
                continue;
            }
            var writeTime = File.GetLastWriteTimeUtc(current);
            if (writeTime > latest)
                latest = writeTime;
            if ((attributes & FileAttributes.Directory) == 0)
            {
                bytes = checked(bytes + new FileInfo(current).Length);
                continue;
            }

            foreach (var child in Directory.EnumerateFileSystemEntries(current))
                stack.Push(child);
        }
        return new TreeInfo(latest, bytes, containsReparsePoint);
    }

    private sealed record TreeInfo(DateTime LastWriteUtc, long Bytes, bool ContainsReparsePoint);
}

public sealed record TemporaryCleanupSummary(int RemovedItems, long BytesRemoved);
