using System.Threading.Channels;
using AlMaktaba.Core;
using Microsoft.Extensions.Logging;

namespace AlMaktaba.Infrastructure;

public sealed class LocalJobQueue : IAsyncDisposable
{
    private const int RetainedJobCount = 100;
    private readonly Channel<WorkItem> _queue = Channel.CreateBounded<WorkItem>(
        new BoundedChannelOptions(4)
        {
            FullMode = BoundedChannelFullMode.Wait,
            SingleReader = true,
            SingleWriter = false
        });
    private readonly ILogger<LocalJobQueue> _logger;
    private readonly IJobRepository _jobRepository;
    private readonly Task _worker;
    private readonly Dictionary<string, CancellationTokenSource> _running = new();
    private readonly Dictionary<string, ProcessingJob> _jobs = new();
    private readonly object _sync = new();
    private bool _initialized;

    public event EventHandler<ProcessingJob>? JobChanged;

    public LocalJobQueue(IJobRepository jobRepository, ILogger<LocalJobQueue> logger)
    {
        _jobRepository = jobRepository;
        _logger = logger;
        _worker = Task.Run(WorkAsync);
    }

    public async Task InitializeAsync(CancellationToken cancellationToken = default)
    {
        lock (_sync)
        {
            if (_initialized)
                return;
        }

        await _jobRepository.MarkInterruptedJobsAsync(DateTimeOffset.UtcNow, cancellationToken);
        var recentJobs = await _jobRepository.GetRecentJobsAsync(RetainedJobCount, cancellationToken);
        lock (_sync)
        {
            foreach (var job in recentJobs)
                _jobs[job.Id] = job;
            _initialized = true;
        }
    }

    public IReadOnlyList<ProcessingJob> Snapshot()
    {
        lock (_sync)
            return _jobs.Values.OrderByDescending(job => job.CreatedAt).ToArray();
    }

    public Task<string> EnqueueAsync(
        string name,
        string inputPath,
        Func<IProgress<double>, CancellationToken, Task<string>> operation,
        CancellationToken cancellationToken = default) =>
        EnqueueCoreAsync(name, inputPath, operation, completion: null, cancellationToken);

    public async Task<string> RunAsync(
        string name,
        string inputPath,
        Func<IProgress<double>, CancellationToken, Task<string>> operation,
        CancellationToken cancellationToken = default)
    {
        var completion = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
        var id = await EnqueueCoreAsync(name, inputPath, operation, completion, cancellationToken);
        try
        {
            return await completion.Task.WaitAsync(cancellationToken);
        }
        catch (OperationCanceledException)
        {
            Cancel(id);
            throw;
        }
    }

    public bool Cancel(string id)
    {
        lock (_sync)
        {
            if (!_running.TryGetValue(id, out var cancellation))
                return false;
            cancellation.Cancel();
            return true;
        }
    }

    public async ValueTask DisposeAsync()
    {
        _queue.Writer.TryComplete();
        lock (_sync)
            foreach (var cancellation in _running.Values)
                cancellation.Cancel();
        try { await _worker; }
        catch (OperationCanceledException) { }

        lock (_sync)
        {
            foreach (var cancellation in _running.Values)
                cancellation.Dispose();
            _running.Clear();
        }
    }

    private async Task<string> EnqueueCoreAsync(
        string name,
        string inputPath,
        Func<IProgress<double>, CancellationToken, Task<string>> operation,
        TaskCompletionSource<string>? completion,
        CancellationToken cancellationToken)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(name);
        ArgumentException.ThrowIfNullOrWhiteSpace(inputPath);
        ArgumentNullException.ThrowIfNull(operation);
        cancellationToken.ThrowIfCancellationRequested();
        lock (_sync)
        {
            if (!_initialized)
                throw new InvalidOperationException("يجب تهيئة سجل المهام قبل بدء المعالجة.");
        }

        var id = Guid.NewGuid().ToString("N");
        var job = new ProcessingJob(id, name, inputPath, null, JobState.Queued, 0, null,
            DateTimeOffset.UtcNow, null);
        await _jobRepository.SaveJobAsync(job, cancellationToken);
        var linkedCancellation = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        lock (_sync)
        {
            _running.Add(id, linkedCancellation);
            _jobs.Add(id, job);
        }
        Publish(job);

        try
        {
            await _queue.Writer.WriteAsync(
                new WorkItem(job, operation, linkedCancellation, completion),
                cancellationToken);
            return id;
        }
        catch (Exception exception)
        {
            lock (_sync)
                _running.Remove(id);
            linkedCancellation.Dispose();
            var terminal = job with
            {
                State = cancellationToken.IsCancellationRequested ? JobState.Cancelled : JobState.Failed,
                Error = cancellationToken.IsCancellationRequested ? null : exception.Message,
                CompletedAt = DateTimeOffset.UtcNow
            };
            await TryPersistAsync(terminal);
            Publish(terminal);
            throw;
        }
    }

    private async Task WorkAsync()
    {
        await foreach (var item in _queue.Reader.ReadAllAsync())
        {
            var job = item.Job;
            string? outputPath = null;
            Exception? failure = null;
            var cancelled = false;
            try
            {
                if (item.Cancellation.IsCancellationRequested)
                {
                    cancelled = true;
                    job = job with { State = JobState.Cancelled, CompletedAt = DateTimeOffset.UtcNow };
                }
                else
                {
                    job = job with { State = JobState.Processing, Progress = 0 };
                    await TryPersistAsync(job);
                    Publish(job);
                    var progress = new InlineProgress<double>(value =>
                    {
                        job = job with { Progress = Math.Clamp(value, 0, 1) };
                        Publish(job);
                    });

                    outputPath = await item.Operation(progress, item.Cancellation.Token);
                    if (item.Cancellation.IsCancellationRequested)
                    {
                        cancelled = true;
                        job = job with { State = JobState.Cancelled, CompletedAt = DateTimeOffset.UtcNow };
                    }
                    else
                    {
                        job = job with
                        {
                            OutputPath = outputPath,
                            State = JobState.Completed,
                            Progress = 1,
                            CompletedAt = DateTimeOffset.UtcNow
                        };
                    }
                }
            }
            catch (OperationCanceledException)
            {
                cancelled = true;
                job = job with { State = JobState.Cancelled, CompletedAt = DateTimeOffset.UtcNow };
            }
            catch (Exception exception)
            {
                failure = exception;
                _logger.LogError(exception, "Local processing job {JobId} failed.", job.Id);
                job = job with
                {
                    State = JobState.Failed,
                    Error = exception.Message,
                    CompletedAt = DateTimeOffset.UtcNow
                };
            }
            finally
            {
                if (job.State is JobState.Completed or JobState.Cancelled or JobState.Failed)
                {
                    await TryPersistAsync(job);
                    Publish(job);
                }
                if (cancelled)
                    item.Completion?.TrySetCanceled(item.Cancellation.Token);
                else if (failure is not null)
                    item.Completion?.TrySetException(failure);
                else
                    item.Completion?.TrySetResult(outputPath!);
                lock (_sync)
                {
                    if (_running.Remove(item.Job.Id, out var cancellation))
                        cancellation.Dispose();
                }
            }
        }
    }

    private async Task TryPersistAsync(ProcessingJob job)
    {
        try
        {
            await _jobRepository.SaveJobAsync(job, CancellationToken.None);
        }
        catch (Exception exception)
        {
            _logger.LogError(exception, "Could not persist local job {JobId}.", job.Id);
        }
    }

    private void Publish(ProcessingJob job)
    {
        lock (_sync)
        {
            _jobs[job.Id] = job;
            var excess = _jobs.Count - RetainedJobCount;
            if (excess > 0)
            {
                foreach (var oldJob in _jobs.Values
                             .Where(candidate => candidate.State is not (JobState.Queued or JobState.Processing))
                             .OrderBy(candidate => candidate.CreatedAt)
                             .Take(excess)
                             .ToArray())
                    _jobs.Remove(oldJob.Id);
            }
        }

        var handlers = JobChanged?.GetInvocationList();
        if (handlers is null)
            return;
        foreach (var handler in handlers.Cast<EventHandler<ProcessingJob>>())
        {
            try { handler(this, job); }
            catch (Exception exception)
            {
                _logger.LogWarning(exception, "A local job status observer failed.");
            }
        }
    }

    private sealed record WorkItem(
        ProcessingJob Job,
        Func<IProgress<double>, CancellationToken, Task<string>> Operation,
        CancellationTokenSource Cancellation,
        TaskCompletionSource<string>? Completion);

    private sealed class InlineProgress<T>(Action<T> report) : IProgress<T>
    {
        public void Report(T value) => report(value);
    }
}
