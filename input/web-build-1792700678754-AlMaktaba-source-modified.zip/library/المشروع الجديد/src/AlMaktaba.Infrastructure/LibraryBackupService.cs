using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using AlMaktaba.Core;
using Microsoft.Data.Sqlite;

namespace AlMaktaba.Infrastructure;

public sealed class LibraryBackupService(AppPaths paths)
{
    private const long MaximumBackupBytes = 4L * 1024 * 1024 * 1024;
    private const long MaximumEntryBytes = 1L * 1024 * 1024 * 1024;
    private const int MaximumEntryCount = 20_000;
    private static StringComparison PathComparison =>
        OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true
    };

    public async Task<string> ExportAsync(string targetZipPath, CancellationToken cancellationToken = default)
    {
        paths.EnsureCreated();
        var fullTargetPath = Path.GetFullPath(targetZipPath);
        var libraryRoot = Path.GetFullPath(paths.Library);
        var libraryPrefix = Path.EndsInDirectorySeparator(libraryRoot)
            ? libraryRoot
            : libraryRoot + Path.DirectorySeparatorChar;
        if (fullTargetPath.StartsWith(libraryPrefix, PathComparison))
            throw new InvalidDataException("اختر مكانًا للنسخة الاحتياطية خارج مجلد المكتبة.");

        var tempRoot = Path.Combine(paths.Temp, "backup-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(tempRoot);
        var dbSnapshot = Path.Combine(tempRoot, "app.db");
        var stagedArchive = Path.Combine(tempRoot, "backup.zip");
        try
        {
            await Task.Run(() =>
            {
                using var source = OpenDatabase(paths.Database, SqliteOpenMode.ReadWriteCreate);
                using var target = OpenDatabase(dbSnapshot, SqliteOpenMode.ReadWriteCreate);
                source.Open();
                target.Open();
                source.BackupDatabase(target);
            }, cancellationToken);

            var databaseBytes = new FileInfo(dbSnapshot).Length;
            if (databaseBytes > MaximumEntryBytes || databaseBytes > MaximumBackupBytes)
                throw new InvalidDataException("قاعدة البيانات تتجاوز الحد الآمن للنسخة الاحتياطية.");

            await using (var output = new FileStream(
                             stagedArchive, FileMode.CreateNew, FileAccess.Write, FileShare.None, 128 * 1024, true))
            {
                using var archive = new ZipArchive(output, ZipArchiveMode.Create, leaveOpen: true);
                long expandedBytes = databaseBytes;
                var entryCount = 1;
                await AddFileAsync(archive, dbSnapshot, "database/app.db", cancellationToken);
                foreach (var file in EnumerateLibraryFiles(paths.Library))
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    var info = new FileInfo(file);
                    expandedBytes = checked(expandedBytes + info.Length);
                    if (info.Length > MaximumEntryBytes || expandedBytes > MaximumBackupBytes)
                        throw new InvalidDataException("محتوى النسخة الاحتياطية يتجاوز الحد الآمن.");
                    if (entryCount >= MaximumEntryCount - 1)
                        throw new InvalidDataException("النسخة الاحتياطية تحتوي على عدد كبير جدًا من الملفات.");
                    entryCount++;
                    var relative = Path.GetRelativePath(paths.Library, file).Replace('\\', '/');
                    await AddFileAsync(archive, file, "library/" + relative, cancellationToken);
                }

                var metadata = JsonSerializer.SerializeToUtf8Bytes(new BackupManifest(
                    "AlMaktaba", 1, DateTimeOffset.UtcNow, ["database", "library"], ["credentials", "models"]), JsonOptions);
                var entry = archive.CreateEntry("backup.json", CompressionLevel.Optimal);
                await using var stream = entry.Open();
                await stream.WriteAsync(metadata, cancellationToken);
            }

            if (new FileInfo(stagedArchive).Length > MaximumBackupBytes)
                throw new InvalidDataException("حجم ملف النسخة المضغوط يتجاوز الحد المسموح.");

            var targetDirectory = Path.GetDirectoryName(fullTargetPath)!;
            Directory.CreateDirectory(targetDirectory);
            var targetStagingPath = Path.Combine(
                targetDirectory, $".{Path.GetFileName(fullTargetPath)}.{Guid.NewGuid():N}.tmp");
            try
            {
                await using (var input = new FileStream(
                                 stagedArchive, FileMode.Open, FileAccess.Read, FileShare.Read, 128 * 1024, true))
                await using (var destination = new FileStream(
                                 targetStagingPath, FileMode.CreateNew, FileAccess.Write, FileShare.None, 128 * 1024, true))
                {
                    await input.CopyToAsync(destination, cancellationToken);
                    await destination.FlushAsync(cancellationToken);
                }

                File.Move(targetStagingPath, fullTargetPath, overwrite: true);
            }
            finally
            {
                TryDeleteFile(targetStagingPath);
            }

            return fullTargetPath;
        }
        finally
        {
            TryDeleteDirectory(tempRoot);
        }
    }

    public async Task ImportAsync(
        string backupZipPath,
        CancellationToken cancellationToken = default,
        IProgress<BackupRestoreProgress>? progress = null)
    {
        var backup = new FileInfo(backupZipPath);
        if (!backup.Exists || backup.Length > MaximumBackupBytes)
            throw new InvalidDataException("ملف النسخة الاحتياطية غير موجود أو يتجاوز الحد المسموح.");

        paths.EnsureCreated();
        var staging = Path.Combine(paths.Temp, "restore-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(staging);
        var copiedFiles = new List<string>();
        var stagedDatabase = Path.Combine(staging, "database", "app.db");
        var previousDatabase = Path.Combine(staging, "previous-app.db");
        var hadDatabase = File.Exists(paths.Database);

        try
        {
            var manifest = await ExtractAndValidateArchiveAsync(backupZipPath, staging, cancellationToken);
            ValidateManifest(manifest);
            var referencedFiles = await ValidateDatabaseAsync(stagedDatabase, cancellationToken);
            var stagedLibrary = Path.Combine(staging, "library");
            ValidateDatabaseFileReferences(referencedFiles, stagedLibrary, paths.Library);

            // Reject every conflict before changing either the library or the active database.
            var filesToCopy = await PreflightLibraryMergeAsync(stagedLibrary, cancellationToken);
            if (hadDatabase)
                await CreateSnapshotAsync(paths.Database, previousDatabase, cancellationToken);

            try
            {
                for (var index = 0; index < filesToCopy.Count; index++)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    var (source, destination) = filesToCopy[index];
                    await CopyAtomicallyAsync(source, destination, paths.Library, cancellationToken);
                    copiedFiles.Add(destination);
                    progress?.Report(new BackupRestoreProgress(
                        BackupRestoreStage.CopyingLibraryFiles, index + 1, filesToCopy.Count));
                }

                await ReplaceDatabaseAsync(stagedDatabase, cancellationToken);
                progress?.Report(new BackupRestoreProgress(
                    BackupRestoreStage.DatabaseReplaced, filesToCopy.Count, filesToCopy.Count));
                await ValidateDatabaseAsync(paths.Database, cancellationToken);
                progress?.Report(new BackupRestoreProgress(
                    BackupRestoreStage.Completed, filesToCopy.Count, filesToCopy.Count));
            }
            catch (Exception restoreError)
            {
                Exception? rollbackError = null;
                try
                {
                    if (hadDatabase && File.Exists(previousDatabase))
                        await ReplaceDatabaseAsync(previousDatabase, CancellationToken.None);
                    else if (!hadDatabase)
                        DeleteDatabaseAndSidecars(paths.Database);
                }
                catch (Exception exception)
                {
                    rollbackError = exception;
                }

                foreach (var path in copiedFiles)
                    TryDeleteFile(path);
                if (rollbackError is not null)
                    throw new AggregateException("فشلت الاستعادة وتعذر إرجاع قاعدة البيانات إلى حالتها السابقة.", restoreError, rollbackError);
                throw;
            }
        }
        finally
        {
            TryDeleteDirectory(staging);
        }
    }

    private async Task<BackupManifest> ExtractAndValidateArchiveAsync(
        string backupZipPath, string staging, CancellationToken cancellationToken)
    {
        using var archive = ZipFile.OpenRead(backupZipPath);
        if (archive.Entries.Count > MaximumEntryCount)
            throw new InvalidDataException("النسخة الاحتياطية تحتوي على عدد كبير جدًا من الملفات.");

        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        long declaredBytes = 0;
        long copiedBytes = 0;
        var hasDatabase = false;
        var hasManifest = false;
        BackupManifest? manifest = null;

        foreach (var entry in archive.Entries)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var relative = NormalizeArchivePath(entry.FullName);
            if (!seen.Add(relative))
                throw new InvalidDataException("النسخة الاحتياطية تحتوي على أسماء ملفات مكررة.");

            var isDirectory = entry.Name.Length == 0;
            ValidateArchiveEntryType(relative, isDirectory);
            if (isDirectory)
                continue;
            if (entry.Length > MaximumEntryBytes || (declaredBytes += entry.Length) > MaximumBackupBytes)
                throw new InvalidDataException("محتوى النسخة الاحتياطية أكبر من الحد الآمن.");
            if (IsSymbolicLink(entry))
                throw new InvalidDataException("النسخة الاحتياطية تحتوي على رابط رمزي غير مسموح.");

            if (relative.Equals("backup.json", StringComparison.OrdinalIgnoreCase))
            {
                if (entry.Length > 64 * 1024)
                    throw new InvalidDataException("ملف تعريف النسخة الاحتياطية أكبر من الحد المسموح.");
                if (hasManifest)
                    throw new InvalidDataException("النسخة الاحتياطية تحتوي على ملف تعريف مكرر.");
                hasManifest = true;
                await using var input = entry.Open();
                using var metadata = new MemoryStream();
                await CopyEntryAsync(input, metadata, entry.Length, () => copiedBytes, value => copiedBytes = value,
                    cancellationToken);
                manifest = JsonSerializer.Deserialize<BackupManifest>(metadata.ToArray(), JsonOptions);
                continue;
            }

            if (relative.Equals("database/app.db", StringComparison.OrdinalIgnoreCase))
                hasDatabase = true;
            var destination = ResolveInside(staging, relative);
            Directory.CreateDirectory(Path.GetDirectoryName(destination)!);
            await using var source = entry.Open();
            await using var output = new FileStream(destination, FileMode.CreateNew, FileAccess.Write, FileShare.None, 81920, true);
            await CopyEntryAsync(source, output, entry.Length, () => copiedBytes, value => copiedBytes = value,
                cancellationToken);
        }

        if (!hasManifest || !hasDatabase || manifest is null)
            throw new InvalidDataException("الملف ليس نسخة احتياطية صالحة من المكتبة.");
        return manifest;
    }

    private static void ValidateArchiveEntryType(string path, bool isDirectory)
    {
        var allowed = path.Equals("backup.json", StringComparison.OrdinalIgnoreCase) ||
                      path.Equals("database", StringComparison.OrdinalIgnoreCase) ||
                      path.Equals("database/app.db", StringComparison.OrdinalIgnoreCase) ||
                      path.Equals("library", StringComparison.OrdinalIgnoreCase) ||
                      path.StartsWith("library/", StringComparison.OrdinalIgnoreCase);
        if (!allowed ||
            (path.Equals("backup.json", StringComparison.OrdinalIgnoreCase) && isDirectory) ||
            (path.Equals("database/app.db", StringComparison.OrdinalIgnoreCase) && isDirectory) ||
            (path.Equals("database", StringComparison.OrdinalIgnoreCase) && !isDirectory) ||
            (path.Equals("library", StringComparison.OrdinalIgnoreCase) && !isDirectory))
            throw new InvalidDataException("النسخة الاحتياطية تحتوي على ملف خارج البنية المسموحة.");
    }

    private static string NormalizeArchivePath(string entryName)
    {
        if (string.IsNullOrWhiteSpace(entryName) || entryName.IndexOf('\0') >= 0)
            throw new InvalidDataException("النسخة الاحتياطية تحتوي على اسم ملف غير صالح.");
        var normalized = entryName.Replace('\\', '/').TrimEnd('/');
        if (normalized.Length == 0 || normalized.StartsWith('/') || Path.IsPathRooted(normalized) ||
            normalized.Contains(':') ||
            normalized.Split('/').Any(segment => segment is "" or "." or ".."))
            throw new InvalidDataException("النسخة الاحتياطية تحتوي على مسار غير آمن.");
        return normalized;
    }

    private static bool IsSymbolicLink(ZipArchiveEntry entry) =>
        (((uint)entry.ExternalAttributes >> 16) & 0xF000) == 0xA000;

    private static void ValidateManifest(BackupManifest manifest)
    {
        if (!string.Equals(manifest.Product, "AlMaktaba", StringComparison.Ordinal) ||
            manifest.FormatVersion != 1 ||
            manifest.Includes is null ||
            !manifest.Includes.Contains("database", StringComparer.Ordinal) ||
            !manifest.Includes.Contains("library", StringComparer.Ordinal))
            throw new InvalidDataException("صيغة النسخة الاحتياطية أو إصدارها غير مدعوم.");
    }

    private static async Task<IReadOnlyList<string>> ValidateDatabaseAsync(
        string databasePath, CancellationToken cancellationToken)
    {
        if (!File.Exists(databasePath))
            throw new InvalidDataException("قاعدة البيانات غير موجودة داخل النسخة الاحتياطية.");
        try
        {
            await using var connection = OpenDatabase(databasePath, SqliteOpenMode.ReadOnly);
            await connection.OpenAsync(cancellationToken);

            await using (var check = connection.CreateCommand())
            {
                check.CommandText = "PRAGMA quick_check;";
                var result = Convert.ToString(await check.ExecuteScalarAsync(cancellationToken));
                if (!string.Equals(result, "ok", StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("قاعدة البيانات في النسخة الاحتياطية تالفة.");
            }

            await using (var tableCheck = connection.CreateCommand())
            {
                tableCheck.CommandText = "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name='files';";
                if (Convert.ToInt32(await tableCheck.ExecuteScalarAsync(cancellationToken)) != 1)
                    throw new InvalidDataException("قاعدة البيانات لا تتضمن مكتبة ملفات صالحة.");
            }

            var references = new List<string>();
            await using (var command = connection.CreateCommand())
            {
                command.CommandText = "SELECT relative_path FROM files;";
                await using var reader = await command.ExecuteReaderAsync(cancellationToken);
                while (await reader.ReadAsync(cancellationToken))
                    references.Add(reader.GetString(0));
            }
            return references;
        }
        catch (SqliteException exception)
        {
            throw new InvalidDataException("قاعدة البيانات في النسخة الاحتياطية تالفة أو غير قابلة للقراءة.", exception);
        }
    }

    private static void ValidateDatabaseFileReferences(
        IEnumerable<string> relativePaths, string stagedLibrary, string activeLibrary)
    {
        foreach (var relative in relativePaths)
        {
            var stagedFile = ResolveInside(stagedLibrary, NormalizeArchivePath(relative));
            var activeFile = ResolveInside(activeLibrary, NormalizeArchivePath(relative));
            if (!File.Exists(stagedFile) && !File.Exists(activeFile))
                throw new InvalidDataException("قاعدة البيانات تشير إلى ملف غير موجود ضمن النسخة أو المكتبة الحالية.");
        }
    }

    private async Task<List<(string Source, string Destination)>> PreflightLibraryMergeAsync(
        string stagedLibrary, CancellationToken cancellationToken)
    {
        var filesToCopy = new List<(string Source, string Destination)>();
        if (!Directory.Exists(stagedLibrary))
            return filesToCopy;

        foreach (var source in EnumerateLibraryFiles(stagedLibrary))
        {
            cancellationToken.ThrowIfCancellationRequested();
            var relative = Path.GetRelativePath(stagedLibrary, source);
            var destination = ResolveInside(paths.Library, relative);
            RejectReparsePointAncestors(paths.Library, destination);
            if (Directory.Exists(destination))
                throw new InvalidDataException("تتعارض ملفات النسخة الاحتياطية مع مجلد موجود في المكتبة.");
            if (File.Exists(destination))
            {
                if (!await FilesMatchAsync(source, destination, cancellationToken))
                    throw new InvalidDataException("يوجد ملف مختلف بالمسار نفسه؛ لم تُجرَ أي تغييرات.");
                continue;
            }
            filesToCopy.Add((source, destination));
        }
        return filesToCopy;
    }

    private static async Task<bool> FilesMatchAsync(
        string firstPath, string secondPath, CancellationToken cancellationToken)
    {
        await using var first = File.OpenRead(firstPath);
        await using var second = File.OpenRead(secondPath);
        if (first.Length != second.Length)
            return false;
        var firstHash = await SHA256.HashDataAsync(first, cancellationToken);
        var secondHash = await SHA256.HashDataAsync(second, cancellationToken);
        return CryptographicOperations.FixedTimeEquals(firstHash, secondHash);
    }

    private static Task CreateSnapshotAsync(
        string activeDatabase, string snapshotPath, CancellationToken cancellationToken) =>
        Task.Run(() =>
        {
            SqliteConnection.ClearAllPools();
            using var source = OpenDatabase(activeDatabase, SqliteOpenMode.ReadWrite);
            using var target = OpenDatabase(snapshotPath, SqliteOpenMode.ReadWriteCreate);
            source.Open();
            target.Open();
            source.BackupDatabase(target);
        }, cancellationToken);

    private Task ReplaceDatabaseAsync(string sourcePath, CancellationToken cancellationToken) =>
        Task.Run(() =>
        {
            SqliteConnection.ClearAllPools();
            try
            {
                using var source = OpenDatabase(sourcePath, SqliteOpenMode.ReadOnly);
                using var destination = OpenDatabase(paths.Database, SqliteOpenMode.ReadWriteCreate);
                source.Open();
                destination.Open();
                source.BackupDatabase(destination);
            }
            finally
            {
                SqliteConnection.ClearAllPools();
            }
        }, cancellationToken);

    private static SqliteConnection OpenDatabase(string path, SqliteOpenMode mode) =>
        new(new SqliteConnectionStringBuilder
        {
            DataSource = path,
            Mode = mode,
            Pooling = false
        }.ToString());

    private static string ResolveInside(string root, string relative)
    {
        var normalized = relative.Replace('\\', Path.DirectorySeparatorChar);
        if (Path.IsPathRooted(normalized) || normalized.Split(Path.DirectorySeparatorChar)
                .Any(segment => segment is "" or "." or ".."))
            throw new InvalidDataException("مسار ملف النسخة الاحتياطية غير آمن.");
        var fullRoot = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        var target = Path.GetFullPath(Path.Combine(fullRoot, normalized));
        if (!target.StartsWith(fullRoot + Path.DirectorySeparatorChar, PathComparison))
            throw new InvalidDataException("مسار ملف النسخة الاحتياطية خارج مجلد الاستعادة.");
        return target;
    }

    private static void RejectReparsePointAncestors(string root, string target)
    {
        var fullRoot = Path.GetFullPath(root);
        var fullTarget = Path.GetFullPath(target);
        var rootPrefix = Path.EndsInDirectorySeparator(fullRoot)
            ? fullRoot
            : fullRoot + Path.DirectorySeparatorChar;
        if (!fullTarget.StartsWith(rootPrefix, PathComparison))
            throw new InvalidDataException("مسار ملف النسخة الاحتياطية خارج مجلد المكتبة.");

        try
        {
            RejectReparsePoint(fullRoot);
        }
        catch (FileNotFoundException)
        {
        }
        catch (DirectoryNotFoundException)
        {
        }

        var current = fullRoot;
        var relative = Path.GetRelativePath(fullRoot, fullTarget);
        foreach (var segment in relative.Split(
                     [Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar],
                     StringSplitOptions.RemoveEmptyEntries))
        {
            current = Path.Combine(current, segment);
            try
            {
                RejectReparsePoint(current);
            }
            catch (FileNotFoundException)
            {
                break;
            }
            catch (DirectoryNotFoundException)
            {
                break;
            }
        }
    }

    private static IEnumerable<string> EnumerateLibraryFiles(string root)
    {
        if (!Directory.Exists(root))
            yield break;

        var rootPath = Path.GetFullPath(root);
        RejectReparsePoint(rootPath);
        var pending = new Stack<string>();
        pending.Push(rootPath);
        while (pending.Count > 0)
        {
            var directory = pending.Pop();
            foreach (var entry in Directory.EnumerateFileSystemEntries(directory))
            {
                var attributes = File.GetAttributes(entry);
                if ((attributes & FileAttributes.ReparsePoint) != 0)
                    throw new InvalidDataException("لا يمكن تضمين روابط رمزية ضمن المكتبة أو النسخة الاحتياطية.");
                if ((attributes & FileAttributes.Directory) != 0)
                    pending.Push(entry);
                else
                    yield return entry;
            }
        }
    }

    private static async Task CopyAtomicallyAsync(
        string source, string destination, string libraryRoot, CancellationToken cancellationToken)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(destination)!);
        RejectReparsePointAncestors(libraryRoot, destination);
        var temporary = destination + "." + Guid.NewGuid().ToString("N") + ".restore-tmp";
        try
        {
            await using var input = File.OpenRead(source);
            await using var output = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None, 81920, true);
            await input.CopyToAsync(output, cancellationToken);
            await output.FlushAsync(cancellationToken);
            RejectReparsePointAncestors(libraryRoot, destination);
            File.Move(temporary, destination);
        }
        finally
        {
            TryDeleteFile(temporary);
        }
    }

    private static async Task CopyEntryAsync(
        Stream source,
        Stream destination,
        long expectedLength,
        Func<long> getCopiedBytes,
        Action<long> setCopiedBytes,
        CancellationToken cancellationToken)
    {
        var buffer = new byte[81920];
        long entryBytes = 0;
        int read;
        while ((read = await source.ReadAsync(buffer, cancellationToken)) > 0)
        {
            entryBytes += read;
            var total = checked(getCopiedBytes() + read);
            if (entryBytes > expectedLength || total > MaximumBackupBytes)
                throw new InvalidDataException("البيانات المفكوكة تتجاوز الحد المسموح.");
            await destination.WriteAsync(buffer.AsMemory(0, read), cancellationToken);
            setCopiedBytes(total);
        }
        if (entryBytes != expectedLength)
            throw new InvalidDataException("حجم أحد ملفات النسخة لا يطابق بيانات الأرشيف.");
    }

    private static bool IsReparsePoint(string path) =>
        (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0;

    private static void RejectReparsePoint(string path)
    {
        if (IsReparsePoint(path))
            throw new InvalidDataException("لا يمكن تضمين روابط رمزية ضمن النسخ الاحتياطية.");
    }

    private static async Task AddFileAsync(
        ZipArchive archive, string path, string entryName, CancellationToken cancellationToken)
    {
        var entry = archive.CreateEntry(entryName, CompressionLevel.Optimal);
        await using var input = File.OpenRead(path);
        await using var output = entry.Open();
        await input.CopyToAsync(output, cancellationToken);
    }

    private static void DeleteDatabaseAndSidecars(string path)
    {
        SqliteConnection.ClearAllPools();
        TryDeleteFile(path);
        TryDeleteFile(path + "-wal");
        TryDeleteFile(path + "-shm");
    }

    private static void TryDeleteFile(string path)
    {
        try { if (File.Exists(path)) File.Delete(path); }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }

    private static void TryDeleteDirectory(string path)
    {
        try { if (Directory.Exists(path)) Directory.Delete(path, recursive: true); }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }

    private sealed record BackupManifest(
        string? Product,
        int FormatVersion,
        DateTimeOffset CreatedAt,
        string[]? Includes,
        string[]? Excludes);
}

public enum BackupRestoreStage
{
    CopyingLibraryFiles,
    DatabaseReplaced,
    Completed
}

public sealed record BackupRestoreProgress(
    BackupRestoreStage Stage,
    int CompletedFiles,
    int TotalFiles);
