using System.Text.Json;
using Microsoft.Extensions.Logging;

namespace AlMaktaba.Infrastructure;

public sealed class LocalFileLoggerProvider(string logPath) : ILoggerProvider
{
    private readonly Lock _gate = new();
    private bool _disposed;

    public ILogger CreateLogger(string categoryName) => new LocalFileLogger(this, categoryName);

    public void Dispose()
    {
        lock (_gate) _disposed = true;
    }

    private void Write(string category, LogLevel level, EventId eventId, string message)
    {
        lock (_gate)
        {
            if (_disposed) return;
            Directory.CreateDirectory(Path.GetDirectoryName(logPath)!);
            var line = JsonSerializer.Serialize(new
            {
                timestamp = DateTimeOffset.UtcNow,
                category,
                level = level.ToString(),
                eventId = eventId.Id,
                message
            });
            File.AppendAllText(logPath, line + Environment.NewLine);
        }
    }

    private sealed class LocalFileLogger(LocalFileLoggerProvider owner, string category) : ILogger
    {
        public IDisposable? BeginScope<TState>(TState state) where TState : notnull => NullScope.Instance;
        public bool IsEnabled(LogLevel logLevel) => logLevel >= LogLevel.Information;

        public void Log<TState>(
            LogLevel logLevel, EventId eventId, TState state, Exception? exception,
            Func<TState, Exception?, string> formatter)
        {
            if (IsEnabled(logLevel))
                owner.Write(category, logLevel, eventId, formatter(state, null));
        }
    }

    private sealed class NullScope : IDisposable
    {
        public static NullScope Instance { get; } = new();
        public void Dispose() { }
    }
}
