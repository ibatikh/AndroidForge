using System.Security.Cryptography;
using AlMaktaba.Core;
using Microsoft.Extensions.Logging;

namespace AlMaktaba.Infrastructure;

public sealed class LocalLibraryService(AppPaths paths, IFileRepository repository, ILogger<LocalLibraryService> logger)
    : ILocalLibraryService
{
    private const long MaximumImportBytes = 500L * 1024 * 1024;
    private static StringComparison PathComparison =>
        OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;

    public async Task<LibraryFile> ImportAsync(string sourcePath, string? sourceOperation = null, CancellationToken cancellationToken = default)
    {
        var source = Path.GetFullPath(sourcePath);
        var info = new FileInfo(source);
        if (!info.Exists)
            throw new FileNotFoundException("لم يتم العثور على الملف المحدد.");
        if (info.Length <= 0 || info.Length > MaximumImportBytes)
            throw new InvalidDataException("حجم الملف غير مدعوم. الحد الأقصى للاستيراد 500 ميغابايت.");

        var name = SafeFileNames.Sanitize(info.Name);
        await ValidateFileSignatureAsync(source, info.Extension, cancellationToken);
        var kind = GetKind(info.Extension);
        var destinationDirectory = kind switch
        {
            LibraryFileKind.Image => paths.Images,
            LibraryFileKind.Document => paths.Documents,
            LibraryFileKind.Pdf => paths.Pdf,
            _ => paths.Generated
        };
        Directory.CreateDirectory(destinationDirectory);
        var id = Guid.NewGuid().ToString("N");
        var storedName = id + info.Extension.ToLowerInvariant();
        var destination = Path.Combine(destinationDirectory, storedName);

        try
        {
            await using (var input = new FileStream(source, FileMode.Open, FileAccess.Read, FileShare.Read,
                128 * 1024, FileOptions.Asynchronous | FileOptions.SequentialScan))
            await using (var output = new FileStream(destination, FileMode.CreateNew, FileAccess.Write, FileShare.None,
                128 * 1024, FileOptions.Asynchronous | FileOptions.WriteThrough))
                await input.CopyToAsync(output, cancellationToken);

            var relative = Path.GetRelativePath(paths.Library, destination);
            var checksum = await HashFileAsync(destination, cancellationToken);
            var now = DateTimeOffset.UtcNow;
            var item = new LibraryFile(id, name, storedName, relative, GetMimeType(info.Extension), kind,
                new FileInfo(destination).Length, now, now, sourceOperation, Checksum: checksum);
            await repository.AddAsync(item, cancellationToken);
            await RecordOperationSafelyAsync(sourceOperation ?? "Import", null, relative);
            return item;
        }
        catch
        {
            if (File.Exists(destination))
                File.Delete(destination);
            throw;
        }
    }

    public async Task RenameAsync(string id, string newName, CancellationToken cancellationToken = default)
    {
        var item = await repository.GetAsync(id, cancellationToken)
            ?? throw new FileNotFoundException("الملف غير موجود في المكتبة.");
        var cleanName = SafeFileNames.Sanitize(newName);
        var oldExtension = Path.GetExtension(item.OriginalName);
        var newExtension = Path.GetExtension(cleanName);
        if (!oldExtension.Equals(newExtension, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("لا يمكن تغيير امتداد الملف أثناء إعادة التسمية.");
        await repository.RenameAsync(id, cleanName, cancellationToken);
        await RecordOperationSafelyAsync("Rename", item.RelativePath, cleanName);
    }

    public async Task DeleteAsync(string id, CancellationToken cancellationToken = default)
    {
        var item = await repository.GetAsync(id, cancellationToken)
            ?? throw new FileNotFoundException("الملف غير موجود في المكتبة.");
        var absolute = ResolveLibraryPath(item.RelativePath);
        if (!File.Exists(absolute))
        {
            await repository.RemoveAsync(id, cancellationToken);
            DeleteThumbnailIfOwned(item.Id, item.ThumbnailPath);
            await RecordOperationSafelyAsync("Delete", item.RelativePath, null);
            return;
        }

        var quarantineDirectory = Path.Combine(paths.Temp, "pending-delete");
        Directory.CreateDirectory(quarantineDirectory);
        var quarantined = Path.Combine(quarantineDirectory, Guid.NewGuid().ToString("N"));
        File.Move(absolute, quarantined);
        try
        {
            await repository.RemoveAsync(id, cancellationToken);
        }
        catch
        {
            if (File.Exists(quarantined) && !File.Exists(absolute))
                File.Move(quarantined, absolute);
            throw;
        }

        DeleteThumbnailIfOwned(item.Id, item.ThumbnailPath);
        await RecordOperationSafelyAsync("Delete", item.RelativePath, null);

        try
        {
            File.Delete(quarantined);
        }
        catch (IOException exception)
        {
            logger.LogWarning(exception, "Library item was removed from the index but its quarantined file could not be deleted.");
        }
    }

    public async Task SetFavoriteAsync(string id, bool favorite, CancellationToken cancellationToken = default)
    {
        var item = await repository.GetAsync(id, cancellationToken)
            ?? throw new FileNotFoundException("الملف غير موجود في المكتبة.");
        await repository.SetFavoriteAsync(id, favorite, cancellationToken);
        await RecordOperationSafelyAsync(favorite ? "Favorite" : "Unfavorite", item.RelativePath, null);
    }

    public async Task SetCategoryAsync(string id, string category, CancellationToken cancellationToken = default)
    {
        var item = await repository.GetAsync(id, cancellationToken)
            ?? throw new FileNotFoundException("الملف غير موجود في المكتبة.");
        var cleanCategory = (category ?? "").Trim();
        if (cleanCategory.Length > 80 ||
            cleanCategory.Any(char.IsControl) ||
            cleanCategory.Contains('/') ||
            cleanCategory.Contains('\\') ||
            cleanCategory is "." or "..")
            throw new InvalidDataException("اسم التصنيف غير صالح؛ استخدم حتى 80 حرفًا دون فواصل مسار.");

        await repository.SetCategoryAsync(id, cleanCategory, cancellationToken);
        await RecordOperationSafelyAsync(
            "SetCategory", item.RelativePath, cleanCategory.Length == 0 ? null : cleanCategory);
    }

    public async Task SetThumbnailPathAsync(
        string id, string? thumbnailPath, CancellationToken cancellationToken = default)
    {
        _ = await repository.GetAsync(id, cancellationToken)
            ?? throw new FileNotFoundException("الملف غير موجود في المكتبة.");
        var safePath = thumbnailPath is null ? null : ResolveThumbnailPath(id, thumbnailPath);
        if (safePath is not null && !File.Exists(safePath))
            throw new FileNotFoundException("ملف المعاينة المصغرة غير موجود.");
        await repository.SetThumbnailPathAsync(id, thumbnailPath, cancellationToken);
    }

    public async Task RecordOpenedAsync(string id, CancellationToken cancellationToken = default)
    {
        var item = await repository.GetAsync(id, cancellationToken)
            ?? throw new FileNotFoundException("الملف غير موجود في المكتبة.");
        var openedAt = DateTimeOffset.UtcNow;
        await repository.RecordOpenedAsync(id, openedAt, cancellationToken);
        await RecordOperationSafelyAsync("Open", item.RelativePath, null);
    }

    public Task<IReadOnlyList<LibraryOperation>> GetRecentOperationsAsync(
        int limit = 100, CancellationToken cancellationToken = default) =>
        repository.GetRecentOperationsAsync(limit, cancellationToken);

    public Task<IReadOnlyList<LibraryFile>> SearchAsync(LibraryQuery query, CancellationToken cancellationToken = default) =>
        repository.SearchAsync(query, cancellationToken);

    public string GetAbsolutePath(LibraryFile file)
    {
        ArgumentNullException.ThrowIfNull(file);
        return ResolveLibraryPath(file.RelativePath);
    }

    private string ResolveLibraryPath(string relative)
    {
        if (string.IsNullOrWhiteSpace(relative) || Path.IsPathRooted(relative) ||
            relative.Split(['/', '\\'], StringSplitOptions.None)
                .Any(segment => segment is "" or "." or ".."))
            throw new InvalidDataException("مسار الملف داخل المكتبة غير صالح.");

        var root = Path.GetFullPath(paths.Library);
        var candidate = Path.GetFullPath(Path.Combine(root, relative));
        var rootPrefix = Path.EndsInDirectorySeparator(root) ? root : root + Path.DirectorySeparatorChar;
        if (!candidate.StartsWith(rootPrefix, PathComparison))
            throw new InvalidDataException("مسار الملف خارج مجلد المكتبة.");

        try
        {
            if ((File.GetAttributes(root) & FileAttributes.ReparsePoint) != 0)
                throw new InvalidDataException("مجلد المكتبة لا يمكن أن يكون رابطًا رمزيًا.");
        }
        catch (FileNotFoundException)
        {
        }
        catch (DirectoryNotFoundException)
        {
        }

        var current = root;
        foreach (var segment in Path.GetRelativePath(root, candidate).Split(
                     [Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar],
                     StringSplitOptions.RemoveEmptyEntries))
        {
            current = Path.Combine(current, segment);
            try
            {
                if ((File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0)
                    throw new InvalidDataException("لا يمكن الوصول إلى ملف عبر رابط رمزي داخل المكتبة.");
            }
            catch (FileNotFoundException)
            {
                break;
            }
            catch (DirectoryNotFoundException)
            {
                break;
            }
        }
        return candidate;
    }

    private string ResolveThumbnailPath(string id, string relative)
    {
        if (string.IsNullOrWhiteSpace(relative) || Path.IsPathRooted(relative) ||
            relative.Split(['/', '\\'], StringSplitOptions.None)
                .Any(segment => segment is "" or "." or ".."))
            throw new InvalidDataException("مسار المعاينة المصغرة غير صالح.");

        var root = Path.GetFullPath(paths.Thumbnails);
        var candidate = Path.GetFullPath(Path.Combine(paths.Root, relative));
        var prefix = Path.EndsInDirectorySeparator(root) ? root : root + Path.DirectorySeparatorChar;
        var expected = Path.GetFullPath(Path.Combine(root, id + ".jpg"));
        if (!candidate.StartsWith(prefix, PathComparison) ||
            !candidate.Equals(expected, PathComparison))
            throw new InvalidDataException("يجب حفظ المعاينات المصغرة ضمن مجلدها المحلي.");
        RejectReparsePointAncestors(Path.GetFullPath(paths.Root), candidate);
        return candidate;
    }

    private static void RejectReparsePointAncestors(string root, string target)
    {
        var fullRoot = Path.GetFullPath(root);
        var fullTarget = Path.GetFullPath(target);
        var prefix = Path.EndsInDirectorySeparator(fullRoot)
            ? fullRoot
            : fullRoot + Path.DirectorySeparatorChar;
        if (!fullTarget.StartsWith(prefix, PathComparison))
            throw new InvalidDataException("مسار المعاينة المصغرة خارج مجلدها المحلي.");

        var current = fullRoot;
        RejectReparsePointIfPresent(current);
        foreach (var segment in Path.GetRelativePath(fullRoot, fullTarget).Split(
                     [Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar],
                     StringSplitOptions.RemoveEmptyEntries))
        {
            current = Path.Combine(current, segment);
            if (!RejectReparsePointIfPresent(current))
                break;
        }
    }

    private static bool RejectReparsePointIfPresent(string path)
    {
        try
        {
            if ((File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0)
                throw new InvalidDataException("لا يمكن الوصول إلى معاينة عبر رابط رمزي.");
            return true;
        }
        catch (FileNotFoundException)
        {
            return false;
        }
        catch (DirectoryNotFoundException)
        {
            return false;
        }
    }

    private void DeleteThumbnailIfOwned(string id, string? relative)
    {
        if (string.IsNullOrWhiteSpace(relative))
            return;
        try
        {
            var path = ResolveThumbnailPath(id, relative);
            if (File.Exists(path))
                File.Delete(path);
        }
        catch (Exception exception) when (
            exception is IOException or UnauthorizedAccessException or InvalidDataException)
        {
            logger.LogWarning(exception, "Could not remove a library thumbnail.");
        }
    }

    private async Task RecordOperationSafelyAsync(
        string operation, string? inputPath, string? outputPath)
    {
        var now = DateTimeOffset.UtcNow;
        try
        {
            await repository.RecordOperationAsync(new LibraryOperation(
                Guid.NewGuid().ToString("N"), operation, inputPath, outputPath,
                "Completed", null, now, now));
        }
        catch (Exception exception) when (
            exception is not OperationCanceledException)
        {
            logger.LogWarning(exception, "Could not record a local library operation.");
        }
    }

    private static LibraryFileKind GetKind(string extension) => extension.ToLowerInvariant() switch
    {
        ".png" or ".jpg" or ".jpeg" or ".webp" or ".bmp" or ".tif" or ".tiff" => LibraryFileKind.Image,
        ".pdf" => LibraryFileKind.Pdf,
        ".doc" or ".docx" or ".odt" or ".rtf" or ".txt" or ".xlsx" or ".pptx" => LibraryFileKind.Document,
        _ => LibraryFileKind.Other
    };

    private static string GetMimeType(string extension) => extension.ToLowerInvariant() switch
    {
        ".png" => "image/png",
        ".jpg" or ".jpeg" => "image/jpeg",
        ".webp" => "image/webp",
        ".pdf" => "application/pdf",
        ".docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".txt" => "text/plain",
        _ => "application/octet-stream"
    };

    private static async Task<string> HashFileAsync(string path, CancellationToken cancellationToken)
    {
        await using var stream = File.OpenRead(path);
        var hash = await SHA256.HashDataAsync(stream, cancellationToken);
        return Convert.ToHexString(hash);
    }

    private static async Task ValidateFileSignatureAsync(
        string path, string extension, CancellationToken cancellationToken)
    {
        var bytes = new byte[12];
        await using var stream = new FileStream(
            path, FileMode.Open, FileAccess.Read, FileShare.Read, 4096, FileOptions.Asynchronous);
        var count = await stream.ReadAsync(bytes, cancellationToken);
        var header = bytes.AsSpan(0, count);
        var normalized = extension.ToLowerInvariant();
        var valid = normalized switch
        {
            ".png" => header.StartsWith(new byte[] { 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A }),
            ".jpg" or ".jpeg" => header.StartsWith(new byte[] { 0xFF, 0xD8, 0xFF }),
            ".webp" => header.Length >= 12 && header[..4].SequenceEqual("RIFF"u8) && header[8..12].SequenceEqual("WEBP"u8),
            ".bmp" => header.StartsWith("BM"u8),
            ".tif" or ".tiff" => header.StartsWith(new byte[] { 0x49, 0x49, 0x2A, 0x00 }) ||
                                  header.StartsWith(new byte[] { 0x4D, 0x4D, 0x00, 0x2A }),
            ".pdf" => header.StartsWith("%PDF-"u8),
            ".docx" or ".xlsx" or ".pptx" or ".odt" => header.StartsWith(new byte[] { 0x50, 0x4B, 0x03, 0x04 }),
            ".doc" => header.StartsWith(new byte[] { 0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1 }),
            ".rtf" => header.StartsWith("{\\rtf"u8),
            _ => true
        };

        if (!valid)
            throw new InvalidDataException("امتداد الملف لا يطابق محتواه أو أن الملف تالف.");
    }
}
