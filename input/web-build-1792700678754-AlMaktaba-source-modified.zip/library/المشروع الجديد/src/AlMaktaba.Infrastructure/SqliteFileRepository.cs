using AlMaktaba.Core;
using Microsoft.Data.Sqlite;

namespace AlMaktaba.Infrastructure;

public sealed class SqliteFileRepository(AppPaths paths) : IFileRepository, IJobRepository
{
    private const int CurrentSchemaVersion = 2;

    private string ConnectionString => new SqliteConnectionStringBuilder
    {
        DataSource = paths.Database,
        Mode = SqliteOpenMode.ReadWriteCreate,
        Cache = SqliteCacheMode.Shared,
        Pooling = true
    }.ToString();

    public async Task InitializeAsync(CancellationToken cancellationToken = default)
    {
        paths.EnsureCreated();
        await using var connection = await OpenAsync(cancellationToken);
        await using (var setup = connection.CreateCommand())
        {
            setup.CommandText = """
                PRAGMA journal_mode = WAL;
                PRAGMA foreign_keys = ON;
                PRAGMA busy_timeout = 5000;
                """;
            await setup.ExecuteNonQueryAsync(cancellationToken);
        }

        await using var versionCommand = connection.CreateCommand();
        versionCommand.CommandText = "PRAGMA user_version;";
        var schemaVersion = Convert.ToInt32(await versionCommand.ExecuteScalarAsync(cancellationToken) ?? 0);
        if (schemaVersion > CurrentSchemaVersion)
            throw new InvalidOperationException(
                $"قاعدة البيانات أحدث من إصدار التطبيق الحالي (الإصدار {schemaVersion}).");
        if (schemaVersion == CurrentSchemaVersion)
            return;

        using var transaction = connection.BeginTransaction();
        using var command = connection.CreateCommand();
        command.Transaction = transaction;
        if (schemaVersion == 1)
        {
            command.CommandText = """
                ALTER TABLE files ADD COLUMN category TEXT NOT NULL DEFAULT '';
                ALTER TABLE files ADD COLUMN last_opened_at TEXT NULL;
                CREATE INDEX IF NOT EXISTS ix_files_category ON files(category COLLATE NOCASE);
                """;
            await command.ExecuteNonQueryAsync(cancellationToken);
            using var upgradeVersion = connection.CreateCommand();
            upgradeVersion.Transaction = transaction;
            upgradeVersion.CommandText = $"PRAGMA user_version = {CurrentSchemaVersion};";
            await upgradeVersion.ExecuteNonQueryAsync(cancellationToken);
            transaction.Commit();
            return;
        }

        command.CommandText = """
            CREATE TABLE IF NOT EXISTS files (
                id TEXT PRIMARY KEY,
                original_name TEXT NOT NULL,
                stored_name TEXT NOT NULL,
                relative_path TEXT NOT NULL UNIQUE,
                mime_type TEXT NOT NULL,
                file_type TEXT NOT NULL,
                size_bytes INTEGER NOT NULL CHECK(size_bytes >= 0),
                created_at TEXT NOT NULL,
                modified_at TEXT NOT NULL,
                source_operation TEXT NULL,
                thumbnail_path TEXT NULL,
                checksum TEXT NULL,
                is_favorite INTEGER NOT NULL DEFAULT 0,
                category TEXT NOT NULL DEFAULT '',
                last_opened_at TEXT NULL
            );
            CREATE INDEX IF NOT EXISTS ix_files_name ON files(original_name COLLATE NOCASE);
            CREATE INDEX IF NOT EXISTS ix_files_created ON files(created_at);
            CREATE INDEX IF NOT EXISTS ix_files_category ON files(category COLLATE NOCASE);
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                modified_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS operations (
                id TEXT PRIMARY KEY,
                operation TEXT NOT NULL,
                input_path TEXT NULL,
                output_path TEXT NULL,
                status TEXT NOT NULL,
                error_message TEXT NULL,
                created_at TEXT NOT NULL,
                completed_at TEXT NULL
            );
            CREATE TABLE IF NOT EXISTS jobs (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                input_path TEXT NOT NULL,
                output_path TEXT NULL,
                state TEXT NOT NULL,
                progress REAL NOT NULL DEFAULT 0,
                error TEXT NULL,
                created_at TEXT NOT NULL,
                completed_at TEXT NULL
            );
            """;
        await command.ExecuteNonQueryAsync(cancellationToken);
        using var updateVersion = connection.CreateCommand();
        updateVersion.Transaction = transaction;
        updateVersion.CommandText = $"PRAGMA user_version = {CurrentSchemaVersion};";
        await updateVersion.ExecuteNonQueryAsync(cancellationToken);
        transaction.Commit();
    }

    public async Task<IReadOnlyList<LibraryFile>> SearchAsync(LibraryQuery query, CancellationToken cancellationToken = default)
    {
        await using var connection = await OpenAsync(cancellationToken);
        var command = connection.CreateCommand();
        var clauses = new List<string>();
        if (!string.IsNullOrWhiteSpace(query.Search))
        {
            clauses.Add("original_name LIKE $search ESCAPE '\\'");
            command.Parameters.AddWithValue("$search", $"%{EscapeLike(query.Search.Trim())}%");
        }
        if (query.Kind is not null)
        {
            clauses.Add("file_type = $kind");
            command.Parameters.AddWithValue("$kind", query.Kind.Value.ToString());
        }
        if (query.FavoritesOnly)
            clauses.Add("is_favorite = 1");
        if (!string.IsNullOrWhiteSpace(query.Category))
        {
            clauses.Add("category = $category COLLATE NOCASE");
            command.Parameters.AddWithValue("$category", query.Category.Trim());
        }

        var sort = query.SortBy.ToLowerInvariant() switch
        {
            "name" => "original_name COLLATE NOCASE",
            "size" => "size_bytes",
            "modified" => "modified_at",
            "recent" => "COALESCE(last_opened_at, '')",
            _ => "created_at"
        };
        var direction = query.Descending ? "DESC" : "ASC";
        command.CommandText = $"""
            SELECT id, original_name, stored_name, relative_path, mime_type, file_type,
                   size_bytes, created_at, modified_at, source_operation, thumbnail_path,
                   checksum, is_favorite, category, last_opened_at
            FROM files
            {(clauses.Count > 0 ? "WHERE " + string.Join(" AND ", clauses) : "")}
            ORDER BY {sort} {direction}, id ASC;
            """;

        var result = new List<LibraryFile>();
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            result.Add(new LibraryFile(
                reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetString(3),
                reader.GetString(4), Enum.Parse<LibraryFileKind>(reader.GetString(5)),
                reader.GetInt64(6), DateTimeOffset.Parse(reader.GetString(7)),
                DateTimeOffset.Parse(reader.GetString(8)),
                reader.IsDBNull(9) ? null : reader.GetString(9),
                reader.IsDBNull(10) ? null : reader.GetString(10),
                reader.IsDBNull(11) ? null : reader.GetString(11),
                reader.GetInt32(12) == 1,
                reader.GetString(13),
                reader.IsDBNull(14) ? null : DateTimeOffset.Parse(reader.GetString(14))));
        }
        return result;
    }

    public async Task<LibraryFile?> GetAsync(string id, CancellationToken cancellationToken = default)
    {
        await using var connection = await OpenAsync(cancellationToken);
        var command = connection.CreateCommand();
        command.CommandText = """
            SELECT id, original_name, stored_name, relative_path, mime_type, file_type,
                   size_bytes, created_at, modified_at, source_operation, thumbnail_path,
                   checksum, is_favorite, category, last_opened_at
            FROM files WHERE id = $id;
            """;
        command.Parameters.AddWithValue("$id", id);
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        if (!await reader.ReadAsync(cancellationToken))
            return null;
        return new LibraryFile(
            reader.GetString(0), reader.GetString(1), reader.GetString(2), reader.GetString(3),
            reader.GetString(4), Enum.Parse<LibraryFileKind>(reader.GetString(5)),
            reader.GetInt64(6), DateTimeOffset.Parse(reader.GetString(7)),
            DateTimeOffset.Parse(reader.GetString(8)),
            reader.IsDBNull(9) ? null : reader.GetString(9),
            reader.IsDBNull(10) ? null : reader.GetString(10),
            reader.IsDBNull(11) ? null : reader.GetString(11),
            reader.GetInt32(12) == 1,
            reader.GetString(13),
            reader.IsDBNull(14) ? null : DateTimeOffset.Parse(reader.GetString(14)));
    }

    public async Task AddAsync(LibraryFile file, CancellationToken cancellationToken = default)
    {
        await using var connection = await OpenAsync(cancellationToken);
        var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO files (id, original_name, stored_name, relative_path, mime_type, file_type,
                size_bytes, created_at, modified_at, source_operation, thumbnail_path, checksum, is_favorite,
                category, last_opened_at)
            VALUES ($id, $name, $stored, $path, $mime, $kind, $size, $created, $modified,
                $operation, $thumbnail, $checksum, $favorite, $category, $lastOpened);
            """;
        command.Parameters.AddWithValue("$id", file.Id);
        command.Parameters.AddWithValue("$name", file.OriginalName);
        command.Parameters.AddWithValue("$stored", file.StoredName);
        command.Parameters.AddWithValue("$path", file.RelativePath);
        command.Parameters.AddWithValue("$mime", file.MimeType);
        command.Parameters.AddWithValue("$kind", file.Kind.ToString());
        command.Parameters.AddWithValue("$size", file.SizeBytes);
        command.Parameters.AddWithValue("$created", file.CreatedAt.ToString("O"));
        command.Parameters.AddWithValue("$modified", file.ModifiedAt.ToString("O"));
        command.Parameters.AddWithValue("$operation", (object?)file.SourceOperation ?? DBNull.Value);
        command.Parameters.AddWithValue("$thumbnail", (object?)file.ThumbnailPath ?? DBNull.Value);
        command.Parameters.AddWithValue("$checksum", (object?)file.Checksum ?? DBNull.Value);
        command.Parameters.AddWithValue("$favorite", file.IsFavorite ? 1 : 0);
        command.Parameters.AddWithValue("$category", file.Category);
        command.Parameters.AddWithValue("$lastOpened", (object?)file.LastOpenedAt?.ToString("O") ?? DBNull.Value);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    public Task RenameAsync(string id, string originalName, CancellationToken cancellationToken = default) =>
        ExecuteAsync("UPDATE files SET original_name = $name, modified_at = $modified WHERE id = $id;",
            cancellationToken, ("$name", SafeFileNames.Sanitize(originalName)),
            ("$modified", DateTimeOffset.UtcNow.ToString("O")), ("$id", id));

    public Task SetFavoriteAsync(string id, bool favorite, CancellationToken cancellationToken = default) =>
        ExecuteAsync("UPDATE files SET is_favorite = $favorite WHERE id = $id;",
            cancellationToken, ("$favorite", favorite ? 1 : 0), ("$id", id));

    public Task SetCategoryAsync(string id, string category, CancellationToken cancellationToken = default) =>
        ExecuteAsync("UPDATE files SET category = $category WHERE id = $id;",
            cancellationToken, ("$category", category), ("$id", id));

    public Task SetThumbnailPathAsync(string id, string? thumbnailPath, CancellationToken cancellationToken = default) =>
        ExecuteAsync("UPDATE files SET thumbnail_path = $thumbnail WHERE id = $id;",
            cancellationToken, ("$thumbnail", (object?)thumbnailPath ?? DBNull.Value), ("$id", id));

    public Task RecordOpenedAsync(string id, DateTimeOffset openedAt, CancellationToken cancellationToken = default) =>
        ExecuteAsync("UPDATE files SET last_opened_at = $opened WHERE id = $id;",
            cancellationToken, ("$opened", openedAt.ToString("O")), ("$id", id));

    public async Task RecordOperationAsync(LibraryOperation operation, CancellationToken cancellationToken = default)
    {
        await using var connection = await OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO operations (id, operation, input_path, output_path, status, error_message, created_at, completed_at)
            VALUES ($id, $operation, $input, $output, $status, $error, $created, $completed);
            """;
        command.Parameters.AddWithValue("$id", operation.Id);
        command.Parameters.AddWithValue("$operation", operation.Operation);
        command.Parameters.AddWithValue("$input", (object?)operation.InputPath ?? DBNull.Value);
        command.Parameters.AddWithValue("$output", (object?)operation.OutputPath ?? DBNull.Value);
        command.Parameters.AddWithValue("$status", operation.Status);
        command.Parameters.AddWithValue("$error", (object?)operation.ErrorMessage ?? DBNull.Value);
        command.Parameters.AddWithValue("$created", operation.CreatedAt.ToString("O"));
        command.Parameters.AddWithValue("$completed", (object?)operation.CompletedAt?.ToString("O") ?? DBNull.Value);
        await command.ExecuteNonQueryAsync(cancellationToken);
        await using var prune = connection.CreateCommand();
        prune.CommandText = """
            DELETE FROM operations
            WHERE id NOT IN (
                SELECT id FROM operations ORDER BY created_at DESC, id DESC LIMIT 1000
            );
            """;
        await prune.ExecuteNonQueryAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<LibraryOperation>> GetRecentOperationsAsync(
        int limit = 100, CancellationToken cancellationToken = default)
    {
        var safeLimit = Math.Clamp(limit, 1, 500);
        await using var connection = await OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT id, operation, input_path, output_path, status, error_message, created_at, completed_at
            FROM operations
            ORDER BY created_at DESC, id DESC
            LIMIT $limit;
            """;
        command.Parameters.AddWithValue("$limit", safeLimit);
        var operations = new List<LibraryOperation>();
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            operations.Add(new LibraryOperation(
                reader.GetString(0), reader.GetString(1),
                reader.IsDBNull(2) ? null : reader.GetString(2),
                reader.IsDBNull(3) ? null : reader.GetString(3),
                reader.GetString(4),
                reader.IsDBNull(5) ? null : reader.GetString(5),
                DateTimeOffset.Parse(reader.GetString(6)),
                reader.IsDBNull(7) ? null : DateTimeOffset.Parse(reader.GetString(7))));
        }
        return operations;
    }

    public async Task SaveJobAsync(ProcessingJob job, CancellationToken cancellationToken = default)
    {
        await using var connection = await OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            INSERT INTO jobs (id, name, input_path, output_path, state, progress, error, created_at, completed_at)
            VALUES ($id, $name, $input, $output, $state, $progress, $error, $created, $completed)
            ON CONFLICT(id) DO UPDATE SET
                name = excluded.name,
                input_path = excluded.input_path,
                output_path = excluded.output_path,
                state = excluded.state,
                progress = excluded.progress,
                error = excluded.error,
                created_at = excluded.created_at,
                completed_at = excluded.completed_at;
            """;
        command.Parameters.AddWithValue("$id", job.Id);
        command.Parameters.AddWithValue("$name", job.Name);
        command.Parameters.AddWithValue("$input", job.InputPath);
        command.Parameters.AddWithValue("$output", (object?)job.OutputPath ?? DBNull.Value);
        command.Parameters.AddWithValue("$state", job.State.ToString());
        command.Parameters.AddWithValue("$progress", Math.Clamp(job.Progress, 0, 1));
        command.Parameters.AddWithValue("$error", (object?)job.Error ?? DBNull.Value);
        command.Parameters.AddWithValue("$created", job.CreatedAt.ToString("O"));
        command.Parameters.AddWithValue("$completed", (object?)job.CompletedAt?.ToString("O") ?? DBNull.Value);
        await command.ExecuteNonQueryAsync(cancellationToken);

        await using var prune = connection.CreateCommand();
        prune.CommandText = """
            DELETE FROM jobs
            WHERE id NOT IN (
                SELECT id FROM jobs ORDER BY created_at DESC, id DESC LIMIT 100
            );
            """;
        await prune.ExecuteNonQueryAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<ProcessingJob>> GetRecentJobsAsync(
        int limit = 100, CancellationToken cancellationToken = default)
    {
        var safeLimit = Math.Clamp(limit, 1, 100);
        await using var connection = await OpenAsync(cancellationToken);
        await using var command = connection.CreateCommand();
        command.CommandText = """
            SELECT id, name, input_path, output_path, state, progress, error, created_at, completed_at
            FROM jobs
            ORDER BY created_at DESC, id DESC
            LIMIT $limit;
            """;
        command.Parameters.AddWithValue("$limit", safeLimit);
        var jobs = new List<ProcessingJob>();
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            if (!Enum.TryParse<JobState>(reader.GetString(4), ignoreCase: false, out var state))
                continue;
            jobs.Add(new ProcessingJob(
                reader.GetString(0),
                reader.GetString(1),
                reader.GetString(2),
                reader.IsDBNull(3) ? null : reader.GetString(3),
                state,
                Math.Clamp(reader.GetDouble(5), 0, 1),
                reader.IsDBNull(6) ? null : reader.GetString(6),
                DateTimeOffset.Parse(reader.GetString(7)),
                reader.IsDBNull(8) ? null : DateTimeOffset.Parse(reader.GetString(8))));
        }
        return jobs;
    }

    public Task MarkInterruptedJobsAsync(
        DateTimeOffset completedAt, CancellationToken cancellationToken = default) =>
        ExecuteAsync("""
            UPDATE jobs
            SET state = $state,
                error = $error,
                completed_at = $completed
            WHERE state IN ($queued, $processing);
            """,
            cancellationToken,
            ("$state", JobState.Failed.ToString()),
            ("$error", "توقفت المهمة عند إغلاق التطبيق؛ لم يتم استئنافها."),
            ("$completed", completedAt.ToString("O")),
            ("$queued", JobState.Queued.ToString()),
            ("$processing", JobState.Processing.ToString()));

    public Task RemoveAsync(string id, CancellationToken cancellationToken = default) =>
        ExecuteAsync("DELETE FROM files WHERE id = $id;", cancellationToken, ("$id", id));

    private async Task ExecuteAsync(string sql, CancellationToken cancellationToken, params (string Name, object Value)[] values)
    {
        await using var connection = await OpenAsync(cancellationToken);
        var command = connection.CreateCommand();
        command.CommandText = sql;
        foreach (var (name, value) in values)
            command.Parameters.AddWithValue(name, value);
        await command.ExecuteNonQueryAsync(cancellationToken);
    }

    private async Task<SqliteConnection> OpenAsync(CancellationToken cancellationToken)
    {
        var connection = new SqliteConnection(ConnectionString);
        await connection.OpenAsync(cancellationToken);
        return connection;
    }

    private static string EscapeLike(string value) =>
        value.Replace("\\", "\\\\").Replace("%", "\\%").Replace("_", "\\_");
}
