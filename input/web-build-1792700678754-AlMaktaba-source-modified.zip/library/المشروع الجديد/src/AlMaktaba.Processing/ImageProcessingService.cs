using AlMaktaba.Core;
using SkiaSharp;

namespace AlMaktaba.Processing;

public sealed class ImageProcessingService : IImageProcessor
{
    private const long MaximumPixels = 40_000_000;

    public Task<string> AdjustAsync(
        string inputPath, string outputPath, ImageAdjustments adjustments,
        IProgress<double>? progress = null, CancellationToken cancellationToken = default) =>
        Task.Run(() =>
        {
            ValidateAdjustments(adjustments);
            using var source = SkiaImageCodec.Decode(inputPath, MaximumPixels);
            using var output = SkiaImageCodec.CreateBitmap(source.Width, source.Height);
            var postStages = (adjustments.NoiseReduction > 0 ? 1 : 0) +
                             (adjustments.Retouch > 0 ? 1 : 0) +
                             (adjustments.Sharpen > 0 ? 1 : 0);
            var pixelStageEnd = postStages == 0 ? 1d : 0.55d;

            for (var y = 0; y < source.Height; y++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                for (var x = 0; x < source.Width; x++)
                {
                    var color = source.GetPixel(x, y);
                    var red = color.Red / 255f;
                    var green = color.Green / 255f;
                    var blue = color.Blue / 255f;
                    var gray = 0.2126f * red + 0.7152f * green + 0.0722f * blue;

                    red = gray + (red - gray) * adjustments.Saturation;
                    green = gray + (green - gray) * adjustments.Saturation;
                    blue = gray + (blue - gray) * adjustments.Saturation;
                    red = (red - 0.5f) * adjustments.Contrast + 0.5f + adjustments.Brightness;
                    green = (green - 0.5f) * adjustments.Contrast + 0.5f + adjustments.Brightness;
                    blue = (blue - 0.5f) * adjustments.Contrast + 0.5f + adjustments.Brightness;

                    // A restrained color heuristic, not face detection or AI retouching.
                    if (adjustments.Whitening > 0 && IsLikelySkin(red, green, blue))
                    {
                        var lift = adjustments.Whitening * 0.10f * (1f - Math.Clamp(gray, 0, 1));
                        red += lift;
                        green += lift * 0.72f;
                        blue += lift * 0.55f;
                    }

                    output.SetPixel(x, y, new SKColor(ToByte(red), ToByte(green), ToByte(blue), color.Alpha));
                }

                progress?.Report((y + 1d) / source.Height * pixelStageEnd);
            }

            var progressStart = pixelStageEnd;
            var progressPerStage = postStages == 0 ? 0 : (1d - pixelStageEnd) / postStages;
            if (adjustments.NoiseReduction > 0)
            {
                var progressEnd = progressStart + progressPerStage;
                ApplyNoiseReduction(output, adjustments.NoiseReduction, cancellationToken,
                    progress, progressStart, progressEnd);
                progressStart = progressEnd;
            }
            if (adjustments.Retouch > 0)
            {
                var progressEnd = progressStart + progressPerStage;
                ApplySkinRetouch(output, adjustments.Retouch, cancellationToken,
                    progress, progressStart, progressEnd);
                progressStart = progressEnd;
            }
            if (adjustments.Sharpen > 0)
                ApplySharpen(output, adjustments.Sharpen, cancellationToken,
                    progress, progressStart, 1);
            SkiaImageCodec.SavePng(output, outputPath);
            progress?.Report(1);
            return outputPath;
        }, cancellationToken);

    public Task<string> AddWhiteSpaceAsync(
        string inputPath, string outputPath, ImageMargins margins,
        IProgress<double>? progress = null, CancellationToken cancellationToken = default) =>
        Task.Run(() =>
        {
            if (margins.Top < 0 || margins.Bottom < 0 || margins.Left < 0 || margins.Right < 0)
                throw new ArgumentOutOfRangeException(nameof(margins), "المسافات لا يمكن أن تكون سالبة.");
            using var source = SkiaImageCodec.Decode(inputPath, MaximumPixels);
            var width = checked(source.Width + margins.Left + margins.Right);
            var height = checked(source.Height + margins.Top + margins.Bottom);
            EnsurePixelLimit(width, height);
            using var output = SkiaImageCodec.CreateBitmap(width, height);
            using (var canvas = new SKCanvas(output))
            {
                canvas.Clear(SKColors.White);
                canvas.DrawBitmap(
                    source, margins.Left, margins.Top,
                    new SKSamplingOptions(SKFilterMode.Linear), null);
                canvas.Flush();
            }
            cancellationToken.ThrowIfCancellationRequested();
            SkiaImageCodec.SavePng(output, outputPath);
            progress?.Report(1);
            return outputPath;
        }, cancellationToken);

    public Task<string> CreateTemplateAsync(
        IReadOnlyList<string> photoPaths, PhotoTemplate template, string outputPath,
        IProgress<double>? progress = null, CancellationToken cancellationToken = default,
        PhotoCropAnchor cropAnchor = PhotoCropAnchor.Center,
        ImageOutputFormat outputFormat = ImageOutputFormat.Png,
        int jpegQuality = 92) =>
        Task.Run(() =>
        {
            ArgumentNullException.ThrowIfNull(template);
            if (photoPaths.Count == 0)
                throw new ArgumentException("أضف صورة واحدة على الأقل.", nameof(photoPaths));
            if (template.PhotoCount <= 0 || template.Dpi is < 72 or > 1200)
                throw new ArgumentException("إعدادات القالب غير صالحة.", nameof(template));
            if (!Enum.IsDefined(cropAnchor) || !Enum.IsDefined(outputFormat) ||
                jpegQuality is < 1 or > 100)
                throw new ArgumentOutOfRangeException(nameof(cropAnchor), "خيارات القص أو التصدير غير صالحة.");

            var width = template.PixelWidth;
            var height = template.PixelHeight;
            EnsurePixelLimit(width, height);
            using var output = SkiaImageCodec.CreateBitmap(width, height);
            using var canvas = new SKCanvas(output);
            canvas.Clear(SKColors.White);
            var photoWidth = template.PhotoPixelWidth;
            var photoHeight = template.PhotoPixelHeight;
            var marginX = Math.Max(0, (width - photoWidth * template.Columns) / (template.Columns + 1));
            var marginY = Math.Max(0, (height - photoHeight * template.Rows) / (template.Rows + 1));
            if ((long)photoWidth * template.Columns + (long)marginX * (template.Columns + 1) > width ||
                (long)photoHeight * template.Rows + (long)marginY * (template.Rows + 1) > height)
                throw new InvalidOperationException("مقاسات الصور لا تتسع على الورقة المحددة.");

            var sampling = new SKSamplingOptions(SKFilterMode.Linear);
            for (var index = 0; index < template.PhotoCount; index++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                using var photo = SkiaImageCodec.Decode(photoPaths[index % photoPaths.Count], MaximumPixels);
                var column = index % template.Columns;
                var row = index / template.Columns;
                var left = marginX + column * (photoWidth + marginX);
                var top = marginY + row * (photoHeight + marginY);
                var sourceRect = CenterCrop(photo.Width, photo.Height, photoWidth, photoHeight, cropAnchor);
                var destinationRect = new SKRect(left, top, left + photoWidth, top + photoHeight);
                canvas.DrawBitmap(photo, sourceRect, destinationRect, sampling, null);
                progress?.Report((index + 1d) / template.PhotoCount);
            }
            canvas.Flush();
            if (outputFormat == ImageOutputFormat.Jpeg)
                SkiaImageCodec.SaveJpeg(output, outputPath, jpegQuality, template.Dpi);
            else
                SkiaImageCodec.SavePng(output, outputPath, template.Dpi);
            return outputPath;
        }, cancellationToken);

    private static SKRect CenterCrop(
        int sourceWidth, int sourceHeight, int targetWidth, int targetHeight, PhotoCropAnchor anchor)
    {
        var sourceRatio = (double)sourceWidth / sourceHeight;
        var targetRatio = (double)targetWidth / targetHeight;
        if (sourceRatio > targetRatio)
        {
            var cropWidth = sourceHeight * targetRatio;
            var horizontalAnchor = anchor switch
            {
                PhotoCropAnchor.Left => 0d,
                PhotoCropAnchor.Right => 1d,
                _ => 0.5d
            };
            var left = (sourceWidth - cropWidth) * horizontalAnchor;
            return new SKRect((float)left, 0, (float)(left + cropWidth), sourceHeight);
        }

        var cropHeight = sourceWidth / targetRatio;
        var verticalAnchor = anchor switch
        {
            PhotoCropAnchor.Top => 0d,
            PhotoCropAnchor.Bottom => 1d,
            _ => 0.5d
        };
        var top = (sourceHeight - cropHeight) * verticalAnchor;
        return new SKRect(0, (float)top, sourceWidth, (float)(top + cropHeight));
    }

    private static void ApplySharpen(
        SKBitmap image, float amount, CancellationToken cancellationToken,
        IProgress<double>? progress, double progressStart, double progressEnd)
    {
        using var source = image.Copy(SKColorType.Rgba8888);
        var strength = Math.Clamp(amount, 0, 1) * 0.6f;
        for (var y = 1; y < source.Height - 1; y++)
        {
            cancellationToken.ThrowIfCancellationRequested();
            for (var x = 1; x < source.Width - 1; x++)
            {
                var center = source.GetPixel(x, y);
                var above = source.GetPixel(x, y - 1);
                var below = source.GetPixel(x, y + 1);
                var left = source.GetPixel(x - 1, y);
                var right = source.GetPixel(x + 1, y);
                image.SetPixel(x, y, new SKColor(
                    SharpenChannel(center.Red, above.Red, below.Red, left.Red, right.Red, strength),
                    SharpenChannel(center.Green, above.Green, below.Green, left.Green, right.Green, strength),
                    SharpenChannel(center.Blue, above.Blue, below.Blue, left.Blue, right.Blue, strength),
                    center.Alpha));
            }
            if (y % 32 == 0)
                progress?.Report(progressStart + (progressEnd - progressStart) * y / source.Height);
        }
    }

    private static void ApplyNoiseReduction(
        SKBitmap image, float amount, CancellationToken cancellationToken,
        IProgress<double>? progress, double progressStart, double progressEnd)
    {
        using var source = image.Copy(SKColorType.Rgba8888);
        var strength = Math.Clamp(amount, 0, 1);
        for (var y = 0; y < source.Height; y++)
        {
            cancellationToken.ThrowIfCancellationRequested();
            var aboveY = Math.Max(0, y - 1);
            var belowY = Math.Min(source.Height - 1, y + 1);
            for (var x = 0; x < source.Width; x++)
            {
                var leftX = Math.Max(0, x - 1);
                var rightX = Math.Min(source.Width - 1, x + 1);
                var center = source.GetPixel(x, y);
                var left = source.GetPixel(leftX, y);
                var right = source.GetPixel(rightX, y);
                var above = source.GetPixel(x, aboveY);
                var below = source.GetPixel(x, belowY);
                image.SetPixel(x, y, new SKColor(
                    Blend(center.Red, MedianOfFive(center.Red, left.Red, right.Red, above.Red, below.Red), strength),
                    Blend(center.Green, MedianOfFive(center.Green, left.Green, right.Green, above.Green, below.Green), strength),
                    Blend(center.Blue, MedianOfFive(center.Blue, left.Blue, right.Blue, above.Blue, below.Blue), strength),
                    center.Alpha));
            }
            if (y % 32 == 0)
                progress?.Report(progressStart + (progressEnd - progressStart) * (y + 1d) / source.Height);
        }
    }

    private static void ApplySkinRetouch(
        SKBitmap image, float amount, CancellationToken cancellationToken,
        IProgress<double>? progress, double progressStart, double progressEnd)
    {
        using var source = image.Copy(SKColorType.Rgba8888);
        var strength = Math.Clamp(amount, 0, 1) * 0.35f;
        for (var y = 1; y < source.Height - 1; y++)
        {
            cancellationToken.ThrowIfCancellationRequested();
            for (var x = 1; x < source.Width - 1; x++)
            {
                var center = source.GetPixel(x, y);
                if (!IsLikelySkin(center.Red / 255f, center.Green / 255f, center.Blue / 255f))
                    continue;

                var red = 0;
                var green = 0;
                var blue = 0;
                for (var offsetY = -1; offsetY <= 1; offsetY++)
                for (var offsetX = -1; offsetX <= 1; offsetX++)
                {
                    if (offsetX == 0 && offsetY == 0)
                        continue;
                    var neighbor = source.GetPixel(x + offsetX, y + offsetY);
                    red += neighbor.Red;
                    green += neighbor.Green;
                    blue += neighbor.Blue;
                }

                image.SetPixel(x, y, new SKColor(
                    Blend(center.Red, (byte)(red / 8), strength),
                    Blend(center.Green, (byte)(green / 8), strength),
                    Blend(center.Blue, (byte)(blue / 8), strength),
                    center.Alpha));
            }
            if (y % 32 == 0)
                progress?.Report(progressStart + (progressEnd - progressStart) * y / source.Height);
        }
    }

    private static byte MedianOfFive(byte first, byte second, byte third, byte fourth, byte fifth)
    {
        Span<byte> values = stackalloc byte[5] { first, second, third, fourth, fifth };
        values.Sort();
        return values[2];
    }

    private static byte Blend(byte source, byte target, float amount) =>
        (byte)Math.Clamp((int)MathF.Round(source + (target - source) * amount), 0, 255);

    private static bool IsLikelySkin(float red, float green, float blue)
    {
        var y = 0.299f * red + 0.587f * green + 0.114f * blue;
        return y is > 0.14f and < 0.92f &&
               red > 0.25f && green > 0.12f &&
               red >= green * 0.88f && green >= blue * 0.72f &&
               Math.Abs(red - green) > 0.025f;
    }

    private static byte SharpenChannel(byte center, byte above, byte below, byte left, byte right, float strength) =>
        ToByte((center + strength * (4 * center - above - below - left - right)) / 255f);

    private static byte ToByte(float value) => (byte)Math.Clamp((int)MathF.Round(value * 255), 0, 255);

    private static void ValidateAdjustments(ImageAdjustments value)
    {
        if (value.Brightness is < -1 or > 1 ||
            value.Contrast is < 0 or > 3 ||
            value.Saturation is < 0 or > 3 ||
            value.Sharpen is < 0 or > 1 ||
            value.Whitening is < 0 or > 1 ||
            value.Retouch is < 0 or > 1 ||
            value.NoiseReduction is < 0 or > 1)
            throw new ArgumentOutOfRangeException(nameof(value), "قيمة أحد إعدادات الصورة خارج النطاق.");
    }

    private static void EnsurePixelLimit(int width, int height)
    {
        if (width <= 0 || height <= 0 || (long)width * height > MaximumPixels)
            throw new InvalidDataException("الصورة كبيرة جدًا للمعالجة الآمنة.");
    }
}
