using System.Buffers.Binary;

namespace AlMaktaba.Processing;

internal static class PngDpiMetadata
{
    private static readonly byte[] Signature = [137, 80, 78, 71, 13, 10, 26, 10];

    public static byte[] Apply(byte[] png, int dpi)
    {
        if (dpi is < 72 or > 1200 || png.Length < 8 || !png.AsSpan(0, 8).SequenceEqual(Signature))
            throw new InvalidDataException("ملف PNG غير صالح أو قيمة DPI غير مدعومة.");

        var dpiChunk = CreateDpiChunk(dpi);
        using var output = new MemoryStream(png.Length + dpiChunk.Length);
        output.Write(png, 0, 8);

        var offset = 8;
        var inserted = false;
        while (offset + 12 <= png.Length)
        {
            var length = BinaryPrimitives.ReadUInt32BigEndian(png.AsSpan(offset, 4));
            if (length > int.MaxValue - 12)
                throw new InvalidDataException("ملف PNG تالف.");
            var chunkSize = (int)length + 12;
            if ((long)offset + chunkSize > png.Length)
                throw new InvalidDataException("ملف PNG تالف.");
            var chunkType = png.AsSpan(offset + 4, 4);
            if (chunkType.SequenceEqual("pHYs"u8))
            {
                offset += chunkSize;
                continue;
            }
            output.Write(png, offset, chunkSize);
            offset += chunkSize;
            if (chunkType.SequenceEqual("IHDR"u8))
            {
                if (inserted)
                    throw new InvalidDataException("ملف PNG يحتوي على رأس مكرر.");
                output.Write(dpiChunk);
                inserted = true;
            }
        }
        if (offset != png.Length || !inserted || !png.AsSpan(png.Length - 8, 4).SequenceEqual("IEND"u8))
            throw new InvalidDataException("ملف PNG تالف.");
        return output.ToArray();
    }

    private static byte[] CreateDpiChunk(int dpi)
    {
        var pixelsPerMeter = checked((uint)Math.Round(dpi / 0.0254, MidpointRounding.AwayFromZero));
        var chunk = new byte[21];
        BinaryPrimitives.WriteUInt32BigEndian(chunk.AsSpan(0, 4), 9);
        "pHYs"u8.CopyTo(chunk.AsSpan(4, 4));
        BinaryPrimitives.WriteUInt32BigEndian(chunk.AsSpan(8, 4), pixelsPerMeter);
        BinaryPrimitives.WriteUInt32BigEndian(chunk.AsSpan(12, 4), pixelsPerMeter);
        chunk[16] = 1;
        BinaryPrimitives.WriteUInt32BigEndian(chunk.AsSpan(17, 4), Crc32(chunk.AsSpan(4, 13)));
        return chunk;
    }

    private static uint Crc32(ReadOnlySpan<byte> data)
    {
        var crc = 0xffffffffu;
        foreach (var value in data)
        {
            crc ^= value;
            for (var bit = 0; bit < 8; bit++)
                crc = (crc & 1) != 0 ? (crc >> 1) ^ 0xedb88320u : crc >> 1;
        }
        return ~crc;
    }
}
