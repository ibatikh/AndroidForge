using SkiaSharp;

namespace AlMaktaba.Processing;

internal static class SkiaImageCodec
{
    public static SKBitmap Decode(string path, long maximumPixels)
    {
        using var codec = SKCodec.Create(path);
        if (codec is null)
            throw new InvalidDataException("تعذر قراءة بيانات الصورة أو أن تنسيقها غير مدعوم.");

        var info = codec.Info;
        if (info.Width <= 0 || info.Height <= 0 || (long)info.Width * info.Height > maximumPixels)
            throw new InvalidDataException("الصورة كبيرة جدًا للمعالجة الآمنة.");

        var decodeInfo = new SKImageInfo(info.Width, info.Height, SKColorType.Rgba8888, SKAlphaType.Unpremul);
        return SKBitmap.Decode(codec, decodeInfo)
            ?? throw new InvalidDataException("تعذر فك ترميز الصورة.");
    }

    public static SKBitmap CreateBitmap(int width, int height) =>
        new(new SKImageInfo(width, height, SKColorType.Rgba8888, SKAlphaType.Unpremul));

    public static void SavePng(SKBitmap bitmap, string path, int? dpi = null)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path))!);
        using var image = SKImage.FromBitmap(bitmap);
        using var data = image.Encode(SKEncodedImageFormat.Png, 100)
            ?? throw new InvalidDataException("تعذر حفظ الصورة بصيغة PNG.");
        var bytes = data.ToArray();
        if (dpi is not null)
            bytes = PngDpiMetadata.Apply(bytes, dpi.Value);
        File.WriteAllBytes(path, bytes);
    }

    public static void SaveJpeg(SKBitmap bitmap, string path, int quality = 92, int? dpi = null)
    {
        if (quality is < 1 or > 100)
            throw new ArgumentOutOfRangeException(nameof(quality));
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path))!);
        using var image = SKImage.FromBitmap(bitmap);
        using var data = image.Encode(SKEncodedImageFormat.Jpeg, quality)
            ?? throw new InvalidDataException("تعذر حفظ الصورة بصيغة JPEG.");
        var bytes = data.ToArray();
        if (dpi is not null)
            bytes = JpegDpiMetadata.Apply(bytes, dpi.Value);
        File.WriteAllBytes(path, bytes);
    }
}
