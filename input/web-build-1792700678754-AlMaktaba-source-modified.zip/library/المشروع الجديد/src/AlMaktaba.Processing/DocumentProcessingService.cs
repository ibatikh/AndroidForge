using System.Diagnostics;
using System.IO.Compression;
using DocumentFormat.OpenXml.Packaging;

namespace AlMaktaba.Processing;

public sealed class DocumentProcessingService
{
    private const long MaximumDocxBytes = 100L * 1024 * 1024;
    private const long MaximumUncompressedDocxBytes = 512L * 1024 * 1024;
    private const long MaximumPdfBytes = 512L * 1024 * 1024;
    private const int MaximumDocxEntries = 5_000;
    private static readonly TimeSpan DefaultTimeout = TimeSpan.FromMinutes(2);
    private readonly string? _configuredExecutable;

    public DocumentProcessingService() { }

    public DocumentProcessingService(string? executablePath) =>
        _configuredExecutable = executablePath;

    public async Task<string> ConvertDocxToPdfAsync(
        string docxPath,
        string outputDirectory,
        TimeSpan? timeout = null,
        CancellationToken cancellationToken = default,
        IProgress<double>? progress = null)
    {
        var executable = ResolveLibreOfficeExecutable();
        var fullInputPath = Path.GetFullPath(docxPath);
        ValidateDocx(fullInputPath);
        var effectiveTimeout = timeout ?? DefaultTimeout;
        if (effectiveTimeout <= TimeSpan.Zero || effectiveTimeout > TimeSpan.FromMinutes(30))
            throw new ArgumentOutOfRangeException(nameof(timeout), "مهلة التحويل يجب أن تكون بين صفر و30 دقيقة.");

        var fullOutputDirectory = Path.GetFullPath(outputDirectory);
        Directory.CreateDirectory(fullOutputDirectory);
        var workDirectory = Path.Combine(
            Path.GetTempPath(), "AlMaktaba-docx-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(workDirectory);
        var temporaryInput = Path.Combine(workDirectory, "input.docx");
        var temporaryPdf = Path.Combine(workDirectory, "input.pdf");
        try
        {
            await using (var source = new FileStream(
                             fullInputPath, FileMode.Open, FileAccess.Read, FileShare.Read,
                             64 * 1024, FileOptions.Asynchronous | FileOptions.SequentialScan))
            await using (var copy = new FileStream(
                             temporaryInput, FileMode.CreateNew, FileAccess.Write, FileShare.None,
                             64 * 1024, FileOptions.Asynchronous | FileOptions.SequentialScan))
            {
                await source.CopyToAsync(copy, cancellationToken);
                await copy.FlushAsync(cancellationToken);
            }

            var profileDirectory = Path.Combine(workDirectory, "lo-profile");
            Directory.CreateDirectory(profileDirectory);
            var startInfo = new ProcessStartInfo
            {
                FileName = executable,
                WorkingDirectory = workDirectory,
                UseShellExecute = false,
                CreateNoWindow = true,
                RedirectStandardOutput = true,
                RedirectStandardError = true
            };
            startInfo.ArgumentList.Add("--headless");
            startInfo.ArgumentList.Add("--nologo");
            startInfo.ArgumentList.Add("--nodefault");
            startInfo.ArgumentList.Add("--nolockcheck");
            startInfo.ArgumentList.Add($"-env:UserInstallation={new Uri(profileDirectory).AbsoluteUri}");
            startInfo.ArgumentList.Add("--convert-to");
            startInfo.ArgumentList.Add("pdf:writer_pdf_Export");
            startInfo.ArgumentList.Add("--outdir");
            startInfo.ArgumentList.Add(workDirectory);
            startInfo.ArgumentList.Add(temporaryInput);

            using var process = new Process { StartInfo = startInfo };
            cancellationToken.ThrowIfCancellationRequested();
            if (!process.Start())
                throw new InvalidOperationException("تعذر تشغيل LibreOffice.");

            progress?.Report(0);
            var stdoutTask = process.StandardOutput.ReadToEndAsync();
            var stderrTask = process.StandardError.ReadToEndAsync();
            using var timeoutSource = new CancellationTokenSource(effectiveTimeout);
            using var linkedSource = CancellationTokenSource.CreateLinkedTokenSource(
                cancellationToken, timeoutSource.Token);
            try
            {
                await process.WaitForExitAsync(linkedSource.Token);
            }
            catch (OperationCanceledException)
            {
                TryKill(process);
                await WaitForExitAfterKillAsync(process);
                if (cancellationToken.IsCancellationRequested)
                    throw new OperationCanceledException(cancellationToken);
                throw new TimeoutException("انتهت مهلة تحويل DOCX. أُوقف LibreOffice ولم يُعتمد ملف جزئي.");
            }

            var stdout = await stdoutTask;
            var stderr = await stderrTask;
            cancellationToken.ThrowIfCancellationRequested();
            if (process.ExitCode != 0)
            {
                var details = TruncateDiagnostics(stderr, stdout);
                throw new InvalidOperationException(string.IsNullOrWhiteSpace(details)
                    ? $"أعاد LibreOffice رمز خروج {process.ExitCode}."
                    : $"فشل LibreOffice (رمز {process.ExitCode}): {details}");
            }

            ValidatePdfOutput(temporaryPdf);
            var finalPath = Path.Combine(
                fullOutputDirectory,
                $"{Path.GetFileNameWithoutExtension(fullInputPath)}-{Guid.NewGuid():N}.pdf");
            File.Move(temporaryPdf, finalPath, overwrite: false);
            progress?.Report(1);
            return finalPath;
        }
        finally
        {
            try { Directory.Delete(workDirectory, recursive: true); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }
    }

    private string ResolveLibreOfficeExecutable()
    {
        if (_configuredExecutable is not null)
        {
            var configured = Path.GetFullPath(_configuredExecutable);
            if (File.Exists(configured))
                return configured;
            throw new FileNotFoundException("لم يُعثر على برنامج LibreOffice المحدد.", configured);
        }

        var names = OperatingSystem.IsWindows()
            ? new[] { "soffice.exe" }
            : new[] { "soffice" };
        foreach (var name in names)
        {
            foreach (var directory in (Environment.GetEnvironmentVariable("PATH") ?? "")
                         .Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries))
            {
                var candidate = Path.Combine(directory, name);
                if (File.Exists(candidate))
                    return candidate;
            }
        }

        if (OperatingSystem.IsWindows())
        {
            var candidates = new[]
            {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                    "LibreOffice", "program", "soffice.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
                    "LibreOffice", "program", "soffice.exe")
            };
            var installed = candidates.FirstOrDefault(File.Exists);
            if (installed is not null)
                return installed;
        }

        throw new FileNotFoundException(
            "LibreOffice غير مثبت أو لم يُعثر على soffice في PATH. ثبّته محليًا ثم أعد المحاولة.");
    }

    private static void ValidateDocx(string path)
    {
        var info = new FileInfo(path);
        if (!info.Exists || info.Length is <= 0 or > MaximumDocxBytes ||
            !Path.GetExtension(path).Equals(".docx", StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("ملف DOCX غير موجود أو حجمه/امتداده خارج الحد المدعوم.");

        try
        {
            using (var archive = ZipFile.OpenRead(path))
            {
                if (archive.Entries.Count is 0 or > MaximumDocxEntries ||
                    archive.GetEntry("[Content_Types].xml") is null ||
                    archive.GetEntry("word/document.xml") is null)
                    throw new InvalidDataException("بنية ملف DOCX غير مكتملة.");
                long uncompressedBytes = 0;
                foreach (var entry in archive.Entries)
                {
                    if (entry.FullName.StartsWith('/') ||
                        entry.FullName.Split('/', '\\').Any(part => part is "." or ".."))
                        throw new InvalidDataException("يحتوي ملف DOCX على مسار داخلي غير صالح.");
                    uncompressedBytes = checked(uncompressedBytes + entry.Length);
                    if (uncompressedBytes > MaximumUncompressedDocxBytes)
                        throw new InvalidDataException("المحتوى غير المضغوط لملف DOCX يتجاوز الحد الآمن.");
                }
            }

            using var document = WordprocessingDocument.Open(path, isEditable: false);
            if (document.MainDocumentPart?.Document?.Body is null)
                throw new InvalidDataException("لا يحتوي ملف DOCX على مستند Word صالح.");
        }
        catch (InvalidDataException)
        {
            throw;
        }
        catch (Exception exception) when (
            exception is IOException or OpenXmlPackageException or ArgumentException)
        {
            throw new InvalidDataException("تعذر قراءة بنية ملف DOCX. اختر مستند Word صالحًا.", exception);
        }
    }

    private static void ValidatePdfOutput(string path)
    {
        var info = new FileInfo(path);
        if (!info.Exists || info.Length is < 16 or > MaximumPdfBytes)
            throw new InvalidDataException("لم يُنشئ LibreOffice ملف PDF صالح الحجم.");
        using var stream = info.OpenRead();
        Span<byte> header = stackalloc byte[5];
        stream.ReadExactly(header);
        stream.Position = Math.Max(0, stream.Length - 2048);
        var tail = new byte[(int)Math.Min(2048, stream.Length)];
        stream.ReadExactly(tail);
        if (!header.StartsWith("%PDF-"u8) ||
            !System.Text.Encoding.Latin1.GetString(tail).Contains("%%EOF", StringComparison.Ordinal))
            throw new InvalidDataException("خرج LibreOffice لا يحمل بنية PDF مكتملة.");
    }

    private static string TruncateDiagnostics(string stderr, string stdout)
    {
        var details = string.Join(" ", new[] { stderr, stdout }
            .Where(text => !string.IsNullOrWhiteSpace(text))
            .Select(text => text.Trim()));
        return details.Length <= 2_000 ? details : details[..2_000] + "…";
    }

    private static void TryKill(Process process)
    {
        try
        {
            if (!process.HasExited)
                process.Kill(entireProcessTree: true);
        }
        catch (InvalidOperationException) { }
        catch (System.ComponentModel.Win32Exception) { }
    }

    private static async Task WaitForExitAfterKillAsync(Process process)
    {
        try { await process.WaitForExitAsync(CancellationToken.None); }
        catch (InvalidOperationException) { }
    }
}
