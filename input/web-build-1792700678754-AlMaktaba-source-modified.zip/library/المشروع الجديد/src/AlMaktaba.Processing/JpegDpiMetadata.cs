using System.Buffers.Binary;

namespace AlMaktaba.Processing;

internal static class JpegDpiMetadata
{
    public static byte[] Apply(byte[] jpeg, int dpi)
    {
        if (dpi is < 1 or > ushort.MaxValue)
            throw new ArgumentOutOfRangeException(nameof(dpi));
        if (jpeg.Length < 2 || jpeg[0] != 0xFF || jpeg[1] != 0xD8)
            throw new InvalidDataException("ملف JPEG غير صالح.");

        // JFIF APP0 segment: inch units, with the selected print resolution.
        byte[] segment =
        [
            0xFF, 0xE0, 0x00, 0x10,
            (byte)'J', (byte)'F', (byte)'I', (byte)'F', 0x00,
            0x01, 0x02, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
        ];
        BinaryPrimitives.WriteUInt16BigEndian(segment.AsSpan(12, 2), (ushort)dpi);
        BinaryPrimitives.WriteUInt16BigEndian(segment.AsSpan(14, 2), (ushort)dpi);

        var output = new byte[jpeg.Length + segment.Length];
        jpeg.AsSpan(0, 2).CopyTo(output);
        segment.CopyTo(output, 2);
        jpeg.AsSpan(2).CopyTo(output.AsSpan(2 + segment.Length));
        return output;
    }
}
