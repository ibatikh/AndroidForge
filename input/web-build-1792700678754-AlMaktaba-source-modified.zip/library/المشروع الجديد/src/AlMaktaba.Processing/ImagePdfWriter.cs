using System.IO.Compression;
using System.Globalization;
using System.Text;
using AlMaktaba.Core;
using SkiaSharp;

namespace AlMaktaba.Processing;

public sealed class ImagePdfWriter
{
    private const int MaximumImages = 100;
    private const long MaximumTotalRawPixels = 80_000_000;
    private const long MaximumPdfBytes = 512L * 1024 * 1024;

    public Task WriteAsync(
        IReadOnlyList<string> imagePaths,
        string outputPath,
        CancellationToken cancellationToken = default) =>
        WriteAsync(imagePaths, outputPath, new ImagePdfOptions(), null, cancellationToken);

    public Task WriteAsync(
        IReadOnlyList<string> imagePaths,
        string outputPath,
        ImagePdfOptions options,
        IProgress<double>? progress = null,
        CancellationToken cancellationToken = default) =>
        Task.Run(() =>
        {
            if (imagePaths.Count == 0)
                throw new ArgumentException("أضف صورة واحدة على الأقل.", nameof(imagePaths));
            if (imagePaths.Count > MaximumImages)
                throw new InvalidDataException($"الحد الأقصى للملف الواحد هو {MaximumImages} صورة.");
            ArgumentNullException.ThrowIfNull(options);
            if (!Enum.IsDefined(options.PaperSize) ||
                !Enum.IsDefined(options.Orientation) ||
                !Enum.IsDefined(options.Ordering) ||
                !Enum.IsDefined(options.Quality))
                throw new ArgumentOutOfRangeException(nameof(options), "خيارات PDF غير صالحة.");

            var orderedPaths = OrderImagePaths(imagePaths, options.Ordering);
            var pages = new List<PdfPageData>(orderedPaths.Count);
            long totalPixels = 0;
            long estimatedBytes = 0;
            for (var index = 0; index < orderedPaths.Count; index++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                using var bitmap = SkiaImageCodec.Decode(orderedPaths[index], 40_000_000);
                totalPixels = checked(totalPixels + (long)bitmap.Width * bitmap.Height);
                if (totalPixels > MaximumTotalRawPixels)
                    throw new InvalidDataException("إجمالي الصور يتجاوز الحد الآمن لإنشاء ملف PDF.");

                var quality = GetJpegQuality(options.Quality);
                byte[] imageBytes;
                var filter = quality is null ? "FlateDecode" : "DCTDecode";
                if (quality is null)
                {
                    imageBytes = EncodeLosslessRgb(bitmap, index, orderedPaths.Count, progress, cancellationToken);
                }
                else
                {
                    imageBytes = EncodeJpegRgb(bitmap, quality.Value, index, orderedPaths.Count, progress,
                        cancellationToken);
                }
                estimatedBytes = checked(estimatedBytes + imageBytes.LongLength + 4096);
                if (estimatedBytes > MaximumPdfBytes)
                    throw new InvalidDataException("ملف PDF الناتج أكبر من الحد الآمن البالغ 512 ميغابايت.");
                var (pageWidth, pageHeight) = GetPageDimensions(options.PaperSize, options.Orientation, bitmap.Width, bitmap.Height);
                pages.Add(new PdfPageData(bitmap.Width, bitmap.Height, imageBytes, filter, pageWidth, pageHeight));
                progress?.Report((index + 1d) / orderedPaths.Count * 0.95);
            }

            cancellationToken.ThrowIfCancellationRequested();
            WritePdf(pages, outputPath);
            progress?.Report(1);
            return outputPath;
        }, cancellationToken);

    private static IReadOnlyList<string> OrderImagePaths(
        IReadOnlyList<string> paths, ImagePdfOrdering ordering) =>
        ordering switch
        {
            ImagePdfOrdering.NameAscending => paths
                .OrderBy(Path.GetFileName, StringComparer.OrdinalIgnoreCase)
                .ThenBy(path => path, StringComparer.OrdinalIgnoreCase).ToArray(),
            ImagePdfOrdering.NameDescending => paths
                .OrderByDescending(Path.GetFileName, StringComparer.OrdinalIgnoreCase)
                .ThenBy(path => path, StringComparer.OrdinalIgnoreCase).ToArray(),
            _ => paths.ToArray()
        };

    private static int? GetJpegQuality(ImagePdfQuality quality) =>
        quality switch
        {
            ImagePdfQuality.Lossless => null,
            ImagePdfQuality.High => 92,
            ImagePdfQuality.Compact => 75,
            _ => throw new ArgumentOutOfRangeException(nameof(quality))
        };

    private static (double Width, double Height) GetPageDimensions(
        ImagePdfPaperSize paperSize, ImagePdfOrientation orientation, int imageWidth, int imageHeight)
    {
        var dimensions = paperSize switch
        {
            ImagePdfPaperSize.A4 => (595.28, 841.89),
            ImagePdfPaperSize.A3 => (841.89, 1190.55),
            ImagePdfPaperSize.A5 => (419.53, 595.28),
            ImagePdfPaperSize.Letter => (612d, 792d),
            ImagePdfPaperSize.Legal => (612d, 1008d),
            ImagePdfPaperSize.Photo10x15Cm => (10d / 2.54d * 72d, 15d / 2.54d * 72d),
            _ => throw new ArgumentOutOfRangeException(nameof(paperSize))
        };
        var landscape = orientation switch
        {
            ImagePdfOrientation.Landscape => true,
            ImagePdfOrientation.Portrait => false,
            ImagePdfOrientation.Automatic => imageWidth > imageHeight,
            _ => throw new ArgumentOutOfRangeException(nameof(orientation))
        };
        return landscape ? (dimensions.Item2, dimensions.Item1) : dimensions;
    }

    private static byte[] EncodeLosslessRgb(
        SKBitmap bitmap, int imageIndex, int imageCount, IProgress<double>? progress,
        CancellationToken cancellationToken)
    {
        using var compressed = new MemoryStream();
        using (var zlib = new ZLibStream(compressed, CompressionLevel.Optimal, leaveOpen: true))
        {
            var row = new byte[checked(bitmap.Width * 3)];
            for (var y = 0; y < bitmap.Height; y++)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var offset = 0;
                for (var x = 0; x < bitmap.Width; x++)
                {
                    var color = bitmap.GetPixel(x, y);
                    var alpha = color.Alpha / 255f;
                    row[offset++] = Composite(color.Red, alpha);
                    row[offset++] = Composite(color.Green, alpha);
                    row[offset++] = Composite(color.Blue, alpha);
                }
                zlib.Write(row);
                if (y % 32 == 0)
                    progress?.Report((imageIndex + y / (double)bitmap.Height) / imageCount * 0.95);
            }
        }
        return compressed.ToArray();
    }

    private static byte[] EncodeJpegRgb(
        SKBitmap bitmap, int quality, int imageIndex, int imageCount, IProgress<double>? progress,
        CancellationToken cancellationToken)
    {
        using var opaque = SkiaImageCodec.CreateBitmap(bitmap.Width, bitmap.Height);
        for (var y = 0; y < bitmap.Height; y++)
        {
            cancellationToken.ThrowIfCancellationRequested();
            for (var x = 0; x < bitmap.Width; x++)
            {
                var color = bitmap.GetPixel(x, y);
                var alpha = color.Alpha / 255f;
                opaque.SetPixel(x, y, new SKColor(
                    Composite(color.Red, alpha), Composite(color.Green, alpha),
                    Composite(color.Blue, alpha), 255));
            }
            if (y % 32 == 0)
                progress?.Report((imageIndex + y / (double)bitmap.Height) / imageCount * 0.95);
        }
        using var image = SKImage.FromBitmap(opaque);
        using var encoded = image.Encode(SKEncodedImageFormat.Jpeg, quality)
            ?? throw new InvalidDataException("تعذر ضغط الصورة داخل PDF.");
        return encoded.ToArray();
    }

    private static void WritePdf(IReadOnlyList<PdfPageData> pages, string outputPath)
    {
        var objects = new List<byte[]>
        {
            Encoding.ASCII.GetBytes("<< /Type /Catalog /Pages 2 0 R >>"),
            Array.Empty<byte>()
        };
        var pageIds = new List<int>(pages.Count);

        foreach (var page in pages)
        {
            var pageId = objects.Count + 1;
            var contentId = pageId + 1;
            var imageId = pageId + 2;
            pageIds.Add(pageId);
            var scale = Math.Min(page.PageWidthPoints / page.Width, page.PageHeightPoints / page.Height);
            var drawnWidth = page.Width * scale;
            var drawnHeight = page.Height * scale;
            var left = (page.PageWidthPoints - drawnWidth) / 2;
            var bottom = (page.PageHeightPoints - drawnHeight) / 2;
            var content = Encoding.ASCII.GetBytes(
                $"q {FormatNumber(drawnWidth)} 0 0 {FormatNumber(drawnHeight)} " +
                $"{FormatNumber(left)} {FormatNumber(bottom)} cm /Im0 Do Q");

            objects.Add(Encoding.ASCII.GetBytes(
                $"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {FormatNumber(page.PageWidthPoints)} {FormatNumber(page.PageHeightPoints)}] " +
                $"/Resources << /XObject << /Im0 {imageId} 0 R >> >> /Contents {contentId} 0 R >>"));
            objects.Add(EncodeStreamObject("<<", content, ">>"));
            objects.Add(EncodeStreamObject(
                $"<< /Type /XObject /Subtype /Image /Width {page.Width} /Height {page.Height} " +
                $"/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /{page.Filter}",
                page.ImageBytes,
                ">>"));
        }

        var kids = string.Join(" ", pageIds.Select(id => $"{id} 0 R"));
        objects[1] = Encoding.ASCII.GetBytes($"<< /Type /Pages /Count {pages.Count} /Kids [{kids}] >>");

        var directory = Path.GetDirectoryName(Path.GetFullPath(outputPath))!;
        Directory.CreateDirectory(directory);
        var temporaryPath = Path.Combine(directory, $".{Path.GetFileName(outputPath)}.{Guid.NewGuid():N}.tmp");
        try
        {
            using var stream = new FileStream(temporaryPath, FileMode.CreateNew, FileAccess.Write, FileShare.None);
            using var writer = new BinaryWriter(stream, Encoding.ASCII, leaveOpen: true);
            writer.Write("%PDF-1.7\n"u8);
            var offsets = new List<long> { 0 };
            for (var index = 0; index < objects.Count; index++)
            {
                offsets.Add(stream.Position);
                writer.Write(Encoding.ASCII.GetBytes($"{index + 1} 0 obj\n"));
                writer.Write(objects[index]);
                writer.Write("\nendobj\n"u8);
            }

            var xrefOffset = stream.Position;
            writer.Write(Encoding.ASCII.GetBytes($"xref\n0 {objects.Count + 1}\n"));
            writer.Write("0000000000 65535 f \n"u8);
            foreach (var offset in offsets.Skip(1))
                writer.Write(Encoding.ASCII.GetBytes($"{offset:0000000000} 00000 n \n"));
            writer.Write(Encoding.ASCII.GetBytes(
                $"trailer\n<< /Size {objects.Count + 1} /Root 1 0 R >>\nstartxref\n{xrefOffset}\n%%EOF"));
            writer.Flush();
            stream.Flush(flushToDisk: true);
            File.Move(temporaryPath, outputPath, overwrite: true);
        }
        catch
        {
            if (File.Exists(temporaryPath))
                File.Delete(temporaryPath);
            throw;
        }
    }

    private static byte[] EncodeStreamObject(string dictionaryStart, byte[] data, string dictionaryEnd)
    {
        using var output = new MemoryStream(data.Length + 200);
        var header = Encoding.ASCII.GetBytes($"{dictionaryStart} /Length {data.Length} {dictionaryEnd}\nstream\n");
        output.Write(header);
        output.Write(data);
        output.Write("\nendstream"u8);
        return output.ToArray();
    }

    private static byte Composite(byte color, float alpha) =>
        (byte)Math.Clamp((int)MathF.Round(color * alpha + 255 * (1 - alpha)), 0, 255);

    private static string FormatNumber(double value) =>
        value.ToString("0.###", CultureInfo.InvariantCulture);

    private sealed record PdfPageData(
        int Width, int Height, byte[] ImageBytes, string Filter, double PageWidthPoints, double PageHeightPoints);
}
