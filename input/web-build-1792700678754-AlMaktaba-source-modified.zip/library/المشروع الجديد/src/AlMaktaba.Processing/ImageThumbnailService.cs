using AlMaktaba.Core;
using SkiaSharp;

namespace AlMaktaba.Processing;

public sealed class ImageThumbnailService(AppPaths paths)
{
    private const int ThumbnailWidth = 320;
    private const int ThumbnailHeight = 240;
    private const long MaximumPixels = 40_000_000;

    public Task<string> CreateAsync(
        string sourcePath, string outputPath, CancellationToken cancellationToken = default) =>
        Task.Run(() =>
        {
            cancellationToken.ThrowIfCancellationRequested();
            using var source = SkiaImageCodec.Decode(sourcePath, MaximumPixels);
            using var thumbnail = new SKBitmap(
                new SKImageInfo(ThumbnailWidth, ThumbnailHeight, SKColorType.Rgba8888, SKAlphaType.Unpremul));
            using (var canvas = new SKCanvas(thumbnail))
            {
                canvas.Clear(SKColors.White);
                var scale = Math.Min(
                    ThumbnailWidth / (double)source.Width,
                    ThumbnailHeight / (double)source.Height);
                var width = source.Width * scale;
                var height = source.Height * scale;
                var left = (ThumbnailWidth - width) / 2;
                var top = (ThumbnailHeight - height) / 2;
                canvas.DrawBitmap(
                    source,
                    new SKRect(0, 0, source.Width, source.Height),
                    new SKRect((float)left, (float)top, (float)(left + width), (float)(top + height)),
                    new SKSamplingOptions(SKFilterMode.Linear, SKMipmapMode.Linear));
                canvas.Flush();
            }

            cancellationToken.ThrowIfCancellationRequested();
            var fullOutputPath = Path.GetFullPath(outputPath);
            var thumbnailRoot = Path.GetFullPath(paths.Thumbnails);
            if (!Path.GetDirectoryName(fullOutputPath)!.Equals(
                    thumbnailRoot,
                    OperatingSystem.IsWindows() ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal) ||
                !Path.GetExtension(fullOutputPath).Equals(".jpg", StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("يجب حفظ المعاينة ضمن مجلد thumbnails وبامتداد JPG.");
            RejectReparsePointAncestors(Path.GetFullPath(paths.Root), fullOutputPath);
            Directory.CreateDirectory(thumbnailRoot);
            var temporaryPath = fullOutputPath + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                using var image = SKImage.FromBitmap(thumbnail);
                using var data = image.Encode(SKEncodedImageFormat.Jpeg, 82)
                    ?? throw new InvalidDataException("تعذر إنشاء المعاينة المصغرة.");
                File.WriteAllBytes(temporaryPath, data.ToArray());
                cancellationToken.ThrowIfCancellationRequested();
                RejectReparsePointAncestors(Path.GetFullPath(paths.Root), fullOutputPath);
                File.Move(temporaryPath, fullOutputPath, overwrite: true);
                return fullOutputPath;
            }
            finally
            {
                if (File.Exists(temporaryPath))
                    File.Delete(temporaryPath);
            }
        }, cancellationToken);

    private static void RejectReparsePointAncestors(string root, string target)
    {
        var rootPrefix = Path.EndsInDirectorySeparator(root) ? root : root + Path.DirectorySeparatorChar;
        if (!target.StartsWith(rootPrefix, OperatingSystem.IsWindows()
                ? StringComparison.OrdinalIgnoreCase
                : StringComparison.Ordinal))
            throw new InvalidDataException("مسار المعاينة المصغرة خارج مجلد بيانات التطبيق.");

        var current = root;
        RejectReparsePointIfPresent(current);
        foreach (var segment in Path.GetRelativePath(root, target).Split(
                     [Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar],
                     StringSplitOptions.RemoveEmptyEntries))
        {
            current = Path.Combine(current, segment);
            if (!RejectReparsePointIfPresent(current))
                break;
        }
    }

    private static bool RejectReparsePointIfPresent(string path)
    {
        try
        {
            if ((File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0)
                throw new InvalidDataException("لا يمكن حفظ معاينة عبر رابط رمزي.");
            return true;
        }
        catch (FileNotFoundException)
        {
            return false;
        }
        catch (DirectoryNotFoundException)
        {
            return false;
        }
    }
}
