#!/usr/bin/env sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
SRC="$ROOT/src"
PATTERN='HttpClient|System\.Net\.Http|Gemini|Google\.GenAI|Telegram|Supabase|Picsart|Remove\.bg|AILabAPI|ConvertAPI|boto3|\bS3\b'

if rg -n -i "$PATTERN" "$SRC" \
  --glob '*.cs' --glob '*.csproj' \
  --glob '!**/bin/**' --glob '!**/obj/**'; then
  echo "Offline boundary violation: remove network providers and HTTP clients from production source." >&2
  exit 1
fi

echo "Offline boundary check passed: no prohibited provider or HTTP client reference in production source."
