[CmdletBinding()]
param(
    [switch]$RequireSigning
)

$ErrorActionPreference = "Stop"

if (-not $IsWindows) {
    throw "This script requires Windows because WinUI 3's XAML compiler is Windows-only."
}

$projectRoot = Split-Path -Parent $PSScriptRoot
$solutionPath = Join-Path $projectRoot "AlMaktaba.sln"
$appProjectPath = Join-Path $projectRoot "src/AlMaktaba.App/AlMaktaba.App.csproj"
$testProjectPath = Join-Path $projectRoot "tests/AlMaktaba.Tests/AlMaktaba.Tests.csproj"
$packageOutputRoot = Join-Path $projectRoot "generated-artifacts/AlMaktaba"
$packageOutput = Join-Path $packageOutputRoot ([Guid]::NewGuid().ToString("N"))
$certificatePath = $null

function Invoke-DotNet {
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments
    )

    & dotnet @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "dotnet $($Arguments -join ' ') failed with exit code $LASTEXITCODE."
    }
}

if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw ".NET SDK 10 is required. Install it before running this script."
}

$hasCertificate = -not [string]::IsNullOrWhiteSpace($env:WINDOWS_PFX_BASE64)
$hasPassword = -not [string]::IsNullOrWhiteSpace($env:WINDOWS_PFX_PASSWORD)
if ($hasCertificate -ne $hasPassword) {
    throw "Set both WINDOWS_PFX_BASE64 and WINDOWS_PFX_PASSWORD, or leave both unset."
}
if ($RequireSigning -and -not $hasCertificate) {
    throw "Signed packaging requires WINDOWS_PFX_BASE64 and WINDOWS_PFX_PASSWORD environment variables."
}

$signPackage = $hasCertificate -and $hasPassword
New-Item -ItemType Directory -Force -Path $packageOutput | Out-Null

Push-Location $projectRoot
try {
    if ($signPackage) {
        $tempRoot = if ($env:RUNNER_TEMP) { $env:RUNNER_TEMP } else { [IO.Path]::GetTempPath() }
        $certificatePath = Join-Path $tempRoot "AlMaktaba-signing.pfx"
        $certificateBytes = [Convert]::FromBase64String($env:WINDOWS_PFX_BASE64)
        [IO.File]::WriteAllBytes($certificatePath, $certificateBytes)
        $env:PackageCertificateKeyFile = $certificatePath
        $env:PackageCertificatePassword = $env:WINDOWS_PFX_PASSWORD
    }

    Invoke-DotNet @("restore", $solutionPath)
    Invoke-DotNet @("build", $solutionPath, "-c", "Release", "--no-restore")

    $bash = Get-Command bash -ErrorAction SilentlyContinue
    if (-not $bash) {
        throw "Bash is required to run scripts/check-offline-boundary.sh. Install Git for Windows or use GitHub Actions."
    }
    & $bash.Source "scripts/check-offline-boundary.sh"
    if ($LASTEXITCODE -ne 0) {
        throw "The offline-boundary check failed with exit code $LASTEXITCODE."
    }

    Invoke-DotNet @("test", $testProjectPath, "-c", "Release", "--no-build", "--no-restore")

    $packageDirectory = $packageOutput.TrimEnd("\") + "\"
    $publishArguments = @(
        "publish",
        $appProjectPath,
        "-c", "Release",
        "-r", "win-x64",
        "--no-restore",
        "-p:Platform=x64",
        "-p:AppxPackageDir=$packageDirectory",
        "-p:AppxPackageSigningEnabled=$($signPackage.ToString().ToLowerInvariant())"
    )
    Invoke-DotNet $publishArguments

    $packages = @(
        Get-ChildItem -Path $packageOutput -File -Recurse |
            Where-Object { $_.Extension -in @(".msix", ".msixbundle") }
    )
    if ($packages.Count -eq 0) {
        throw "The publish command completed but produced no .msix or .msixbundle file under $packageOutput."
    }

    $packageState = if ($signPackage) { "signed" } else { "unsigned" }
    Write-Host "Created $($packages.Count) $packageState MSIX package(s):"
    $packages | ForEach-Object { Write-Host " - $($_.FullName)" }
}
finally {
    Pop-Location
    if ($certificatePath -and (Test-Path -LiteralPath $certificatePath)) {
        Remove-Item -LiteralPath $certificatePath -Force
    }
    Remove-Item Env:PackageCertificateKeyFile -ErrorAction SilentlyContinue
    Remove-Item Env:PackageCertificatePassword -ErrorAction SilentlyContinue
}
