import requests
import json
import os
import time
import logging
from PIL import Image, ImageDraw, ImageEnhance
from zipfile import ZipFile, ZIP_DEFLATED
import uuid
import mimetypes
import io
from datetime import datetime
import pytz
import asyncio
from db import db  # db.py في نفس المجلد
import subprocess
import sys
import threading
from queue import Queue

# ===== STARTUP CHECKS - تحقق من التبعيات =====
def check_and_install_dependencies():
    """التحقق من التبعيات وتثبيت أي مكتبات ناقصة تلقائياً"""
    python_libs = {
        "requests": ("requests", "requests"),
        "PIL (Pillow)": ("PIL", "Pillow"),
        "reportlab": ("reportlab", "reportlab"),
        "python-docx": ("docx", "python-docx"),
        "pypdfium2": ("pypdfium2", "pypdfium2"),
        "pytz": ("pytz", "pytz"),
        "convertapi": ("convertapi", "convertapi"),
        "google-genai": ("google.genai", "google-genai"),
        "img2pdf": ("img2pdf", "img2pdf")
    }
    
    missing_libs = []
    installed_libs = []
    
    print("\n" + "="*50)
    print("🚀 بدء البوت - فحص التبعيات")
    print("="*50 + "\n")
    
    # التحقق من مكتبات Python
    print("📚 فحص مكتبات Python...")
    for display_name, (module_name, package_name) in python_libs.items():
        try:
            __import__(module_name)
            print(f"  ✅ {display_name}")
            installed_libs.append(display_name)
        except ImportError:
            print(f"  ⚠️  {display_name} غير مثبتة - جاري التثبيت...")
            missing_libs.append((display_name, package_name))
            # تثبيت المكتبة الناقصة
            try:
                subprocess.run(
                    [sys.executable, "-m", "pip", "install", package_name, "-q"],
                    timeout=120,
                    capture_output=True
                )
                print(f"     ✅ تم تثبيت {display_name} بنجاح")
                installed_libs.append(display_name)
                missing_libs.pop()
            except Exception as e:
                print(f"     ❌ فشل تثبيت {display_name}: {str(e)}")
    
    # استخدام ConvertAPI بدلاً من LibreOffice (لا حاجة لتثبيت برامج إضافية)
    print("\n🔧 فحص تبعيات النظام...")
    print("  ✅ ConvertAPI (تحويل DOCX إلى PDF - سحابي)")
    
    print("\n" + "="*50)
    print(f"✅ تم إعداد البوت - {len(installed_libs)} مكتبة جاهزة")
    print("="*50 + "\n")
    
    logging.info("✅ جميع التبعيات جاهزة - البوت جاهز للتشغيل")

# ===== DOCX CONVERSION QUEUE =====
docx_conversion_queue = Queue()
is_processing_docx = False
user_conversion_counts = {}  # تتبع عدد ملفات كل مستخدم
pending_docx_files = {}  # قائمة الملفات المعلقة: {chat_id: [(docx_path, file_name), ...]}
pending_docx_message_ids = {}  # معرفات الرسائل: {chat_id: message_id}

def docx_queue_worker():
    """معالج قائمة الانتظار - يعالج ملفات الوورد بالتوالي مع عرض التقدم"""
    global is_processing_docx, user_conversion_counts
    
    logging.info("✅ بدء معالج قائمة انتظار DOCX - في الانتظار للملفات...")
    
    while True:
        try:
            # الانتظار على ملف من القائمة - محجوز بلا timeout
            task = docx_conversion_queue.get(block=True)
            logging.info(f"📥 تم استقبال مهمة من القائمة: {task}")
            
            if task is None:  # إشارة إيقاف
                logging.info("⛔ استقبلت إشارة إيقاف معالج القائمة")
                break
            
            docx_path, file_name, chat_id, current_idx, total_count = task
            is_processing_docx = True
            
            logging.info(f"🔄 بدء معالجة: {file_name} ({current_idx}/{total_count})")
            
            # إرسال رسالة المعالجة وحفظ معرفها للحذف لاحقاً
            processing_msg = send_message(chat_id, f"⏳ جاري تحويل الملف {current_idx}/{total_count}: {file_name}")
            
            success = False
            result = None
            
            try:
                success, result = convert_docx_to_pdf(docx_path, file_name)
                logging.info(f"📊 نتيجة التحويل: success={success}")
                
                if success:
                    # بناء caption مع المعلومات المهمة
                    caption = f"✅ الملف {current_idx}/{total_count} تم تحويله!\n📝 الاسم الأصلي: {file_name}"
                    
                    if send_document(chat_id, result, caption):
                        # حذف رسالة المعالجة بعد إرسال الملف
                        if processing_msg:
                            delete_message(chat_id, processing_msg)
                        logging.info(f"✅ تم إرسال الملف {current_idx}/{total_count} وحذف رسالة المعالجة")
                    else:
                        # إذا فشل الإرسال، أرسل رسالة خطأ بدلاً من حذف رسالة المعالجة
                        send_message(chat_id, f"❌ فشل في إرسال الملف {current_idx}/{total_count}.")
                        logging.error(f"❌ فشل إرسال الملف {current_idx}/{total_count}")
                else:
                    # حذف رسالة المعالجة وأرسل رسالة الخطأ
                    if processing_msg:
                        delete_message(chat_id, processing_msg)
                    send_message(chat_id, f"❌ فشل تحويل الملف {current_idx}/{total_count}: {result}")
                    logging.error(f"❌ فشل التحويل للملف {current_idx}/{total_count}: {result}")
                    
            except Exception as e:
                logging.error(f"❌ استثناء أثناء التحويل: {e}", exc_info=True)
                # حذف رسالة المعالجة وأرسل رسالة الخطأ
                if processing_msg:
                    delete_message(chat_id, processing_msg)
                send_message(chat_id, f"❌ خطأ في الملف {current_idx}/{total_count}: {str(e)}")
            
            # تنظيف الملفات المؤقتة
            try:
                if os.path.exists(docx_path):
                    os.remove(docx_path)
                    logging.info(f"🗑️ تم حذف الملف المؤقت: {docx_path}")
            except Exception as e:
                logging.warning(f"⚠️ لم يتمكن من حذف الملف المؤقت: {e}")
            
            try:
                if success and result and os.path.exists(result):
                    os.remove(result)
            except:
                pass
            
            # إنهاء المهمة وتحرير الموارد
            docx_conversion_queue.task_done()
            is_processing_docx = False
            logging.info(f"✅ انتهت معالجة الملف {current_idx}/{total_count} - جاهز للملف التالي")
            
        except Exception as e:
            logging.error(f"❌ استثناء خطير في معالج القائمة (سيستمر): {e}", exc_info=True)
            is_processing_docx = False
            time.sleep(0.5)

# لن نبدأ معالج القائمة هنا - سيتم بدؤه في main

def init_convertapi_key_from_env():
    """تهيئة مفتاح ConvertAPI من متغيرات البيئة تلقائياً عند البدء"""
    env_key = os.getenv('CONVERTAPI_KEY')
    if env_key:
        convertapi_key_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "keys", "convertapi_key.json")
        os.makedirs(os.path.dirname(convertapi_key_file), exist_ok=True)
        
        data = {'current_key': env_key, 'backup_keys': [], 'expired_keys': [], 'used_count': 0}
        try:
            with open(convertapi_key_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
            logging.info("✅ تم حفظ مفتاح ConvertAPI من البيئة تلقائياً")
        except Exception as e:
            logging.error(f"❌ فشل حفظ مفتاح ConvertAPI: {e}")

# تشغيل الفحص عند البدء
check_and_install_dependencies()
init_convertapi_key_from_env()

# Iraq timezone
IRAQ_TZ = pytz.timezone('Asia/Baghdad')

def to_english_numerals(text):
    """Convert Arabic numerals to English numerals"""
    if not isinstance(text, str):
        text = str(text)
    arabic_to_english = str.maketrans('٠١٢٣٤٥٦٧٨٩', '0123456789')
    return text.translate(arabic_to_english)

def get_iraq_time():
    """Get current time in Iraq timezone"""
    return datetime.now(IRAQ_TZ)

def create_progress_indicator(progress_percent, operation_text="Processing..."):
    """
    Create a visual progress indicator with dynamic loading feedback using block characters.
    
    Args:
        progress_percent (int): Progress percentage (0-100)
        operation_text (str): Text describing current operation
    
    Returns:
        str: Formatted progress indicator message
    """
    # Ensure progress is within bounds
    progress_percent = max(0, min(100, progress_percent))
    
    # Create progress bar using block characters
    bar_length = 20
    filled_length = int(bar_length * progress_percent / 100)
    
    # Build the bar
    filled_bar = "█" * filled_length
    empty_bar = "░" * (bar_length - filled_length)
    progress_bar = f"{filled_bar}{empty_bar}"
    
    return f"⏳ {operation_text}\n{progress_bar} {progress_percent}%"

def create_auto_processing_indicator(progress_percent, operation_text="جاري المعالجة..."):
    """
    Create special progress indicator for auto processing with block and gray characters.
    
    Args:
        progress_percent (int): Progress percentage (0-100)
        operation_text (str): Text describing current operation
    
    Returns:
        str: Formatted progress indicator message
    """
    # Ensure progress is within bounds
    progress_percent = max(0, min(100, progress_percent))
    
    # Create progress bar with special design
    bar_length = 15
    filled_length = int(bar_length * progress_percent / 100)
    
    # Build the bar
    filled_bar = "█" * filled_length
    empty_bar = "▒" * (bar_length - filled_length)
    progress_bar = f"{filled_bar}{empty_bar}"
    
    return f"🤖 {operation_text}\n{progress_bar} {progress_percent}%"

def create_status_loading_indicator(progress_percent):
    """
    Create special progress indicator for status loading with green circles.
    
    Args:
        progress_percent (int): Progress percentage (0-100)
    
    Returns:
        str: Formatted progress indicator message
    """
    # Ensure progress is within bounds
    progress_percent = max(0, min(100, progress_percent))
    
    # Create progress bar with circles
    bar_length = 10
    filled_length = int(bar_length * progress_percent / 100)
    
    # Build the bar
    filled_bar = "🟢" * filled_length
    empty_bar = "⚪" * (bar_length - filled_length)
    progress_bar = f"{filled_bar}{empty_bar}"
    
    return f"⏳ جاري تحميل حالة البوت...\n{progress_bar} {progress_percent}%"

def send_progress_update(chat_id, message_id, progress_percent, operation_text="Processing..."):
    """
    Send or update a progress indicator message.
    
    Args:
        chat_id (int): Chat ID to send message to
        message_id (int): Message ID to edit (None for new message)
        progress_percent (int): Progress percentage (0-100)
        operation_text (str): Text describing current operation
    
    Returns:
        int or None: Message ID of the progress message
    """
    progress_text = create_progress_indicator(progress_percent, operation_text)
    
    edit_succeeded = False
    
    if message_id:
        # Try to edit existing message
        try:
            response = make_request(f"{API_URL}/editMessageText", method='POST',
                        json_data={
                            'chat_id': chat_id,
                            'message_id': message_id,
                            'text': progress_text
                        })
            # Check both HTTP code and Telegram's 'ok' field
            if response and response.get('http_code') == 200:
                try:
                    response_json = response['response'].json()
                    if response_json.get('ok') == True:
                        # Edit succeeded!
                        edit_succeeded = True
                        return message_id
                    else:
                        # Telegram returned ok=false (e.g., message too old, not found, etc.)
                        error_desc = response_json.get('description', 'unknown error')
                        logging.warning(f"Edit failed (Telegram ok=false: {error_desc}), will send new message")
                except (json.JSONDecodeError, KeyError, AttributeError) as e:
                    logging.warning(f"Failed to parse edit response JSON: {e}, will send new message")
            else:
                logging.warning(f"Edit failed (HTTP {response.get('http_code') if response else 'None'}), will send new message")
        except Exception as e:
            logging.warning(f"Edit request failed: {e}, will send new message")
    
    # Send new message (either message_id was None or editing failed)
    # Only execute if edit didn't succeed
    if not edit_succeeded:
        try:
            response = make_request(f"{API_URL}/sendMessage", method='POST',
                                  json_data={
                                      'chat_id': chat_id,
                                      'text': progress_text
                                  })
            if response and response.get('http_code') == 200:
                try:
                    response_json = response['response'].json()
                    if response_json.get('ok') == True:
                        new_msg_id = response_json.get('result', {}).get('message_id')
                        if new_msg_id:
                            return new_msg_id
                        else:
                            logging.error(f"sendMessage succeeded but no message_id in response")
                            return None
                    else:
                        error_desc = response_json.get('description', 'unknown error')
                        logging.error(f"Failed to send progress message (Telegram ok=false: {error_desc})")
                        return None
                except (json.JSONDecodeError, KeyError, AttributeError) as e:
                    logging.error(f"Failed to parse sendMessage response JSON: {e}")
                    return None
            else:
                logging.error(f"Failed to send progress message: HTTP {response.get('http_code') if response else 'None'}")
                return None
        except Exception as e:
            logging.error(f"Failed to send progress message: {e}")
            return None
    
    # Should never reach here
    return None

def create_status_animation(frame=0):
    """
    Create animated status indicator with professional wave effect.
    Creates a smooth wave pattern that moves from left to right continuously.
    
    Args:
        frame (int): Animation frame number
    
    Returns:
        str: Animated status bar with wave effect
    """
    # Define the wave pattern
    wave_pattern = "▁▁▁▁▁▁▂▃▄▅▆▇█▇▆▅▄▃▂▁▁▁▁▁▁▁▁▁"
    pattern_length = len(wave_pattern)
    
    # Calculate the starting position based on frame
    # This creates a continuous scrolling effect
    start_pos = frame % pattern_length
    
    # Create the animated wave by rotating the pattern
    animated_wave = wave_pattern[start_pos:] + wave_pattern[:start_pos]
    
    return animated_wave

def send_animated_status(chat_id, status_message, duration=900):
    """
    Send an animated status message with continuous updates for 15 minutes.
    
    Args:
        chat_id (int): Chat ID to send message to
        status_message (str): Base status message (without animation)
        duration (float): Animation duration in seconds (default 15 minutes)
    
    Returns:
        int or None: Message ID of the status message
    """
    import threading
    
    try:
        # Send initial message
        initial_text = f"▁▁▁▁▁▁▂▃▄▅▆▇█▇▆▅▄▃▂▁▁▁▁▁▁▁▁▁\n\n{status_message}"
        response = make_request(f"{API_URL}/sendMessage", method='POST',
                              json_data={
                                  'chat_id': chat_id,
                                  'text': initial_text,
                                  'parse_mode': 'Markdown'
                              })
        
        if not response or response.get('http_code') != 200:
            return None
            
        message_id = response['response'].json().get('result', {}).get('message_id')
        
        def animate_status():
            """Background thread to animate the status message"""
            start_time = time.time()
            frame = 0
            consecutive_errors = 0
            
            while time.time() - start_time < duration:
                try:
                    # Calculate uptime
                    current_uptime = time.time() - BOT_START_TIME.timestamp()
                    days = int(current_uptime // 86400)
                    hours = int((current_uptime % 86400) // 3600)
                    minutes = int((current_uptime % 3600) // 60)
                    seconds = int(current_uptime % 60)
                    
                    # Get current time
                    current_time = get_iraq_time()
                    current_time_12h = to_english_numerals(current_time.strftime('%d/%m/%Y - %I:%M:%S %p'))
                    
                    # Build animated status with wave effect
                    animated_text = f"{create_status_animation(frame)}\n\n"
                    animated_text += f"📊 *حالة البوت في :* {current_time_12h}\n\n"
                    animated_text += f"🗄️ *اتصال قاعدة البيانات:* ✅ متصل\n"
                    animated_text += f"⏰ *وقت التشغيل:* {to_english_numerals(f'{days} يوم | {hours} ساعة | {minutes} دقيقة | {seconds} ثانية')}\n"
                    
                    # Add version info
                    version_data = load_bot_version()
                    show_version = version_data.get('show_in_status', True)
                    
                    if show_version:
                        import re
                        match = re.match(r'(\d+)\.(\d+)\.(\d+)', version_data['version'])
                        major, minor, patch = map(int, match.groups()) if match else (2, 0, 0)
                        build = version_data.get('build', 1)
                        status = version_data.get('status', 'مستقر')
                        release_date = version_data.get('release_date', 'غير محدد')
                        
                        show_components = version_data.get('show_components', {
                            'major': True, 'minor': True, 'patch': True, 'build': True,
                            'status': True, 'release_date': True
                        })
                        
                        animated_text += f"\n🔢 *معلومات الإصدار:*\n"
                        
                        version_parts = []
                        if show_components.get('major', True):
                            version_parts.append(str(major))
                        if show_components.get('minor', True):
                            version_parts.append(str(minor))
                        if show_components.get('patch', True):
                            version_parts.append(str(patch))
                        
                        if version_parts:
                            version_str = '.'.join(version_parts)
                            if show_components.get('build', True):
                                version_str += f" Build {build}"
                            animated_text += f"• الإصدار: `{to_english_numerals(version_str)}`\n"
                        
                        if show_components.get('status', True):
                            animated_text += f"• الحالة: {status}\n"
                        
                        if show_components.get('release_date', True):
                            animated_text += f"• تاريخ الإصدار: {to_english_numerals(release_date)}\n"
                    
                    # Try to update message
                    edit_response = make_request(f"{API_URL}/editMessageText", method='POST',
                                   json_data={
                                       'chat_id': chat_id,
                                       'message_id': message_id,
                                       'text': animated_text,
                                       'parse_mode': 'Markdown'
                                   })
                    
                    # Check if edit was successful
                    if edit_response and edit_response.get('http_code') == 200:
                        consecutive_errors = 0
                    else:
                        consecutive_errors += 1
                        # If too many consecutive errors, stop animation
                        if consecutive_errors > 5:
                            logging.warning(f"Stopping status animation due to {consecutive_errors} consecutive errors")
                            break
                    
                    frame += 1
                    time.sleep(1)  # Update every second
                    
                except Exception as e:
                    logging.error(f"Failed to animate status frame {frame}: {e}")
                    consecutive_errors += 1
                    if consecutive_errors > 5:
                        break
                    time.sleep(1)
        
        # Start animation in background thread
        animation_thread = threading.Thread(target=animate_status, daemon=True)
        animation_thread.start()
        
        # Schedule message deletion after 5 minutes (300 seconds)
        def delete_message_after_delay():
            """Delete message after 5 minutes"""
            time.sleep(300)  # Wait 5 minutes
            try:
                delete_response = make_request(f"{API_URL}/deleteMessage", method='POST',
                                             json_data={
                                                 'chat_id': chat_id,
                                                 'message_id': message_id
                                             })
                if delete_response and delete_response.get('http_code') == 200:
                    logging.info(f"Status message {message_id} deleted successfully after 5 minutes")
                else:
                    logging.warning(f"Failed to delete status message {message_id}")
            except Exception as e:
                logging.error(f"Error deleting status message: {e}")
        
        delete_thread = threading.Thread(target=delete_message_after_delay, daemon=True)
        delete_thread.start()
        
        return message_id
        
    except Exception as e:
        logging.error(f"Failed to send animated status: {e}")
        return None

# --- 1. Configuration and Constants ---
# Enable logging for debugging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Replace with your actual bot token and admin ID
BOT_TOKEN = os.environ.get("BOT_TOKEN", "8178257536:AAGUl60_Dk9xs6jd6I2Nf98jm6QSPZMrICI")
ADMIN_ID = 5096360287  # Replace with your admin user ID
API_URL = f"https://api.telegram.org/bot{BOT_TOKEN}"

# Ensure necessary directories exist
# حساب جذر المشروع (main.py موجود في الجذر مباشرة)
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))

# المسارات النسبية من جذر المشروع
TEMP_PDF_DIR = os.path.join(PROJECT_ROOT, "temp_pdf")
WORD_FILES_DIR = os.path.join(PROJECT_ROOT, "word_files")
KEYS_DIR = os.path.join(PROJECT_ROOT, "keys")
CONFIG_DIR = os.path.join(PROJECT_ROOT, "config")
PENDING_USER_PHOTOS_DIR = os.path.join(PROJECT_ROOT, "pending_user_photos")

os.makedirs(TEMP_PDF_DIR, exist_ok=True)
os.makedirs(WORD_FILES_DIR, exist_ok=True)
os.makedirs(KEYS_DIR, exist_ok=True)
os.makedirs(CONFIG_DIR, exist_ok=True)
os.makedirs(PENDING_USER_PHOTOS_DIR, exist_ok=True)

# Define constants for file names
REMOVE_BG_KEY_FILE = os.path.join(KEYS_DIR, "removebg_key.json")
PICSART_KEY_FILE = os.path.join(KEYS_DIR, "picsart_key.json")
CONVERTAPI_KEY_FILE = os.path.join(KEYS_DIR, "convertapi_key.json")
AILAB_API_KEY_FILE = os.path.join(KEYS_DIR, "ailab_key.json")
GEMINI_API_KEY_FILE = os.path.join(KEYS_DIR, "gemini_key.json")
CONVERTAPI_USAGE_LIMIT = 250  # تبديل تلقائي عند الوصول للحد
AILAB_ENDPOINT = "https://www.ailabapi.com/api/portrait/effects/smart-skin"
AILAB_BALANCE_ENDPOINT = "https://www.ailabapi.com/api/common/query-credits"

# Gemini Configuration for Image Generation/Editing
GEMINI_IMAGE_MODEL = 'gemini-2.5-flash-image'
USER_STATE_FILE = os.path.join(CONFIG_DIR, "user_states.json")
BACKUP_FILE = "bot_backup.zip"
BACKUP_LOG_FILE = os.path.join(CONFIG_DIR, "backup_log.txt")
LAST_BACKUP_TIME_FILE = os.path.join(CONFIG_DIR, "last_backup_time.txt")
REMINDERS_FILE = os.path.join(CONFIG_DIR, "owner_reminders.json")
BOT_VERSION_FILE = os.path.join(CONFIG_DIR, "bot_version.json")
START_MESSAGE_FILE = os.path.join(CONFIG_DIR, "start_message.json")
TEMPLATE_MESSAGE_FILE = os.path.join(CONFIG_DIR, "template_message.json")
MAINTENANCE_MODE_FILE = os.path.join(CONFIG_DIR, "maintenance_mode.json")
SUMMARY_MODE_FILE = os.path.join(CONFIG_DIR, "summary_mode.json")
SCHEDULED_REMINDERS_FILE = os.path.join(CONFIG_DIR, "scheduled_reminders.json")
USER_DAILY_STATS_FILE = os.path.join(CONFIG_DIR, "user_daily_stats.json")
ALLOWED_USERS_FILE = os.path.join(CONFIG_DIR, "allowed_users.json")
STATS_FILE = os.path.join(CONFIG_DIR, "bot_statistics.json")
XKA_FILE_PATH = os.path.join(PROJECT_ROOT, "assets", "KA.pdf")
XKA_KEEPALIVE_LOG_FILE = os.path.join(CONFIG_DIR, "xka_keepalive_log.json")
XKA_STORAGE_PATH = "keepalive/KA.pdf"
XKA_BUCKET = "pdf-files"
XKA_UPLOAD_HOUR_BAGHDAD = 3    # 03:00 AM Baghdad (UTC+3)
XKA_DELETE_DELAY_SECONDS = 3600  # 1 hour after upload

# ===== KA.PDF AUTO-GENERATION =====
_KA_PDF_B64 = (
    'JVBERi0xLjQKJZOMi54gUmVwb3J0TGFiIEdlbmVyYXRlZCBQREYgZG9jdW1lbnQgKG9wZW5zb3Vy'
    'Y2UpCjEgMCBvYmoKPDwKL0YxIDIgMCBSIC9GMiAzIDAgUgo+PgplbmRvYmoKMiAwIG9iago8PAov'
    'QmFzZUZvbnQgL0hlbHZldGljYSAvRW5jb2RpbmcgL1dpbkFuc2lFbmNvZGluZyAvTmFtZSAvRjEg'
    'L1N1YnR5cGUgL1R5cGUxIC9UeXBlIC9Gb250Cj4+CmVuZG9iagozIDAgb2JqCjw8Ci9CYXNlRm9u'
    'dCAvSGVsdmV0aWNhLUJvbGQgL0VuY29kaW5nIC9XaW5BbnNpRW5jb2RpbmcgL05hbWUgL0YyIC9T'
    'dWJ0eXBlIC9UeXBlMSAvVHlwZSAvRm9udAo+PgplbmRvYmoKNCAwIG9iago8PAovQ29udGVudHMg'
    'OCAwIFIgL01lZGlhQm94IFsgMCAwIDU5NS4yNzU2IDg0MS44ODk4IF0gL1BhcmVudCA3IDAgUiAv'
    'UmVzb3VyY2VzIDw8Ci9Gb250IDEgMCBSIC9Qcm9jU2V0IFsgL1BERiAvVGV4dCAvSW1hZ2VCIC9J'
    'bWFnZUMgL0ltYWdlSSBdCj4+IC9Sb3RhdGUgMCAvVHJhbnMgPDwKCj4+IAogIC9UeXBlIC9QYWdl'
    'Cj4+CmVuZG9iago1IDAgb2JqCjw8Ci9QYWdlTW9kZSAvVXNlTm9uZSAvUGFnZXMgNyAwIFIgL1R5'
    'cGUgL0NhdGFsb2cKPj4KZW5kb2JqCjYgMCBvYmoKPDwKL0F1dGhvciAoYW5vbnltb3VzKSAvQ3Jl'
    'YXRpb25EYXRlIChEOjIwMjYwMzE4MTAwODA0KzAwJzAwJykgL0NyZWF0b3IgKGFub255bW91cykg'
    'L0tleXdvcmRzICgpIC9Nb2REYXRlIChEOjIwMjYwMzE4MTAwODA0KzAwJzAwJykgL1Byb2R1Y2Vy'
    'IChSZXBvcnRMYWIgUERGIExpYnJhcnkgLSBcKG9wZW5zb3VyY2VcKSkgCiAgL1N1YmplY3QgKHVu'
    'c3BlY2lmaWVkKSAvVGl0bGUgKHVudGl0bGVkKSAvVHJhcHBlZCAvRmFsc2UKPj4KZW5kb2JqCjcg'
    'MCBvYmoKPDwKL0NvdW50IDEgL0tpZHMgWyA0IDAgUiBdIC9UeXBlIC9QYWdlcwo+PgplbmRvYmoK'
    'OCAwIG9iago8PAovRmlsdGVyIFsgL0FTQ0lJODVEZWNvZGUgL0ZsYXRlRGVjb2RlIF0gL0xlbmd0'
    'aCA1MTc1MQo+PgpzdHJlYW0KR2F0a0s0LU1OYE8uR08tP1ckTWJlMnMvLyxqP2RGT3M9YmxTbW5j'
    'V1VNMypHTClnLz8tKl9EbEAmX11BJDIjKl9NSVpgNTEsamErSSgzT1hJIXNsTygmQD1VNUA3ZHRq'
    'cl8+OmNbVCQxOSlcVUFzODVtblREbktvczVFOyRya2kpbTUmSmcqXl0mVU1oazBjRW0uMyUsZjcz'
    'YyFycVwhPipkZGdhRiQqZzFRVG85UXAlO1xsaGxtKFhJaVFGNWJPYkQpZTV1N2xnViZndEhATHEp'
    'cl1HJiNZP2pHQ0coNSM/JzRZT1Q1T1VHclgsbGRgbSs4IS1HcCQsXUtUKHVpckUhXzFjYS5xWVl1'
    'N2BdQ3FzLCFbPC8/MnAhO0trSiwocHRva1E5KHE+MmcoYWlFMVFUQloqaHJWYCk8TzdATDZjQ19E'
    'Zk5OcTVpZ0pRU2tnTDRUZVk8U2Y1cT5UcnVkSC8naGNSPi02NTRXJTRyOz9BUGJrIylnZkRvJmU2'
    'Wm9rJm0/dC1vQCQ3aGhJNEstcF1iUC4+TzFFQHJjZ003aj5PZzRyYTRJQixUP2slcWlgXkBVcVlR'
    'dDdZJ10sO2l1SyoxU1tjPztTU1MlYzU6dGIhKWdVbmpJXk1CJkliQGdQWT8lKzQ4ITdaTz1LQVcz'
    'SCdlJmhDNEdwKUg5VW9vP1lZZGNcQ0VkaG1xXkQsbl9UNXFoTXBec15OaHFQZU1kJkNdUktTP0c1'
    'MF49aEEpW1FlYFExRWNQcl1qYmoxI1lhUFZLdD41dHUoZiNMbTxNSSskQSdJLl1lQ29tPSJrOipO'
    'XnErUHIocWhFYkVIVUgiLCsqNVZSVlZnIidbcSowKW5wM2hnMChybjxIQGVVbFYhVSooPzIjVmFr'
    'MWItL1wlTWgzZnJuPmdUQj1AQWAoJlRGZGVmWGxUODA0K1QwSjdzTTFJQS1hJ0wubmUpL2BDOlhu'
    'W2E4Ql5oTUhVSDowKyorRTFVPk9SV3FiXU9xVzRZPUJrMHJNYCdoS2FeKlVoJj9sWlcnVUdZWjgo'
    'JTtZWF9SZEtxOW10WyRETGxdMk1wKlInREwxMUZyVk8pMzdgPGI5MilmJzZlUkBkZCFDbmdYN2cz'
    'I1ZyakxsWElQRTM5MTUxL2kiZGkyMzFTYlJNXExWR1Y7YChcV0FkYC9KYE02WmckZUZXTENZPyc1'
    'SDJjSUMrNDRZLSc1NFclNkkvZzRaRi1HLEZkMUVSTkBZQVdVTzFpaDpmODBRdVdQKmQoRW1YVSZI'
    'Vl9qOCp0LTgvVlZnIWxya2MmKjFZO0w/XUNvOTNRaG5KcnJFbyMjb0RlTzlKKkxELHMqanVVcyQs'
    'WyJjPWQuVU1kcDdsXW5ZLDRrNFxCRi0lIytQZkApcVg/XnFuckBEMC1ZZCpUQWU9bmNCVHMoK1Ji'
    'b0RUYllzJmFeJi9ARjgrcThpRmxgc2hNbjJxZllVSTsrMzJvY08zSHBMXXFCb0RUWClmWmlaYW4o'
    'cCJEYSUhJUheK1NscFpJWVoiImxHSG88TzlZLkVgMG1KQjlXcGRdaWpmbWFbXD5SZy90RVFjUlNO'
    'cy1DcSxySFRgSHJoOGNWZjB0NXFOcUwqZWxfQiFzSipJQGJcPTIuKzZzMVVpYXA2c0BuTTxhOEhl'
    'KzNLOCk4NG1OYUA4cW1HZU5zJVZNX1c2YSMtZVNjbEtFczJzZ1Inaz1wdCM7Z25bUD9bJ1JcaEUs'
    'N0txM1lDUzFdPiYlSilMbV5GLC9LJEBsTEAyaF91dCdoV00jcGhTM1tpPl1DTE5ySDNgVkVKKTou'
    'YSopaGs4WDQ7PydJL2luQ29qMGgyO1oqRjUjWjdrJUojWVUjKzhJVGsqR208XlRbK11UYDlcZ3BZ'
    'Pl0pSVdgOlhdX0NaPU5kLEtsNUtSUi1saDosK1JxVGsqcjlcYVg+YGYwJkRLQzQvTT4iOGotYE9c'
    'XFI6OmhlTyxdXHVnWFtFUTUxQkRLRjVOU0orLD0oXkByQWonb19cTCdKKC5vYC1uT09hbGQkRW9I'
    'NV5cRmFqQyY1KzdYSmBoRTVkUnAwWVE1aiImbUFjWDsuU0gtLjBUZ1hsJlsvRm5oZyxdISE4RGUj'
    'KCxRRnNNcWEyW2hGZmo5X29DdWtBWVFoKC44SC0/MU1uLCluVjVGZjNxZi5nbllEIiFrPnJrJ21p'
    'XlswZGtEbzQ1aF00UHBBcFQxS11zLlFqbklHK01BcE9hWipoYDFJMmBkQCRTXTI2XT5dMjEnbFlJ'
    'ZEkhcVZBaklvaFVTNm9oUjBtcXAxJVtyNW5mNWY/OFVoUkowI0hycCtjNjo+YmE9TE8uKG4/ZFxd'
    'QjAyOjN0cUwrXTRlbUVvRilYb3U1V1hDUU8tS1ZaM282TlksQC8sU2BwJjVQZ1oyYUFhaHErbUlI'
    'TERmcV0+RWJfaUY+JzhCWy05SVpoRkNnWUNIL2k1Ij5xTEdpKV8zam5CcDltWDhSQyh1byxsb3Qp'
    'IVpPRDQvKlZVLC5WUjNaVW1CN19qSGctPF9JaCo3KVtAKlAwIlNtTDhmTXFzZDwpTFEmT0xFYyZ0'
    'bXBiXFcsOFRkQl9SSlg3LnA7SENydEJjZSJQOyxPI0gxIjNQS21BXTVaMnVlaiNnZVNwUCJDYUNs'
    'RTdzbGkoWmBiQWoqVlQiWHAqb0otMzxfRCFsV15Gc0UiLVROLUA6R2BMV2Y2amFdckNdISVUKT9G'
    'UWZfQm08aXEiMS9DcU9oTC9FXk8pcEZaOiJwR2xHV2YkLHJHanRMZVJHOmVcPCk+Lj1sT0siayU8'
    'PjwxOVNWJjBWSTw2P28jYERsRmZzcF1EJWglZlQ8TVs7PVVDaCM3VU1FajorcS80YTRjakBVSXBX'
    'b0trJVtDPWRtJEk4X11Cb3BTYjsmMT8xTkw0NSdvLU1JSjFEMzpTMUNLO1pGNWA+JHBgQS9IM0Qt'
    'Y2VbWENWTCkqVkUzKjx0XlwpZylQSXA6SHIjJD5jZSVgLFpJSUlVJV8qUidGbXNlXENDMGVgLCg7'
    'XSpeczdRPklPbWBrWTUvMlNzcVtVMTtbRWBeKk8jaTkpLighQDlOV0pTTnJLJGxsRGdkVnNfKkAq'
    'SUNyRyosLTtlS3BOXTJtMU5zckFDLmVQPmtmbzE3JEUoTyYxMU85aW5IR0BcZmouNTwxJiJDdS5N'
    'SGotNzBWYyphQihVLWJdb2ExTkxFb2wmYyQxOWFqKmZKIkIiVDVEa1BVK1tHZTtpWS5XKFJDSEw+'
    'WGlGMD1PQEFCIllDK2ZXViFgYGNpa3FtYCQ8PVNuWSNtOj01a3I/YkJVX2ktSSZSQmIlW1hAWyQ6'
    'KktqQjUyNTprcWtQT2ssXCslXWYqYTEwPC9gTlRaTkFiVCVuKzY/WEsmLHA7WTMsWEBYPnJFVltM'
    'KDBMIyVwKjcsMjpTbFZnU0s1bHROXT9Vc1c0aT41O2AqUERhMkJaRFU0MDJNJ087aTNpJSJiRldd'
    'O21kbz1IY1RpbkkxdGxdakJZV21PRWAlSTtwW2gjLy04OWNuaCJVYm1mZV50O0lmPmknUkd1JThO'
    'T0lPc2EiTWU6PmghOjM1ITlPZSQtXHRNNTxhRTRmcSdjO3JRXyFecVZOUVhbYkEoTjA3MS00ZTdO'
    'Vl80VkcxMDRQLCE8Zmo0U15PZlc8a2tMOUdYQnNdSk5yVVQscTgyOzdgb0JEQ0E5am1bOjl0cFNz'
    'azowVzhwKy0pYmZbLk8uY09AJVVzNzU+czgxJG5XXDRbPiJtYSU5OW0hN084bidCL3U4Uk0vNHJk'
    'PVMiLGBUN2RvREoxQkc9WCZoSW0tIi5bTCgwTCJiMXVOP002bzJYIjQpPWwkbm1SZzFudDFqajMs'
    'aTVPcjBlOCxiV15ZWUNlYVprKioxckwqJWVQMDJLK3F0JyclUDtNIXRWZ1gkaW8vZTRdWVduYSQk'
    'LzVTcDpQMW1INTsuQC9RKmxxVnE9TUVuKUp1bVtycG81cmtZK24tVDIxTiREJCUlVl5uMi4+YjRc'
    'QFVDRXJgSmwkbm1SZzFudC9qajNDVzlaJGRWSDZkOz9Rb3UsXnI7T0BxT105bkRwPzBwKS0+Qmo7'
    'VCkkUiVoXVxEQHJWPyhWZkhyOyEyWjNDTEguYUZBWFI1QiNWdUtLPkJXRjtuUVRyNVAxKCFqTGwm'
    'aTJFP2s2TkhycXVjPnAyaWw7XWp1VVZyR1JpZz5HJlJOMDdTRytBLm5WIWRqJjpqXmBOVkJxQG4y'
    'TUYtZmtXSGhRWE9zIURIZW03SGY2NUpLU1YuKjJDOEg2ZDs/UW90dVhxLnNNTkhSK21MLWk8TiJK'
    'ITJfQ0M8dUxwVEFMZltLYDFgPThEIzdDSF42aUFZS05RTVVwQF87a0A/Xk9dLzg1VmNoY2JMbXVV'
    'NStTcz5YKS8yLWExOVZEKjwmLF5eIy9xNHEqYi9QaCtvQkNhZzF0bzBISSIobl80IV4jbzVHJnUn'
    'Z0I7K2FLZzIzNUpuMDNSUSZWNzJxPU1FbilKdW1bcnBvNXI4MSVicDUhOU9lJC1cdEFJc3VsUnAu'
    'LVlQLFElKXNKITJfQ0MvPWxrY2Zea3UsUUInOmNCX0s6Z0I7LTdLS2woRnFKOzRnWjgmW01URGdj'
    'QFVUTzc2P2lLczVhWCQ2IVZhblReSl9AQmdjZ1QzJypfQnBRQjdFLEREaiFSb21GZjhQcSZQVmlm'
    'VWtzI0tQXmQ7cV5fTz49Ilx1TyxhQ09TSDMjUkEiImBFV0IqUSFNUT0nWGglYHAhXC0qWUhwP3Ve'
    'XDkiRDFHXjVHKnBzQ2xiQnRWZSg/QXJHUmlnPk8/Lj5yOnFAcjhfQlkyTytfP09JbG1ZbmxnYSlf'
    'Ty8wKUVhbzZcYWheIjJpXWQhTElrQkJKUk9rSEAmTytfP09aWS4rSGhrLTV1UDAwQV1yVj8qIzhL'
    'KUhSQkRxRGFHPVgmaEltLSIuW0woSFRxMTFjRjVJM0xPO1ZDdFlJbTNnTFAiJERhYmcucWxJWVZH'
    'SHA/MG1MQEBQKCFXVVQqRmtAS15NWjw9THVURGdjQFVUTzc+P2lHRjJfRVJOdFpEU2FuRyUkbFVt'
    'LTQkJmZlN2lIUDAuQ19yZD1TIixgVDdkZHNxMmI0IV4jbzVHJnUnZ0I7LTdLS200OTA3K3QwYydl'
    'UCtvWTNzOUQ3L1ImamozREJSSC5lKzUhOU9lJC1cdE1Jc3VsUnAuLVsmNDhcWDZKITJfQ0M8dW5A'
    'Y2dRcmhfWiJxLyxdIiwyTCs7XVVwTGdwSThMZHBqcXQnJyVQO00hdEI5Y2onciFwZ29tKkRTIl9E'
    'WnR1ZSk4UkBjY1tBJEFaS0JsNTVmRF83VSw3b15cbW1KUCJGO3U6UUwwRyFqUDYkbC1FXUMsRzU0'
    'S0gxIUs7Y0paL0giTGFVYSVoLiRHWkxIVTo9clJqWTVlKGA6KHA8ZDlxLlJpJiJsb0ZcQjhlNlY8'
    'PWlBa2J1LXEkUDswSVEkQ1wsXDBnXXBCa0E8bVdHNmZuU1tDYjRST0IhOSlNOXEhWVg8XlVmayVy'
    'KGdPRFRZbGhpQDIycTA8cU5iVlBZMD8hbE5LJl5kXWZBTGhjU09Ia185K3FldD4tUE5lRlReTEw9'
    'PnFqOSRYWGdSRzcxdCxWP2Y2a1RmPCdwQi8oKig0USY/NG8mcCk/LjVmYmlNXTxzKkI3MERLXGhI'
    'U3BRLSRzU0MqdEU6Q1peJCZYODpUXWA1Xi1gIzFZUEM0MSNQNC5WUVQ6NDJLWUY5ci4pR2I6NGpp'
    'RkRNWV82W08jV209XEI1VlVRKjIyQSk+WlJsSTFjMjZbKz4uITs0Pm0iMW9SK0RQNEVOXUhxOHNm'
    'Z3FcZFVRKjIyX3FyazNsSilrZzZbK0RUITtPUHBaNyhQS1ktIUByOEsoWWdQRGRVdCxPcmRwcFtr'
    'bj9cUlhGQWg9LThscioyXkpxR3I2V1BzP3JuajJ1UTlGVyMkQWhBSDBKJTNKNipcJG9HYEVBYCRS'
    'TiJaI2lMMkpPIz5ZOjIhR3FzWldOJkQ7ZU4uNFgsPk41KFtbb1hoOitRLUEiX2ljKHQlWS5haWxC'
    'NCEsWFFUNjNPaFo2ZjQkaGZSSGRwZGptIlItdSpeRlxHbzgnbDJcNysvYkJVPk43QVBfbD8pL1VZ'
    'VSheNlBnO0skY2wpbkpSaV5xbTskJm9TOyNLPVI2STAxazNIPHE6RzQ+OHVSXUphaENyJk90ZmRX'
    'Wl9IRyRNdWs+OGtjYDVkXUoxSjhVPWoralIiX1Y4QSRZbTUvIWlNbVxpJ2RPVEMjZkEiPXQnKm9b'
    'QkkvJkMpKFkuMWQrXU5tdUdNKVUxLFZgMyxbKlZiQEExKj9SOlg+PTgrI11CdClYYjsnbilIU2hb'
    'XCcmRzBuXSRDW29WUXJIQSlHWCUicD85NUZmJ0QxTGA+RVciRmBvXD0jUThPYkBpLWpgaDwsIVtY'
    'LFInaHA9ZHIiPiNSVVtXbS5UKXNYUFlJbjpQW1taZTJEQkkhJmVcRy8waSglbGA/XyFyRCEkal5B'
    'YDpNYEo0NGlAZyk8ZUErNDRZXUl0RnI+LUJoQUAwUyI1aC5qMyxgYShhRkY5Mll0Y3JzY2pYZ3Rw'
    'OHMiImwpPj10ZXJtTWNCSSEmZWtrT2Nrb2xlQmxUbzA8YkhsVkg3WWlIKy8jUTFcLEtMbShgcCo9'
    'UkNkNzMsVCFWNUosSFRHTkNbcylASjVpYyNQWTpDYzYjZTFLXy0+P2A8YjBUOFomKllVV1NNOVdo'
    'IiVQaUBaPihLYSFbW18pMS5paCYpQDNKS0xJbGYiTm9dUl9nLjhrMjlLcC5paFg1blJGSEhTKVBb'
    'Zzc2aEIoWzJLLkEqU1AvYGQ7alIiX1Y4QSRaVDUvIVpIbVssdFVPVEMjdUEiPWUiKm9bQlgudFFd'
    'QW1eVFFvXU5tdUdNKVBYXlZgMy9cKj5YRF8xKkdMcVg+PTssJHVaQGhZKFZeKSlIU2hcXCcmRzBu'
    'XSNoTG9YOShYLE5JLT4icEFDcUZnY09BTGA3Sj4iSD50az0xND0lYkBpLWpgZlUjYEpNTyE/PW5O'
    'bT4hXTdydUIjL2guJCNeJXFZKFZnLClLMkshXlI+cU5TIU5QZTZIdUZbZUN0dWNMRnQ+KUUtJiww'
    'YDdtWjc/dVtLQzlbXkdWUUZwS20paTZLWGNEVURhbGltQ15wJzJISGNvS1smJEpzT1RnT1k7NkA6'
    'WFxAYS1EWUZtNSFCZF1KNFJuXXFzVFItb2xDMyFKLWhQU0hWWWVHV1ddXC0oJUJTXD9fQzQ+dCxj'
    'aTJob1hzJitnYSFiR3BDLSNRWDhYYT0tVEFDQT46TztDOlhfM0tna3BCSSEmZSNsPTFuSEZtXEtj'
    'cFwtQUw1cERWR15HNWM3JzZaWThLKFoyUElKX0ssT3JicnFYaEBGXT5OYVc3MF04RkgrVCJKTWxx'
    'ZXQvKWInJmBnLTVYbTUhQmRdSjVGMV1yQmxWTGNLUj4hSi4lVlNMTkQ6aVdiVnQ2MD04WEUrTWk5'
    'RnI+LUJoQUFrV2hIIlE9Y2xCWDxKLG4nJ2NBIVcsXUgoK2ImbyZiLT5oTW0vL3UrRUUpbClaLCM8'
    'JVJdQV5zKk8iSi0pbTxsRWBbZ3UqMyFpKFZRLkYhUFtqZDczLFQhVlBcN29sYyw5VG8wPGI4MC4i'
    'UW5iKk1RYCo8VTFQO0tHRC0jXS10N2NLQ15bPSFXI2tQVGwqI2hnYzRwIlhgaTJDczlXITBrJSdv'
    'SGFqMGA0J1VmO2w9UW5uaSlcQmtxR0lZRlhLaihmTjU6b0QvPihsPydEQCFrImItLiZAKEZIQHFs'
    'JEwyVkNCYFxkcjM2OixhQzluazZnS14tSiRzJkwqKyM0LyQ7JUxqaWlEYzU+QSIvLm9sLVZPIWpg'
    'MSFfdEZKdU4mUU4iT00rTU8/USJrRShzb0tcKy80byNaUk8rQURgVyJCM0xpZ1IsQ3BBOmdlL0pN'
    'VGJkXS43TF1LVXRQMy9rLk5oYlcxXmIrWmZzLnBTIXJtJTdFYTNEaDdxU20obCw8MzVjN1xHTi1t'
    'a3JLMF9TVk4uKGprVEtFM1IvNkhEXSE/RD9jdSZARCImbTYkJUA0TjYrbSlQVFJBPWg2L05MMXMl'
    'TUJrQldEQEgyOkhOYjFoJyU0STlIRUYtSGxMcV0lNUUoZGM2U0IiKXAsRXRGSEg5KjlSVjRjU19M'
    'XHJrWT8rJ0AtVWlhKCshcmZiYWw3IjhgUnMqRWNEczssWComRFRBRVUlR08/SF4pYTpOalQ/QVdb'
    'bTtAYGonNmJkOz5oTWxkL3UrJzsjQGhNajpgaT5tXCRvR2BFQWAkUk4iWFwvTDZ0JkJCMWVALEdx'
    'c1pXTiItSUJOMl1VVj5ONShbW29YaDpALVVqbF9pYyh0JWBJLlo0LU1NKFhRVDYzT2haNmY0KDdG'
    'J0hkcGZANCw1R28qXF9gPG84J2wyXDA6ITBnbU9zWEFQX2w/KScndGQoZlInYDtLJGRJKjRlW2pe'
    'c29YNyZvUzsjNmQyKzIxSi1XTDxxOkc0Pjh1UlMwbStScVdSODVXQzwxcUBlQHBzJSclUUUpUW9m'
    'OyNQK0okY0grVCJGJmcqKDM6VHBiLDQqTTA/QTNhUGY9SnEiYkxVXE1pOj5AayovJD5zI0RqU2o7'
    'aWUmdVlrbWQ8L2tLXWNaJGpdTklsTzZsTl9WOVgvNClubnJgZylQRW00cF5uSG5fRV1dckJsVmdj'
    'OUo9IUouNFtTTE5EOmllRWdeRUcoSFNRLUpDVzEtLnNSMFclJUlYa3JMJDNIVUFhSlozLk0vYCVR'
    'Lkw2dCZCQjlMOSJtSCFYaTNfNFdQVkVVJkE3RDdOZkYkLDQkIXMyRUFqJmNuMyVyanRcU1teSUk6'
    'WCJzNj50LCdVJichLGlfIlkpXWNKLik4MSpBOG5YT0BRSy0sXEpnUW9mOyNIS3JHNltILV4xM180'
    'V1BWRVZbYF4icDU/a1RVKjE7b15wMC86IytlSlhBTj1COUw5IjRpdUdpRkhIOSo5UlY2MVQkR3NU'
    'bTJbJlVRb2BnN2xVbHNQQGRfMSo4SyhbPW5oXi1aNmklLi4tVlc/T0BWUl9QV3MxPSUwWFwpL1VJ'
    'O04lK20pUFRSQTopTThEWXRvSz5cIilsSTJnIW1FVjdpKEUhZE8zbkM6aW0zLUEnXEonMDZCaj1l'
    'OGhDYlJVYCE5ZjtkaTdUPmNDSTw9KSVgL3JlZiFLNytgPCtIJzZhck5OW3NHO2dMWUpncGc/ZERI'
    'O2hONVxUP3NZIXMyRUEzWVJoJ245LHI6Oj5EODVFRmdxT104UjQ0KyxtMHBEbF4/L0c3SW5oNVtg'
    'a1pCOGE2U1wwOiEwZ21Pc1hBTlAxTE4iLUlCTjJiLGJAQmwwSUVkUlw5JGpdTklZRjVYYFYnV2Jw'
    'THErMUMtPkMsXFFNYkskbjg7RkhnQmdmTj87a2NkbU1yZ1pKQUJbPjoocU9WRUM3c0BcMi1fOmIk'
    'K0BaKScndGQoZlNXVG8+YjFxRGY6LGUhSi40W1NZdERaNGhNZWtcSicxYVFadWNnOERZdG9LPlwi'
    'KWxJL3UmbUVWN2koRSFkTzNuQEg8QTsuSnAwbURYJixgTzxZYWtMQktPU0UzV2gxb0hTMWJQZ1Ux'
    'KkE5WVk5VGYxW0NbVUU6PkQ4NSlzMF1KL3UrJzsjQG0mSlg2VCl0U080MjImPT5OMFdUKjpnRE1Z'
    'aDpHOiUkLz1cW2EqVVAkSmlBKlZQL2xLdWxmNlBnVU9Rb2BmXEsuZmdPJjlCNWU5W15HVlQiSj51'
    'I0RpdTJlPkc3VWdSVUVdL2kiUCdGZltDPGdJJ2EtRiFwQXFkTFdNSThfdShwSz5cIilsSTRNUW1F'
    'VjdpKEUhZE8zbkR1Z0E7QFZyMG1EWCYsYE8+L2FrTEJLT1NFM1doMW9IUzFiUGdFMSpBOG4wWDtu'
    'WipvX3BBNClubnJETztZb104UjQ0KyxtMHBZR251bUc3SW5oNVtga1pWaHFtPFwwOiEwZ21Pc1hB'
    'TSYyPk4iLUlCTjJib2xLcUlyPWlXTVgxQ1VpUTlvNFxNXlpRRSQrQjtDI01VNjdMJDVxbUZCVz9N'
    'NC1OdT08Jz9PUWtMOkpdc0NTaDZhPDBRbTVUMC1UXlExJVJjclJEKGQ3cVQ1Ky5uP2xiaVNWM3ND'
    'SXQtdFoyRmMrWDBRZl5tS1g7aT9iZzU0Xi0ydGIocU1nSXBBIjtMKkBIcUosO3AzTUEpI1I4Y1s0'
    'Y0w9a1lsakMxSShOcjpkYWpbKXRPSjM2LjwqSiNjPG9bW2tbMz02aylpV2cxUUErcDduI04rblFi'
    'W1pCQVVhUXVhO042P1ghPUlRUD9wQkhUWFlIT0tiXEEuTDxQX11gb1JxJyMvR2ROPyJGQC1YLVRO'
    'KHQiWE4yXVVWV0BMJlMlYyZIUjU7NzVdZHBTI2opZSs4UDQtTU0oWDxpWGZkN04+XTElamM/b2tF'
    'VTdUZl4xJ0o+bSVMSl5bTSVnXnMnRWdtT3NYQUt1Sy9OKHQiWE4yXVRrV2NMN0clYyZRRCFERk8i'
    'YUoncXRNInI0XjlbXkdWUjlXdWQtXShYPWVCXylmTlEsaGNMLzcwc2s7I1kvcV8/JWUmOWZJOD5o'
    'TWxkL3UrV0stWSRvNTpgaT5tXCRvR2BFQWAkUk4iWFppJG8ndWJTTEk5TmpONktNMS0vIVMxOFs3'
    'S0RNYyFfaEhsPzJKPm0lTCVTTSttM3RWIU5nbU9zWEFOY3NbTnI3X05nQmdmTmhQOHJxZ2M5Sj1v'
    'bWojTypEKT48RE1cKjNtUyknPVo2c3EwTih0IlhOMl1Ua1dPRnM1JVVHa3BALVVqLE03ODhNK20r'
    'UWkxSi1XTDxxOkc0Pjh1UmMxJWo5J1ZGS1VPV1pfSEc7dThVMjhsWVtCYDtDMGotTCRASVAuL1d1'
    'LGs5IURxWGc1Jl02IS9eNzBXbWxOY2dlOEhcYFZNSVleKEBGTidOcWpSIl1gOFVOOmo1LyFaSG1i'
    'QmdFT1RDJDRBIjxXbjdYLiErbzBfPCRVaUJyakgrVCMxJnRiLF46Tio4QjQqTTA/QTNhUGY9RCpO'
    'I0xVXE1pTFVdLTNqMnUhKUZyP2hyNHJJOmtoSCJRPW1NcmdaSkFCWz5jNSg9L0VDN3FcRUcoSFNR'
    'MG1aIjEtLyFTMThbNnI8XmpeWFxUOWxnK1RoZEVgdE1ZaERcJGhUYlJcXStQK0okY0grVCMxJnRi'
    'LF5qYWxsMTpSbm8nR0BXc0hsPCdyIzREOUpZIiMzJFlTYSEqZT00V1BEYk5MNUFhZERxcypxYV4+'
    'Y0NwLikjWVo5KTRMIWxRRFswYSNMY15lV1kzXGE6L3UrV0stWSlHaj5QPDBRREsjIWJKQUJbPiVV'
    'TjQnZ15zJ0VnbU9zWEFMZyE/MDBIJjZuOTJbdURcJjNSTlFcPlEkal1Qb2xjOkpPbURmZTA2ZW4q'
    'KiNOZVM2L3UrV0stWSlHalg2VCl0U080MjImPT5OMFdUKjpnRE1cKjNtUyknPVpDOEYzN09PJGdg'
    'bWduRmVEJE5VTEZ0PikwUWpIUWA3bVo3JkcmOUUzTVxhPlg9JXFRZDdOPl0xJWpkKm9sZk5EVG8w'
    'PGI5SEVGbT0+SWVLSlhAUD1jNlNCIlMmc0RyRkhaRTA5UlY0a14icDU/a1RVKjE7b15xJ11LTzFC'
    'MGdFVUk4SyhbPVBJSmEhLGs5IURxUmRJV0hSVVBVW20ucmFec3FscT1uI2EkX1Y5WC8rNihRa05B'
    'bz1MP1ZMcGI5aFRebUBIdTxXbEt1bGY2UGdVT1FvYGY0aXBAbixNInI0XjlbXkdWUUZwS20tXShY'
    'PWVGTlY6WW8hMmlnRTBya0AtVWtXLjxtXVxEWzBhI0xjYSdZNEtgS0dEalNqQ2lmYytpa3EyUk9r'
    'S11jWiRqXU5JbFJaL0RfVjlYLys2KFFrTkBTNVRnTFlKaXBnZChzcDQwLWlcPykuP0pBQltLTmY0'
    'ViRJTElxcWAxOUsyQD8wRjkxLS8hUzE4WzdLV28hMSEzSFVBYUpaMy5NLmMpNitMNnMoQmM2U0Ii'
    'WDMnKy1GSFpFMDlSVjRtXiJwNT9rVFUqMTtvXnEpXUtPMUIwZ0VVSThLKFtdUElKYSEsazkhRHFY'
    'Z1kyXTYhL143MFdtbE5jaDRESFxgVk1JWV4oQG9SZVpAUC4vV3UsazkhRHFYaDRCXTYhL143MFdt'
    'bE5jZDYyZyM7PGBiUlxdK1AvYGRTalIiXWA4VU46aklYQWxbQk8iUmlBM2FQZj90O149NGlAZGE1'
    'SycqYVxtXldbbTRwXm9IbnFRX11yJ1pTZ2M5Sj0hSi40W1NMMzI3aWVFZ0JpbSZnLy5yMzhdQVRY'
    'KzFBNSJSJm5HXHEiJjE9PicjO2h0KmNEVG4yYzxkMGYuaWdZMC1oTjslQC1WaXNtcTFOIVFsNjMh'
    'cjg9SWptUkteZUdBbV5hVnJKailCZVJITE1uYEw8YSVELzoxOFlnLDg3QWZuMEskUVtyLkNXTjBq'
    'Uj5OQC1bQTE/VUVJPjElWEJWS19ZLEJrVmtFXk4sPWE2S1csISVKKzMlZmpxMkcsOUspJGwmXmsh'
    'Q1IyN3FXK0NgXz9DczRbOFFjIzJHXWdYV19yNEokKjBAc2ZHYzU3X2xWM2xOP0hEWkdcOkglP29t'
    'QjhBJiwlSC8mZDZOQTxwRDNPQmFXPV4qTEk5aS5vLTNUQmROO1UmUW9caENVUlQxXEEqVUg6O2tu'
    'PjplYD5gcVZOLGQ7LzksWXNiX3J0ZThgUnJzRWJIP0gsZWItcFRBRUQ6RzQkP102aTZxTzNuPjAu'
    'OiMhVnIwZV9QMyxgTztuYWc1USNQUEFgYEk8bmhfZ1VWQ2g6MnBQSWw8JE9sLSNsO3JNbXRRN2oy'
    'dHRTRT5kUlheKTlrQWhHdTpSbU1yZVc1LV48RGI6JDZUQVZiVURHOiUkL2ZoVDc2VVJUMVxAcXMr'
    'XislcWEqW29eZ28yMGxmbSclTDxDUWtzYVQ4czozPjEzcEtqREEoaWNXREJeJWlwTzpiPSFUazhs'
    'PCd0JU9yaUhpYDRVbWZQO0tHRGtPZFNtXk8oMmVASHU8Z2VEJE5VTEcja1IwUWpIQT5BIzQhTGo5'
    'U1YtPj9gPFBJdDBqMmkySW1lPktlKmdSVUVdMCUoZ3FGZlpnVVAvSWVhMEIxOCZOQFM1VGdcI0sl'
    'TGk6O19EXCYzUk5RXD5WJGpdUG9sYzpKT206RCohJlUsU2RNKWdhLmJOTDtDYydcQSJSWDJTZWtL'
    'bFglIkslMyVSV3MxOCllKi1sU086IUpiJWdLaik7UVJQKSxtMGE6aUNSRyo0ajRBXnNvWDdKMGNH'
    'USpKZXRRRzolJC9mZ3NzUFVSVDFcQSpWTzRsS3VsZjZQZ1VPUW9gZmRpcEBuLExqOVNWLT4/YDw5'
    'XHFDc1MmQDZxbEk0TVFtRVY3aShFIWRPM25FIURtMy1BJ0duRzZJQmpCPWRoQ2JSbWAmRDJrbzRW'
    'LlJnUlVGSEV1NllUMFFmTF8oJUx1LzJvTkBiNC1UPFQqNkhySEZIY0szOUokZCYrKyoiW110R1dt'
    'IWBSLSNeIzIxNF1IKWZSJlUxK006MF5wcGhDYlJtYCZEMmtbMXVXOEVFZSwqI1laOSk0TCFsUURb'
    'MGBYYDE5STw9OCFuWFFkSk9lUmthVSMvVUtOY1wkcFFsNVtga1ojSG9YJERNV1FNRzolJC9mdWhZ'
    'KSRQMkpQXVVeYkxnNTtsV1w/JFVpSkFCW0tOZjRWJD9BPWdgRUcoRlVRbTZtZ04sQjljTjJiRTA5'
    'VEAmLydmJG1jRmZcTlxnSSdhLW8tM1RyZF5aVE9dTm11Y00vVURgVmAzLFtTTkRUWjEqQThuWD5A'
    'Zkw2ZWk3RSw0NkghKkVVZ1VcJyp0Xm5dZEh0b1ZRckhGNkNuPSJwQ2ZgRlhBWi1pVSZuU01tdFE3'
    'ajJ1ISlGckIqXV4pOWtBaEgiUT1tTXJnWkpBQls+YzUoPS9FQzdzLlwyLV86YicqPyEpO1FSUCks'
    'bS9PX0k+MHBqbkFCUSklYC9yPzhXLEk5MXNMayZHJSs2OVtcL0EvYyFyKGk4KGJuW2hHVyZdcida'
    'U2djOUo9IUouNFtTTDMyN2llRWc6RUcoSFNRKm9dPzE6ZyYpMVQkSzRrRSE8bGhxbj5UIXMyRUEz'
    'YCFTPUhbJVVgby0zVHIwQ2NRWE9oPXNoMmkySW1lPktlKmdSVUVdL2kiUCdGZl9vV2FVMnFrQFVA'
    'IUQ4SyhbPVAuL1d1LUxvP0pxWCI7XlVOJ0VvT1RDJDRJMnMxT1drQWZxMEIxOCZoKFZAaUZyQipd'
    'Xik5a0E/PChvZm1NcmdaSkFCWz46KS5bWEVDN3MuXDItXzpiJWdLaik7UVJQKSxtLzY9KVc8Tio0'
    'ajRBWlI5W1g7NTJkZiZHJSs2OVteR1ZUIko+dTJpMkltZT5HN1VnUlVFXS9pIlAnRmZbQzxnSSdh'
    'LW8tM1RCZExXTUk4X3UocFMmQDZxbEk0TVFtRVY3aShFIWRPM25EdWdBO0BWcjBlX1AzLGBPPi9h'
    'a0xCS1BQQWBgclV0Y0BkQz84XWFGTShVIVBqUztIXGBWTT9HckMrXG1eV1ttNHU3RUhvJVdgXXIn'
    'WlNnYzlKPSFKLjRbU0wzMjdpZUVnOkVHKEhTUSpvXT8xOmcmKTFUIVdtW05HO08ibz5BTiVkbEso'
    'U2RWWkshYm5EYlMsPj4hQ1Ava0JGVkByTE1uUHI6SzgmViIoOTk4b2tpaDdqOSxORkAjZFIzXCIr'
    'USxGbF1LJTxNW3BfLEVFSDUpPE9NJiRgP25rZ2Z0aC1PIzdJKGcqQ2lXWDQxVzUyZG9kNSghbzgw'
    'UyJLXlUoLHViamMtOkI1UjhcbTdpOTwoPFxYOkFbNF9sMlViX0ViPSxaLXVkKDU9RTBXJGNCMyte'
    'SUc8YVwyIzNncSgnTmtQLUNhVktaMihIKC03XkFeYkRHTGcyLDxuTU0wKSRpUi0pQFtvRWQlTCQz'
    'KCxiUzpJWFdfbG0yOG4iRiJXTXVUOj9GJTBaMy4vZXEkcWExOWpmIWBVIlJLQi4+ZDFIblAoZ2w1'
    'KClBcywzcU9CSCIrMzFCQmZgWFBJI0xncTxHcURzPz1samVPKCMxdT1FNFNfaVxfLFBTUTZkLSIr'
    'Qzx1Kk5LVyRlRUA1XV9waUEtZ1VzNUgzRHBdJVIqLUE1PmdUXiI4XSptODxlcFstX2dtIVBDQSlx'
    'YF9ULW1ZPjJxTVpsPUo2VCVpRkhvTCpiRzEvNy47PmQudTRjXlhadD8kNDdbTSYxWjpsUkhMc2M2'
    'VTxBSFZuZyklKEhYMVlnZ1RgKUxQNjVEVlc2TWpARmMsMighIWtLX1QpcD9vJ1JNOjtXPW9faUJ0'
    'YyM+Pm0yLyMkNCM/P043N1ZNOlNCKFIxaDg6PHBPS3RWcEdGZDdkQ05uV0hfT0glTytXTklpMTsk'
    'InJCV1g/NE82ZWRGUCJwLjI1YEQ8bDcvWitHR2syRDcmYFhPOTE2V2FzLDorI2BWWS9cTWRwZWxB'
    'MS8+XC4zcjNWODIscilSZiQoaUY/Z0dYWkpCM1xOcGZmOW9tWCxLcCMoVCgsKHRVa2NlalNEampH'
    'O2FhTFJPZ2UudHJVWUtQPVRjck0wTVxTc15sIVtGO1BbJDVSR2pXRjlWZD4ubVZHZEtkPUtOYCc2'
    'SylGYT4/XlwwJUI1WHFYRzExWD9QKzNNOmlbX3VpaFs9cypJZisrUlNIL29BJHIhRyUxM1BgRG1c'
    'clpPUSksOThoLzldI2BWWS9cWlRFM2IpMW51XyUobGZWYTBJTmctZlYtX1QpWDk+J0ZYTi9dRDA2'
    'KDI4KUo3T1hMK0IhSFRTYEJqZj1MVkJXYVlrMiU3LDtfYUdAakUlcjQjRWI/QF4xTkMxZCsvTSdN'
    'Pk8+PU00JzJUcCliQWZoZy1IVFImXmooNSwuKkhqa2ssRmJiXU49dEVeKE9mIW4mVGhvYkFgbzpQ'
    'SCRRWUAoVm0hcEw1aEJNUj9NJGdWNjNEJERjYygqQThFJU5zalZbNyhHakQrWkthLS4+LzcrVUhj'
    'cm8lcVlOWmFnNF1acFpVNSkmO087dEFhMW8oVWtaMEk5KTRbTEEtOGhTTG5dTFpQKzZhSy1lZGpd'
    'TmdYSllHa1Ukc2Q/Tm4sM2g7TzRSaVlzdDBnP1J1dEgjJDVVbD9GLW9gbC5ONCgxbj1dXHFlQG5h'
    'K10sP18yKHRzYUw7TTtfO0o5SSpiO1lfbF5wLytqYSRSZ1tMVkJXYSZHVEEwK3VEWEZBLEk9SzQj'
    'RWFIQSRKcGwxcWQnbC41XFErQSs+RzpMIUotV0k4LVYpblpnZTVCUz03QzVlPT8hKj8laG5ZdWtT'
    'WFIoYWUlNkQ8SzJObDtBZygtNVBab0pOMWthaUEtcC9YZEBsK1IzWHJUY2teJk1cVVE2a24raS06'
    'aWB0YWlxND8jU1pqLjJSU0VuSEEkcTxDI19lPjVGZ1VTYE86JSZmbDk8WWcjYFZZL1xiS1wpbnJK'
    'S2JnNV9NMDlyRlpWbktNOTJgT2VyW0o/YmtsTFA/TGovNjJ0PFZVcTEnNkQ7NicrSCc8Ui85TCN0'
    'a1xFM19ZKWgqTzY2ZDEuIzJAUDo2VVUtJyg5N2Q2ZSNQb3M2QSVvdSgsJC8ja2pbdWRmNXFAOysw'
    'Lk9uOEhqZVBXNFRGVio/JWZjWjwzNVsrcjpORTphaWtQQUZXaWNLaGdTOkk4LVU+cHAmT05NXF8h'
    'Tm4yamZ0QkxtOWVAUG9CRUhBImE5UFskMlJHajM6OWEpU2BqZTh1JVxuI09TIkxXSTVSZUBbMTop'
    'JScrJDhZTF1EWHMuImgqUWQ8KyxSXjBkKlZ1NCJKYjNIW01VMldfTnJhTzVtYS4nTE9pOGVCZGUh'
    'Zyk6YWlsVUFGW08iS2IhO1ZJOC1WSXFsczxwQlM9N0NhPzNYTUJMalNvQEtlKW1IRjlcTUJRMDZZ'
    'aWNRUlVTXlxcVlJTRW5aQSRxMD8jX2U8X0g+LE5kQkxsXlZAZUQnWHE/Tl0rJDctTFovNypNKmQj'
    'bS5YWU5aYi41Pz9OUmRBRzdqWCUySWMlNE8sOlhTYT48TzNlL2RQJiFsMFk8bENVbHUoRV5SU0pH'
    'NEk1TW9BY28tR3VlQF9fNSklJyskOFlMXUQva0IsYzhdcCRdLjE3MFUqVnU0Il8+ZSNRTDxwM1tP'
    'M3I8XW1hLiVOUGY4TVlkZSFnKTphaTswamwpJFRHcUJPISVdMVgiOmQsPy9LMGZ1NiZjaHQwLGNr'
    'cSRoaj1EVSEmZ2ViW05uVkUuXmFyZU8jQStKW0pPbmtFYyNWa0QtRj9uVjNUdDNfbXQ1XHFTTztw'
    'V2BsYylUTSU2IyJpLHU+NU1FV0xsOFNrSl0pXypeQV9vNFY5KDhcKURRRUU+Qjp1PkojJz1BPmBr'
    'KTQxVF04Tl1bb0VzUW5yLWspRk9VTmApKU5aN2RNVEduSEZhPWU8XV1mSFojbyMzSj5RbS9kQz87'
    'Xl5zcSE/OERnTjI0YktVNz9RL09FOSMmUlpFMFwvcmgscThZL3FARicrKUBqMiNCKltWMEE1L1Mw'
    'bGguPTdkaXVbVykoJkhvKU4hKzNvPSY1a3JgQlwxVlhJLkJdL1dyJGZKJ0NbNCgqcGhQNChnb0NW'
    'ZGckXXJvbWYvN1I9SikoOG5sU2BbczpOUkRnQixRTCs7RDxFWDxrSFRxSEM2IjMhSlZPRFsnVTNb'
    'XSRoaUhUWUJfZjMvbTgscGhGdD42R19rSz4ycU1abD1KNlQlaUIyY2QqYVBebCMkbGNKR1FGYGVS'
    'cyU0JDRRTzc1cjNoSmYiQjheSEM2aHUjKTQnSVsnVTRmUmRDLzUzW15IP1gob01RLjVXYSZnQlBw'
    'ZDRuQSJdKU03alVRLCczPl0vQjdaQl5kVz5DVU9WdGtlUV03Zj9DNSshNTtXPE1gVVtEbUssNSJx'
    'T3NSS2clLTs/WSglPE1LYS11STFiND9cWGtQczRUdDFXaVg1VVE2PFxTaVxlZj5aXHFqUz4+ViEv'
    'STBVbGBgLjhwPUVPIk9xWERjKSV1WmkyYmgvYWZwQkVIYU40ZmQsdFZmImMyQ1QpUGlKW0EiS2pr'
    'IV0ycjJoIkAvNjtyJVZdZU0sNSUjMGw/cD4nRldjbVZjLFFQR1grKFVsWXBwOSIucjoiT3FYRDly'
    'R1ExaTJcJHFaQF5KTkMiNTolIlNYalVRUG43UktFYG0kTU9EbTUoKWQ1SD8hbCdbbUszL3U2UzAy'
    'ailTLT0nKSFabS4/S09lUEpgNFRVV0g+IlpWaElUKklGbShtV2svOEZnLWZWOUskZXFQbWEpTyNo'
    'bE1EVjlvbVhES2lDRTxdJV1PclRZQmAtM243TDk/WXEjRThBWExRPidGV2NtVmMsdVBHVWlgTz90'
    'Rm8uRjM9WjY2aS87NTkiPnVlUWkwKU5bdEdGO0Q8RVhlZj5aXHFqWi1jViEyOyIuQz9HaWQkaj4n'
    'MWNnMlhXaCRxPEY7TV9vbE5kcXQwUkFmQ2ldQXQicEdYVio4UGQ+MyU4cGtSKFNFWT8iX191bEgw'
    'QiQpZVFpL15tODhjXyQ0WWVwQkZPUSQ1cWhoJFRuMjFCJDgoV0hadD9vTU5RcmRbSTgtV04kZkop'
    'TTN1OT1fXWdxQXUlRGkiZmImLFQhcUk2XVgxakJoMD1pRipQPzAyU2pWbio3RFgncUMpJUBZW2tb'
    'LWw5UGd1IzQkLTtCUUorR0VkPztuQ0xHLEc7ZDpDSEMhTyErMmlQMWU+SUg0XiomQyNqdVYzSjxR'
    'ajNNXmpEYm1mRz5IXzVYUWs0QURgYiRmSiZwS0Vga0JdcERkNzZVUGdCWlYkYEJJN0l0NDZFOCFS'
    'aC5gUHA6dUNxJ1NhJWhYWTtYcSo4WU1paSEwKlwkLi1QNmYnSC5nK1hIODxbOHA9S1EiT3FYRDly'
    'R1ExaTJeXkoidDpEJjgqXldvXz5WVm5GNDBbZCU4b2FJM1RYaF1wZmhzUTZmWlI5V2svOTEsJGpp'
    'W10yMzIpL2pOcEYqdCVsMD8xUFVPZD9qO2dUdSI+QFZxV2FaIXBbRDNWR2w6U25DOEZESytzOiRV'
    'Tk0/SGk7Uj89M2Jgb0pXKTc2dC9xQlVITyMpXFUxYGZBaFxkUkdzNFU7S3AwUj5DU0VKSzsscmFv'
    'XydNLU0vWzg+MmtjSkNAZD4pP0tNOj9kbCJCIXItTScvUXJpLFxkUWslbEEnc3RrIjs9dWlQbDNW'
    'bS9mKnBpTWlzJl1XKC1wRzYpTTslLmdubjFPPiw1Kj8nUCxSaGJMaWtuK2kwT0BqZGpbcCFHSmU5'
    'Pz04Vm4qOG9YJlhmVy4yXWBnbE9GQj9yUVFnPGRlIWVTO0ZpWi5WOyFSWSFwW0QzVkdsOlNuQzlR'
    'ZEsrczokVU5NP0hpO1I+YjRfXTVNVylJQyEvalFjLlQlXmQjZHJfViUhNUAvVEJUUmhuSFlHV2VC'
    'RiskRTxvWiE1SWgzTm9PSypcI0c/XF9gZTk/PThWbio4b1gpNTdYO2VZQUk1XCRgNyRAOCslS2Eq'
    'OE4vIzczWFZsUkUwTkstSlByTUFhWEc2KzNaKDUpbEAocWlIKiVMcDhRYylRNkBvRVluKEJQQTlV'
    'Mjs4OkpGQExUP0NIQyFPISsyaU8xZT5JSDReKiZDI2p1VjNyZmEzTEJUUFBSXSlWcEo1Z1JjTytn'
    'OjhDbTAnaT1WckBQSk9CYjxYaTFIV3BvaEczIyc0O1dsLUMpRTBgMk9DNWwhUDw4ZCkidEw+WEFD'
    'KUEiK3ItK1w9MyNRXEtSMChQYyFKPV1KbEY4VFJJIlhjVz1RTlNDSW4xVC5KY09ENWcsVCMiNlQw'
    'OSgtWlY8JkdDWjtTcmRfOXVSLTwiSHFIZERnJVIhV0dJMEtCQXIySC1da0hfM2AwT1hqWVwqNipT'
    'Y0xnT2w/NTg+ciwwbnRWMyFXZUdBREBpJDhZQTxQNTc7MV5IXEghQCwjVlo5dHUnMyw2MEYxImpB'
    'W2VjJm1lQUw8Xm1IWCRhXTZjIiMiYSpgdEg9LTAkOHNRMFRbOjo3Y1g4Rjo9XyRbL1hXKyM8P0NZ'
    'ZSwlcC0oXm9dT2xzXm5UKzVMOkNiVidGZTdbbShgb2M/bEEldVU9OSsiWDIiNWtKIm46JUhAWSFO'
    'dWhQOFY9b0NWZGckXXJvWWYvN09UIlBqNHVGUWUmNzpIND0kIXIrPVRAT04pLDdyLW9COXRlYz1p'
    'VzZyTCdpSUl0bCMkbGNKR1FGYGVScyU0JDRRTzdfKF4xcmYiQjheSEM2aHUjKTNANVVzYnUuRldc'
    'cj9HQSdyS1FvMFIlTDNfTl0ocWlHcl1nRy8rczApaipQXjBhOD80JS51IlcxOU48KlFoV1JRNUws'
    'XmZUaTo7NV9kZj8lQmFmNTg8YEZIaUNxMG9lL1wxZCw4MltARltpVEZkbzlYPC1KQGoyM11JciJm'
    'KGcqaDRaIiVJb3NybVJOQS5nJEU8PGhGSS5cTjVeaDg5PmNQQzleKUUkLkBLaVAkQlxmQVVjT0k7'
    'aiZDVmpcODBPNj80XkhrSShqJmBobFNoUDlcZE1vSEBANE01TD0oQFRtYSlPIzVIRzJAOWIzLlEr'
    'azdhJERSN1txVzowU086M0BBZz0yUGUkLmk+c2Q8a1VqZkU8IS5fVWJSOWRCVFBQMTgxTkcoVGIx'
    'LFlvZWk8Ki9xQyxgZT1vNyZUdDo7V1RtZUVSQVdASEMoYG9jPy5bKkpLPiVlJmdHQzwyYFxkUkdz'
    'OW5XXiIocWlIKiVMcDhRX1s7WFZvRVluKDgwcG0pXS5HaUBsRlhkLTtyJVdIZU1dYUgnVENuREZi'
    'Yl8wcmFEJ2FCbVBGOi5BVS5EbnVQbkQxXWx0PlpfPTZwaCQqPDJhRl9iXSJmKGcqaDRaIiVJb3Nm'
    'alJOPDYsNjdRL3I4KCFBXidBb00yMjRhImJKP1JOOSlQZ2Q1Km1fZkxCRisjSjxrRlRmTiJIdShP'
    'SytYPnBUYCdOVzowU086M0BBZz0qckdrTEkrQFAhPHRwaTpzZEM1O0o5SF9ZWDBnTC5jJzMpJ15I'
    'NmdZM0FvMCFJUWJRazk6KSlwTHJCVitoMyMoMixmck0/UnV0SCM0RFUlLnFrcmJiSWpQNTwtSkBa'
    'MiU5KWJfKF4xcmVmPlpccWhMRm9WPEpSMVVsWXFROSIudTsiT3FYRDlyR1ExaTJdazIidDpEJjgq'
    'XldvXz5WOjpTJ3BxRDs1TVh0PyU/PzA6OjU1NlZzLjApIUlWOytjbGBMZXBYOD5OQkYrI0o8cDJC'
    'O21nJ0EjOD5UKFg0Ilc4amxGWGQtO3IlV0hlWVpNLC41WixfP25nKEAiaGktSjYzRyxYJ2lOOlRs'
    'IyRsZ0pHUUZQa3U7ai1JJ25zXCs5ZVA3QlxmQCpcOjdXRjtqbmMkNW1qVWRXUCVSNUoqU18yQktW'
    'X1lGVmhpI1VsMnMzKENDVy0iVy5bQDZVPihtOTdIVWZxWFJvPzFqQmdFPTtiKFRoPCZFNGVRaS9e'
    'WFddTWxfPD0kY0dBJTlNKycmZjhWSDhab0thLXVJJScsL2BYa1BzNFZuKjhvWCQkXnQ7RDxETVhg'
    'OSxOaTtSLmI7MkpPIzFlOGU/N0AhO0hjajZUPXFPMTAlKFZqKlZDPS9kJmNzOzE8OmQ1WmQxMDRl'
    'bCRrSEIwIl1BLHRHNiVtZy1MXmUwZSNEYTpmUDI4Y0QxYzloKmolTFwiU1dHLVA9ajpLMWU4Y2k4'
    'c087JWNqNlQ9cU8xMCUoVmorUSNSc1pjSEI2VnQpTTdqQSdoa0lnJks3SSw4dT40aT5BKy9oR0M8'
    'MmBcZFJHc0ZiQnJKKHFpSColTHA4UV9eX1M0b1AuNyRkLDgyW0BEdTBRRmRvO248LUpAals+RTZR'
    'ImYoaD9ITEIsa2djcWxuQy8iWE0xZThjKTszZ1JYY2o2VD1xTzEwJShWaiwsQz0vcCpjczsxPDpk'
    'NVpkMTNYJzcka0hCMGVQbz1HRzYlbz00UmAsPmUjRGE6MyhZWSwlOG5tK080RzxpSyk6PDw8TWVw'
    'bClQaUo7V18wYSdCRVpoL0k4LVdOJGZKJ0NLRWBrQl1ncUF1JURpIlxXaU9TPyNSc1smb2kyTS8n'
    'QDMuZixeaUtEQDlOLzgzOGJHMydwOFJsazlqXGQnRTV1U2ZFSktOQVQvdTkuXldCVjxhJW9vMTE9'
    'I2BWUTVcbjtAbEBIOSg4XDk+aTNNLzxEP0xvPUBMWUNFT0FJbFxWZUNEPDxyMDYvcT5QJkVJMTVb'
    'JCwvN01ELG5XQSFHMilGK0lGRyFWLHQmKWpjOzw7V3QrV2s+KCY4cFAybmNZVzw/UUhqMGhSXD0r'
    'WGhWUCpWPC4tZ3EsXFdPaS5vTmlcOm9gYzoyTEZvZyU1aU9pZVdRL0c7RmhIJmxMalQmQkgiUzZf'
    'SXE7YmgzajFFOG00ZVI3byppJSJlWkZjSDRrSjNJOmRKR1s6bEk0dVBRajs3blQvQUUtQEFbPVwz'
    'R2ZRNFhrUHU6Ry5JI0JqPWQocVtfWGVITyZpZzlkcjJrYS9qVENLcisoTUxGb2BxUWU7cSJUbyta'
    'UERUNTVScTMlR2laOCN0Si4uPkJLI0tgUW9BTmg4QC5Rbz9UMDY3aixOXiRZc3NDL19ydGE7TVpd'
    'Q1lcKDptcl1FaFghUDxFRm9iP14+PVxuSEdRIlgtWlZzXC5SKCFPJWQ8aTdfRDtOamVnYU9wMjRC'
    'WippPyU/WGM+SUFVQT0iUmszJ0guaE5EMWNRcCpkUkppJURpImwkRmohcmgzclg9MWpCZ0U9cStQ'
    'TWg8Jkc2ZTZOJl1YZkZtXTY6NXF0LTpAYC5kKihlTyVuInNgJSVUXztHNitRVUY0SmlZU3UsPz8i'
    'bjomPSVbW3VpaFA1NEtMPmAmRi0hYjUyXDJQazRVOTtwTSgpZDVIPyFoWlBtSzMvdS1qLjltN2Ru'
    'YTk2VVJJYkNfbjRrN3FkdU5XcFkyRVxkTDRWLF5lM15SU0l1QV5mSj8sRF07QkZwTHJCVitoMyMq'
    'T11SdG0oNkxwNW8uJlIuVGIxLFlvZWk8Ki9xQy1bSW5AUWM3ZG0wUm4nRFgkNUhXWFQ5T0FBTVVs'
    'YWxUOHA9Qk4iT3FYRDlyR1ExaTJbPHBCTWBDKzAjMiJyKnQhPV4sRD8+Vi1TKSIwWUw4c1cpP0tN'
    'Oj9kbCJCIXItTk9dcllXNipqJUxcIlNZXW1zJTpgYjFlOGNpSjxmUTJjajZUPXFPMTAlKFZqLCwj'
    'UnNaY0hCNlZ0KU03amEnblc6SCZLN0ksOSM4WlY/RXFpX1c6LyZlUlNJdUFebjJoWjZBI3UyaFA1'
    'NEtMPmAmRidrKGcmPUA8THEtN2czLDVRND8oTElUbTtXay84Rj4iPDdmSyRlcC0oWjFvMFw6N1ty'
    'PUYpX2xCVFBQMSVQLUFVNjZpLztsWUFRMz5sXDchOzJaSiYlR18yVCUudXRSMENxYy9KYDRdWFdD'
    'ajc2UWJRRCE0I0ZPRztyJVdIZWIjRGonVENuREZiYl8wcmI5PlxCbVAzND07MltkJFNcXGhYTDli'
    'UUw4SW8qImdITjJiaEU/TmtXTipuQkYrJHU8XS0yPzdxZHVOV1oqSkVDN3U1OWh0OGp0bDdSVWo8'
    'WTY3R0AuWU1CNCNAKjc6RmRNW2UjUHAmNkEnSV9WSCZgLmVucSJVO3IlV0hlSFM/bSdUQ21BWDVC'
    'VG9cOjdbJmZwS0p1MWU4Y2lQKlBJQmNqNlQ9cU8xMCUoVmorQUM9L2ooY3M7MUQ6ZDVaZDExcHEn'
    'JHI5bnAtIldwYi9NbU9vXT10LkBoJCo7dTJGPCQxTjhDPVBMUEZhZEJwRTdESEB1Sk9VdFctRlo8'
    'UjcvXUEwK01CS0ZbTCEuVStgcVZrZC8xaXNPQTE9UWc8SUojNWdoN01tb0dHM0NBPyU/V2hCIWxj'
    'TlZzLjApIUlWOzBjbGBMZXBMckJWK2gzIypYXV8qIS9TWXQ8XUYtRXFnb1JyJW8vKiQnL3FDLyEr'
    'PmNYKmtlNEBDKj8nUCxWXFBhS0VlMlJbS2lFNHJdJCFEYlRZQmAtM243TDk/WXVjMk1hQmRUIUBD'
    'MjQ6c2RCai41V19APVd1PWY0XkhrSVF1bEJEbFZDNlFcZE1vSEBANE01VlU5YXRtYSlPIzVIUD5H'
    'OW9tWERLaUVrL10lJytsVFlCYC0zbjdMOT9gYk0vOEFYTFE+J0ZXY21bbU9AUURSL2NPQCNzPC8p'
    'Pio6JlElQlgyNGEiYko/Uk45KVBnZDUqaiVMXCJTWVxCOU08ajg3QGNidEc2K1NrVlVhNzdTdSxI'
    'QiJuOiVoNkEjdTJoRm0xRjZVUGhtWmpPMnFySWBIPktpRmdKXSVdT3JUWUJgLTNuN0w5P1l1aTRS'
    'bUtKZCFAQzI0OnNkREAuNVdfQD1Xbk5cNF5Ia0lRdW9SSWxSdHUxXGRSRkFZb2trb188PSRjR0El'
    'OU1UMnI6YVZGUDxdX0clUUFGNHI3XlVfRV9wP2RsIkIhci1MPlRnOSNUbidTXjY2WkUoNGlqQ1Ur'
    'NkEjdGFnJy0tLT9bSTVDJT0pZjdsbS9mKzRxL2wxIWdRKGIhPDtzQlhEYnU1UWlPX3UyUTcrXjEn'
    'M3MxZlVgUnIhQi1TQkRvci1oWyQ3W0dVU05nRFEvRzxRXFw9IT5XZ14jaFlfbzZlVF5DdVAoTFpp'
    'K3MvK1I7a0hHPiViQjJNXFAjZC9mTkhTT1ZFRmhDPDR1IVRsOFRTSXRlJipmUmsqLGQ9cSNUZyEv'
    'cT5QRiEjQ2EpJnEiRFBnU3RLWyMoa3FNaiJob28vb2RyYjRiJ2hZPklBRlkzSGJGJFYsI2wnZkxr'
    'WTAwbE8sIjMlMlJCV1lpbFkiPytsQ1tCbko3WEpIc1pMVT0rZ1FnRi46ZlEkNVNALl8wTExBSCFf'
    'NDY/UlBiIickXTxuTSsmNVMmU0VaLjxjYCpvYHArITtVRkloRFgiVW4nTlZvSCRaRUptSzJJVUIi'
    'M3FRZztFJV4kTlUkaFxTbVBIOk5SQnFKKkVLNCVDWFoyWytdQWdJYlMuUCFWMlQ4Ml80NyUkX1NA'
    'OGEnLHJ0JytVZUwhMUFUNVtfWGtKTzRMaGM7W2QjRk0/YVEuPG5MY2wkYUAsLSFoYVwqVm5eaGgh'
    'KzBSZi5TLmtLNF4uRzg6T2ZSWyEqTy9nPm5hLV9jczsxSGE4QzohWyJNUlxCT0k0OiVDWFoyalA7'
    'bVMiU1ppOE8lWW1iQ1suYkNpKkNrTS0kJEQ5UyM7WlFHNioqIVhxbC1lJUdfMz8lLnV0UjA9MGgr'
    'JHNpbGdGOiZLNiJrWmorPSdOLlpSUjItNV5mUGpvKVBnZDUqaiVMXCJTWmk4UXFQb0dJbjFhNWJh'
    'JVYlY2o2VD1xTzEnIihWaio+ZmsiMjxIQjZWdClaJjVzXSlYUUs2QSN0TW5fRFVEPyVDMj9yMHIv'
    'YUZLMnFRW01qbUdnTCh1NjgqXldvXz5XLCdrZ0srLUxfTmAlPzBPNlROSV5sLllOXSMxIUlRYUVm'
    'WW4xZW4iaiVRY2ssIUlYZEYhIj9QKzNQT05RZltHP0FNXWU5Pz04Vm4qOG9Xc3VJTTpoXSZGXmgw'
    'TWUkQDgqYkthKjpCT01GVjZGZXEvTzFdbHNTXjg9aWIibjonSGBROEhWbidTXjY2WkUoNm8iJFlA'
    'NkEjdE1KUi5NWCRdVF01WS03KGhHNiooS2pCYmtASEI2VnQpTTdqcWVfLWVgJks3SSwuZGJCYj9F'
    'cWlfVzovJmVSU0l1QV5uMmhaNkEjdTJoUDU0S0w+YCZKImE9Wyw9QDxMcWo9VktCNVE0PyhMSVRt'
    'O1drLzhGPiI8N2ZLJGVwLShaMW8wXDo3YEU/JFw3cUJUUFFcXWRxcFo2NmkvO2xZQVEzPmxcNyE7'
    'MlpKJiVHXzM/JS51dFIwQ3FjL0pSTC9WWVl1LT9rcTdJXD1FZUcjOXJHUTFpMmMqKChGXjM3OCpe'
    'V29fPlcsJ25eQCgrQF4uPTxHU2FhbDNGNlEuanBiJV9cZE1vSEBANE01W2FCSC9tYSlPI15UQW47'
    'OW9tWERLaUZAPl0lJytsVFlCYC0zbjdMOT9gYk0vOEFYTFE+J0ZXY21iXyc5UV9taUIuWVMpcSFj'
    'MEM2WDAoLD05ckdRMWkyWzw/InQ6RCZRV0NqZzZaRSg2MTssRGo3cWR1Ti5iJCEpQnFaLDhodDhq'
    'dGw3UlVqMlYiTm5UcVQndVMiWTlaa1tpJFIpQXFVJyFdc0VLUTB1Ki0jY1I0Z1JTSXVBXmZUN3Il'
    'OG5tK080RzxpSyk8ImxtXFQuWylQaUhlcFdDWnNuW0lxLExXNitSPC1KQkA3Q3FdQEdHM0MxPyVD'
    'MHI1ODxiP11CIjIpVStiRFg2QSdJX1tNQT5fZW5xIlU7ciVXSGVKXmMsJ1RDbkRGYmJfMHJiXEta'
    'Qm1SMWM7LyNHT15wXCFsZzpHUFhGSzJxUV49bjRkKzllUDdkTWQ9QyNrJFNOZSFKLFo2QSN0TTxG'
    'PXVDJF1UXTVZLTcoaEc2KiohViV0V2klR18zPyUudXRSMDY8dTpeYj9RO2ZWdU9QbDA5bjprJSJC'
    'YklxaCRwPmxcKDxfbjlpak5TXkZRTFBGYWRELGwlIUhAdUpPVWNROT1YVk1mVW9qKHFSV1U5aV9D'
    'KSpGLiQ6YUwzXGpKaShzMGNzXzFkKzBYJ04yYlNsI21Hb0pHUUZQa3U7ai1JJ28hXSs5ZVA3Qlxm'
    'QCpcOjdgPT9eYjpRbDRiL0wkYT9jKllJOD8/MW5FbmFKP0xqQylQZ2Q1PzxZWXEpTTdqcSdgYTlZ'
    'KytzaElVXzpKa2glZ24wb2oocVJXVTlpX0MwTjpEJ0g0T2pZU2xfXUptUlM3VG4tVyksZDozIWk3'
    'JDReSkJjLjQzdXVnbVdrLzcrJmRxJFknVENuREZiYl8wcmJXczRCbVBGOi5BV11SZFZUYTwhVktg'
    'KmUjRGE6cGhDODM1bWcqTWRDTVw0RTwhQiNeYmUyQEsrcTQraTU5U3FrRko1OGoxTWYqZitBcEI1'
    'KWhmYTY+XXU1IThzS0FKYjw9RClcXjpGSjU3WUk+WGVdP08/S2xXSi1LUSRVNUQ7Y0MxRV9JLSYk'
    'RzxKaElTbnFCNj9MQzlqa1ZXZlhBZypWZjg7KEJCSExXZkFhS2F0QTJ0ZHJCXyRcZ1lDXTdfPmVm'
    'XDIkP1EwZWpNTTg2O3IoSSFXKCtKQXVIViIiNVAvITU/WVopQWdnaiQsLzc5RDpPN2gnN3ByNGoi'
    'aCktYjEyJj06TmNjY1w/L3EiSSdPLjxiOkozcCxbSFltOTRRZ1ovUjRdb1gtYWAzMThIRiUjSVk4'
    'QzVNIjhENF9nW2paXjolSC1zSzpOYFRWXyUiU0s7QC5jcT1aRl1EMGdVbklGY0gtUTdOTm4nLkdm'
    'QVJlJyJpczM0KFlVZE9aZSpfaTNnLzs1b0owWUFJTEkjajpqXmotQDAmVytgVkAyN0s6Y05mK0o4'
    'JSFCXFU8NEtpLkkqWDtGbV9iOF9yPjBPLi43bTojVWA3MDdtb2g3KEdgMFw/UU0/VEtqSUQuKTcl'
    'PTdiV0ttJiRHQjNFJiVKXDwpPHJfcmJlRCQpNmJiRz9dSy1Waz9qQzooInUoNF4uRzg6R0k3TS41'
    'M0dcODN1VzcuSk1qX3BDN1owNGEkaU1OUmpobFE5a11HKmRSSmklSnI7MyFBNjVaLFtmckNILzhL'
    'R29LK24wQWtxW29gJTUybG1NJFM0cExyQlZFSCIvKWFhWS89cmFrOi0pUktrcGg4X2siVG1sM0Ak'
    'SDRWX1hTKmJuNkQ1NzA4Kl5ZRUtEUkIhJDRSREIrVFxwKWMhKHIlJWVXMXJGIik4NUBeVyYpZjpw'
    'VWxdZ3FBdSU9Ti1APmxePDdUYi5WaDw8a11ubGlMa2QxOVlDUWBAY1xFZWtnZ2EnVDE6YlstbDoj'
    'XDAoPTxkKGg9TSZobltiXU9ta3I6ZD1TMFNSTkJYPF5VLiQ7Q0ckJ1YsZCEyMzROPlhXQDlZWDlT'
    'RVZuKl1AcT1CSzRLUEk4LVdsImMxXWA9dTdXYTVrISszNmZbKlJiYGI/cV9jMDFCbHNdTF9Lbl90'
    'bmQrPEFzPyU/I2RzLHIwUE1VP2RYbWEqcicrN2w7VF5iP0s5MFJNSGJENSNvYjVQLWgoQE1eLmZf'
    'XE9VSydWa0Q5aDRcaC01TllQMkpSTCNSQC5zKEdrQDVVOkEqSjRyZTpbZ14qUkJpWS8uLik/ciMp'
    'WDZfYGJkUm86dW01X2ZRVSxmdSlyKElqU0xyTFlGWzBKN0hXN3FVUTJiYFY7NW1wUDQqRzI8TiJW'
    'YF8uRDUoT2BnM1l0bC9VPj9kRz42UEJNXFtdXyRxS3R0MEBlMyhlIlViSG5eb1xqOEhObCFgJWZY'
    'dHNFY2BxVFVDSS8kQU5uI1dNPzc2TkpjWTItW21mNy5JUE9dY0xrcFVxY0xXcGQocERjaF1eKld1'
    'JWxyXCpJbXRGKF9yW2IxI2tJZ3UhQVksTGEqZXJvLUknXFVRUmhjcCZWKmVUJyFdWUEpMlYiTm5U'
    'YFAuT2VmPlk2PUNbcDopQW8/SG5CRSI0RGQtbTdRNEE9OyNpT0A/Zy4jYi82OEFJdWVmPlk2PUNb'
    'cDopQW8/SG5CRSMnRChQXEM9Uk9OcV5mayhAOHEoaDRxV18wMjFyLGEyXGpQS1hDV3IiIipmSWBy'
    'KCgoTjFmWz1VUClOTFhdXlZPUXVaIigxcmNqNT43ciMpVXUxXy1iMDQ9TipAOUxuJzI0bUFnP2op'
    'PGF0QktWX1lfNklMWFZzKGBOS2EuPVlbKU8rKSM/XiQ6NCwhbG5rcFVxY0xXcyQ9KU5MWF0/ZGdH'
    'YEctJi4lVS4oYVZyZiNESylAJ0FTU2VOKFtWUEVZKipcbjZHPj9kRz47cSEwVFtdXyRxS3R0MEBl'
    'MyhlIlVzTzRUJ0guZ2NVW1pNTDJRcDp0MzBrJiY5ckhxJVohJ1MwS0wuRW1ON0shZiM/WUstJ0gu'
    'Z2NVW1pNTDJRcD11MzBrJiY5ckhxJVohJ1kyS0wuRW1ON0shZiM/WUstJ0guZ2NVW1pNTDJLKWM0'
    'MzBrJiY5ckhxJVouX1RaS0wuRW0vP1MoRk48PzduU2dUM3JMP1UrNlpcUWZbKClpNDA2WFM6azMt'
    'TUMzZVk1ZDMhV0omLyo/Iy9iQSJGQVEob0YodGJvWiJaYEJxSklGUlVrVlZyNjRBUkxCdTZocUJm'
    'MDxwbjxvXmApZz9kKGg9VUtsP1toSC1KW25aI28yRjNYKlFhZUpeYiEnVDJFblstbDojXmApZz9k'
    'KGg9VUtsP1tQR29jUXBjZC9AMDA6ci5INV4/ZSk6Vydyai1TUDA6I20+Wyomc3RUOURiTC5rRDNO'
    'K005QiZxLigwIVUwJDhWISZVPC9BJVl0W3Q0PlpyI1Axbjc1RVxcSzMsV2BrWDdcOS5UbE5ucStX'
    'L0syKXUqTigzNkEocmFaW3RnY0U1dGUhLzxjcVhiQCNSa2k5TEk2NWh0SF1YWXJlTFZuJmMwVF1h'
    'OV45YjwsYl8sY3FKWSlXUzlrXzNLU2ZwcilzTzg9SmwhU2ZUazdWbUdZb0glQDtuQShyYW9hT0ln'
    'UEs5ak5pWF1pNGlUR080O20jJVVMXjkpZG5bQCFpc1E/SD1fbEtmaC9IXCcodUsoM0pmM0w0aUIm'
    'JEFcZ1tTSlFvTj41WFZmTlAqQmEnLHJ0PiNcRVxHLTg2cGk0QnFYN11ZPixCb3UzUWZYXl1nQHRn'
    'NC5bW25RPkEkK0tKNG1jSDZHITYmIV8wN2o7TiltUjhlJ2xAJkEqNjUkKV84OzZaMVY0XyspQl1w'
    'OWZTKVBtIUxpI0tDPF5VKTZJbkpWb1BNW2EzTFRaMWZlOkhBKmBsa0ojbWReVnIqUDlOaCpwQ2Mv'
    'PzJRSW4iNTFrMztXSlEiMCFcRUFwcDNNLjglQVtbX10iTDROUmpmVTpuWHEhUS5vT2EkOUBXIVxd'
    'JzhZTF5vYFg7KmszT1dQPispQl1wbDBqbUlHT2YuSFVKa2hTYTZubl9XTS9xRTU3RzZYPldkITUl'
    'SFo1VWg8JkRZPEs/SVE0OXVCbzBgSSReKj8jIVxdQEZCZWwxR05LJ0g1MyM6Tm9yVCJJPTRaYykm'
    'UmZJQzVuMUE1UiJnYTZubl82VTxBSFY5bEhdbiJlO0NhNm0hYzxhMW85OiItKF5DZy5AZCUpMEBE'
    'Qj0uKlImN0Y9cl4rRSVpTWIjI0FcITpqO2NqMjJpcU8xMEVBLEMhaFRaZGJfVDs+UVZjaydVQFho'
    'SlhHP1ArM1BPUXRSbUc/QU1dUT9JW05Wb2w4bVtAbj9Gbm88ZERTWyE4YmtbZmJnKUFtQG5PUXRU'
    'Q2UmcTclVktJWWA9LmBAPmt0YVlCP3FDXVsuKyxVbjZeVkpwLCteWCk1ITpKKSU3Wm9FTUtpbiUx'
    'MmosOy4tZTFpMFsrQD8pa29hZCVMbGo4aDI2SSpvRVluKDg0Plk7PjpoW2A+ZTdaR04xcydTWFdm'
    'U21fJTduckdBJTkybHJNJmdWSDhbKkthKzx0REZIW3FGZG85bVVTdVhDKVtIbU4wTFJAbElZV1kz'
    'YyMsczRBLDs1NCtHRWU1O25DRkUsS1FfSTpcXW1DOjElazw3P14mKjsuak5eKSUoXFgxUEgkZilf'
    'N14uVCRsRjEpRjV1XUojZ29eJ0guZyMyVkpVO1UzMjZHMFs0Syg0REIrcCJ0Pz5sVCg1OVZyNy5P'
    'c1RjbSs5PjdvMis+OkI+azsoKzc4RmBvKnVUcUxpai0sM2glSURbSEkpTjZfaCglS2YpRC1oa0Au'
    'LWdIVClGQiZqJHJOYUFMUEBNLURGSFslSEY5XEtCSkFgPDxsQHBAW3M4TDM3VCQoZXApbDFfXyU3'
    'byFjTDAkalZWLyktLWJaKXAxZThjKW5XYElJY2o0W1ZxTzEub0ZvI2lHL1FyaSxNRTNoX2I+P1Iv'
    'PlVfS2BnZlBeN25OOilHU1hpTzlHNVxFKTwpS1FxTDErXGhoJTFsOUdBJTkybHJNJmdWRlA8XTY3'
    'VXREaC5pVnFqTzNdWVNMV3BzZUxFbjwnRltqNUZiYl0qYyMsczRCbVBGOi5BUy9aZGQ3ZWc1cVpH'
    'TWUjQic6P2BiUDA4QVBpYD4nRldjZSpMLFJQR1ZFPjNlW2Q1Yz5IJzVbPDd0Omt1Ok5YWTtRdDJV'
    'Z1QhVj4wZTMtX0RKaz5uVmxdU0tFYG0kLCtkNj0oKWZJaz8hbCdbVS8jJzRYJHJMRTZXJUsvRVoj'
    'NDFSNi0qLEwpVlk9LCthQkNNTTROXTkxTCtuOikubjQvaCUmODtEOkxxZWY+W0cxcU9MbVYhL0kw'
    'VWxeSVk5Ii5yOiJNJlcmOXJFazBJQzRnVis5YixzQlxmQCo5WEBxODpSVz51NW1qVElrQlovJWNb'
    'NFlKbWVGaUBvJFNlVUxCImtuSCs9OFI6cy9CbmZWSm4oQGZpO3VSb0JTXiZ1UXFGcGtGdE4nXydP'
    'WCNrOHM7KXIibkFIbSxWWjtBcCN1aicsP0ksP1wkKUlaKUBGXFZURzUhSGdTSitMYGtGU0BmM1lD'
    'ITFWUipnMFB0Lj8vTFRWL047Vz9oXUVJV19DaUdgOk5WTzNaZ0RFZ1FgPCJJJ2VeLTBEIit1UkE6'
    'UXI4bjZYVzRoKjhbVlllPSxiWGUxXEdiLHNRazxmSnBdQ05mdGRzc0pyKSZacz1xQyY1KmBrOEVX'
    'XDIoXmZxbyVDdCxnQWI/aldEVl1vQ08vbG1jbTYzXWp1PT9FLVA4NzZuJ104UWBmaG9vZFQxdWwi'
    'LCtEX0ZVV3MpMjowbzNmUTVuKXIqZVhWbSJcJFUvM08zTSxxMTNDTzJDI0dzQCNnLnVdLUJbMV9H'
    'Wls7UFRDRWhLL1A+WXBPOGtbVERdWGBnMjNQbWVDTWpvVTxqJ2gxTlxIOjc9Yls7UFJfKihFZTw1'
    'M1xIZmtbVERdWGA5aS43az8xVWJVNSVTPFl1LWNsSWNWMmYiMCxUWlBGNnRqcyhfMU5CVyhGZEAu'
    'T2lITTJ1Y2M/cG5VQCJqXz5rQDZxQ1s8N21NP05PNldSRDBdYEQiS0dNTTdlMWo3YicvZy5kRzc4'
    'PD84MCZNS2ckaXIzPWdpU246X2RTSmg1TGslS1BgWFpKQHUyKEluOCNdZC45LmNPU1EvKW1QMWdI'
    'PkdKVTxcTlY9Ujo4XDFfYidyOUozPDxvOydhS25HJ1JBOjgrQVtvOmFYQzZYT282VS8lPWxsJihC'
    'YzZXKiRhaj4lR0ExMDRlbHF0aitxV0pLYSUuZERFRjFpQ29gUlNGVD9nMWhJOjJZbjhiNy1iPGxA'
    'QEU1bG5ZR0RYJkxqTSJUJGhIaylGNXVdP2RsIUs6MSgrSDFlPkZvVjZvTS4pVCI8US8paEdxPStn'
    'YyxVYHVELlgwRCNjNlpaT19rWicuN1pkZ2JSRlJMcypMPVo9XiRDLHQ+ZWZJUEgmIW11LlhaYm9M'
    'cWYlMiRcXDtDWF9FKSYraWttJkdLNT41VyswSkdOYShrImhvUC43IiYhcF9cQSR1JDtGZGs+WmlA'
    'OnIjZUhTM0I7RD8wPVhhWWMwNktLOGhbMjc7OUkoNXU2Q0ArVDo+MkJZXGs1I190NiItPWYyViJO'
    'bkd1JWwpX3NBcmhvSjEoJUhQZGcqT0Q9L1NHP2BvM3A/KTNVSTpmQ2lMTEknLE8kUFwybV5zb0ht'
    'XWZyQjFkMUNOLkFVLW9uazw2YmlPSVs6K11SbTc+J29lUD5QLmEkOmhWOFlIXk1MI0pqKD9Fci5u'
    'Vk0pN2BSVzBXXVcmZXQwPGZvLDwhR0BAYVVRJi9xP1BPOkE8UjFrYSI3PGJtYm49LFJ1TiMvZSRt'
    'Q0AsYSQyWGM0Qy4nMyRqKmVYX0goaENQTWA+b2pgalc6SjE3a1lcYiU4b2EpcDgjO08xa05FT3Jk'
    'ckhFWFJqdS4+LW9cNydcNUZraEVqTF1GL0A3IW42Z3JMQ1taP1tlaWUrZ1kzU2tYVltEYSsyJTI6'
    'c0hPUjNSRmJiXUpcXThJUGRJW1xSO0ZuNGhVZyNFLUsiXF8vVkdpMWteMDNzPU9GZmJWWy1sOVAu'
    'ZWQmSTRkbUZjNW1qVUJTb2hTdTdeK2knZjYiJHNjPCc8OyU4bm4kTD1SQGA2S0s4aFs3QV1IN0Bj'
    'YnRAR1BHJHA5XHQzVnMuL2hTWmFwYClQZ2MmOWo1amApRkVPLFgwaWJtNTZxXXI4QEEvZV0uR2pr'
    'XXQoa1M7aF1BLmcvYStpS25kSVVMWTVsW2tbai9yKUFqTnNPRD0xKTk2bWVoI2ttQzZuWDwyZmYo'
    'Zl0nNiJsQDM1clErPGNrJV0kPUtPYFQqaGJrLFdSZFlfUnRYPjkycVFaJ1dqJ2NNQ0J0QUkwWl0i'
    'Iio/JTkrKmlsXD1kaiRcPytrPjouOlpeU10vJ2NHIlVcM11ZPiE8QlssdTosSTZQPnBWciQ7LE5f'
    'Vl5eXFlnK1NcXzNyNkBlZk9oKFQsSkY9Yy8wRS5hb0dRLDAqKGlIJkNMcD5uO21NV2hTZC84YCNR'
    'biE+NGdcZF0oQk44XCRYXi0pUmldZTAtR2RmW1M0YS8rX18qc2RWLSppcUwmZ2NFVmRVdVJqKVJM'
    'WzxIcUlGYzRQaUZsZ08mUUlhZF1BS0pLY09nS111Qm9MZHJJQzZxTVZHRS9zTjI0IzhoV1knbC9O'
    'UGlCUG8nRmotPUVBcixEMXNLUUBfIy9iaEsuTy8mVjdcOlEvQEtQMyxxcEVibzhAOkNtMF1ZJFRX'
    'Mjk2VSUyTEYzN1hDc21AdGpwRTI4VD5FWF0/QTlnWGJRUjYsXCFjK1lIWlQsaXBKPXVUWCM3OjUn'
    'Rl86QDxHcURzPz1samVPNVwxZjFWcFpPKj5TWGtoSFlRRzpERENVQyctMVUkM28yMUM6QUlVMDY8'
    'cENfIWtsZ1I6KVIkJS9bPFxEO0tyYC4nMVU3XlI0RkBLNUBNdC1zJTI1R3U/YjRHZD4xW1lZSXRM'
    'ck5YcGpTdDgnRVlWJSJnYiZoUD5BNHBSJ285I3EzOkM3TD06S0VoaGYnLEUoW1tfXSJMQWQ8TEtt'
    'ITJ1OGksOi0jMi5FSi8sWD1qMj1bUWpfIWtsZ1I6KVM3RjcuKFBbcz1FJigiVkoiXmJPWUwjMi5G'
    'S2tQNldPM2AjYW1kIzM8Rk8zSG89MV9lTjdGZG85WDwrMCdlPF9XN1I2KzQvWGBFNWdzOFlMXm83'
    'KlhqMV9gSCYtNU0hRWplKSlbVz5ORVdiOypbM1RoUloobEldb3QuWCFQPEVALDgrbEhlUSdUQ1JT'
    'ITVmJURTa0IiR0dbWkN1RHJMLz5FbFtKIjlbPUA8THFldC11UUtncjoqZkBQLEVZZy08YyNSc1pj'
    'YTxuJDhMUEFYOUFbVjVAcU1OV0JLaURqVkY7PEBZM25yKlVMTC5DKjNhMycyOV9YaT0yUk1sXz0v'
    'YW9bUCNzUCg1JFV1Vi0qYTdNbURCRCxrNSdEUyRMPClJTUBaJGYlJ2xSTEolLmksUUJmQ19sLilN'
    'Iysia0lCQUw0VWdGZGs+WmlAOnIjZUhTM0I7RD8wPVhhWWMwNktPTXVgLzxlQDUkVXVWLSphNy0v'
    'YWlqaUY4XnJLVFdsXkNScWc/SF1WaHVPMG1hOTNeISlvOCplbCRtVWxuai5oM1JlZV10KyxDVEBr'
    'W15AQDY8OTE8PjQkU2JJZlsvTHVaSGRqJyghNjdSZzxjX1NOJU5sckZdNktPTXVgLzxhNlU8Z2w2'
    'Njo1MjtAZUxRRXFMaSxFLEJEMUVqP2ZRVllcbVQ4LzhhNSoyPkUtSTNhXSE0MWU+RyopZDdIISNh'
    'SlVwJnJXVmdNXS45Ul9uJ0QqWipcWUNwVjpEVWYoaiVrNkEjc1xaSmtLOSVMbytQYj1aNmskTy9x'
    'TSdOLkxSa3EzQCc/dU4zX2kla2ArSSdvZGQvSURyQEZjNHBXLi1QNkYnSC5nW1hINiVgU1pdaUA3'
    'OyNpOXJtWiVpWWctOmUwW21eSE86QTxSMWthIicudT9eRCw7X3E3USxKaSdbRW8zUWs1KE5BKCJX'
    'MXEncW1vIyMyLkE3NlVSZy1aQkE8SDRbT2M4O0ZyRyhGcGo6O0RtJDsuPCsyPyRlZSZnckAjdGki'
    'NCNEVzUvTHVaSGUjUHAuNkEmXyZaQkE+RF0kOF1HV2onY01SZzlJJDBaWVRDazcucnBFbSUnYWBV'
    'alstSytxM1QvRXEkW05GNlwtWU5dInBTWmZLUFUucT5UWVxsMUIkTys1ZlNPKkZyUDgtdGUvOXJa'
    'dCgpayRHciQ+W3VXUFVdR2lAYkhHO0Q/MUhlZj5ZcWpkKTFNVT9ONy5VbFwyWDhbaGk5IkZHMzw5'
    'ckE/YUknbl5VKzlkQzZCXGZAKjwsUGkxLz1JV1I1bWpTOmVwNlVGU3AsVyU0YztXP28mK2dYTk1t'
    'XjwmJUViaGM/PVhASTw0QGM5Xm4jWkZBYSIzOFhyQ15pVWVXWGFSTklzUFthZiQ/c1BtJ2dTbjQr'
    'WGU4QixMPlYzSi9CajZYV15UXzlFcDY8Jm1kcFk1VGxGO2VuWVJHNWNCbWUqNFhALyY5Y0VFLTkp'
    'blFeRGVyRm9sTyQ0KThaXkFTPUdPbjVlViFUK0pUXF1OSyw1PmU8bVcxUUVFZjhIMWpCNC9wIyVW'
    'TkJlRzZiSDMzRVpcPy9wb1s3anUhMC1jKzVWJXBAL0EpOjhOKXFDQm5lXFhCZjhUUkhTLkFCX2Fl'
    'IisxK1d1I3BQUDIzZ2VpQ1VqLlMkXC1mS3UrKUgjP1Zla2JPQit0PCJfajhjMj9HTz5OZSNVI0BM'
    'aT1mJHBFajBaXHVMXF1ubzlSNFdcS0wsVVdZUCQkLVEoJylZOjZAWmRIITorKyVKSl1MNUs1PjUv'
    'Z1VzNUgzRHBdJUdkQl5kTSdedGxPWypMSDluMSNnITorKU9JPl1IVks1PjRcZ1VzTVAzRSYlSkdk'
    'Ql5kTS5MZ1hJXVJbXVZmZDRhbGBUZUBQOCtNM1RmJGNbWm47bnRoLFEoQFpVLS11QUhyXUtjRmxU'
    'XyVMQi1uS25eV21hOWkuKU9FXjA/Vy1WaHBALDVzY2lGW2VnWWczNGdsJlc1aW8vKE8+VClVM1xx'
    'X3Q4NisscCZnS21uZjNyQiF1b10nR3VkREg+QnVsZzI1ajVNIUVqZGhHdVgnSDZnci9saltJTD1S'
    'QGBwPiVJPV0nQ2tYUmhbaiEzaG90RmYiMCxUPlp0MjklNCwsWEAjdGkiNCNEbl4hUzFOZkQ2bmc3'
    'V3AvWEhlbk9HKmNbT2I4LjVXX0A9akEtLz4nRlo0bWZEYCxbSmI1QlMzZD1eOjBZMlFSU0knW1Ru'
    'MjFFJDNvMVo8VVw5bzwpMlNULjVXYGs9V3MnSzNhS05eRC1jOTVeJD4sWisiaTlxLmk7ZWFsaShp'
    'NlEsPmBLX287K1dLaUdUUF0lJnVMQjVhS0k9JDo8cEUlc0lYXyZzXCNwUDQqbyo5S2c3L3F1OzhV'
    'cmtSQypWU0dRSE9LZSclaTtIJjxaQ2dROFxsTz1bLzBhWypcJlEvb15xKk9HZEJgOj5VLyc9SC1i'
    'L0prWUVILF5xKldiV15XLUIqWnVEKkdNWURcJWVITC9MWi1KYldIKnU/XClmYmNEa1hxckI2TUZF'
    'KG5SZzpPOkE8Um1pPG01R3VFTTpuN0lBUlxPTi9eTWEmMko0I0BHNFA6LCtKKy0yPUQqdT43bjVX'
    'NiI7Y289dTdvQWlGJlU8Z283NkEmWzpGSVJ1PVphXDsibi85JFE9S05gJzhBUURmPidGWCIuWWk6'
    'SUJPSChrNkU0OkMtaS9uPT4yNWZrVzE2UVlVc1FwSEEtSVUlR2VMVVNqJXFiSz9fbCZhbjdJQVJc'
    'T08wUjZHcUpca1YpXT4/c1RrQmU9b0MqIVFeI0gqPydeVUBAZS9PKHVEP1UuYkMxQ0AlRl9Zbzs4'
    'RDZxKzc5MmlRMkUyZyFJO3RqJXFiW1A8b0FoUmhcaV8pWDE5MSU7MFVRWU5eL1snSC5nW1hDLiwh'
    'WFpKP0xRLD5eNTFiY1JGK11ZXC1EUlt1M3AobUxuOjFtQHJKYDRdWCMyLkE3NmZWISdiYGI/cV9q'
    'X0I9alZtQVkkT3BgZVRzKl4mYzRoMDZTdWM9XTlqNWpgKU1jSlc0QVE6biR1XTA7USMhMi0vTXMh'
    'Mkt0YUc1XFBtMExHZDtvZTJSTW8hMylnQ1pVc1FwSEFxYTNwN1VGNXFLbmNxQ0dfdCRvXGszOz0k'
    'cjluWGFHLzdkKU1jSURTZU4oW2hRMmVnZjE8QVJCSzE+SEk4LVc/VjltJElBLUlVJUJcZkElVyNY'
    'cWtUbjIxSSRFOCdqSCouay1DTjVBQVBbMFAlNmhyUk9KdVVxIVxtdHRXNCRTUzlSSUUtXiEzRUx1'
    'QVdSRS5LRikwIj9zVE5gciprUiZzLXM0cmNNKmdxTi1DSmckSk08N3Bhc2RMYHVONCQ+NGZJUVBB'
    'WihfPy42cVJCXFpYMm0kZSsuZmVPU1ctYCFlcDJKS1BRLlF0cltEaychR2g/UUJZRVROWTwiMD85'
    'W0w3XXRcR1gyPjJaWGsyaikyKiozY21GYGw+R19BZCJ0dUUvMGc7cSpESHNhN29EbjFxU2AvYlMk'
    'YTFNIkZnZk1XKEQ7bjYkSk06MURsYE8tImFJZlNNPUhgQ2RaI2QvODRoY0xTZls3Qz8rbTJDUWdG'
    'LEQlTmMmLitJZmEuXXQmYS86Kzw6OWwiLTZCI1ctblxdT2xVN20qNTJCZ2Q+TUBZTF8yST0vWj5W'
    'Y21sTU05ZVdoIW4mSSsmJlNVbUJILEJcK2ZVTTE7cGtjaks/WXBuaTZENTwuNmBdJiolREJ1Sl8+'
    'cUpxNyVpNU5rIlViZT91TjI0aUBrVylIbzY9SCVZXFlaJUJYVz4ydFxxPU0/YVI9JlY0TylTJHNz'
    'cFc7KmRiQ0s1LCdGZkFKY0FcKHFQWkNzLW9vPF8sdV9SYHU3UnVSYjJIVyYjYkdnPHVpX29jTz1Y'
    'QGxQTS5hdShHTzo/TDAlWlJMTTN1JDktV1pIN01UXDc2RkZvUlpQbidKOjtja1AnLV9wS3NfXWtX'
    'VzxYWkpCKzwmVEdRcTYyYjwsMSxbYm8sXDhLcT9OMl9jUTFxIiRMPywpQldPbyVXXi9QTW1hLzFm'
    'OFpBcEhyclluVCwxLFtibzlQKDdJM20pckdpOkZjbGRBa0UuYXUoR086QTxSMiFoaGEkTEA3YWIz'
    'NFhIWlxRYic9UClhOjVHREVQKTIzMj4+I2hHSGVLPmY3R0ElZ0Y7Y29BMClCQkUncDk4aGU2Nmsh'
    'U0pfcXVaWDVxKis4IytGLT1CQ3AoOyQ2Rj4nSC5nYyw2RF5GMS9EPWFVRWV1LUoqOWxfWEt1JTZK'
    'MD9AQEs1PjVXKzBKR05CJnUkZEhAMzVyY3IsLSFrdVJcI0s+ImgwP0ZAWDI/T2FLIydXT0dXWy1l'
    'SCtXKkhcIiomUD80PDlfOzM9UCdXOkxVTSpsIyZebGQzYVphXl9bVjw3T0EvcFdyYyFTNjIoUXVi'
    'ZHMkMkxVIVFcXyVkP2EzSGJuUURJai0kYVhSanU+PXU3XHMuQktTb2hFakxdRi9IVSpANjNKcGxz'
    'XUxvamg1Jj9ZLnJNIkcwNS5lPmFiIltLNT41V0d1KEFEWmdvKG00ZWFTRD10N2lBY19TTiVObHJG'
    'XTZLT1oka0Q4PFdVPGdsNjY6NTBlQWJIbEhxTGksRSxCRDFFaj9mUVZZY18sUyVXMSVhMj5FLUkz'
    'YV0hNDFkW2xTQTQsWW0lQUBnZWImYnIlQy9MYlE/cykkXjRHVUBfbyxkW2NfRSkmay5KY0BzVHFT'
    'XW4xNCtyMiRiYWNINjNHLElhSVYjJWp0LXQjP3VOM19pJWtgK0knb2RkL0lEckBGZDpXYS4tUDZG'
    'J0guZ2M2Z2kvPjEvRD1hVUVldS1JcWgjRT1EK1xWRStRVV4lQzJbTUxQQVg5QiZ1JGRIQSJhOVpy'
    'RVZhXSUnK2xmVU0yQjNgVDtGWCZYZ0ItcmJoOEJcZkAqPDNCQUwlW25INCZJTCtUa0UnU2pjajlA'
    'LXFPMS5vZihqJiRUYi5YXis8K0wuQkYnbD08aD1yQD0sVCtuIy9lI2FqWjBcalMjPkxNQEBhU1sm'
    'Szc/PiVDL1JrXE8vYF8+ZE51QDEmWmFPI19lU2VGJUNMWkJFV1snSTgtVUhsWzYrQigyWEJmS2xy'
    'WzY+OkFdSG1NJFFWVkYwZHEqZWpkOTY2ay1QXlZqbks8RVNFO3F1cmMrJElwNzw+J0ZXY1Eic0Vs'
    'SztNLlBLTC8+bjNNYkNcMWtORU9eOD1oX0ZoViRIQlM4XTBhRy83ZClGRVBTUTA0aCkmSzdAaTtM'
    'KzpEPDNwaStMbS4nI2ZPYyxXLz4lWmZeYXVCQlA5YC1CcSs6NSdLWUs1QkAlQyJBSy5WcFlHbipl'
    'QzwuYjdlcSpFRydBZCM0LDtrXVtdNEVQOUBEOjNEJCg9YSdROCRdLTFYaE8jSU5GQ1lpbmYyPnU8'
    'Y3RyYyRMO01yTm5acUwkSk08J0RRRUQ/Q1Y0WmBgKF5YYEJlSV9PSEBVLWo6OClhal9yWlc9a088'
    'JW5PTztvXWNtRmBsPlA2cHNuPW8uXGoiaG9vMCRlTmBKOT9LPlRsXT1MTU8mZDhbWXRWTWcpQ0NR'
    'VWJRZWcoOVMpN1FUanBSNlYqWmhGLkFpPVxqOGo1S3JaIzRwNis3Rl51N2wkK0lmYS5ddCh1YmY7'
    'R2p1VmpIQV4kRTYuQ0ZJVylTWVcoMFBFIkBZRl4wNEhuNkdYY2A+My5aR2wiLjxhcj45RlJPTk1X'
    'OEc/PWhKSFpULGQ1PmJQR1dzdXVJLjJaU19YNTJuSV4hKVZVITVqZDI7TCZjOjo1YWQ1RGx1PWAw'
    'RkksbjIoWnVaIzIuP0FbczpuKkYvRjJ0RSs9VCRTalUqRDY2YidPbFlsSGFTVXBwXDlfWDktMlJN'
    'VWBoVV1tKi41M0kyPTxXc21ZW1h1KkY3N0pbaWlyalZFX1RdNkhjJHNGbydSTTo8SyNOW1hOTko9'
    'KV84OHVsYTRbSU8wcmxzMWlrLkpiRz45LW1MPWViQlxmQGoyJHQmS2pqRjxsJ2o/MzNISGJCMFs7'
    'UFJtS2RzMXFlSzBBSi4yWlNfbE9GQXRFbDYlQGQuQFNRO0o2QmZrcyRhIVouPGNgayMtblVePWtu'
    'ZU9GZmJWWy1sO2ZrNj9RXTBnLmpVJ08kKjJxR2w1a0NMLSdbOXJBP2FDYylWV2gmP1JPZCgyUzNX'
    'OCtXSiomS2YwLCkpPWpTU2ZNSD1SLmtAZSNDMkY/YGJKLjhBUUVRKXBJL0RVJD80PydILmcrWE8l'
    'VF1kcmJDcVhrUHU6STJhVWwwTy5gKmImYTR1TFBHYUtqWitzJHAycyoiVDoyJzEyUV0ldF0pIyot'
    'cTgjV0UvNG1cI0YuZFoyYGk2ayxIMUpsJWRcaiEzVGdAZCM6MDE8VVRFRypzSiNMW0FsRW8ocWJc'
    'VkE8VS4iO1clOlBeQ2ImYnIlI1JzWyZqWjAsQC9NciZhXSJcJCJVLyMndCt1RGosJjEoTShCRion'
    'LDxoPXJAPSxTUF4jLEJJUGpaMFxqUyM4SEZXNytoI0s8XiJPOG5tclsxa11RUS8nZWdWR0QkL0xW'
    'IixNUlNKRSwwL21XdERCLCNMYkMvWl5RalB1K1kjRiE+LWQqJXEuMWJkXWUrZE01UG1eQ0lKRXA8'
    'RilJOmZEKF5iRStCQD5HUHU0I0RWKSVQLGprZGokXD8rZE01UC1pMmkrKD9IIzhAQEcqVkYyWmci'
    'ZEM1JCNUcVNFKzBZJVNxSUQ3MysiZig5IzdcUzE6ZTJhVG1MVU0qbClMUCJPVm0iWV8pUGdicych'
    'NDVQS1A6b0hjVSQkXDc/J1dkOzxQMVMqODghS0hmLV07M2RuQ0BUZzkkPy4uTT4kTFBATS1ASEJO'
    'NW9hSU5bJEU2LkNGSS5cTk9BIjNXRksyOmc9J0tGZVU8bGBkM0xGJytKbVJTM1RuMjFCJEU2Ly5r'
    'cGtzPEZGXiJMOkpJYUUzYy1fXzFFLj9oLissVW42XlsjP25mMEpMNkEjdE1HbjAoPiRdUTlxWS03'
    'KGg7NV5UdSZLN0hRTF8/Z08xa11RUS8nZ04xLDtfcTdRMDQ2SFwnUEQkbDIkaUQnbTlAZipNR2Ir'
    'TCsoSFw2VVI3J1lqcmJqXWlybzcxYDE/Ri8nam9rZ0g4My5NRTYwbk05bUBLNl42I0ZtYSlOQjNO'
    'UD41OWBINGw4ME84XU9SQlIoI11mMitSU0ZUP3FKJzRkZyhZSF8zWDprbDpzZERALjVXYTY9PFdz'
    'bSY+Vy9TMWtKc24hbXUraVc3LGBYNiJsQDMrXEstMGNrKic3WD82X15PM2YjJzwxWklnYnNFWXJW'
    'PF9uWDxSZzk2MjF1L18obnNGYSVMbGo4X29kJklvRVluKDhFRGtjNyFYZ2EnOmU8UFQzZSxMRCQi'
    'aVQwQDAvSDhKNzlZciQ2SCJfVl5eXFc3KilZXzMpWzg0TkhbZEZcWSE4Y111aDlRcy0qIVFdWFE8'
    'VUppbkQxYFRpNTMzOS4lV1g+ZHRSYGZjQipgMiRxMV0xTGdiPDhlUkMhMVZSKmcwUHQuPy9MVGVU'
    'Iy9GP2hdREgoZGNZVVQmXUhuM1teS1drSzhRcDorYWZOYksoZllkQWBMMilXUzlrXzNOdDpoJ14z'
    'VDdhYlA1ajdJal8tXzk1WmIoal8sL15ORCFhPDYsX1dMLVIlbzxyRG1iNCdUQicyTD85VXEmVi5r'
    'cGJuZkZGW2AuSDtTPC5nImQjVVNlTVQxOSQ+PlEuc3U7YU1FNjAzKSc1bEBiJl4rX1JHUzdbRlN1'
    'Rjw6dDRhMTI3NGhIJHJOYSFEWSc8J0FrViFBaVA+bCM0R1MkNiJbSi9CZixzSnE3QGgwSDVSYGEr'
    'K1xLLHFEO05YXyolOzpNNEJOYmxrRSwsPTgtajgjcUBhQDZXNytoY2RdP2k0JyE2L0MydFxxPU0/'
    'YVAjPF8yPTRVcTgzKEptPm5kPGhKJW8tbnJrXUY7Z2xBQ1luMmpeISojSyIyZmErO0wmYkpcclol'
    'MDQjRXJgYmFMaiNfb3RUSitcTGhPNCNEVik6K09YVlI8TkgzVjlpVyIzTllFIVtWa1tuRiI2Skll'
    'W2VyNi41VmBdOip1PSRUVTRAJyssNnFKKSozSFVVWCFUODNPRXB1Vl5ZU0JWbSNlOjFlPkZvLSFH'
    'TSsjaCw7RVNxRW4xQlRQUDFjZEFWVGtLcWRzVCZycD5TXEVmRUJUUmZoOSFuJDVkLHRVI1NNPDhv'
    'SytxNC9OXSsiJUxVSmksUlxqIlBTW0tHa1I+anMvUFxBbUgrXFpyXEduLThhKDZMcDVjZEFWVGtL'
    'cWRzU3UsRlRTXEE4cEJUUmZoYXU1WW1cakZyalg9NXRbNEJOYmxrQGhJIm5tZWZWNEFEYDIzZG5F'
    'MCgoQ1RbN0BmWGFBTFFiUk5ZRUJLKmlxJzAoajBUKXIzPWdpVClRSUsnSC5mYEVqdU44RHIuMHJe'
    'TWJvXiMpOjFNMi9ydF9bT2o+bWVucSJVZSRgMWdAKDxJbkZOaENHTElVJEVSNi0qLEwnSzQ7U0w6'
    'IWgrOF4kN2VuJjE+S1s/QGBpRjk9JUpvcEBxbz03KkByWTFuTklDTCs4WD4iYWYwUTZiQ25bXnM/'
    'WHBJQlNbXWNRSCVBW0QwKTZOZVInanJXYmo8cnVhTzJkKUE+aXNcZi5iQUEiMTJnaG06bF1DbkBA'
    'NG4qMiNgSGJyU1wqZlNsV0NWVlQ0SGIkRTgnKkZLPU46XnNdQmgjc2dTW1k/JGVbOEFZJ1c+J0pn'
    'Oj9wMVc0JThGI0E8UV1bNFopOlUpZEZOMCstM1dHX149a2ovLDZkLFJkY3UmNSc0PHUqRV9UNmJP'
    'blZCaTxOX0pQWypUKDBtSjw3X1BbalQqO189RlApVG88NEEqSGg6YkZDIjwwS2BHXDxOX0pQW2E1'
    'OjJtSjw3X1BbalQqKWtmUClgaDFZaTZVUUNzWyl0Nl80W09jODtXU2dCPnE+cDI9Uk9OST9wMVc0'
    'OXRVZktJPEAoVClUbzw0QSpIaDpRY0c5SCpmSWByKCgoTjVmW0Q+JUJeN1JbXy5UIUJxZT9TNjVt'
    'a1coZENNXDRKRyQ6bDIpTiFNZTBtL0BAbycuMVVUTjk1OXJILj1JQzA8UjVta1coVilAXGYmN0Ba'
    'J0VYZl4vLDtfcTc8Tl9KUFpIcmsubUo8OEhRIjBdKzkuYTxdKVRvPDRBKkhoOmI/UUpRMEtgR1w8'
    'Tlw+ZmprLGRCW1dNSklrdTlbT1hiTDZnaHBfP1Y+J0ZXY1liIm4rTDhJSVNPQCNzUCxNZCsuJlFt'
    'Y1syNFo1O3A9MVdaSytzOC9VTk0/SCE6Kz9hQ004JEkidD9AajI6Q2stKU0rX2o/ZGt1cENnWDpo'
    'MWU+SVgxS28hOSNkQm4kXFY/dF9NYFFPckY2bVYrQ1VBNVJWcy4vQFtdX1MkKVBnZD09XicsbCk/'
    'UiI8PE5fMkMrK3NoSVVya1JDaCVnb1tWLVJIV1dIKWZeRDYkKnA2OjNkLEExU2AuSEM2aksjKTNA'
    'NVVya1IzWCw7VSM/dG5lLlJTSyxYM3QhUEUlOG5uWk43SyFmIWomOyJZK2IobClQaUhFZjE8QVJC'
    'RVhXRUk4LVdeWiRqJDdjbGBNUGNZMi4uK2kmRC1qVmpSL1RnOSRiRW04a1ooWExpWGAyLFZqKE88'
    'MEw6VyI2Xk1gY0tFLFM5VkQ4UlU4Kl5HLGFLW1M4NihsMFFWZ1EicywiKi4uO0lRRFJwV2IicyYz'
    'VWI7bHNYVUpBTzo4Vjs6PG4xX1xLaUtCXVI6QzA7Pl9DJTU8UT5JUTM0OkVmRUkxNVspNzI2U0Qs'
    'bldBIVFPb1FHYWZta1kkPyRvaTdPTltbbCEzIVhMRDY1blJXY1M9LTlqRkJQRUZbV1d1VDAjMy1C'
    'VzFGJFY6Pl1ZNUxmVUlyMjIhJ0BrW29UWyVBUnBuJXBKcUpNTkhuYTlFK005ZjR1JEB1OFhfMF1T'
    'PVhjZmMiQzdsV3UjcFBQMjNnZWlDVWxcWmE6XUZdPj1nKVZdPUhoUVhOJ0BGL1IvPGRWXC5ASllj'
    'WWVfKisjbXFlQWhXJDNmSjlCVS4+YlZPLHUhcExCUmRjZVBMP05IQnBaNVtcPFgrN0tzKmZZNicp'
    'JSQ2KTJCPS1CMGhVJ0ZjLjFAb1NWZT5Fc1xPTzBaK3NGMXRsVkJMIUVibylXK1RqLzFJbiI1L2pz'
    'YiJATlpIUm4rQG1ZVVkqJi5cTzlkRSlxSEpBW1ZrQ2daS0M8W1QpNkoxUlwrTU0jJDRJQDdsJ1hW'
    'NVkhSyliR2c8dWlVS1lPOS41V2EmaS1RRG03YyhnRzZcK2o8YXUsRS9cIypJPSVIYztpKVRVXV5b'
    'XGA7KmsjQEIuWCooaEs7ZVJUImhNZTl1NXFmUy01N0lTKlpgaSZlLSMmT3JwSl1RU09SQXIjSVBO'
    'W0UrOTtqUDYsMTgiIitkPT1VS1BDdUY0Lz1nX3FaMUJUTyhsYWtkMVdBV1xjci5BdUYmXjU4ZjJQ'
    'NlptNT1wQVhUXFZUMDxBKkJTR1Y1biprKXJmIWRSX1pdO21TU01iXTpkWTQ1bC5HPzdvXSZlQ08w'
    'dDM1RzNucFEpP09tViksWzQ3bWksTlA1MEpRcyFhJiU3azUvQTQ0PV1UPFE7ZCkkK28tUD0pP09t'
    'ViksWzViJC5kaW1mPyFPNC0sNS1QV2FrWFsnZ0ViaW9ONGtmQSZpSS1lLkAvcmNbRGlGKkl1L1lD'
    'bCcndD80J2UrYTYlVTxJbHNhcVooK180Tm5sJDxSUi5KS2ZOVnFPIjVtbj02aylnQyJnIk0wO1tF'
    'Qm1XMkBVVThmXiJaXExNdUZmOk5YVEM6S0AhKkJXVDE4UGlgI1dhaUE/cmNoRGtqOFokO14jXVUw'
    'NExTKD0zcWNUVz1vdGpqVy5GMlRoImpuaHFuOlVuUy9TI3VVYzJDTmEtRVRTbCk9WSVwbDRIOldB'
    'MVFwRlY2UGNdYkldXE5uYjdzYSQiRj1gYUNlSSw+ZVFsO1pTZTRxcjE1LWQ8VjBEOyQ1OT8hSzY5'
    'Nm9QVVNIJmJRN1BFXzcsakcuWDBpL18kRiRZWjkxOyExcj5EVy5GMzBKPGFBaUdQSylpYERgYGo9'
    'QUopXmAsOXRiJnFJJVdMYWs4VW1eST8wRjJjJCVNYXNfPjAjNzFIPUgjanVQTkEjXUpGQTUsWzEw'
    'UkZwUDo6VjleXmZwJmtlTXEyJEIiRUBiSXRHMjMrVVdHYTs6PiEzb2AxMiREayY0ZWJPWFBQX2h1'
    'YDAwNU07JW1dQyRhQDtqKDhJPD5iOi1fSWZQUTNZIWNbaGhVL0BtdUVyWWohPUQuRjFDJ1lyaWAz'
    'Uz9CQylnKThuMTpKWiFGaU9XTjBbOm0wIzFMYnJyQDs0Lm8/RHRxSERhSD4lNjAoNCNOJXMrKmEp'
    'TVxjQXVTQzlJXERdZ2wmJEA8MkRBUTw6RlRXJC1dQCckRD4+WUJdP0guUSkrMDtuO3UhK0ZXZHJx'
    'XCFZaiJrWTxpKnJtQ3JZUGRhOG5fcz9YQzhfTkVdZDRHaFJOQlgkPyVDUzBLLE9mMW9jP3UsTDw5'
    'REs+QFBfRmJidG4sZS00TF0mclRVXU82KVRZNWpXWkgpP09tTmhQKy9QQDwyREFRPDlrZEovU0pb'
    'L1s5LWUzJlFfcCsqYSlNXGNCImlfaSxZMSMkbGJdVUFiMl8xblIvRjleP0o+R0E8IS0lZD0lMkk7'
    'LGtFKFgiNzUhOGU3N0MpXnRqbWgmUTdSLCNIaS0nZyhtQydZcmlgM05mbUMpZyk4bjE6SlohRmlN'
    'QkMnX1cqSFVPLDstTU1Gc00nXj50KT9OR11aInVDaSlGcjlmNE5mMFpKQ25eaCk/T21OKmA4Ymdh'
    'bzBzdUBgZTJiQkYkS0Yia19aRU1jITMwamNoQV9tJ10uZyFQIUdvZDlXX1tFcllqIT1ELkZLZS49'
    'bFtNLk9UbGUyWDFPaSlyaD4hbFN1RykvWiZPPyVCJk9yVzJMRkdHNTs9b3NNRm9bRFtCSEY5L2hh'
    'MWNOb01RO2I/cFRkM3M7TCZiSmw3b1pIckVyWWohPUwoJmYrYjgmVGJEK2lQRUNCY0BaXmZHSUx0'
    'dCtqK1RQVTQmUU5TNWdxVU5LUTdOUF0jVSRPbkg2NCdeLys8SDI3RCtdS25HbVJeRD8nTGZMaEQ6'
    'XipZNlBZJkZlUyxPL3NFLnMyImlQWWVrKzJva3BYXjkxdUAxP25NRVwqLTNtQGB0UG8iTUpgLjQs'
    'IkdTSlwlbS5iRiNeST8uQkEzKWpDaUNlb29ANiI1WiJkKkdnOCZcK0xXMF9uXTkqV24xRWldWCs8'
    'Jkc/KmJHb2ZUVyk8LS5ZLjUoQj9iR2xHY2JsXEgmblpOUTQ0Q1JMNmI0WlkiQD9iak1INWg+IVBf'
    'ZEZvNiEqTFI6Y1RQIWs1Pkw/XStmWiM4KSpfY2dxSmxULidFK1tHRVg8J0opYkwsI1ZsUSplRkAt'
    'I1lGZExzX1VwKydNPChHOXE1XDlgKFVNdSFcSk5VcWMxRTBkdXRYYW5uNmJEK2lWcVtpRTJePm5k'
    'NyRaTDpUYmlmJTNdZ20xcG9LI2RTVmxMb2c+NjFdTFE0OWAqK0BRMFxUPUBZUyFoQSduMyQ4MyZt'
    'aCw1XWhXL0NyNmokLCQiZi5HZDJJK09cJkc2UV9pSVpVZ0UtQHVcK29rXjUmXj9kJGliPlI2Iz5C'
    'JT5VbT4rQGdlTlw7b2FjTkNSYjxOM1FzTCw9b2NETVxrdSJAMCRSIVZLVUI9JT1ZdSdgIlVaUFRs'
    'MWJZNEo7JDU5PyFOdDpTbVQrKThFXiduTFUnQEwoIWBEWkIpaWpcYShtUSMhUSpaSkpUZU1rXSY4'
    'RkpEN29aSlhiNUdFaUlrVjpbMSg5azJcLFxHIlNKaVs6KyQ8MjBdK1slVV1iS0RpNGViUS49NzQq'
    'aU0mTWM8JDpsYlJEIm90STZJXDVFZiRhNztDMSk/Ol50IWQiUG9AO1JURjJtY0ssT2VeL1s1TjdW'
    'Iz5PO2RkJkheckIhallkbjlfRWhCVCZNR2lhQ1VQR2omc1hhbm42Q0wjXi9NYyEzMGpnPWJNJTg4'
    'RFlcOV5AbCZiUVstbk1GSUUjLFxqMjtHNCstPTVqKCU8Nz4+O201JVRBZG45X0VoQlQmTVlrTV42'
    'JXBdMDwqbjFiOjxZbzA1Y1c+UVhXcC1kWXA2RFMtbChuQV1taCZRN2ZbbGUiTEciKi46VDheSjI4'
    'Zlo7KT8lVU5STkJYZGhoYDg5YFlJRnM0ZWJPWFFmNm0pJ1FualRAIjQiQDBOXXJXND1dVWtydVk9'
    'OiMsW18ua05ZNCk4ZShoI0R1ZzteSiFHXiQyO2VOaVdwLWRZTmZnOGtsKG5BXW1yO10+V1VcLjBc'
    'MXBiLl8iOltDPFlyUStbbzRNPnJJXGBDKkkiNF5WTyU/aF1nbCYkbl1MZjQtVyd1cD42LnI2ISNu'
    'LGw3LkY1ayUkb0I0akNcZmBFc11ZNEhVTyw7WU0+MV1ub01kZmxmU2pwTF5XXF5pO3RcX2t0Ukpt'
    'cTQ0SThsKG5BXW1oJlE3XVEtNmY4XnRRSjxePnJYQj5gbF0jWjpXWz1cYFUmZUExXVNKPy9GIy5R'
    'KFBDKzZ0MWVAIVg9R3AiSGIyRkQ/Sy1KKywiZUYhYlgwSDc/WVtIXShAaWBbZ2Y8M1s3Syhkb3Vq'
    'UGY6RUc8O140Xi9LNGQzOC5vP0R0OSopM1AsSEI3PGphTzpwVy5GMzhKQ0pBXEw+L1s+VUFpIThT'
    'QmRcKEphJyEyPTc2YCRDOm5ST2VrK0Isb04iNkJbOl4jXj0kMVY0UG87VSlsJF9bVm1ZX1Y0UVZb'
    'ZUw0ZWJRLj03NCppcTpZWilfdFBKLCYvVy06aDVNIVxya1lxMmhFPV48ZG45X0VoQlQmTUdpYUNV'
    'UEdqJnNYYW5vOiVvVTVmQkdRak8ycDpINi1ZZCU4LkRYSlxNZThnKi8sKUVAOENZSEk8Xj5yWEI+'
    'X2NoJllmOUBaXmZsSlUnQEtdIWFORS88Mm9FMXJFKEZFIjRMSFRXUm91Z0tGPlNvVXBqSCRmNjxx'
    'blZPJT9oXWdsJiRuXUxmNC1XJ3VwPjYxX1RTZGgvZiw9TUtfQi9zNkw7JDU5PyFOdDkoV21sOlRJ'
    'XVNhM0phJzplZTgqQmJfbDQ2QnJrWXEyWSojWjZsKG5BXW1oJlE3XVEtNmY4XnRRSjxePnJYQj5g'
    'aVwjWjpXWz1cZFJAZUExXVNKPy9EW2gzQW5eZ2kpTjZNJk1jPCQ6cWwoQ3EtI1MrbUwuM2JOW2A7'
    'KU9PaDxFOms4TFY4YiVbQSI/IXM5USgqMT9AMixQL2NfWjBoU1hDMT5fc0FkPzQoWkUqYDhjUi8s'
    'KlBFNmspaC4iZixJTzJYRjF1Jkc2Uipqbi5lbylPT2g8RTprOExWOGIlW0EiPyFzOVEoKjE/QDIt'
    'SFxRc0xAXVRiTUdjbkUjN1tibGhzQ2dWQWMqQ2s4WXEhWXNBbGhlTjVZUS5vLj9kcEZxRDtSbE1u'
    'cHEwJmpGdUBpW2A4ZExnNUJoQzppTUhfPDpESUY+c0FmaDxcN241T09aQDtCV2pSR0ZyQU5oa2th'
    'ZnBLPEkpSSJjMTIzci02TjdTSTMoN11rMC1AQXJzPC1ANlJELmFcI2ZnXy1WSG9DMCE4N1lNXUtX'
    'MkUuNS5jSSYwaV4nMWlURmxVXT1AKV4iWFNYbE8ycD1hamBEdWteK08/OjVnKm5LNk5wYm4wcmNI'
    'NEopJEdIXEVCKGIqKytDKW4mR2YyXjcmKy1lIU5wJE5RR29RTGdlMVkucD0yKkhDPmpyIUY/K21d'
    'cTcvWys1ajhBKkJgOj5mPG4sKWcrMXFpPi9yPVNdKWhmM3FnImMxdHExQz9Ca29jRExcZSpCLUBU'
    'ISFOOWJQVCI6KyYtWjchS08qI3BrZTxpL2pTYl1fMTteUFkyMURnMjguLFxTO0BIO1FNNWZTNSs6'
    'PkstNixsSW4tXiRAPyVDUmUsL1hHJz03NmFHUmJtJTxZL0NRPWJQVCI6KyYtWjgtJyJvR3BzIVNk'
    'LVc4VD09NTBDW0hCMmFpb188USJcYz9BZ0FlXWNYSEw3RVVJN01QYWU3YC9CPkc/akhHSTdta1g3'
    'clIpUG8+V0MlOitLX0dySkMiOmRcTj1pUCJxJWVhdXMoa2xTZUBLLEcsbCMkbGJeVUFiMl8xZTdP'
    'USkjUm5dNjRKJjxMQTBEMzw3Pj1gViRkakhoNFZhZ0ZCQG9DPEdJb1Y1SjVVPi8uWko4XmR1MDRE'
    'Im90SU5pNCVFZWwnJ1paLmZAcSonZWBAKmA4YTxtaTEkYzM2UXBtIztCJlo0bzkhYFtvOz1DcVhJ'
    'OWdRO2I/cG5cc0MoOnVfUGVYN3FFIjIsKkVbaEo1b1E3bipfOztRbWJnXVtuNCJSTkJYJD8lQ1Mw'
    'SyxQIUE/K2g9YzdLITNDU246WEZecExjQ2dbaWhiVkdsTjJxTE45PlYkZGpIOWtINTkpS1oia01Z'
    'W1JuZSF1NzVSJFJKcEhUbW5URWJaUms1T141JUY5LGpbIl9vI0JHUCoiU1YyIStqW1NFUCRWQ3Fz'
    'KCsmLVo4Mjw3RXNuWUleQTFIU0hkaGBxdUNHUCoiU1Yxc0tTU00hMiwnKVgkVWsraFtAUVckOSRv'
    'bSMzLjIrJjAmV1NxLSJLQzgiZlUuUGxdaVRVRFNGb0UhUm8xP0YwaGYyRnNXVCFsTC9qUGFSKGpF'
    'aGAlQ3VPRjc9PkplQSI5S0tsMEJpUTQ7J084IVsrTi1aKDA1R0xmSj1GSTElcHIhZCMxTSV0TFIn'
    'LVlkJmMmY2hPTm9VXjwlR1ViUVRiOi1fSWZUIjNeI0xIYmk3b1pIckVrZWA/VC46dV5KZl5WP1xj'
    'Qlg7R1ZVYzU5cFNfaCE1PXBzR0k3bWtYN3FFIjIsKkVbaFNgP1kjO20hIVVhRFprQ2VmczdsM0Vw'
    'QlBWLDVmZWosMnNrY1diZVdtaWA1SXM7VyY9ZTZLZ1RuXixZX2pibStXcC1kWWRLUEhfLUUobmFo'
    'OjZrMTdcdGpdclBQK0xUJmczVUU8JTRAblsuN3FDKWcpOG4xOkpaIUZpT1dOMFs6bS9qTks4cnJA'
    'OzQubz9EdG5nXSU1OCg2M2ZOP2RdblQmbDFoNWpYNj8sU0VAZG9jP3UsTDw5RDNSczwqSFRaLiJr'
    'ZUFUZldHLT8vVV4rKSFYUTtiP3BuSzw4TV8+PWpbY2lyVl9sNXAhSl1zJUEjSUlaOm4mbys/UTBZ'
    'RTVpVVJFN0kuOiVKViVDSzc7aDo2aj9QbzsiRCVyXkdWYjs1bkdlNS1yaEdTPGtCMipJNyhcY0Ii'
    'aUk4UXNUQz0hLkouZEEsM0p1OlVCMikkVmNfWThGN111UipsNy9hcC1TQy5Sc2gmXjIjI1c6ZklG'
    'Oz1IWko+YDJnQzEoNE9MJSJoLkg/OTFCXVZuJGBNcmcwVUpGQCshPyM+NV5sOTFrNiU/cFtFMnQ8'
    'LW82JmJzYFdKUk1eUm9BQCdxTE45PlYkZGpIMixOPDVcdVlSXS5RJ29mKzVYcTdRM1Q4V0AmLC1A'
    'MkI1Sk8sTyxOKmpjaEFfbG8lK2ciNmNvRSxIQjZJXFVTaTs6S2E4LCVBQU5mITVrOk4xOTBURFND'
    'LlJzaCVsci8hOFoxUE1zYTFIUFBeK29uTj4iUFRaLiJrZUFUZ2pnU28wXHJQNWIwZEtQSF8yRGEm'
    'UiVDdU9GN0shPkhDJG5AdTlac0wrNFdkWkUwO2xmJW9nOWExM01kKXA5Jl4iaConZWBAKmA4Ymdh'
    'bzAsSEdmb1RNYFc7JUpgNydJc1dHdD8pXnBCUVoiYzF0cVcsVmduZVUnXUwpQ0cxaERyTjRoSyxP'
    'dEs7QTdDTltiJVtwcW4wKnJETGxmZkM7MTRtUyRhMj4zPilEbXFsZSo7SWRmIUEhI05FZVtFNSFN'
    'UVI4PG0hJXUmPW4jP28maC1kUkdCNUdKdERFNC1tXicxNHJhNVArPlY1dFRAUCwjRkEtXzszQ2Ve'
    'PSdNOyN1LygkbDomU3FeOCE+LFYtQSlcKkVoUVxINlBnYyJjYGZWK1hrSyFvLlZPTTRlSlIkTjt1'
    'UkdmRFgjKmFJYz4uZWplJ1JhbUJSSzdYZ0dqKiloP0NENSQ8IjtnIV5HTFpybl8sRChSIThrZENl'
    'TUZfN2kqM0YjPFkqSWFfR3IuR0IvaG5UUnM7WGxcY0I0UFc7XiZlKEdHSjQ/Z1xeX0dRRz0jRGMp'
    'PmUhVmpcMWQwNT9mRDdWNT8yPVwlXnBacWc3cUxTK0Y0UWxqYkRPaFhjSj8vRiNZKnJcW0MlY1pB'
    'QSVGMDUyPVwnNEY5M0ZaNU9dPzwkIWkpNkQxVmlrRTprOExZTlxjUWsiSVZJRkI6X0JpYj88bDlL'
    'OGJxaSJuIV9cY0F1U1RBZyU0bDkxa0VlKVNXImtsUkM6NW1STGUtRCEtTjo1TDRcI0NjOTVmbmdF'
    'MTxubFBVb2NETVxsMShrWEY5MFxYYmlmJSknMk9rKG4jM2ReKVUvWSU5QFViYWcnNSRlcFNiXWgp'
    'TkEqWlVeTSxrbXExZiFDOF9NWkhQOTFFMipGdThcY0IiaT9xKk1eNW84SFs7PyRXQFJObTs5JSI5'
    'cj9Ubl4sWVtsPGhmPDc+PWBWJGRqSGg0VEsmPmVOWCxXRjlpSW03Zl1TR3Utai5XSlJNXisvZCpq'
    'b2BOTkQ4ZiZVbkhVJiNAXDlhNDc7TTRdUW1LL3A/NW4qamotRCdvOE5jMWk4JmJZMTwqJVwiMCFU'
    'TyVyaGs1XSg+ZU5YLFdGOWlJbTdmXVNIIjgxTlNtNmVpZlVXcE5lLjRbYi46JUpWWGIuTW5FOnIo'
    'XjxpS01KczZXTkNjZ2hPcCYzcyNEISNyUUxHWjwuJTNNZClwXTFsbG9LYzUlNkRBRGdUSj5ZQ0Ay'
    'KSppJGQkImpRR0hfJGs8Nz4+O1YkaUFsVHJ0aT9tSFFqLzhlJDhvNCdkQzc5KSNLPVNtMjkwJ14h'
    'SDJSTkJYJD8lRGlqKFVYXWk9NzZgJENBOkc1a1E5Z2hjI2EtXWo5ImkqbDk/PlRvX2RKKkY5MXMh'
    'Y0lGaF8/K2lhLVdTdWBYVltKVSQiUSdzQFA3J1ZuaD0kMU4yLWZqUCRdcm5YWzEuIlRtcjtdPldT'
    'b1RwPyVCJCVHNlJYIiFqR3IvR1o8L1BzLy02RGI4Imk9Z2QySV0hNFJqXiZvYUMwJTg/TiJaPmI4'
    'Y0dpRlM+V1JNYjlWZlZySydnP1tGXnQhZCJQbzsiRGhxbTZrUUtNJyUmU2U2UEUtbSg9N08+YWlF'
    'XzcuYEdKZ2ZBIy5MWi1MYWs4VW1fP0hNWFhqdXQjVSZmTFs6KyxrKilTcmkvPm1SakBeY1BWI2Yr'
    'dTs3JFNaO3BZWGliPGdJQWY5ck9hPF8hVik7KTplQF06P19odURBMU0ySj8vRFtOQ2pZRHFldHFB'
    'SF41YkhMJmIsJD44bzJtYFkla0djWjJWbytFZ3U1QlpXLCwoWjg9a3JyQDs0Lm8/RHQ+bGdxPlhV'
    'VmE8aiwhUF9CL3VkciZBLW5UPm1iUUQqYDhiZ2FvL15DXCE/JkAlMDw6KFtlP3FQYERjTTJXSCM4'
    'N2RLUEYzbCYtKS9RVmA7ZV5vYUAxIVYiTTZiMFNvXCsyMEQlTDpSQW9wVT1eNWRwa0Q3JFA5cWRp'
    'YChIL3BQOjpWOV5dWy9eVEInNU40TWhRPyVDXSxnRzVlblooMDVHTHR0bVMoI1xBajdDLG4walNt'
    'cDJnUFUiUEMnWXNUXCRiMlRlMlgxT2kpcmg+IWxTc2UxTz1dbUY5LTdvb2FjU05xJzldX1xnbm9y'
    'W3NhJFIhSCoyLUopRC1kLjl1cjIlRl0mMmdvZktZV21pYDVzN1pII1o5NScvSkNOSy1MPFpdOzcv'
    'YXAtU0MuUnNoJjw0OCEqQVYkPEdJb1ZJc1paTD1XWicoNWpFOSdfcjkqKVU0MiQnOj9faHVEP0pC'
    'Iko/L0YjLlEnb2ZeVi5DYS9DMDkwOmRcTj1nXF1fXFdwLWRZZEtQSF8oOHJBVj03N2BQLmxDI2de'
    'Vi5ETD1vSlVfIkhgSzdnMkssMk5pNCVFUTtiP3BaLmlrWz5Hc2goaSlXX1QhLWpxbzskNTlRIU5F'
    'aiQ0Lzw3J2JBNyhaczAvJEEiVUhGRSFdOiw9bDkxazYlP3BbLW1yJ2AiSyxPZV5yRz9FKFNKayNK'
    'JW04I2E/JUNTMEssT2Yxb2M/dSxMPDlEJ3BVP0ZMNW4qampyak05RFYtU0FtSC8haShBKVwhSUlO'
    'KmFKQlhhRk4sUiImPj9dayRbaSpUUmQvcT5UaVA7PTQzckdDRW0+XyM/JG9IMyJHUyg2KEktZjNG'
    'c2Q4XVRlI1tLWSk3b2gzUWVXPyU5WG8zLCxlSnIxREZUJl1jYTMtTCUhbFUpa2pCJDRFLyU+Uz9s'
    'TUJdMDQnODduPGVKXiM/KlkoWmkqaCs+Ij8hNV1uOjAqSjJSXjBkQTA9QkBfNypoJ1hEWE9HJ1di'
    'Q1JeR0BsUnFxSmgwXCxfVCZrcylyb146WFJiXnBnUj9vYURsa3BfS3MiZVVvWjFFInJjQCtcQF5G'
    'cmpNOU8wIy9eOHEqMTVCYEphXTtRaHVJRT8zJS5iPjgzZlwhNTxIJUY5LGlyUyI5c1hyRz9FKHJP'
    'UDRmSWMqOj8mJVZiRz5BJEQxaTlFSiJYLz1Lb1JRWHNUUiU9WFVyRz9DMlNIKTEwJixhQGc2NUxi'
    'ZlMpQWVzPmVOWVdDTzIyQjM+MmlVNFZhKFRnWS1VLCc5OSI1cGs5KjEvalNkQ2EoLDRcSEIyYWpv'
    'W2xObDAjMVUyS0ZnRTZEZW04WFBXNUNkaSZAai1TT2U8R1sxKzBZbWgpW2oqYWU+LihaNmpqTiIu'
    'ISdbbWQ6bk5nYTFPZENga3E2ayloakQ9RyZdTzFKUHBkSjI4blxjQVohRE8rViZMOlJBR3BVPV41'
    'ZHBxTDgkUDlvWkFpLC9aRjkqRXRvYWNTTjNWIUVtaSRaRFJDOF9PMEdeaXBlMipJNyVcY0IiaSU7'
    'SDBhZVUnXUwpTj9jZT8lQjdEVyQtXUBocSFPQztyYF0xSlMtUjIkUDlwNVRTPEdPXWdsJiRfPj1G'
    'XCFSQzgvTCZiLCQ+QzRjaltvOz1DcVhORVhRO2I/cG5KXl8zOmRZNWNoQlQmTTBZLjVScmpLKnAx'
    'KGxrO0RlbThZZTJYMU9pKXJoPiFsU3NzZS5ALzJwRDEvLyU/cFoybXIqUT1Ea01nYjtMX21pOjhj'
    'KURvYE5OXDhmJlVuUyc1T1EyPFkqKC5kQSlVOk5JanRAIVg6Rm9zYVQwVmB1NlFvTjRsUSFwIStR'
    'QyldOjxoQlQmTW4uciFGIUhSQVFXSVdMVWYmKzE/aiYmTzNqY2hBX0lZRSlvTFYnVl1MYWs6W2g8'
    'ZjpibmdpT28hYEZNUElqclUmN2pVPEpNJG1VPnIsLmsoISpBViQ8R007JUFgczNWR0tpZWJiaUFp'
    'cGdaajVgPmNIXT4vdUspPV5OQTxJaTlFSm5NXnBbX2dbOS5hbnNBOjQhYlFIUi4mNmZlPDc+PjtW'
    'JGlDOG4wSCZkSEI1IiZfZSIpKCEqUGtiJENHMmMhakdyL0daPC9Qcy8tN29hOyZOOjRAMExnITA8'
    'JDYmb2FFPj5rLlMpQyNNR2hcY0BmKGshL0AhamNoQkpZQ15KciUzQVU+JlFOUzVoI0RWQz9zK1Ej'
    'JjQjTGpDcj5EYjMyMWxbPVxlMl9gLDYlNiY6Z2hVTGFrOFVtWE1sMllVbitaUlNaQFdKQiw4KDFU'
    'S11FU0MuUnNoJ1QnRCEqQVZAKU8yM2ZwSFJMVHBhZVdwJTA8OW1eYyNGbU4/ZF1uVCZsMWg1allx'
    'SGQxVTNAImFGInI1Ni47OzklOlpLPCddXllDcj5ZaTMyMWxbPVxlMl9gLD1kc1RgQTBfJlFOUzVo'
    'I0RWQz9zK1EjJjQjTGpDXystWjRFWSJyKUU1aGc/JUAwXV5BLVc3I3JVb0o0PV1WPCEkQW5YcjlT'
    'ayVpVk83JlchaSo+R0AzbHQ0ZEskWCEzbUxCUCI1VlZoQlQmTTBZLjVSbV9IK2oxWzc6OUZURVFQ'
    'JWE6bEthKVhjZytFaUNWVztwI2cvWGhxQy1NS2FdKkVcTzY6ZFk1XjQwVC85Vm9CPkEiNCkhWyhF'
    'ZG1KUipkLy5URjo3ZlcuK2UwYnBRP2pkby06SDQ3Rz4tJGgyNVFyV0JvOzo/X2lURE89SlppLFNF'
    'Mjs1SyNockp1Li1RSzpDQSFNby8hMkpjLUosTyxOKmpjaEFfbSsrRTIhUCFIOlcpQ09vcmw7VlFi'
    'T1Y8XCEpZSNLKVwvZGMmYlE3UEVfNyxqRnJSKi8hKm0zLTwyajtIczVWcGRBVS5sRUtHcytXNFBo'
    'Kkc7LCosNVBWLDVmW1FrOSZcOWApQD8pXzdRczVWcGRjZ2ojbitiOCZfZlM4LltFQ0JjQFpeZkdJ'
    'THRzc0ZnLVE3WyEwPCQ2I0plZ0RNJk1iUSQ6cyEoaF1aOVU3cGJkL3BrUnNxL2pMaEEoVDhKVz03'
    'NmAkQzcqZlZHXiFPdSpuMWBkbDQuWEptYU80akljK0Aoa2xTZUAqUmtYTlg3cUUiMiwqRmZdSzw+'
    'SyVyKUBtRlUqQTZndGpSTXJWJmA7XiRFUVAzU3JYX2dsTCxJM29pZztxIVlzZmVyUEg1QD1fY2ZK'
    'VyY3QzhyJCZgaS0vUV0hITQtXTEyPT4iQ2dELEFJQTdjViJsQkM1cCE7VTxXaGxkOFpCQ3VqNCMk'
    'WDhRPEFwRUlyOUZMTyhwO19cVD0+PmI+dWEtJ1JVOjdjImMxXDdiPV5HRG4qRGlGXjBIQEExZGs2'
    'UmFtQ0FFZ2RASWdZQj0zUUQ6Rzs+OzBobjJwVWNdUmFtRFRSMmk/YkpfdVUjISFtPT8mLG8mTj5f'
    'KEpILURxbloibEZvM1pbLVMmY2RKbTk0R0NsKGcpXXIvXyQrNi1jUHE+ND9iRyRwSSg8VW9pISYn'
    'KF1nWFI9KzJCaFwla2JZI2hQUVZAO0tsTGZHLypINGUzRV9nYjYnQjRmclsnKiIqIW9TZDhlWl00'
    'TydKI0lTO0J1ViFjI1ZTNStTR29hY04yM2U3WlhHKzdFPyEqbTMtZTgnQW9WYD5EIjBZSjBeXGNe'
    'XSszPjRhLzVQVHA/InRtXkVOUis6IkU6azoiWFFfPS5rIjokOm9NUnM+JVcnJk1QUiguZGkmQGot'
    'U09lPXJXO3AjZyZacUtDSGcmOUxPUURuWCFNby8hLiE9RUVGIjksOihYLzJESmEnLTY9NzkiMS5s'
    'QTVQbUwnZ3IuZHEhNidsJk80QClFUXUkKTpDblojWzo4NTg0O1gpRj1uM3BQOjpWKVcqUlUoSTQ7'
    'TC1jNkwxTF5SVi5nU2tkWnJrWXBvW1FAPWdkby06TWhCVCZNQmAnbjo+UUBuSmUuPW4xJVcnJidX'
    'PWJtKF82XUg5LVcndXA7WlgmWCxIQjhPSTAzYVQ9V1onKDVqQWhxcj9ULkspQm5DPHA2JHUpckIh'
    'allkby06TWhCVCZNR2lhQ1VQR2omc1YxPkJwSi45K2gsPU1LX0IwIz9COyQ1OUchTnQ5YGUxKj1e'
    'XF9rdFBNJk1hZiQ8WlFwZlBpbC82SVw1RVFJQSMyMiklMC5pOUVKIjhyWnA/YSNdJXFRc0wsJWwy'
    'b1VXM0FqLlE1QnJMQ14oTjpXNFZjbz80ZWJRLj03NCppTSZNYWYkPFpRcEdgMSNtTyhydGxWZ1Rx'
    'LVlcZz9APmVOWCxXU29GLGk8IzdoV01ybl87QVsuK14mSSVoOF5IOlo1LUA5X14vJiM4WTIxRCdl'
    'Rjdba19aX0hsRkMsQVdsMnBgUkBKbF8sO1N1bCQxLkl1Qj9oQyZtPTc6LTk+Y0hbOFElOTw+aERN'
    'VlJZZ2BqR0RsYG5fPDc+PjsqSSI0Xl5PYE5mPTc2YCRDQT45b2k8IzVzXyhQc0NGVEdgOnM3KiVi'
    'YSlYNTRyKE9xPlkraDknO29NXDdpQSpOI0o+MT06M0laQzUkU1leOUlsbzRGcT5bKUVNJk1iUUhD'
    'ViYxTGFrOltzMiwhZ1ldUUUwKEhDWTpWYWNMPSNMQEVPPkc7PiFWWkwsOjdvWkpYYjVHRWk7JDU5'
    'PyFEP1x1KWMhOyNNIyVBJkVdUmotIyxcOiI+ZVJVWzwsMCdkXlRCOikyKSldWFlnYGlcaUdyW2RX'
    'LjQ6ZlZmTy8hQCFYPDxlVSddTClSJXFXRlY2UGNdYkleIyJnSHMvQzRyTzhuMTpKWS1ZZCU4Ll9z'
    'U103JFNbb2dsSFJqMikpXVhZZ2BpXExZWEpQXSEiX2NTKXM6Vm5vT1FFI09iPGdFTiZWZi5RKFBD'
    'KzcmISNtdSVfNlFWXiVTISNwKlo3WXBtR2NaNEArNmspZ2MiaDhsPlcpRFpAcWxybmojLFteZztL'
    'bE0+ImxIIlY8LDEyPlZ0WmFcSmEnLTY9NzdgMFBvP2pdJillXjAiNEttRFdCNzxuKy9fU2FxP1A+'
    'ZUg5WzYpUiU9WShvYz91LGBbZ2RuU088b1wwKlMwPl8hX2dlITJHXzZAUUBgT00mTWJRJD81WVo7'
    'NU04X3BMQmFeJTg4RFlWIWMjVkNlZnMkb2FkWVVGTD1MRzlNWWklSEI1IiZqLUJNSDo4LnJpUU5D'
    'Jy8/bEtUUjdZcG1HY1o2VGRVJ0BLbSFhTkUvPDJvRTFyRShGRSI0S21EV0I3PG5RVyMrc3JJXGBD'
    'PnE4YlNkby06TWhIUCknQzpuVCVYYEdrKUAhWDdFRlUsQTZHJXVdL0orLCJlQ0Y8aylIN0hfXEhV'
    'Tyw7WU0+MV0maURBVidUZm0uXkksTDJOKFNDLGJOWCdvQzEpPztedCFkIlBvP2pdTyopJ20wWUow'
    'XlxjXl1rNCNLQFM1QnJMQ1ZeSDRlSDdIX1xIVU8sO1lNPjFdJmlEQVYnVGZtLl5OVy5qamdGXWdz'
    'MHRfPWhiMltBX2YnZWQlayRJMCNsKmwnLDQjLUJeVFtdQyErNDUmRzwwIT8iMj1ySiEpOz5CKzVo'
    'bCxEbVpaLW5dIjdfVkxpX1Bra105WVo+KGhoTDkwSExtMSwnazllcmNFbGM0M0FFJi5lOitNSnNS'
    'cSNYLjAkOCtTQj8ycVFyJm8yVTZDMzcyNjtSLW9PVFdwUjRKc3Q1TD4+ciQzXjxNWGE+PC8sWl4n'
    'MWlURmxVXT1AKV4iWFNdVDo1KlZeWWsiX2RKKHJyPjkuJ2RtNWRobzcibjFNQmJXL1FhbTIjQTQ4'
    'Ii5NZyRAXilYOTJKX3EmRkowcUpxNUY7NWNNdUNlYnFoNURhITNZMF8nVl4kVl4yXFVEIUZnPkRo'
    'P2xnMEpTaic8XGopcDxpJmBQJVxjQiE+QjE8LWFsOTFsQlZVcCpeNF5KI1JoP2xnMEpTZEI7IShZ'
    'TkxyNTxfRShFZG1qaS4oZjRdZ3BSZkhCWTZlJytIWS8ncC0hL2dNZi5kTmk0JnBLYVdWZjVqWkpx'
    'NFRXJz1PKGQsOigvSnV0NSUmW2UrRVtwdGlIQGc1OypYUT5mP0AhY15wTWYiYy4uLy9YLzxAT1JR'
    'RClgZG91alA0InM6X0dMWUQ/TlRMRE4tIy1na0QxaCE5NG1IcF03VWxybFxjQVohRE8rViZMOlJC'
    'MF0pc2pobCo1OVciYzF0PTFFJlJoXGM+R25yPCh0bE5yNl5JcHJQNEMpWDdBXG1nZFI/VlQwPEEo'
    'RWRuNTVuKmspSEI1IiZVW2JHZ0Y5MFxYVFM8R0VHQDJAUjo1cExgI0cvPmYvalNkc0ovU0sub2M/'
    'dSwjNEVNZCJaWFxYKT9OSWNKX3FWVkowcUpxJXQmIk1WJGw0bkA5Uk4jazM+Kyg4clpUOkwrXjhF'
    'Klo1OCxGVSw/YEdBOCpwNU9eNSVGOSxqWyVWYzliZVUqM1hWMiEramMrPShNalZ0LUFKQ0dVbEw9'
    'PCxBNy9hcC1TQy5Sc2gnT3FINjRMTCs5aCMhX2krXkopJTg6W0RWIWMjVj5ZXjgnbDNFcEJQViw1'
    'ZltRazkmXDlhNDc7VCVTcGsxdFQiR3Utai5XQjc8bltvOz1DcUxOOT5WJGRqSEQsPFMiWTIxRCdl'
    'MWVHSkgkPFkhKm4xYGRsNDMvNDo0R0FVbCQ1cCJcY0I5PldTLlIkZVUnXUwpVnVbJy9qU2lwXGVW'
    'SDUkYyR0aXFgU3FxTDssNzAvak9sPl0lUkE1ZVUtJ2Y9KS5OQmdaXGUjPTFXO1JtLFM2O1YoYitU'
    'ZWF1cz1rbFRwaV07VFNuPmVOWCxXU29McVRhUXQ+MjciJSVQNywwRVg4ZEVEZHBrRDckXXIsRlkt'
    'cFc7b2M/dSxMNEBzSy9qVENLcilVVS4valQkcl5sMW0zL3BsJU5hRDFLSko/L0YjLlEoSWNWW0pV'
    'OnE1bzFzKkknTDIlYTpsS2E4XHBPVFpJcGJHcjIzIT8lQWVUOFxmSF0yKSlfWWIvL3VSRjkuaUNr'
    'NVhAQjo/X2h1Lk1MO0NKPy9EW05DallEcWpWZDc1MEZJNTZORilJWVJRcHRqLCFQX0IvdWRyJkEn'
    'TitbIks/PiFMZW9CI0plZW5NJk1jPCQ6cyEoRDdILFQ4KDgmM2I6LV9JZlBRNlohY1tmUjs1SyNo'
    'clFWcVZiT1c7cFtTVD1zSkVHWz0pM3NpM1E7Yj9wbks8OE1fPj1qW2Npbik0bDVwIUpdcyVBI0lJ'
    'WjpuJm8rP1FkKERGb1VSRTdJLjolSlYlPUtyRmk5RUoiOGUlIV1ScywrJ2pkQXNeQzhfTmVdSzdn'
    'QlJOQlgkPyVDUTowQzJTZVg3bUNTOGUlIV1ScywpUWpUPHBDNWpBaHFfb0pgcjcvYXAtU0MuUnNo'
    'Jl4yIyNXOmZJMV9vWm9KPmAyZ0MxKT88K0VbcDxMTkVRY11dTUhKTXJnMFVKRkE1LFsxL1MqcFA6'
    'OlY5XlppVSpFXFU0MiRCI1AiNUMlPzIzK1VXR2E7Oj4hM21KWFk2JXRCN29aSHJFZSFdS15wNikk'
    'K2I4Jl9mUzc7Q0VDQmNAWl5mR0lMdHI5NitUUFU0JlFOUzVndSNiK1lVbitaTC86NkNKRUdbPSk6'
    'ZUBdOj9faHVEQD1yKko/L0RbaDNBbSpwR19PTkkkVk41JTA8OW1eYyd0Q04/ZF1uVCZsMWg1allx'
    'SWQyJEtEIl9dQ04qcm8pWC1ZZCU4Lmovcz5JWVciR1JfN2NJbi4zXGs/JT5gYTAyUCI5WTIxRCdl'
    'MWVHSkgkPFkhKm4xYGRsNC5YSm1hTzRqSWMrQChrbFNlQCpSa1hOWDdxRSIyLCpGVmhBb15hIzts'
    'WEdcY11eVipkNllpbz0iXC8lRGNmZG1DMiV1J19bIW1GNiVrJXM4Rk9TXiohN1wkYnVyODc7WXJX'
    'I1RzO20jOzNmVjJ1TyE2bVwvOFIzNEBlOmNULTtKXzcoUC9yQVlkIls/T1pZPHAvXEdoMTx1Ik0t'
    'MWopNVE1YTxocTxNZiY6XUhxZnIlRUlKZFg4M2YwO0VqWVhbNkc3VkMkcWFcI2ZnYW1RcU1DMCE6'
    'XStsTkx0MkUsTHBjZEBAUF4nMWlURmxVXT1AKV4iWFNYbE9SRnBFSWREdWxpS2tzKXJvbVJaOjxw'
    'Ym4yaFpjXltKJEdIXEVCKGIqKytDKW4mXDtyZ0Q6W0pZaU5wJE88SC1RQiJlMVkucD0yKkhDPmpx'
    'dFA+ZVJUcDcvWys1ajhBKkJgOj5mPE48RD9jOXM9RzpJbWo3Tkc/YzIyIUZpT2BNdWtcPF1nbTFw'
    'b0sjZFNWbExvZ2RSXzFGZElhOkxpLyU1XFQ9QFlbIWxTc2kqJnJLLWw5MWtKZSFpSkVSOnErYkJk'
    'RFg0QlI3amlFKCdaPzAzZzJRIUZkdU84S0dUY29jRE1ea3EvTGg4cG5GXTFfVDsqMXFpOkAzMjFs'
    'WzJtOFg/ODdCdDdEMWdnNDRlYnMqZ0g8YE9MazA4UyxpSktvUDU/N1dbby91SF8vK3JIMkVmUEoo'
    'cDtfam1UKyhpZ2NySjZZWjBLKGRPV2dEKExWUTU/cSoiOjxfZzQrWi5pWVU2YDw5ZUAmVSNSISdK'
    'TWc1OFhTaCkyOnNUPyVEMXFKSm0jMT1AMjZSYCw3TjRFPCpvLEhVTyw7TkEoJSYkWk1DOjIlRiNr'
    'bV9DYC5TL09vSSVtNFZWPyVDU3AhQXQ/cFw5YTQ3O000XVFtSy9wPzYmYnU2V0I5VDJVXkptPDI/'
    'LzZyLz5tUmpIb0lOOUMpW1JfbWgmUTdGRkc2bjAjMVUyKSctTGRoMTlGcVNKayNKJW04I2E/JUNT'
    'MEssT3RLPmVSVkY8R0hYQDFpcmItcSQoUlJeZUVSOEQpZSgpOCg4JjNiOi1fSWZQTkM9LkZiIXUw'
    'Tj9PZCExcj1IZUEvRkonKEM5Kl4jZGEnVTQyJCc6P19odURAPXJSSkRvY1ZVLlBsWXFrbldDUUs6'
    'RGwiLjYmTFlSUyc/aiwhUF9CL3VkciZBKWRVaXJGaDdwUDo6VjleXFAwKkVcVTQyJUYja21fRiJM'
    'RzwlT0BXI3RiZy8+bVJqaV1jbzcyJUYkKEhCNSImX3JVZ11oMTktX0E5N2YtRlUuVVVWZ19FSFdT'
    'b0Yja2xSWVVWKmYqUGlUYFNvTV5wWnQ3NE1TbmdjOEBRJCRcWSZoWC9nUz0wZm0kRipZTkstWWku'
    'IWwyaGcqaEJUJk1uOTtAaiJqIWxoUVVWJUpPL0RaaSc/Km5MaUBmMkUkXXM2NDE9UzMhWTIxRCdl'
    'RjhnSWNpcU1aUlpVJkBTcl1bOyhMWUMkcm9JQUxcN1hxK1ViQThMWzEua2twUDo6VnI3Z1hdIVYy'
    'VDhWMy07a1Vaalk2TDhhRF1LXSY7bSRdcm0tVHNoZFZvYz91LEw8SyguIU89YT5OPEQ/YzlsRSdN'
    'JWRYPm5zKVw5cj5ldWBIJ1BidHUoYjRmREo5PT5VIyxcNVpKRkJFIy9aNlQjb2BOTlw4ZiZVTj1e'
    'NjdaMjxZKU0oJWkpZlZuIUV0MEovN2U0PEk6OTQjTiVzKyphKU1cY0IiaSJ1UWx1XDlhNDc7VCVT'
    'cGwucG8lSDJgRSg6ZFxOPWwucG4uUTFTc1s7bjt1IStGV2RycVwhWWoiVy9gUypybUNyWVBkYThu'
    'X3M/WEM4X0xvXWZScENSTkJYJD8lQ1E6bUFDK0E+ZU5YLFdGOWlJb145TiM0Plo3aCU8Vl1LRzZf'
    'X1pkcGtENyRQOXFEMDg5SV1YN21DUzhlJSFdVmZyQF1qVDxwa0o9M3ROZ1tLMnQqKVNyaS8+bVJq'
    'QF5oKzE0W0tVaCEoMDNSIjVtbFdNJk1iSTdLVDBCVWRsNS9iJXB0WV5LPTdxIXItWEBJbjpvOWlU'
    'YFMjOGUlIV1WZnJCM2pbImsuUiZOME8lQF47Vk0jKVs4M01kKXBdPjxKQF5pOHJmOzVLI2hyUjhA'
    'XGJPVj1HIVIwJTZmUzc7Q0VDQmNAWl5mR0lMdHRtUyJZYTJwN29aSHJFclllIl5wNidZKUY9bVUh'
    'TigmR0FsUjVoM01kKXBdLkhrPiEvQFFLKD5ZNW8tTUw9KSVYYVNXNiZidTZXQjc8bltvOz1DcUxO'
    'OT5WJGRqSEQuXi8vKUtaIjdNWVtSbmUoZmN1UiRMMkNTcl1uM1FXKXEjcU9uRClTQy5RSC0xTSRv'
    'JVVjZW1PL1Bzb2pTbkUiSlJzKydpckVdViVXJyZOZTJYMU9pKXJoPiFsU3NzZTJXITtsOTFrNiU/'
    'cFtlRzZhR3E2JmJ1NldCOVZIZmtzbUozY0ZuVmNac24hZ01hdG9aTC0rRk5lRHJfcltZOmcrOGNL'
    'U15dajNyRDZnKFdWKiIwLkouJlVCOiZiNyZdKk5RYk5icyNWK1wsSklbaWZlazMjbCkvUFo6KE9F'
    'alR1cFtXYG8qQXAmNG9HWEVcUzFfTUUrXV4/PXEqXV1Zcl4nMjJeMi9tL2haPTc3dFBLRDNYPyVC'
    'b15eXitbVVlNZDFKKkI6TDxFSGBhIjtvLHFOZXVXYlopJjAvUyhyJWplPi5YbU8sSWRfSGhYaG9K'
    'I0lmXzQhSVBpVTw2bnJMXzcqaCZYPCpsTEtXQTJsMmxebypGcEVJZEY5Ll0/azVTXU8oR0dKND9n'
    'XF5fR1FHPSNEcGU8aWohRVYmaz02PTJRRkgrXUpDR1VsTD5CJzEsTyxOSmo3OGlOJkEqJ3NGOSZL'
    'IyxKJVc5U1l0L2llVzhzdEpDR1VsTD02SEo3L2Fucz5VT1VvQF5jWFIjZit1Ozcob0hWSCgkUDoh'
    'N1AzU1dCNzxuUVNbVFZxTE4iYEAtQFsxREw+Q3FKPy9GI0FrZDQ2MWZyWj1WUmxuLUdAMkEtVm8w'
    'Mj8iMkItK2xwTTFTWCk1KEddZ29HRUhDTGhDJy87MnMncC0hL1VYWF1eYylvSy8/OCxUWCMsXXAv'
    'PUteTVVtVCsoaWdxVUtgWVowSyhkT1dnRChMVk40P3EqIjo8X2c0K1ouaVlVNmA8OWVAJl4pUyEn'
    'Sk1nNThYU2gpMjpzVD8lRCVtSkptIzE9QDI2UmAsN040K1RQVTQmUU5SJnA8XVFCRTBeX2QiSF4x'
    'c2dbSzJ0KilTcmlYSkwiPkBeY1RsJjpnaFVMYWs5LGhyJC0mPVdaJyg1akFqVyVkPSRHSC1MaXM0'
    'M0snWSE4ZTc3QylcXiptaCZRN0ZNO21KMCMxVTIpJHFGLiNJXCZiQylnKThuMTpKWiFGaU1KQydf'
    'VypIXSkoKDdkJkFIa2xTZm8lRmJxU2w0LlhKbC1xXGVJYytAKGtsU2VAUDhSKWcjJGxiVVVBYjJf'
    'MWhXTmVWUmxuLUdAMkBCVm9CPkEiNCkhWyhFZG0qVFM8R09dZ2wmJEA8MkQ9bV9IK2pXJC1dQCpT'
    'PywkV0d0PylecEJRWiJjMXRtVyQpLkJtaCZRN1IsI0hoNDBVN0hDJ1lyKSNJXHVtYkdmSkxyTz1k'
    'czNNZClwcFE2OGorVFBVNCZRTlM1Z3FVS2BZVWtpbyJPTj4/WWUlRkg5NCU0Pm4xOkpaIUZpTT1D'
    'J19XKkhlXUU9QzcqZWtdSzxAUSkxcmgva2ZGITlNcGljL0MzaEcvRjktRVs7Ukh0Ilg3cUUiMjd1'
    'QC0/JUNdals0QG10KFAoc1xzNyolYmEpWGNnK01VNktEMWdzODRlYk9YSXMzdFtKR2AlNlkoMypL'
    'ITU5MDBhLm5maF5Wa2dZNV5wMiNnJzVhTkhVTyw7cl9hV0YhO1RuVj5sZCshITtzOyVPJTImalE7'
    'Yj9wcStLbWMpXz4oWiZRTlRAXCkkOU1qPWU+biJuXmpXOmUoS1RXMkBVVThmJlZOaUcnO189Nz48'
    'TTsuJnM9WD46SkgwXG1KalA3LDBIcTtZPUhPOGtoKV5sZzUjbmxTM2ZcYz5BbEkwbURZVSdATGw9'
    'JzdMW0suWy51Uk5CWCQ/JT8kZ0ssT2Yxb2M/dSxMPDlEO10qJDdJciFAMjVMOlJCLl0pc2k9bC5t'
    'bmdGOTFBZXFWbS8lLS5KUnFZWjArOiEnWV45cTpZWilfdFBKLDpgIU1iR0AzbHQ0ZEskWCEzb2A1'
    'MiREayY0ZWJPWFBQXlxqI0Y9Sj47Jjx1RyRhQDkqMFZiJ1hiOi1fSWZGQDVHKCNcQWo3QyxuMGpT'
    'bjhzSk9SKkwyJEIjUCI1RTxiQylnKThuMTpKWiFGaU5uKSpOIyJkZmlpJ2w1cCIlbzFASElGQjpg'
    'bSVmP2gkIVxBV0FKKUQtZC45dXIyJUZdJjIvNkQ5UDxHSW9WXlV1WTQvLlpKJCtFW3B0QDw2MCc7'
    'KlhQJFZmVnJLMnVGdGEhYU5FLzwyajtIczc1VG5aOTUnL0pDR1VsTDtVITE3L2FwLVNDLlJzaC1i'
    'NFBedCFkIlBvOyJEMENLQiViOzVuOmU1LXJoSCQ8WGMyKkk3KFxjQXVTQzlJXERdc200LmUxZUZf'
    'SCRBMlFyIWRCSCtFW3B0aUhBclU7KlhQJFZmVnJLXCc5bD86a0xDOTtHbUdvR2FeXWsiNExOVldC'
    'OVQyVV5PRWYyPy81Vz1BSileS1ReUzIpP09tTipgOGJnYW8wRHAiM144LkwmYitxP2xPOWVgWSVr'
    'R2NaMlZvK0VtKERMJmJKbDdvWkhyRXJZXnVecDYpJCtiOCZfcSMwXWgucldWY3JyJUhgKy9BUGFu'
    'QlhOIjRJJS03aTRvO0xYUj9Eb18/K1pXSHI2QSxEJDc6aCNDWm5zIU9mYCxobl1ib2FLOTVRcjlU'
    'YEVXU2d0bFxwYldaWEJOY0grWSxRVl0pdTonVHUhZ2pYcmlYWm4tMjRoITc9ZFA1OTtoUiRHSFxX'
    'QWk0Tz5PS3I+KGgiOFw4Zyldci9fJC9LZlZMSmljSyldRyxpN1IyM20+aTVdImxGbzdaYXQtZzpw'
    'PUQ7cjZGQTptMTAmU2h1W19DZSVeTVdIcFt1Z0o4XHFdbDU9Q2ZwX0tzImVVb1oxRSJyY0A6L0h1'
    'JW1fSjpJMCM2JmlyNVlYX25SQjkoamFRMD8oUCZSXCg1OFwvSjheciI/JT8mNlZSO1ElOj5MSjxm'
    'X3JCR1U0MiNeL2U+TW5aITFqMT8xKS5jIWMvVkUldExTMmUoJ0xuRCdaPmFHQDJAYi1icD5lIiRe'
    'ZHJjaW82XS05KitKPTc2YW9SYm0rPmM5cWIuQ0VuRCRcY15dKzM+N0ZPKzhDTnRMK1lhWGBiLDtR'
    'XDlhM0xmKDlfUkYhWCJYPXJSZTdlL2QxcmdGNywxclAzPlgxSFVeI2RxVGg8PTc2YSdSYm0xQG1S'
    'LklXQ0VuRCRcY1xfV0k3TVBhZTdgL0I+Rzs+IWVNYydfaFA5TD5DNypla11mV0d0aFRhSiFlNS1y'
    'aEhacmplMipGdThcY0IiaT9xKk1eNW8zcTBXLitlMGMmazQtIyFXdVs6ZFxOPW1HMz0yZWF1czFr'
    'bFNlQDJsSWwiPTc2YCRDNypla11mV0dMJXIpQG1GVSxBNmo0JCZfSWMrQCVrbFNlQCYjXldPPTc2'
    'YCRDQEpzUj8lQjdEVyQtXUAqVl5aJyJrYFs/SiZjYyE7bjt0QylsRC5EZldPJ1VXbXA2W1xNJTY9'
    'WlRLdVU1akFocV9zWiM2VTQyJCc6P19odURCNzQ8Sj8vRFtbN1pHKFtncGFnTHVmU1MrYjgmX2ZT'
    'N2tTRUNCY0BaXmZHSUx0c0M2UlIuSXAhKl9uaiI1bW49NmspaCosQ3VEcyI1QGNUMjMrVVdHYTs6'
    'PiEzdDhbMiREayY0ZWJRLjo3WytsXmZfYC4mNCNMakNyPllpMzIxbFs9XGUyX2AsNk9EJjpnaFVM'
    'YWs4VW1iY2tBPUknMUwiSF4xc2dWKUoqZTJYMU9nYCpQaGRLUEkoYTokSy9KPy9GIy5RJ29maHFm'
    'QVVROkZDRzhEU2k6LyxDOlxgMEQ2bmpjaEFfbG8lKjwhUCFIOnFyMTNXUFBfaDUjRjdHXTpkWTVe'
    'NDBUMDRWb0I+QSI0KSFbKEVkbjVSRipWOVRGN3UoZTM8cilrKy9IJUJsLC0iO2cyVmZFVmVdbTlv'
    'bkQjL2pTaShSVGNRIUhCNSImX2NycWIiaiE2NVs/ODciaDE+T1xsVFpHVW9fYCJaRjkxcV9lQFBj'
    'ZV1nbCYkaVU6Wl4kXW5gWzRyI2M4JGMmK0dyLTIyaUBsXkBuT1BmSFIoI1xAP1UuUGxFVz0zJ19y'
    'MnVIZUo9MFhCSVR1Y2tVUkU3SS46JUslVj1VaGk9Nz48UTsuJSZnTmNkZ2MjLFw6IkFvW28jVV01'
    'UjxkcGtENyRdcnAuLGZkTkNPL1Bzb0FVKGNkPWUyL2xSKW9NPlxidHVyVlQ4XjQoTFlFJENqQmlq'
    'IyRsYl1VOnBiOC1XJ3VwbzthRjQrMWVZI2xGbmAqRE8rNTQhOl8xW25cUCk4Qz0hLjouZEEpVSsy'
    'K2xVbSFcRV9xXCFZQiRhQDwrMFZiJ1hiOi1fSWZXQmNFIWNbZlI7NUsjaHJTK3BkYk9XbFUkVDZF'
    'O2ZcUlg5OywqLDVQViw1ZkcoVVw3RTpyKF49ZkdoTXM3WWxyVTBOM2UhX0QtdUQ+NihKTmk0JUVR'
    'O2I/cFoubTBUKmhgZERKPz5SRiFVcXE8NmspaCosQ3VEcyIyQDQ3ISpgaCVuK2FrQjhmLDllX21K'
    'LCVnWFVYPVBvOyJERHNuL2ViQ15dNzhEU2k2ZlVOak1lLjRbYi46JUpWJTU3J0dKPy9GIy5RJ29m'
    'aHFmQVVRM1Q4TU9MYlBLRSZdXzhXI3A4TTtuO3Q2KXVjIWshTnQ5KFdtaWA1SXNaQkk9ZTZLP1Ru'
    'XixZZ1VkUERXcC1kWWRLUEhfP3VbWzNlVSo1QjhlJSFdW3MmJ0BiTVN0SSEpZSNLKWZEUm4mYlE3'
    'UEVfNyxqRzIoNVMkVDcsTENfY1VSSj5dcGsyKSkubCJFcyY/ciFxcm1DampRWFcuUVkhRjkrXiJd'
    'S2NvLFw5YTQ3O1QlU3BtRzM+KUd1LWouV0I3PG5dMlJhR3FMTjk+ViRkakhGXGtGKlkyMUQnZTFl'
    'Rl9IWnJrIypuMWFPRjloZ0RoOkRBVkkvTF80SGdnSiRxZ1FSbXM3QlleTT4sPWpgMkF0ZT9fYCZM'
    'aFcrNEJJcTdzVmhOSGJcZUV1a0FeVyxJIV5sRS9WbkpJbm9dMEckSnI4KydkUEI1KjxBWUNwP2dP'
    'M0huZjBAa2BDXFJdSDhNJkJLSigmOWlvNjVbUDosKlExYSRQOD00OHFLN15IVT9LXjdPZj5aKEhO'
    'XFlQZ0kkNUVUOE5yL25PMHJTSU1FPWwySCk/WyFILVpmJTleYl48MCZoN3JGUWNaJXA7XF1bPFA3'
    'WGNPOzoxWENdb0NKcz8kaF5Gc3IrIm1cJ0NoVCUwKFAkVnJkJmJjTTtYaXRoKismWm4pczlVKTp0'
    'cC5pWzwxTj9bajdTcEs9X01JXCoxKGFRSk1qSTRzcmk1N3NPYFNEKi5fVW9lOk47NG1hKF1bRTQx'
    'KyVhXGljUTpEWzxANGx1NTplM0knOydRIi1IbXQlOj9LOj0/ZEZjdFBOVk8pcT48cUNDWlkwQG89'
    'OCVyZXQiYk9zNUlbM2s0XDk6PGVwXC1AXV0pYGg+Wk1LZGNHLTRyLWxBYC06XjQjPVwzNU5jUXFZ'
    'VXA6NWpLPSx1bTteP2EpakFqL0dDYU5FW0BrLl04TmNkLiVlaGQ+aSVUOmBwNnJxI0dfcm5JLShU'
    'PENLWm9ATi5Nam81LEo1Q0VGITVNdTpbTmspbSwmLEZkPistUzBqTSpITChybjUnZGdZYCMjZj4l'
    'MVpzOChYUXA8VU1Rciw1cWxyZWhUY105LzMkSGUiTl9Hc0Bva3AmRWQrKCx0ZWhzN1tJbHJPSy9p'
    'L2ghPjZsWSJRNnMxWkpGcyo2NnNuX2E6YnJJMktbYHVrPShYKnAyMTU5RShqaHQpMzxndSFWW1Z1'
    'UDNWanJhVDQ0cUVmZik0X19dbiphJidIJS06YDtba3JJJzFeMTxkc25qWUxROCE2cjc3WF8/V0oo'
    'Vl5EQF0tZkMuJklwRCInPWFbdDcrYlI3b1lrR1hTKChdKT4ublshRE9jZDFpJ29xUVMlcEFOKENt'
    'VFdGaklfcCpZajdDc3FmXiJeSDs8JztbTk8lSCJNYEc7ZSRjTkZrRyZsPCFlMmNlPmNAdTc8Ryc7'
    'U0hKLEUrLT9wajh+PmVuZHN0cmVhbQplbmRvYmoKeHJlZgowIDkKMDAwMDAwMDAwMCA2NTUzNSBm'
    'IAowMDAwMDAwMDYxIDAwMDAwIG4gCjAwMDAwMDAxMDIgMDAwMDAgbiAKMDAwMDAwMDIwOSAwMDAw'
    'MCBuIAowMDAwMDAwMzIxIDAwMDAwIG4gCjAwMDAwMDA1MjQgMDAwMDAgbiAKMDAwMDAwMDU5MiAw'
    'MDAwMCBuIAowMDAwMDAwODUzIDAwMDAwIG4gCjAwMDAwMDA5MTIgMDAwMDAgbiAKdHJhaWxlcgo8'
    'PAovSUQgCls8MWViNzExNGRhOTlkNDlmYmRkZjExNjUwM2ZmYTk1MjY+PDFlYjcxMTRkYTk5ZDQ5'
    'ZmJkZGYxMTY1MDNmZmE5NTI2Pl0KJSBSZXBvcnRMYWIgZ2VuZXJhdGVkIFBERiBkb2N1bWVudCAt'
    'LSBkaWdlc3QgKG9wZW5zb3VyY2UpCgovSW5mbyA2IDAgUgovUm9vdCA1IDAgUgovU2l6ZSA5Cj4+'
    'CnN0YXJ0eHJlZgo1Mjc1NQolJUVPRgo='
)

def ensure_ka_pdf_exists():
    """ينشئ ملف assets/KA.pdf تلقائياً عند الحاجة (البيانات مضمّنة في الكود)."""
    import base64 as _b64
    ka_dir = os.path.join(PROJECT_ROOT, "assets")
    ka_path = os.path.join(ka_dir, "KA.pdf")
    if os.path.exists(ka_path):
        logging.info("ensure_ka_pdf_exists: KA.pdf موجود بالفعل")
        return
    try:
        os.makedirs(ka_dir, exist_ok=True)
        pdf_bytes = _b64.b64decode(_KA_PDF_B64)
        with open(ka_path, "wb") as f:
            f.write(pdf_bytes)
        sz = len(pdf_bytes)
        logging.info(f"ensure_ka_pdf_exists: تم إنشاء KA.pdf ({sz} bytes)")
        print(f"  ✅ تم إنشاء assets/KA.pdf تلقائياً ({sz} bytes)")
    except Exception as e:
        logging.error(f"ensure_ka_pdf_exists: فشل الإنشاء: {e}")
        print(f"  ❌ فشل إنشاء assets/KA.pdf: {e}")


# Centralized mapping for key files and display names
KEY_TYPE_MAP = {
    'removebg': {'file': REMOVE_BG_KEY_FILE, 'display_name': 'Remove.bg'},
    'picsart': {'file': PICSART_KEY_FILE, 'display_name': 'Picsart'},
    'convertapi': {'file': CONVERTAPI_KEY_FILE, 'display_name': 'ConvertAPI'},
    'ailab': {'file': AILAB_API_KEY_FILE, 'display_name': 'AILabAPI'},
    'gemini': {'file': GEMINI_API_KEY_FILE, 'display_name': 'Gemini AI'},
}


# --- Helper function for MarkdownV2 escaping ---
def escape_markdown_v2(text):
    """
    Helper function to escape characters for MarkdownV2 parse mode.
    Only essential characters are escaped to avoid over-escaping.
    """
    if not isinstance(text, str):
        return str(text)

    # Characters that need to be escaped in MarkdownV2
    # Reference: https://core.telegram.org/bots/api#markdownv2-style
    # Escaping these characters: _, *, [, ], (, ), ~, `, >, #, +, -, =, |, {, }, ., !

    # This list is carefully chosen to escape characters that would break MarkdownV2 parsing
    # in plain text, but not characters that are part of valid MarkdownV2 formatting.
    # For instance, we don't escape `[` or `]` if they are part of a `[text](url)` link.
    # However, for general text outside of specific formatting, these need escaping.
    # Given the context (user info, IDs), a broad escape is safer.
    chars_to_escape = '_*[]()~`>#+-=|{}.!'

    escaped_text = ""
    for char in text:
        if char in chars_to_escape:
            escaped_text += "\\" + char
        else:
            escaped_text += char
    return escaped_text


def cleanup_temp_files():
    """نظام تنظيف دوري شامل - يحذف ملفات PDF والوورد والصور القديمة (أكثر من ساعة)."""
    import glob

    # Protected files that should never be deleted
    protected_patterns = [
        os.path.join(CONFIG_DIR, "*"),
        os.path.join(KEYS_DIR, "*"),
        TEMPLATE_MESSAGE_FILE,
        START_MESSAGE_FILE,
        BOT_VERSION_FILE,
        MAINTENANCE_MODE_FILE,
        SUMMARY_MODE_FILE,
        SCHEDULED_REMINDERS_FILE,
        USER_DAILY_STATS_FILE,
        ALLOWED_USERS_FILE,
        USER_STATE_FILE,
        REMINDERS_FILE,
        STATS_FILE
    ]
    
    protected_files = set()
    for pattern in protected_patterns:
        protected_files.update(glob.glob(pattern))
    
    # نظام تنظيف شامل: temp_pdf + word_files + pending_user_photos
    temp_patterns = [
        os.path.join(TEMP_PDF_DIR, "*"),  # جميع ملفات temp_pdf/
        os.path.join(WORD_FILES_DIR, "*"),  # جميع ملفات word_files/
        os.path.join(PENDING_USER_PHOTOS_DIR, "*"),  # جميع صور المستخدمين المعلقة
    ]
    current_time = time.time()
    cleaned_count = 0
    cleaned_dirs = {"temp_pdf": 0, "word_files": 0, "pending_photos": 0}

    for pattern in temp_patterns:
        for file_path in glob.glob(pattern):
            # Skip protected files
            if file_path in protected_files:
                continue
            
            # Skip directories - only delete files
            if os.path.isdir(file_path):
                continue
                
            try:
                file_age = current_time - os.path.getmtime(file_path)
                if file_age > 3600:  # 1 hour
                    os.remove(file_path)
                    cleaned_count += 1
                    
                    # تتبع الملفات المحذوفة حسب المجلد
                    if TEMP_PDF_DIR in file_path:
                        cleaned_dirs["temp_pdf"] += 1
                    elif WORD_FILES_DIR in file_path:
                        cleaned_dirs["word_files"] += 1
                    elif PENDING_USER_PHOTOS_DIR in file_path:
                        cleaned_dirs["pending_photos"] += 1
                    
                    logging.info(f"🗑️ حذف ملف قديم: {os.path.basename(file_path)}")
            except OSError as e:
                logging.warning(f"⚠️ خطأ حذف الملف {file_path}: {e}")

    if cleaned_count > 0:
        summary = f"🧹 تنظيف دوري: حذفت {cleaned_count} ملفات قديمة (temp_pdf: {cleaned_dirs['temp_pdf']}, word_files: {cleaned_dirs['word_files']}, photos: {cleaned_dirs['pending_photos']})"
        logging.info(summary)

def load_statistics():
    """Load bot usage statistics."""
    if os.path.exists(STATS_FILE):
        with open(STATS_FILE, 'r', encoding='utf-8') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logging.error(f"Error decoding JSON from {STATS_FILE}. Returning empty states.")
                return {"total_users": 0, "operations": {}, "last_service_time": None}
    return {"total_users": 0, "operations": {}, "last_service_time": None}

def save_statistics(stats):
    """Save bot usage statistics."""
    try:
        with open(STATS_FILE, 'w', encoding='utf-8') as f:
            json.dump(stats, f, indent=4, ensure_ascii=False)
    except IOError as e:
        logging.error(f"Failed to save statistics: {e}")

def get_total_users_count():
    """Calculate total unique users count from allowed and banned lists."""
    user_data = load_allowed_users()
    allowed_count = len(user_data.get('allowed', []))
    banned_count = len(user_data.get('banned', []))
    return allowed_count + banned_count

def get_pending_requests_count():
    """Get count of pending user requests."""
    user_data = load_allowed_users()
    return len(user_data.get('pending', {}))

def increment_operation_count(operation_type, user_id=None):
    """Increment count for a specific operation and track user activity."""
    stats = load_statistics()
    if operation_type not in stats["operations"]:
        stats["operations"][operation_type] = 0
    stats["operations"][operation_type] += 1

    # تحديث وقت آخر خدمة بالتوقيت العراقي
    current_time = get_iraq_time().strftime('%Y-%m-%d %H:%M:%S')
    stats["last_service_time"] = to_english_numerals(current_time)

    save_statistics(stats)
    
    # Track user activity in daily summary if user_id provided
    if user_id:
        track_user_activity(user_id, operation_type)


# --- Reminder System Functions ---

def parse_reminder_time(time_input):
    """
    Parse various time input formats and convert to Iraq timezone (Asia/Baghdad).
    
    Supported formats:
    - "HH:MM" or "H:MM" (e.g., "18:30" or "6:30") - today
    - "HH:MM AM/PM" or "H:MM AM/PM" (e.g., "6:30 PM")
    - "Tomorrow at HH:MM" or "غدًا الساعة HH:MM"
    - "YYYY-MM-DD HH:MM" or "YYYY-MM-DD HH:MM:SS"
    
    Returns:
        tuple: (success: bool, datetime_str: str, formatted_display: str, error_msg: str)
    """
    import re
    from datetime import datetime, timedelta
    import pytz
    
    iraq_tz = pytz.timezone('Asia/Baghdad')
    time_input = time_input.strip()
    
    try:
        # Pattern 1: Full datetime format YYYY-MM-DD HH:MM:SS
        if re.match(r'^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}$', time_input):
            dt = datetime.strptime(time_input, '%Y-%m-%d %H:%M:%S')
            dt = iraq_tz.localize(dt)
            return True, time_input, dt.strftime('%Y-%m-%d %H:%M:%S'), None
        
        # Pattern 2: Date with time without seconds YYYY-MM-DD HH:MM
        if re.match(r'^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}$', time_input):
            dt = datetime.strptime(time_input, '%Y-%m-%d %H:%M')
            dt = iraq_tz.localize(dt)
            datetime_str = dt.strftime('%Y-%m-%d %H:%M:%S')
            display_str = dt.strftime('%Y-%m-%d %H:%M')
            return True, datetime_str, display_str, None
        
        # Get current time in Iraq
        now_iraq = datetime.now(iraq_tz)
        target_date = now_iraq.date()
        
        # Pattern 3: Tomorrow variations (including AM/PM support)
        tomorrow_patterns = [
            # Tomorrow with AM/PM: "Tomorrow at 8:00 PM" or "غدًا الساعة 8:00 م"
            (r'(?:tomorrow|غدًا|غدا)\s+(?:at|الساعة|في)\s+(\d{1,2}):(\d{2})\s*(AM|PM|am|pm|ص|م)', True),
            # Tomorrow with 24-hour: "Tomorrow at 18:00"
            (r'(?:tomorrow|غدًا|غدا)\s+(?:at|الساعة|في)\s+(\d{1,2}):(\d{2})', False),
            # Tomorrow without "at": "Tomorrow 18:00"
            (r'(?:tomorrow|غدًا|غدا)\s+(\d{1,2}):(\d{2})', False)
        ]
        
        for pattern, has_am_pm in tomorrow_patterns:
            match = re.search(pattern, time_input, re.IGNORECASE)
            if match:
                target_date = (now_iraq + timedelta(days=1)).date()
                hour = int(match.group(1))
                minute = int(match.group(2))
                
                # Handle AM/PM if present
                if has_am_pm:
                    am_pm = match.group(3).upper()
                    if am_pm in ['PM', 'M', 'م']:
                        if hour != 12:
                            hour += 12
                    elif am_pm in ['AM', 'S', 'ص']:
                        if hour == 12:
                            hour = 0
                
                if 0 <= hour < 24 and 0 <= minute < 60:
                    dt = datetime.combine(target_date, datetime.min.time())
                    dt = dt.replace(hour=hour, minute=minute, second=0)
                    dt = iraq_tz.localize(dt)
                    datetime_str = dt.strftime('%Y-%m-%d %H:%M:%S')
                    display_str = dt.strftime('%Y-%m-%d %H:%M')
                    return True, datetime_str, display_str, None
        
        # Pattern 4: Time with AM/PM
        am_pm_pattern = r'(\d{1,2}):(\d{2})\s*(AM|PM|am|pm|ص|م)'
        match = re.match(am_pm_pattern, time_input, re.IGNORECASE)
        if match:
            hour = int(match.group(1))
            minute = int(match.group(2))
            am_pm = match.group(3).upper()
            
            # Handle AM/PM conversion
            if am_pm in ['PM', 'M', 'م']:
                if hour != 12:
                    hour += 12
            elif am_pm in ['AM', 'S', 'ص']:
                if hour == 12:
                    hour = 0
            
            if 0 <= hour < 24 and 0 <= minute < 60:
                dt = datetime.combine(target_date, datetime.min.time())
                dt = dt.replace(hour=hour, minute=minute, second=0)
                dt = iraq_tz.localize(dt)
                
                # Check if the time is in the past - if so, schedule for tomorrow
                if dt <= now_iraq:
                    dt = dt + timedelta(days=1)
                    logging.info(f"Parsed time {time_input} was in the past, rolling forward to tomorrow: {dt}")
                
                datetime_str = dt.strftime('%Y-%m-%d %H:%M:%S')
                display_str = dt.strftime('%Y-%m-%d %H:%M')
                return True, datetime_str, display_str, None
        
        # Pattern 5: Simple time HH:MM or H:MM (24-hour format)
        time_pattern = r'^(\d{1,2}):(\d{2})$'
        match = re.match(time_pattern, time_input)
        if match:
            hour = int(match.group(1))
            minute = int(match.group(2))
            
            if 0 <= hour < 24 and 0 <= minute < 60:
                dt = datetime.combine(target_date, datetime.min.time())
                dt = dt.replace(hour=hour, minute=minute, second=0)
                dt = iraq_tz.localize(dt)
                
                # Check if the time is in the past - if so, schedule for tomorrow
                if dt <= now_iraq:
                    dt = dt + timedelta(days=1)
                    logging.info(f"Parsed time {time_input} was in the past, rolling forward to tomorrow: {dt}")
                
                datetime_str = dt.strftime('%Y-%m-%d %H:%M:%S')
                display_str = dt.strftime('%Y-%m-%d %H:%M')
                return True, datetime_str, display_str, None
        
        # If no pattern matched
        return False, None, None, "تنسيق الوقت غير مدعوم. استخدم أحد التنسيقات التالية:\n• HH:MM (مثال: 18:30)\n• HH:MM AM/PM (مثال: 6:30 PM)\n• Tomorrow at HH:MM (مثال: Tomorrow at 8:00)\n• YYYY-MM-DD HH:MM (مثال: 2025-01-15 14:30)"
        
    except Exception as e:
        logging.error(f"Error parsing time: {e}")
        return False, None, None, f"خطأ في تحليل الوقت: {str(e)}"


def load_reminders():
    """Load owner reminders from file."""
    if os.path.exists(REMINDERS_FILE):
        with open(REMINDERS_FILE, 'r', encoding='utf-8') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logging.error(f"Error decoding JSON from {REMINDERS_FILE}. Returning empty reminders.")
                return {}
    return {}

def save_reminders(reminders):
    """Save owner reminders to file."""
    try:
        with open(REMINDERS_FILE, 'w', encoding='utf-8') as f:
            json.dump(reminders, f, indent=4, ensure_ascii=False)
    except IOError as e:
        logging.error(f"Failed to save reminders: {e}")

def add_reminder(reminder_id, title, description, reminder_time):
    """Add a new reminder."""
    reminders = load_reminders()
    reminders[reminder_id] = {
        'title': title,
        'description': description,
        'reminder_time': reminder_time,
        'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'acknowledged': False,
        'last_sent': None
    }
    save_reminders(reminders)
    return True

def update_reminder(reminder_id, updates):
    """Update an existing reminder."""
    reminders = load_reminders()
    if reminder_id in reminders:
        reminders[reminder_id].update(updates)
        save_reminders(reminders)
        return True
    return False

def delete_reminder(reminder_id):
    """Delete a reminder."""
    reminders = load_reminders()
    if reminder_id in reminders:
        del reminders[reminder_id]
        save_reminders(reminders)
        return True
    return False

def get_reminder(reminder_id):
    """Get a specific reminder."""
    reminders = load_reminders()
    return reminders.get(reminder_id)

def get_all_reminders():
    """Get all reminders."""
    return load_reminders()

def acknowledge_reminder(reminder_id):
    """Acknowledge a reminder to stop repetition."""
    return update_reminder(reminder_id, {'acknowledged': True})

def check_and_send_reminders():
    """Check for due reminders and send them."""
    reminders = load_reminders()
    iraq_tz = pytz.timezone('Asia/Baghdad')
    current_time = datetime.now(iraq_tz)
    
    for reminder_id, reminder_data in reminders.items():
        if reminder_data.get('acknowledged', False):
            continue
            
        try:
            reminder_time = datetime.strptime(reminder_data['reminder_time'], '%Y-%m-%d %H:%M:%S')
            reminder_time = iraq_tz.localize(reminder_time)
            
            # Check if reminder is due
            if current_time >= reminder_time:
                last_sent = reminder_data.get('last_sent')
                should_send = False
                
                if last_sent is None:
                    # First time sending
                    should_send = True
                else:
                    # Check if 15 minutes have passed since last sent
                    last_sent_time = datetime.strptime(last_sent, '%Y-%m-%d %H:%M:%S')
                    last_sent_time = iraq_tz.localize(last_sent_time)
                    time_diff = current_time - last_sent_time
                    
                    if time_diff.total_seconds() >= 900:  # 15 minutes = 900 seconds
                        should_send = True
                
                if should_send:
                    # Send reminder
                    title = reminder_data.get('title', 'تذكير')
                    description = reminder_data.get('description', '')
                    
                    message = f"🔔 *{title}*\n\n{description}\n\n⏰ الوقت المحدد: {reminder_data['reminder_time']}"
                    
                    buttons = [
                        [{'text': '✅ تم الإقرار', 'callback_data': f'acknowledge_reminder_{reminder_id}'}]
                    ]
                    
                    send_message(ADMIN_ID, message, inline_buttons=buttons, parse_mode='Markdown')
                    
                    # Update last_sent time
                    update_reminder(reminder_id, {'last_sent': current_time.strftime('%Y-%m-%d %H:%M:%S')})
                    
                    logging.info(f"Sent reminder {reminder_id} to admin")
                    
        except Exception as e:
            logging.error(f"Error processing reminder {reminder_id}: {e}")


def edit_message(chat_id, message_id, text, inline_buttons=None, parse_mode=None):
    """
    Edits an existing message.

    Args:
        chat_id (int): The chat ID.
        message_id (int): The message ID to edit.
        text (str): The new message text.
        inline_buttons (list, optional): Optional list of lists for inline keyboard markup.
        parse_mode (str, optional): Optional parse mode (e.g., 'MarkdownV2', 'Markdown', 'HTML').

    Returns:
        bool: True on success, False otherwise.
    """
    # Always convert to English numerals before sending
    text = to_english_numerals(text)
    
    payload = {
        'chat_id': chat_id,
        'message_id': message_id,
        'text': text,
    }

    if inline_buttons:
        payload['reply_markup'] = json.dumps({
            'inline_keyboard': inline_buttons
        })

    if parse_mode:
        payload['parse_mode'] = parse_mode

    response = make_request(f"{API_URL}/editMessageText", 'POST',
                            headers={'Content-Type': 'application/json'},
                            json_data=payload)

    if response['error']:
        logging.error(f"edit_message cURL error: {response['error']}")
        return False

    try:
        if response['response'] is None or not isinstance(response['response'], requests.Response):
            logging.error(f"edit_message: Invalid or None response object for chat_id {chat_id}, message_id {message_id}")
            return False

        response_data = response['response'].json()
        if not response_data.get('ok'):
            logging.error(f"edit_message API error: {response_data.get('description', 'Unknown error')} for chat_id {chat_id}, message_id {message_id}")
            return False
        return True
    except json.JSONDecodeError:
        logging.error(f"edit_message: Failed to decode JSON response: {response['response'].text}")
        return False
    except AttributeError:
        logging.error(f"edit_message: AttributeError on response object for chat_id {chat_id}, message_id {message_id}")
        return False


def edit_or_send_message(chat_id, message_id, text, inline_buttons=None, parse_mode=None):
    """
    Attempts to edit an existing message, falls back to sending a new message if edit fails.
    
    Args:
        chat_id (int): The chat ID.
        message_id (int): The message ID to try editing.
        text (str): The message text.
        inline_buttons (list, optional): Optional inline keyboard markup.
        parse_mode (str, optional): Optional parse mode.
    
    Returns:
        int or None: The message ID (original if edit succeeded, new if fallback succeeded, None if both failed).
    """
    if message_id:
        success = edit_message(chat_id, message_id, text, inline_buttons=inline_buttons, parse_mode=parse_mode)
        if success:
            return message_id
        else:
            logging.info(f"edit_message failed for message_id {message_id}, falling back to send_message")
            delete_message(chat_id, message_id)
    
    new_msg_id = send_message(chat_id, text, inline_buttons=inline_buttons, parse_mode=parse_mode)
    return new_msg_id


# --- Bot Version Control Functions ---
def load_bot_version():
    """تحميل نسخة البوت من الملف."""
    if os.path.exists(BOT_VERSION_FILE):
        with open(BOT_VERSION_FILE, 'r', encoding='utf-8') as f:
            try:
                data = json.load(f)
                return data
            except json.JSONDecodeError:
                logging.error(f"خطأ في قراءة ملف الإصدار. استخدام الإصدار الافتراضي.")
                return {
                    "version": "2.0.0",
                    "build": 1,
                    "release_date": datetime.now().strftime('%Y-%m-%d'),
                    "status": "مستقر",
                    "features": []
                }
    return {
        "version": "2.0.0",
        "build": 1,
        "release_date": datetime.now().strftime('%Y-%m-%d'),
        "status": "مستقر",
        "features": []
    }

def save_bot_version(version_data):
    """حفظ نسخة البوت إلى الملف."""
    try:
        with open(BOT_VERSION_FILE, 'w', encoding='utf-8') as f:
            json.dump(version_data, f, indent=4, ensure_ascii=False)
        return True
    except IOError as e:
        logging.error(f"فشل في حفظ إصدار البوت: {e}")
        return False

def get_version_string():
    """الحصول على سلسلة الإصدار المنسقة."""
    version_data = load_bot_version()
    return f"{version_data['version']} Build {version_data['build']}"

def increment_version(version_type='build'):
    """زيادة رقم الإصدار."""
    version_data = load_bot_version()
    
    # Parse version string (format: x.y.z)
    import re
    match = re.match(r'(\d+)\.(\d+)\.(\d+)', version_data['version'])
    if not match:
        logging.error(f"صيغة إصدار غير صالحة: {version_data['version']}")
        return False
    
    major, minor, patch = map(int, match.groups())
    
    if version_type == 'major':
        major += 1
        minor = 0
        patch = 0
        version_data['build'] = 1
    elif version_type == 'minor':
        minor += 1
        patch = 0
        version_data['build'] = 1
    elif version_type == 'patch':
        patch += 1
        version_data['build'] = 1
    elif version_type == 'build':
        version_data['build'] += 1
    
    version_data['version'] = f"{major}.{minor}.{patch}"
    version_data['release_date'] = datetime.now().strftime('%Y-%m-%d')
    
    return save_bot_version(version_data)

def decrement_version(version_type='build'):
    """تقليل رقم الإصدار."""
    version_data = load_bot_version()
    
    # Parse version string (format: x.y.z)
    import re
    match = re.match(r'(\d+)\.(\d+)\.(\d+)', version_data['version'])
    if not match:
        logging.error(f"صيغة إصدار غير صالحة: {version_data['version']}")
        return False
    
    major, minor, patch = map(int, match.groups())
    build = version_data.get('build', 1)
    
    if version_type == 'major':
        if major > 0:
            major -= 1
        else:
            return False  # Cannot go below 0
    elif version_type == 'minor':
        if minor > 0:
            minor -= 1
        else:
            return False  # Cannot go below 0
    elif version_type == 'patch':
        if patch > 0:
            patch -= 1
        else:
            return False  # Cannot go below 0
    elif version_type == 'build':
        if build > 1:
            version_data['build'] -= 1
        else:
            return False  # Cannot go below 1
    
    version_data['version'] = f"{major}.{minor}.{patch}"
    version_data['release_date'] = datetime.now().strftime('%Y-%m-%d')
    
    return save_bot_version(version_data)

def set_version_status(status):
    """تعيين حالة الإصدار."""
    version_data = load_bot_version()
    version_data['status'] = status
    return save_bot_version(version_data)

def toggle_status_display():
    """تبديل عرض الإصدار في /STATUS."""
    version_data = load_bot_version()
    current_display = version_data.get('show_in_status', True)
    version_data['show_in_status'] = not current_display
    return save_bot_version(version_data)

def toggle_component_display(component_name, show=None):
    """تبديل أو تعيين عرض مكون معين في /STATUS."""
    version_data = load_bot_version()
    if 'show_components' not in version_data:
        version_data['show_components'] = {
            'major': True,
            'minor': True,
            'patch': True,
            'build': True,
            'status': True,
            'release_date': True
        }
    
    if show is None:
        # Toggle current state
        current_state = version_data['show_components'].get(component_name, True)
        version_data['show_components'][component_name] = not current_state
    else:
        # Set to specific state
        version_data['show_components'][component_name] = show
    
    return save_bot_version(version_data)

def get_component_display_status(component_name):
    """الحصول على حالة عرض مكون معين."""
    version_data = load_bot_version()
    if 'show_components' not in version_data:
        return True
    return version_data['show_components'].get(component_name, True)

def update_version_status(new_status):
    """تحديث حالة الإصدار."""
    version_data = load_bot_version()
    version_data['status'] = new_status
    return save_bot_version(version_data)


# --- Start Message Management Functions ---
def load_start_message():
    """تحميل رسالة البدء من الملف."""
    if os.path.exists(START_MESSAGE_FILE):
        with open(START_MESSAGE_FILE, 'r', encoding='utf-8') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logging.error(f"خطأ في قراءة ملف رسالة البدء. استخدام الرسالة الافتراضية.")
                return get_default_start_message()
    return get_default_start_message()

def get_default_start_message():
    """الحصول على رسالة البدء الافتراضية."""
    return {
        "enabled": True,
        "message": "مرحبًا بك 👋\nيرجى اختيار العملية المطلوبة من الأزرار الظاهرة أدناه."
    }

def save_start_message(message_data):
    """حفظ رسالة البدء إلى الملف."""
    try:
        with open(START_MESSAGE_FILE, 'w', encoding='utf-8') as f:
            json.dump(message_data, f, indent=4, ensure_ascii=False)
        return True
    except IOError as e:
        logging.error(f"فشل في حفظ رسالة البدء: {e}")
        return False

def update_start_message(message_text):
    """تحديث نص رسالة البدء."""
    message_data = load_start_message()
    message_data['message'] = message_text
    return save_start_message(message_data)

def toggle_start_message():
    """تفعيل/تعطيل رسالة البدء."""
    message_data = load_start_message()
    message_data['enabled'] = not message_data.get('enabled', True)
    return save_start_message(message_data)

def reset_start_message():
    """إعادة تعيين رسالة البدء للافتراضية."""
    return save_start_message(get_default_start_message())

def get_start_message_text():
    """الحصول على نص رسالة البدء المخصصة أو نقطة إذا كانت معطلة."""
    message_data = load_start_message()
    if message_data.get('enabled', True):
        return message_data.get('message', '')
    else:
        return "·"  # نقطة عند التعطيل


# --- Template Message Management Functions ---
def load_template_message():
    """تحميل رسالة القوالب من الملف."""
    if os.path.exists(TEMPLATE_MESSAGE_FILE):
        with open(TEMPLATE_MESSAGE_FILE, 'r', encoding='utf-8') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logging.error(f"خطأ في قراءة ملف رسالة القوالب. استخدام الرسالة الافتراضية.")
                return get_default_template_message()
    return get_default_template_message()

def get_default_template_message():
    """الحصول على رسالة القوالب الافتراضية."""
    return {
        "enabled": True,
        "regular_template_message": """🧩 *اختر نوع القالب:*

1️⃣ *قالب المعاملات العادية*
   📐 قالب 3×3 (9 صور)
   📝 مثالي للمعاملات الرسمية والهويات والبطاقات

───────────────────

2️⃣ *قالب الجوازات*
   📐 قالب 3×2 (6 صور)
   📝 مخصص لصور جوازات السفر والوثائق الرسمية

───────────────────

3️⃣ *قالب أكثر من شخص*
   📐 تخطيطات متعددة
   📝 لشخصين فقط - قوالب مرنة
   القياسات المتوفرة: 4×6، 3×4، 2×2

───────────────────

*⚠️ ملاحظة:*
*إنَّ سعر كل ما يوضع او ما يحتويه احد القوالب آنفة الذكر هو 4000د.ع فقط لا غير، على ان يخفّض قليلًا في الحالات الانسانية او الخاصة إن تبيَّن ذلك فقط.*""",
        "auto_template_message": """🤖 *اختر نوع القالب للمعالجة التلقائية:*

1️⃣ *المعالجة مع قالب المعاملات العادية*
   📐 قالب 3×3 (9 صور)
   📝 مثالي للمعاملات الرسمية والهويات والبطاقات
   توزيع احترافي لـ 9 صور بنفس المقاس
   🔄 معالجة تلقائية: إزالة الخلفية → تحسين الجودة → توزيع في القالب

───────────────────

2️⃣ *المعالجة مع قالب الجوازات*
   📐 قالب 3×2 (6 صور)
   📝 مخصص لصور جوازات السفر والوثائق الرسمية
   توزيع 6 صور بمقاس الجواز القياسي
   🔄 معالجة تلقائية: إزالة الخلفية → تحسين الجودة → توزيع في القالب

───────────────────

3️⃣ *المعالجة مع أكثر من شخص؟*
   📐 تخطيطات متعددة
   📝 لشخصين فقط - قوالب مرنة
   القياسات المتوفرة: 4×6، 3×4، 2×2
   🔄 معالجة تلقائية: إزالة الخلفية → تحسين الجودة → توزيع في القالب

───────────────────

*⚠️ ملاحظة:*
*إنَّ سعر كل ما يوضع او ما يحتويه احد القوالب آنفة الذكر هو 4000د.ع فقط لا غير، على ان يخفّض قليلًا في الحالات الانسانية او الخاصة إن تبيَّن ذلك فقط.*"""
    }

def save_template_message(message_data):
    """حفظ رسالة القوالب إلى الملف."""
    try:
        with open(TEMPLATE_MESSAGE_FILE, 'w', encoding='utf-8') as f:
            json.dump(message_data, f, indent=4, ensure_ascii=False)
        return True
    except IOError as e:
        logging.error(f"فشل في حفظ رسالة القوالب: {e}")
        return False

def update_template_message(message_text, message_type='regular'):
    """تحديث نص رسالة القوالب."""
    message_data = load_template_message()
    if message_type == 'regular':
        message_data['regular_template_message'] = message_text
    elif message_type == 'auto':
        message_data['auto_template_message'] = message_text
    return save_template_message(message_data)

def toggle_template_message():
    """تفعيل/تعطيل رسالة القوالب."""
    message_data = load_template_message()
    message_data['enabled'] = not message_data.get('enabled', True)
    return save_template_message(message_data)

def reset_template_message():
    """إعادة تعيين رسالة القوالب للافتراضية."""
    return save_template_message(get_default_template_message())

def get_template_message_text(message_type='regular'):
    """الحصول على نص رسالة القوالب المخصصة."""
    message_data = load_template_message()
    if not message_data.get('enabled', True):
        return get_default_template_message().get(f'{message_type}_template_message', '')
    
    if message_type == 'regular':
        return message_data.get('regular_template_message', '')
    elif message_type == 'auto':
        return message_data.get('auto_template_message', '')
    return ''


# --- Maintenance Mode Management Functions ---
def load_maintenance_mode():
    """تحميل إعدادات وضع الصيانة من الملف."""
    if os.path.exists(MAINTENANCE_MODE_FILE):
        with open(MAINTENANCE_MODE_FILE, 'r', encoding='utf-8') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logging.error(f"خطأ في قراءة ملف وضع الصيانة.")
                return {"enabled": False, "message": "⚠️ البوت تحت الصيانة حاليًا. يرجى المحاولة لاحقًا."}
    return {"enabled": False, "message": "⚠️ البوت تحت الصيانة حاليًا. يرجى المحاولة لاحقًا."}

def save_maintenance_mode(mode_data):
    """حفظ إعدادات وضع الصيانة إلى الملف."""
    try:
        with open(MAINTENANCE_MODE_FILE, 'w', encoding='utf-8') as f:
            json.dump(mode_data, f, indent=4, ensure_ascii=False)
        return True
    except IOError as e:
        logging.error(f"فشل في حفظ وضع الصيانة: {e}")
        return False

def toggle_maintenance_mode():
    """تفعيل/تعطيل وضع الصيانة."""
    mode_data = load_maintenance_mode()
    mode_data['enabled'] = not mode_data.get('enabled', False)
    return save_maintenance_mode(mode_data)

def update_maintenance_message(message_text):
    """تحديث رسالة وضع الصيانة."""
    mode_data = load_maintenance_mode()
    mode_data['message'] = message_text
    return save_maintenance_mode(mode_data)

def is_maintenance_mode_enabled():
    """التحقق من تفعيل وضع الصيانة."""
    mode_data = load_maintenance_mode()
    return mode_data.get('enabled', False)

def get_maintenance_message():
    """الحصول على رسالة وضع الصيانة."""
    mode_data = load_maintenance_mode()
    return mode_data.get('message', '⚠️ البوت تحت الصيانة حاليًا. يرجى المحاولة لاحقًا.')


# --- Summary Mode Management Functions ---
def load_summary_mode():
    """تحميل إعدادات وضع الموجز من الملف."""
    if os.path.exists(SUMMARY_MODE_FILE):
        with open(SUMMARY_MODE_FILE, 'r', encoding='utf-8') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logging.error(f"خطأ في قراءة ملف وضع الموجز.")
                return {"enabled_users": {}, "send_time": "20:00"}
    return {"enabled_users": {}, "send_time": "20:00"}

def save_summary_mode(summary_data):
    """حفظ إعدادات وضع الموجز إلى الملف."""
    try:
        with open(SUMMARY_MODE_FILE, 'w', encoding='utf-8') as f:
            json.dump(summary_data, f, indent=4, ensure_ascii=False)
        return True
    except IOError as e:
        logging.error(f"فشل في حفظ وضع الموجز: {e}")
        return False

def add_user_to_summary(user_id):
    """إضافة مستخدم لوضع الموجز."""
    summary_data = load_summary_mode()
    summary_data['enabled_users'][str(user_id)] = True
    return save_summary_mode(summary_data)

def remove_user_from_summary(user_id):
    """إزالة مستخدم من وضع الموجز."""
    summary_data = load_summary_mode()
    if str(user_id) in summary_data['enabled_users']:
        del summary_data['enabled_users'][str(user_id)]
    return save_summary_mode(summary_data)

def set_summary_send_time(time_str):
    """تحديد وقت إرسال الموجز (بصيغة HH:MM)."""
    summary_data = load_summary_mode()
    summary_data['send_time'] = time_str
    return save_summary_mode(summary_data)

def is_user_in_summary(user_id):
    """التحقق من وجود مستخدم في قائمة الموجز."""
    summary_data = load_summary_mode()
    return str(user_id) in summary_data.get('enabled_users', {})


# --- Scheduled Reminders Management Functions ---
def load_scheduled_reminders():
    """تحميل التذكيرات المجدولة من الملف."""
    if os.path.exists(SCHEDULED_REMINDERS_FILE):
        with open(SCHEDULED_REMINDERS_FILE, 'r', encoding='utf-8') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logging.error(f"خطأ في قراءة ملف التذكيرات المجدولة.")
                return {"enabled": False, "interval_days": 1, "last_sent": None, "title": "تذكير مجدول", "message": "هذا تذكير مجدول من البوت."}
    return {"enabled": False, "interval_days": 1, "last_sent": None, "title": "تذكير مجدول", "message": "هذا تذكير مجدول من البوت."}

def save_scheduled_reminders(reminder_data):
    """حفظ التذكيرات المجدولة إلى الملف."""
    try:
        with open(SCHEDULED_REMINDERS_FILE, 'w', encoding='utf-8') as f:
            json.dump(reminder_data, f, indent=4, ensure_ascii=False)
        return True
    except IOError as e:
        logging.error(f"فشل في حفظ التذكيرات المجدولة: {e}")
        return False

def toggle_scheduled_reminder():
    """تفعيل/تعطيل التذكيرات المجدولة."""
    reminder_data = load_scheduled_reminders()
    reminder_data['enabled'] = not reminder_data.get('enabled', False)
    return save_scheduled_reminders(reminder_data)

def set_scheduled_interval(days):
    """تحديد فترة التذكير المجدول (بالأيام)."""
    reminder_data = load_scheduled_reminders()
    reminder_data['interval_days'] = days
    return save_scheduled_reminders(reminder_data)

def update_scheduled_reminder_content(title, message):
    """تحديث محتوى التذكير المجدول."""
    reminder_data = load_scheduled_reminders()
    reminder_data['title'] = title
    reminder_data['message'] = message
    return save_scheduled_reminders(reminder_data)


# --- User Daily Statistics Functions ---
def load_user_daily_stats():
    """تحميل إحصائيات المستخدمين اليومية."""
    if os.path.exists(USER_DAILY_STATS_FILE):
        with open(USER_DAILY_STATS_FILE, 'r', encoding='utf-8') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logging.error(f"خطأ في قراءة ملف الإحصائيات اليومية.")
                return {}
    return {}

def save_user_daily_stats(stats_data):
    """حفظ إحصائيات المستخدمين اليومية."""
    try:
        with open(USER_DAILY_STATS_FILE, 'w', encoding='utf-8') as f:
            json.dump(stats_data, f, indent=4, ensure_ascii=False)
        return True
    except IOError as e:
        logging.error(f"فشل في حفظ الإحصائيات اليومية: {e}")
        return False

def track_user_activity(user_id, activity_type):
    """تتبع نشاط المستخدم."""
    stats = load_user_daily_stats()
    today = get_iraq_time().strftime('%Y-%m-%d')
    current_hour = get_iraq_time().hour
    
    user_key = str(user_id)
    if user_key not in stats:
        stats[user_key] = {}
    
    if today not in stats[user_key]:
        stats[user_key][today] = {
            'messages': 0,
            'services': {},
            'peak_hours': {},
            'total_activities': 0
        }
    
    # Track message count
    if activity_type == 'message':
        stats[user_key][today]['messages'] += 1
    else:
        # Track service usage
        if activity_type not in stats[user_key][today]['services']:
            stats[user_key][today]['services'][activity_type] = 0
        stats[user_key][today]['services'][activity_type] += 1
    
    # Track peak hours
    hour_key = str(current_hour)
    if hour_key not in stats[user_key][today]['peak_hours']:
        stats[user_key][today]['peak_hours'][hour_key] = 0
    stats[user_key][today]['peak_hours'][hour_key] += 1
    
    stats[user_key][today]['total_activities'] += 1
    
    save_user_daily_stats(stats)

def generate_user_summary(user_id):
    """إنشاء موجز نشاط المستخدم لليوم."""
    stats = load_user_daily_stats()
    today = get_iraq_time().strftime('%Y-%m-%d')
    user_key = str(user_id)
    
    if user_key not in stats or today not in stats[user_key]:
        return "📊 *موجز نشاطك اليوم*\n\nلا توجد أنشطة مسجلة لهذا اليوم."
    
    day_stats = stats[user_key][today]
    
    summary = f"📊 *موجز نشاطك اليوم ({today})*\n\n"
    summary += f"💬 *الرسائل المرسلة:* {day_stats['messages']}\n"
    summary += f"⚡ *إجمالي الأنشطة:* {day_stats['total_activities']}\n\n"
    
    if day_stats['services']:
        summary += "🛠️ *تفصيل استخدام الخدمات:*\n"
        
        # Service emoji and name mapping
        service_names = {
            'إزالة الخلفية': '🖼️ إزالة الخلفية',
            'تحسين الجودة': '✨ تحسين الجودة',
            'قالب 3x4': '📸 قالب المعاملات (3×4 سم)',
            'قالب جديد': '📸 قالب الجوازات (3.5×4.5 سم)',
            'قالب متعدد 6x3': '👥 القالب متعدد (6×3)',
            'قالب متعدد 5x4': '👥 القالب متعدد (5×4)',
            'معالجة تلقائية أصلي': '🤖 معالجة تلقائية المعاملات (3×4)',
            'معالجة تلقائية جديد': '🤖 معالجة تلقائية الجوازات (3.5×4.5)',
            'معالجة تلقائية متعدد 6x3': '🤖 معالجة تلقائية (6×3)',
            'معالجة تلقائية متعدد 5x4': '🤖 معالجة تلقائية (5×4)',
            'PDF': '📄 قسم PDF'
        }
        
        for service, count in sorted(day_stats['services'].items(), key=lambda x: x[1], reverse=True):
            # Get nice name or use original
            display_name = service_names.get(service, f"• {service}")
            summary += f"{display_name}: {count} مرة\n"
        summary += "\n"
    
    if day_stats['peak_hours']:
        # Find peak hour
        peak_hour = max(day_stats['peak_hours'], key=day_stats['peak_hours'].get)
        peak_count = day_stats['peak_hours'][peak_hour]
        summary += f"⏰ *ساعة الذروة:* {peak_hour}:00 ({peak_count} نشاط)\n"
    
    return summary

def add_version_feature(feature):
    """إضافة ميزة جديدة للإصدار."""
    version_data = load_bot_version()
    if 'features' not in version_data:
        version_data['features'] = []
    version_data['features'].append(feature)
    return save_bot_version(version_data)

def get_version_info():
    """الحصول على معلومات الإصدار الكاملة."""
    version_data = load_bot_version()
    
    info = f"🔢 *معلومات الإصدار الحالي*\n\n"
    info += f"📌 *الإصدار:* `{version_data['version']}`\n"
    info += f"🏗️ *رقم البناء:* `{version_data['build']}`\n"
    info += f"📅 *تاريخ الإصدار:* `{version_data['release_date']}`\n"
    info += f"🎯 *الحالة:* {version_data.get('status', 'مستقر')}\n"
    
    if version_data.get('features'):
        info += f"\n✨ *الميزات الجديدة:*\n"
        for idx, feature in enumerate(version_data['features'], 1):
            info += f"{idx}. {feature}\n"
    
    return info


# --- Bot Status and Uptime Functions ---
BOT_START_TIME = get_iraq_time()

def get_bot_uptime():
    """Calculate bot uptime."""
    uptime = get_iraq_time() - BOT_START_TIME
    days = uptime.days
    hours, remainder = divmod(uptime.seconds, 3600)
    minutes, _ = divmod(remainder, 60)
    return f"{days} يوم | {hours} ساعة | {minutes} دقيقة"

def get_bot_status():
    """Get comprehensive bot status."""
    current_time = get_iraq_time()
    
    # Test database connection
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        db_connected = loop.run_until_complete(db.test_connection())
        loop.close()
        db_status = "✅ متصل" if db_connected else "❌ غير متصل"
    except Exception as e:
        logging.error(f"Database connection test failed: {e}")
        db_status = "❌ خطأ في الاتصال"
    
    uptime = get_bot_uptime()
    
    # Get version information
    version_data = load_bot_version()
    show_version = version_data.get('show_in_status', True)
    
    # Convert start time to Iraq timezone first
    iraq_tz = pytz.timezone('Asia/Baghdad')
    bot_start_iraq = BOT_START_TIME.astimezone(iraq_tz)
    
    # Format time in 12-hour format with AM/PM
    current_time_12h = to_english_numerals(current_time.strftime('%d/%m/%Y - %I:%M %p'))
    start_time_12h = to_english_numerals(bot_start_iraq.strftime('%d/%m/%Y - %I:%M:%S %p'))
    
    status_message = (
        f"📊 *حالة البوت في :* {current_time_12h}\n"
        f"\n"
        f"🗄️ *اتصال قاعدة البيانات:* {db_status}\n"
        f"⏰ *وقت التشغيل:* {to_english_numerals(uptime)}\n"
        f"🚀 *وقت البدء:* {start_time_12h}\n"
    )
    
    # Add version information if enabled
    if show_version:
        import re
        match = re.match(r'(\d+)\.(\d+)\.(\d+)', version_data['version'])
        major, minor, patch = map(int, match.groups()) if match else (2, 0, 0)
        build = version_data.get('build', 1)
        status = version_data.get('status', 'مستقر')
        release_date = version_data.get('release_date', 'غير محدد')
        
        # Get component visibility settings
        show_components = version_data.get('show_components', {
            'major': True,
            'minor': True,
            'patch': True,
            'build': True,
            'status': True,
            'release_date': True
        })
        
        status_message += f"\n🔢 *معلومات الإصدار:*\n"
        
        # Build version string dynamically based on visible components
        version_parts = []
        if show_components.get('major', True):
            version_parts.append(str(major))
        if show_components.get('minor', True):
            version_parts.append(str(minor))
        if show_components.get('patch', True):
            version_parts.append(str(patch))
        
        if version_parts:
            version_str = '.'.join(version_parts)
            if show_components.get('build', True):
                version_str += f" Build {build}"
            status_message += f"• الإصدار: `{to_english_numerals(version_str)}`\n"
        
        if show_components.get('status', True):
            status_message += f"• الحالة: {status}\n"
        
        if show_components.get('release_date', True):
            status_message += f"• تاريخ الإصدار: {to_english_numerals(release_date)}\n"
        
        # Add features if available
        if version_data.get('features'):
            status_message += f"• الميزات: {len(version_data['features'])} ميزة جديدة"
    
    return status_message


# --- Periodic Reminder Check Function ---
def check_scheduled_reminders():
    """فحص وإرسال التذكيرات المجدولة للمالك."""
    try:
        reminder_data = load_scheduled_reminders()
        
        if not reminder_data.get('enabled', False):
            return
        
        interval_days = reminder_data.get('interval_days', 1)
        last_sent = reminder_data.get('last_sent')
        
        current_time = get_iraq_time()
        should_send = False
        
        if last_sent is None:
            should_send = True
        else:
            try:
                last_sent_time = datetime.strptime(last_sent, '%Y-%m-%d %H:%M:%S')
                last_sent_time = IRAQ_TZ.localize(last_sent_time)
                time_diff = current_time - last_sent_time
                
                if time_diff.total_seconds() >= (interval_days * 24 * 60 * 60):
                    should_send = True
            except Exception as e:
                logging.error(f"Error parsing last_sent time: {e}")
                should_send = True
        
        if should_send:
            title = reminder_data.get('title', 'تذكير مجدول')
            message = reminder_data.get('message', 'هذا تذكير مجدول من البوت.')
            
            reminder_text = f"🔔 *{title}*\n\n{message}\n\n⏰ التكرار: كل {interval_days} يوم"
            
            send_message(ADMIN_ID, reminder_text, parse_mode='Markdown')
            
            reminder_data['last_sent'] = current_time.strftime('%Y-%m-%d %H:%M:%S')
            save_scheduled_reminders(reminder_data)
            
            logging.info(f"Scheduled reminder sent to admin")
    except Exception as e:
        logging.error(f"Error in check_scheduled_reminders: {e}")


def send_daily_summary():
    """إرسال الموجز اليومي للمستخدمين المفعلين."""
    try:
        summary_data = load_summary_mode()
        enabled_users = summary_data.get('enabled_users', {})
        
        if not enabled_users:
            return
        
        for user_id_str in enabled_users.keys():
            try:
                user_id = int(user_id_str)
                
                # Use the detailed summary function
                summary_text = generate_user_summary(user_id)
                
                # Add footer
                summary_text += f"\n\n❤️ شكرًا لاستخدامك البوت!"
                
                send_message(user_id, summary_text, parse_mode='Markdown')
                logging.info(f"Daily summary sent to user {user_id}")
            except Exception as e:
                logging.error(f"Error sending summary to user {user_id_str}: {e}")
    except Exception as e:
        logging.error(f"Error in send_daily_summary: {e}")


def start_reminder_checker():
    """Start the reminder checker in a separate thread."""
    import threading
    
    def reminder_checker():
        last_summary_date = None
        
        while True:
            try:
                check_and_send_reminders()
                check_scheduled_reminders()
                
                current_time = get_iraq_time()
                summary_data = load_summary_mode()
                send_time = summary_data.get('send_time', '20:00')
                
                try:
                    summary_hour, summary_minute = map(int, send_time.split(':'))
                    current_date = current_time.date()
                    
                    if (current_time.hour == summary_hour and 
                        current_time.minute == summary_minute and 
                        last_summary_date != current_date):
                        send_daily_summary()
                        last_summary_date = current_date
                except Exception as e:
                    logging.error(f"Error checking summary time: {e}")
                
                time.sleep(60)
            except Exception as e:
                logging.error(f"Error in reminder checker: {e}")
                time.sleep(60)
    
    reminder_thread = threading.Thread(target=reminder_checker, daemon=True)
    reminder_thread.start()
    logging.info("Reminder checker started")


def daily_full_cleanup_job():
    """نظام تنظيف يومي احتياطي - يحذف جميع الملفات من temp_pdf و word_files بدون استثناء."""
    import glob
    import shutil
    
    cleanup_dirs = [
        (TEMP_PDF_DIR, "ملفات PDF المؤقتة"),
        (WORD_FILES_DIR, "ملفات الوورد المؤقتة"),
    ]
    
    for dir_path, dir_name in cleanup_dirs:
        if not os.path.exists(dir_path):
            continue
        
        try:
            deleted_count = 0
            for file_path in glob.glob(os.path.join(dir_path, "*")):
                if os.path.isfile(file_path):
                    try:
                        os.remove(file_path)
                        deleted_count += 1
                    except Exception as e:
                        logging.warning(f"⚠️ لم يتم حذف: {file_path}: {e}")
            
            if deleted_count > 0:
                logging.info(f"🧹 تنظيف يومي: تم حذف {deleted_count} ملف من {dir_name}")
        except Exception as e:
            logging.error(f"❌ خطأ في التنظيف اليومي ({dir_name}): {e}")


def start_daily_cleanup_thread():
    """بدء thread احتياطي يقوم بتنظيف يومي شامل في منتصف الليل."""
    import threading
    
    def daily_cleanup_checker():
        last_cleanup_date = None
        
        while True:
            try:
                current_time = get_iraq_time()
                cleanup_hour = 0  # منتصف الليل (12 صباحاً)
                cleanup_minute = 0
                current_date = current_time.date()
                
                # تنفيذ التنظيف كل يوم في الساعة المحددة
                if (current_time.hour == cleanup_hour and 
                    current_time.minute == cleanup_minute and 
                    last_cleanup_date != current_date):
                    
                    logging.info("🧹 بدء التنظيف اليومي الشامل...")
                    daily_full_cleanup_job()
                    last_cleanup_date = current_date
                    logging.info("✅ انتهى التنظيف اليومي الشامل")
                
                # فحص كل دقيقة
                time.sleep(60)
            except Exception as e:
                logging.error(f"❌ خطأ في thread التنظيف اليومي: {e}")
                time.sleep(60)
    
    cleanup_thread = threading.Thread(target=daily_cleanup_checker, daemon=True)
    cleanup_thread.start()
    logging.info("✅ بدء thread التنظيف اليومي الاحتياطي")


# ═══════════════════════════════════════════════════════
# XKA KEEP-ALIVE  –  Supabase Storage Ping System
# ═══════════════════════════════════════════════════════

def xka_load_log():
    """Load XKA keep-alive log from JSON file."""
    try:
        if os.path.exists(XKA_KEEPALIVE_LOG_FILE):
            with open(XKA_KEEPALIVE_LOG_FILE, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception as e:
        logging.error(f"xka_load_log error: {e}")
    return {
        "last_upload_time": None,
        "last_upload_success": None,
        "last_delete_time": None,
        "last_delete_success": None,
        "next_upload_time": None,
        "total_uploads": 0,
        "total_deletes": 0,
        "total_failures": 0,
    }


def xka_save_log(log: dict):
    """Persist XKA keep-alive log to JSON file."""
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(XKA_KEEPALIVE_LOG_FILE, 'w', encoding='utf-8') as f:
            json.dump(log, f, ensure_ascii=False, indent=2)
    except Exception as e:
        logging.error(f"xka_save_log error: {e}")


def xka_upload():
    """Upload KA.pdf to Supabase Storage. Returns True on success."""
    try:
        if not os.path.exists(XKA_FILE_PATH):
            logging.error("xka_upload: assets/KA.pdf not found locally")
            return False

        with open(XKA_FILE_PATH, 'rb') as f:
            file_data = f.read()

        # Remove existing file first (ignore errors) to allow re-upload
        try:
            db.supabase.storage.from_(XKA_BUCKET).remove([XKA_STORAGE_PATH])
        except Exception:
            pass

        response = db.supabase.storage.from_(XKA_BUCKET).upload(
            XKA_STORAGE_PATH, file_data,
            {"content-type": "application/pdf", "upsert": "true"}
        )
        success = response is not None
        logging.info(f"xka_upload: {'✅ success' if success else '❌ failed'}")
        return success
    except Exception as e:
        logging.error(f"xka_upload error: {e}")
        return False


def xka_delete():
    """Delete KA.pdf from Supabase Storage. Returns True on success."""
    try:
        response = db.supabase.storage.from_(XKA_BUCKET).remove([XKA_STORAGE_PATH])
        success = response is not None
        logging.info(f"xka_delete: {'✅ success' if success else '❌ failed'}")
        return success
    except Exception as e:
        logging.error(f"xka_delete error: {e}")
        return False


def xka_run_cycle():
    """Full keep-alive cycle: upload then schedule deletion after 1 hour."""
    baghdad = pytz.timezone('Asia/Baghdad')
    now_str = datetime.now(baghdad).strftime('%Y-%m-%d %H:%M:%S')

    log = xka_load_log()

    # --- Upload ---
    upload_ok = xka_upload()
    log["last_upload_time"] = now_str
    log["last_upload_success"] = upload_ok
    if upload_ok:
        log["total_uploads"] = log.get("total_uploads", 0) + 1
    else:
        log["total_failures"] = log.get("total_failures", 0) + 1

    # Calculate next upload (tomorrow same hour)
    baghdad_now = datetime.now(baghdad)
    next_upload = baghdad_now.replace(
        hour=XKA_UPLOAD_HOUR_BAGHDAD, minute=0, second=0, microsecond=0
    )
    if next_upload <= baghdad_now:
        from datetime import timedelta
        next_upload += timedelta(days=1)
    log["next_upload_time"] = next_upload.strftime('%Y-%m-%d %H:%M:%S')

    xka_save_log(log)
    logging.info(f"XKA keep-alive upload done (success={upload_ok}). Next: {log['next_upload_time']}")

    # --- Schedule deletion after 1 hour ---
    def delayed_delete():
        time.sleep(XKA_DELETE_DELAY_SECONDS)
        del_ok = xka_delete()
        del_log = xka_load_log()
        baghdad_del = pytz.timezone('Asia/Baghdad')
        del_log["last_delete_time"] = datetime.now(baghdad_del).strftime('%Y-%m-%d %H:%M:%S')
        del_log["last_delete_success"] = del_ok
        if del_ok:
            del_log["total_deletes"] = del_log.get("total_deletes", 0) + 1
        else:
            del_log["total_failures"] = del_log.get("total_failures", 0) + 1
        xka_save_log(del_log)
        logging.info(f"XKA keep-alive delete done (success={del_ok})")

    del_thread = threading.Thread(target=delayed_delete, daemon=True)
    del_thread.start()


def start_xka_keepalive_thread():
    """Background thread: runs xka_run_cycle daily at XKA_UPLOAD_HOUR_BAGHDAD (Baghdad time)."""

    def checker():
        baghdad = pytz.timezone('Asia/Baghdad')
        last_run_date = None

        # Compute initial next_upload and save to log if empty
        log = xka_load_log()
        if not log.get("next_upload_time"):
            now = datetime.now(baghdad)
            from datetime import timedelta
            nxt = now.replace(hour=XKA_UPLOAD_HOUR_BAGHDAD, minute=0, second=0, microsecond=0)
            if nxt <= now:
                nxt += timedelta(days=1)
            log["next_upload_time"] = nxt.strftime('%Y-%m-%d %H:%M:%S')
            xka_save_log(log)

        while True:
            try:
                now = datetime.now(baghdad)
                today = now.date()
                if (now.hour == XKA_UPLOAD_HOUR_BAGHDAD and
                        now.minute == 0 and
                        last_run_date != today):
                    last_run_date = today
                    logging.info("♻️ XKA Keep-Alive: starting daily cycle...")
                    xka_run_cycle()
                time.sleep(60)
            except Exception as e:
                logging.error(f"xka keepalive thread error: {e}")
                time.sleep(60)

    t = threading.Thread(target=checker, daemon=True)
    t.start()
    logging.info("✅ XKA Keep-Alive scheduler started (daily at 03:00 Baghdad)")


def xka_build_status_text():
    """Build a formatted status message for the admin Keep-Alive panel."""
    log = xka_load_log()
    baghdad = pytz.timezone('Asia/Baghdad')
    now_str = datetime.now(baghdad).strftime('%Y-%m-%d %H:%M:%S')

    def fmt(val, ok_key=None):
        if val is None:
            return "لم يحدث بعد"
        status = ""
        if ok_key is not None:
            status = " ✅" if log.get(ok_key) else " ❌"
        return f"`{val}`{status}"

    delete_info = ""
    last_del = log.get("last_delete_time")
    if last_del and log.get("last_upload_time") and last_del > log["last_upload_time"]:
        # Last delete is after last upload → currently deleted
        storage_status = "🗑️ محذوف حالياً (دورة مكتملة)"
    elif log.get("last_upload_success"):
        storage_status = "📄 مرفوع في التخزين (انتظار الحذف)"
    else:
        storage_status = "⏸️ غير نشط"

    text = (
        "♻️ *Keep-Alive · XKA Supabase Ping*\n\n"
        f"📅 الوقت الحالي (بغداد): `{now_str}`\n"
        f"🗂️ المسار: `{XKA_BUCKET}/{XKA_STORAGE_PATH}`\n"
        f"⏰ وقت الإرسال اليومي: `03:00 AM (Baghdad)`\n"
        f"⏳ مدة البقاء في التخزين: `1 ساعة`\n\n"
        "📤 *آخر رفع:*\n"
        f"  🕐 الوقت: {fmt(log.get('last_upload_time'), 'last_upload_success')}\n\n"
        "🗑️ *آخر حذف:*\n"
        f"  🕐 الوقت: {fmt(log.get('last_delete_time'), 'last_delete_success')}\n\n"
        "🔮 *الإرسال القادم:*\n"
        f"  📆 {fmt(log.get('next_upload_time'))}\n\n"
        "📊 *إحصائيات:*\n"
        f"  ✅ إجمالي الرفعات: `{log.get('total_uploads', 0)}`\n"
        f"  🗑️ إجمالي الحذفات: `{log.get('total_deletes', 0)}`\n"
        f"  ❌ إجمالي الأخطاء: `{log.get('total_failures', 0)}`\n\n"
        f"💾 *حالة التخزين:* {storage_status}"
    )
    return text


# --- Admin Panel Helper Functions ---
def show_admin_panel(chat_id, user_id, message_id=None):
    """Display the main admin panel."""
    admin_text = (
        "⚙️ *لوحة تحكم المالك*\n\n"
        "اختر القسم الذي تريد إدارته:"
    )
    
    admin_buttons = [
        [{'text': '👥 إدارة المستخدمين', 'callback_data': 'admin_section_users'}],
        [{'text': '🚫 إدارة الحظر', 'callback_data': 'admin_section_ban'}],
        [{'text': '📋 القوائم', 'callback_data': 'admin_section_lists'}],
        [{'text': '📊 الإحصائيات', 'callback_data': 'admin_section_stats'}],
        [{'text': '💾 النسخ الاحتياطي', 'callback_data': 'admin_section_backup'}],
        [{'text': '🔑 إدارة المفاتيح', 'callback_data': 'admin_section_keys'}],
        [{'text': '🗄️ إدارة قاعدة البيانات', 'callback_data': 'admin_section_database'}],
        [{'text': '⏰ إدارة التذكيرات', 'callback_data': 'admin_section_reminders'}],
        [{'text': '🔢 إدارة الإصدار', 'callback_data': 'admin_section_version'}],
        [{'text': '⬅️ رجوع للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, admin_text, admin_buttons, message_id, 'admin_main_menu', {})


def show_admin_users_menu(chat_id, user_id, message_id=None):
    """Display the users management menu."""
    users_text = "👥 *إدارة المستخدمين*\n\nاختر العملية:"
    
    users_buttons = [
        [{'text': '➕ إضافة مستخدم', 'callback_data': 'admin_add_user'}],
        [{'text': '🗑️ حذف مستخدم', 'callback_data': 'admin_delete_user'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_back_to_main'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, users_text, users_buttons, message_id, 'admin_users_menu', {})


def show_admin_ban_menu(chat_id, user_id, message_id=None):
    """Display the ban management menu."""
    ban_text = "🚫 *إدارة الحظر*\n\nاختر العملية:"
    
    ban_buttons = [
        [{'text': '🚫 حظر مستخدم', 'callback_data': 'admin_ban_user'}],
        [{'text': '✅ إلغاء حظر مستخدم', 'callback_data': 'admin_unban_user'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_back_to_main'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, ban_text, ban_buttons, message_id, 'admin_ban_menu', {})


def show_admin_lists_menu(chat_id, user_id, message_id=None):
    """Display the lists menu."""
    lists_text = "📋 *القوائم*\n\nاختر القائمة التي تريد عرضها:"
    
    lists_buttons = [
        [{'text': '✅ المستخدمون المسموح لهم', 'callback_data': 'admin_view_allowed'}],
        [{'text': '🚫 المستخدمون المحظورون', 'callback_data': 'admin_view_banned'}],
        [{'text': '⏳ الطلبات المعلقة', 'callback_data': 'admin_view_pending'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_back_to_main'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, lists_text, lists_buttons, message_id, 'admin_lists_menu', {})


def show_admin_backup_menu(chat_id, user_id, message_id=None):
    """Display the backup menu."""
    backup_text = "💾 *النسخ الاحتياطي*\n\nاختر العملية:"
    
    backup_buttons = [
        [{'text': '💾 إنشاء نسخة احتياطية', 'callback_data': 'admin_perform_backup'}],
        [{'text': '📥 استعادة من نسخة احتياطية', 'callback_data': 'admin_restore_backup'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_back_to_main'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, backup_text, backup_buttons, message_id, 'admin_backup_menu', {})


def show_admin_keys_menu(chat_id, user_id, message_id=None):
    """Display the API keys management menu."""
    keys_text = ""
    
    keys_buttons = [
        [{'text': '🛠️ Remove.bg', 'callback_data': 'admin_keys_removebg'}],
        [{'text': '✨ Picsart', 'callback_data': 'admin_keys_picsart'}],
        [{'text': '🎨 ConvertAPI', 'callback_data': 'admin_keys_convertapi'}],
        [{'text': '💫 AILabAPI (تبييض)', 'callback_data': 'admin_keys_ailab'}],
        [{'text': '🤖 Gemini AI (تعديل/إنشاء)', 'callback_data': 'admin_keys_gemini'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_back_to_main'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, keys_text, keys_buttons, message_id, 'admin_keys_menu', {})


def show_admin_database_menu(chat_id, user_id, message_id=None):
    """Display the database management menu."""
    database_text = "🗄️ *إدارة قاعدة البيانات*\n\nاختر العملية:"
    
    database_buttons = [
        [{'text': '📊 معلومات مساحة التخزين', 'callback_data': 'admin_db_storage_info'}],
        [{'text': '📋 عرض جميع الملفات', 'callback_data': 'admin_db_all_files'}],
        [{'text': '💾 نسخة احتياطية', 'callback_data': 'admin_create_pdf_backup'}],
        [{'text': '📥 استعادة نسخة', 'callback_data': 'admin_restore_pdf_backup'}],
        [{'text': '🗑️ حذف جميع الملفات', 'callback_data': 'admin_db_delete_menu'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_back_to_main'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, database_text, database_buttons, message_id, 'admin_database_menu', {})

def show_admin_delete_files_menu(chat_id, user_id, message_id=None):
    """Display the delete files submenu."""
    delete_text = "🗑️ *حذف الملفات*\n\nاختر نوع الملفات المراد حذفها:"
    
    delete_buttons = [
        [{'text': '🗑️ حذف جميع الملفات (عادية + قوالب)', 'callback_data': 'admin_db_delete_all'}],
        [{'text': '📋 حذف ملفات القوالب فقط', 'callback_data': 'admin_db_delete_templates'}],
        [{'text': '📄 حذف الملفات العادية فقط', 'callback_data': 'admin_db_delete_regular'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_section_database'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, delete_text, delete_buttons, message_id, 'admin_delete_files_menu', {})


def show_admin_reminders_menu(chat_id, user_id, message_id=None):
    """Display the reminders management menu."""
    reminders_text = "⏰ *إدارة التذكيرات*\n\nاختر العملية:"
    
    reminders_buttons = [
        [{'text': '➕ إضافة تذكير', 'callback_data': 'admin_add_reminder'}],
        [{'text': '✏️ تعديل تذكير', 'callback_data': 'admin_edit_reminder'}],
        [{'text': '🗑️ حذف تذكير', 'callback_data': 'admin_delete_reminder'}],
        [{'text': '👀 عرض جميع التذكيرات', 'callback_data': 'admin_view_reminders'}],
        [{'text': '📅 تذكير مجدول', 'callback_data': 'admin_scheduled_reminder'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_back_to_main'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, reminders_text, reminders_buttons, message_id, 'admin_reminders_menu', {})

def show_scheduled_reminder_menu(chat_id, user_id, message_id=None):
    """Display the scheduled reminder management menu."""
    reminder_data = load_scheduled_reminders()
    current_status = "✅ مفعل" if reminder_data.get('enabled', False) else "❌ معطل"
    interval_days = reminder_data.get('interval_days', 1)
    last_sent = reminder_data.get('last_sent', 'لم يُرسل بعد')
    
    text = f"*📅 التذكير المجدول*\n\n"
    text += f"الحالة: {current_status}\n"
    text += f"الفترة: كل {interval_days} يوم\n"
    text += f"آخر إرسال: {last_sent}\n\n"
    text += "اختر العملية:"
    
    buttons = [
        [{'text': '🔄 تفعيل/تعطيل', 'callback_data': 'admin_toggle_scheduled'}],
        [{'text': '⏱️ تحديد الفترة (1 يوم)', 'callback_data': 'admin_scheduled_interval_1'}],
        [{'text': '⏱️ تحديد الفترة (2 يوم)', 'callback_data': 'admin_scheduled_interval_2'}],
        [{'text': '⏱️ تحديد الفترة (3 أيام)', 'callback_data': 'admin_scheduled_interval_3'}],
        [{'text': '⏱️ تحديد الفترة (4 أيام)', 'callback_data': 'admin_scheduled_interval_4'}],
        [{'text': '✏️ تعديل المحتوى', 'callback_data': 'admin_edit_scheduled_content'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_section_reminders'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, text, buttons, message_id, 'admin_scheduled_reminder_menu')


def show_admin_version_menu(chat_id, user_id, message_id=None):
    """Display the version management menu with advanced controls."""
    version_data = load_bot_version()
    current_version = get_version_string()
    english_version = to_english_numerals(current_version)
    
    # Parse version components
    import re
    match = re.match(r'(\d+)\.(\d+)\.(\d+)', version_data['version'])
    major, minor, patch = map(int, match.groups()) if match else (2, 0, 0)
    build = version_data.get('build', 1)
    status = version_data.get('status', 'مستقر')
    release_date = version_data.get('release_date', 'غير محدد')
    
    # Get display status for each component
    show_major = get_component_display_status('major')
    show_minor = get_component_display_status('minor')
    show_patch = get_component_display_status('patch')
    show_build = get_component_display_status('build')
    
    version_text = f"🔢 *إدارة الإصدار المتقدمة*\n\n"
    version_text += f"📌 *الإصدار الحالي:* `{english_version}`\n"
    version_text += f"🏗️ *رقم البناء:* `{build}`\n"
    version_text += f"🎯 *الحالة:* {status}\n\n"
    version_text += f"🔧 *مكونات الإصدار:*\n"
    version_text += f"• الرقم الرئيسي: `{major}` {'✅' if show_major else '❌'}\n"
    version_text += f"• الرقم الثانوي: `{minor}` {'✅' if show_minor else '❌'}\n"
    version_text += f"• رقم الإصلاح: `{patch}` {'✅' if show_patch else '❌'}\n"
    version_text += f"• رقم البناء: `{build}` {'✅' if show_build else '❌'}\n\n"
    version_text += f"💡 *ملاحظة:* اختر مكون لإدارته (✅ = يظهر في /STATUS | ❌ = مخفي)"
    
    major_icon = '✅' if show_major else '❌'
    minor_icon = '✅' if show_minor else '❌'
    patch_icon = '✅' if show_patch else '❌'
    build_icon = '✅' if show_build else '❌'
    
    version_buttons = [
        [{'text': f'🔢 الرقم الرئيسي ({major}) {major_icon}', 'callback_data': 'admin_version_major'}],
        [{'text': f'🔢 الرقم الثانوي ({minor}) {minor_icon}', 'callback_data': 'admin_version_minor'}],
        [{'text': f'🔢 رقم الإصلاح ({patch}) {patch_icon}', 'callback_data': 'admin_version_patch'}],
        [{'text': f'🔢 رقم البناء ({build}) {build_icon}', 'callback_data': 'admin_version_build'}],
        [{'text': f'🎯 تغيير الحالة ({status})', 'callback_data': 'admin_change_status'}],
        [{'text': f'📅 تعديل التاريخ ({release_date})', 'callback_data': 'admin_change_release_date'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_back_to_main'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, version_text, version_buttons, message_id, 'admin_version_menu')

def show_version_component_menu(chat_id, user_id, component_type, message_id=None):
    """Display submenu for a specific version component."""
    version_data = load_bot_version()
    
    # Parse version components
    import re
    match = re.match(r'(\d+)\.(\d+)\.(\d+)', version_data['version'])
    major, minor, patch = map(int, match.groups()) if match else (2, 0, 0)
    build = version_data.get('build', 1)
    
    # Get component value and display status
    component_values = {
        'major': major,
        'minor': minor,
        'patch': patch,
        'build': build
    }
    
    component_names = {
        'major': 'الرقم الرئيسي',
        'minor': 'الرقم الثانوي',
        'patch': 'رقم الإصلاح',
        'build': 'رقم البناء'
    }
    
    current_value = component_values.get(component_type, 0)
    component_name = component_names.get(component_type, component_type)
    is_visible = get_component_display_status(component_type)
    
    menu_text = f"🔢 *إدارة {component_name}*\n\n"
    menu_text += f"📊 *القيمة الحالية:* `{current_value}`\n"
    menu_text += f"👁️ *الحالة في /STATUS:* {'مرئي ✅' if is_visible else 'مخفي ❌'}\n\n"
    menu_text += f"اختر الإجراء:"
    
    buttons = [
        [
            {'text': f'➕ زيادة (+1)', 'callback_data': f'admin_increment_{component_type}'},
            {'text': f'➖ تنقيص (-1)', 'callback_data': f'admin_decrement_{component_type}'}
        ],
        [
            {'text': f'👁️ تفعيل العرض', 'callback_data': f'admin_show_{component_type}'},
            {'text': f'🚫 تعطيل العرض', 'callback_data': f'admin_hide_{component_type}'}
        ],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_section_version'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, menu_text, buttons, message_id, f'admin_version_{component_type}_menu')


# --- PDF Page Conversion Function ---
def handle_pdf_conversion(conversion_type, user_id, chat_id, current_state, page_num=None, end_page=None):
    """تحويل صفحات PDF المحددة إلى صور"""
    start_time = time.time()  # بدء الوقت من هنا - وقت التحويل الفعلي
    
    user_state = get_user_state(user_id)
    pdf_path = user_state.get('data', {}).get('pdf_path')
    file_name = user_state.get('data', {}).get('file_name')
    page_count = user_state.get('data', {}).get('page_count', 1)
    
    if not pdf_path or not os.path.exists(pdf_path):
        send_message(chat_id, "❌ فشل: لم يتم العثور على ملف PDF.")
        clear_user_state(user_id)
        return

    send_message(chat_id, "⏳ جاري تحويل PDF إلى صور...")
    
    try:
        import pypdfium2 as pdfium
        
        pdf_document = pdfium.PdfDocument(pdf_path)
        
        # تحديد الصفحات المراد تحويلها
        if conversion_type == 'all':
            pages_to_convert = list(range(page_count))
        elif conversion_type == 'single':
            pages_to_convert = [page_num - 1]  # تحويل من 1-indexed إلى 0-indexed
        elif conversion_type == 'range':
            pages_to_convert = list(range(page_num - 1, end_page))  # start_page to end_page
        
        # تحويل الصفحات
        for idx in pages_to_convert:
            try:
                page = pdf_document[idx]
                bitmap = page.render(scale=4.0)
                img = bitmap.to_pil()
                
                img_path = os.path.join(TEMP_PDF_DIR, f"pdf_page_{idx+1}_{uuid.uuid4()}.png")
                img.save(img_path, "PNG", quality=95)
                
                try:
                    with open(img_path, 'rb') as img_file:
                        files = {'photo': img_file}
                        caption = f"📄 صفحة {idx+1}/{page_count}"
                        make_request(f"{API_URL}/sendPhoto", method='POST', 
                                   data={'chat_id': chat_id, 'caption': caption},
                                   files=files)
                    logging.info(f"Image sent successfully: Page {idx+1}/{page_count}")
                except Exception as e:
                    logging.error(f"Error sending image: {e}")
                
                try:
                    os.remove(img_path)
                except:
                    pass
            except Exception as page_err:
                logging.error(f"Error processing page {idx+1}: {page_err}")
        
        pdf_document.close()
        
        # حساب الزمن المستغرق
        elapsed_time = time.time() - start_time
        time_str = f"⏱️ الزمن المستغرق: {elapsed_time:.1f} ثانية"
        
        if conversion_type == 'all':
            msg = f"✅ تم تحويل ملف PDF بنجاح!\n📄 الملف الأصلي: {file_name}\n🖼️ عدد الصور: {page_count}\n{time_str}"
        elif conversion_type == 'single':
            msg = f"✅ تم تحويل الصفحة {page_num} بنجاح!\n📄 الملف الأصلي: {file_name}\n{time_str}"
        else:
            msg = f"✅ تم تحويل الصفحات {page_num}-{end_page} بنجاح!\n📄 الملف الأصلي: {file_name}\n{time_str}"
        
        send_message(chat_id, msg)
        
    except Exception as e:
        logging.error(f"Error in PDF conversion: {e}")
        send_message(chat_id, f"❌ حدث خطأ: {str(e)}")
    
    finally:
        try:
            os.remove(pdf_path)
        except:
            pass
        clear_user_state(user_id)

# --- Image to PDF Conversion Functions ---
def convert_images_to_pdf(image_paths, output_path, dpi=300):
    """Convert multiple images to a single PDF using img2pdf (lossless, exact colors)."""
    import img2pdf
    from PIL import Image

    temp_files = []
    ready_paths = []
    try:
        for image_path in image_paths:
            if not os.path.exists(image_path):
                continue
            try:
                img = Image.open(image_path)
                # img2pdf requires RGB or L mode (no alpha channel)
                if img.mode in ('RGBA', 'LA', 'P'):
                    bg = Image.new('RGB', img.size, (255, 255, 255))
                    if img.mode == 'P':
                        img = img.convert('RGBA')
                    bg.paste(img, mask=img.split()[-1] if 'A' in img.mode else None)
                    img = bg
                elif img.mode not in ('RGB', 'L'):
                    img = img.convert('RGB')

                # Save as lossless PNG to preserve colors perfectly
                tmp = os.path.join(TEMP_PDF_DIR, f"tmp_i2p_{uuid.uuid4()}.png")
                img.save(tmp, 'PNG')
                temp_files.append(tmp)
                ready_paths.append(tmp)
            except Exception as e:
                logging.error(f"convert_images_to_pdf: error preparing image {image_path}: {e}")

        if not ready_paths:
            logging.error("convert_images_to_pdf: no valid images to convert")
            return False

        layout = img2pdf.get_fixed_dpi_layout_fun((dpi, dpi))
        with open(output_path, 'wb') as f:
            f.write(img2pdf.convert(ready_paths, layout_fun=layout))

        logging.info(f"convert_images_to_pdf: created {output_path} from {len(ready_paths)} images (lossless)")
        return True

    except Exception as e:
        logging.error(f"convert_images_to_pdf error: {e}")
        return False
    finally:
        for tmp in temp_files:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                pass

def create_pdf_from_file_content(file_path, output_pdf):
    """Create a PDF from file content when standard conversion fails."""
    try:
        from reportlab.pdfgen import canvas
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.units import inch
        
        c = canvas.Canvas(output_pdf, pagesize=letter)
        width, height = letter
        
        left_margin = 0.5 * inch
        top_margin = 0.5 * inch
        
        c.setFont("Helvetica", 11)
        y_position = height - top_margin
        
        # Try to read file as text
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                # Write content to PDF in chunks
                lines = content.split('\n')
                for line in lines[:200]:  # Limit to 200 lines
                    if len(line) > 0:
                        c.drawString(left_margin, y_position, line[:100])
                        y_position -= 14
                        if y_position < 40:
                            c.showPage()
                            y_position = height - top_margin
        except Exception as e:
            logging.error(f"Cannot read file as text: {e}")
            c.drawString(left_margin, y_position, "Unable to extract text from file")
            y_position -= 14
        
        c.save()
        return True, output_pdf
    except Exception as e:
        logging.error(f"Error creating PDF from file content: {e}")
        return False, f"خطأ في التحويل: {str(e)}"


def handle_image_to_pdf_conversion(user_id, image_paths):
    """Handle the complete image to PDF conversion process."""
    try:
        if not image_paths:
            return False, "لا توجد صور للتحويل"
        
        # Create output PDF path
        output_pdf = os.path.join(TEMP_PDF_DIR, f"converted_pdf_{user_id}_{uuid.uuid4()}.pdf")
        
        # Convert images to PDF
        if convert_images_to_pdf(image_paths, output_pdf):
            return True, output_pdf
        else:
            return False, "فشل في تحويل الصور إلى PDF"
            
    except Exception as e:
        logging.error(f"Error in image to PDF conversion: {e}")
        return False, f"خطأ في التحويل: {str(e)}"


# --- Word (DOCX) to PDF Conversion Function (ConvertAPI with Key Management) ---
def convert_docx_to_pdf(docx_path, original_filename=""):
    """Convert DOCX to PDF using ConvertAPI REST API with key rotation support."""
    try:
        # Get active API key from key pool
        api_key = get_active_key(CONVERTAPI_KEY_FILE)
        if not api_key:
            logging.error("ConvertAPI key not set - cannot convert DOCX to PDF")
            return False, "❌ خطأ: مفتاح API لـ ConvertAPI غير مُعرّف. تحويل DOCX إلى PDF غير متاح حالياً."
        
        logging.info(f"Starting DOCX to PDF conversion using ConvertAPI REST API: {docx_path}")
        
        # ConvertAPI endpoint
        url = f"https://v2.convertapi.com/convert/docx/to/pdf?Secret={api_key}"
        
        # Create output PDF path
        output_pdf = docx_path.replace('.docx', '.pdf').replace('.doc', '.pdf')
        output_dir = os.path.dirname(output_pdf)
        
        # Upload file and convert
        with open(docx_path, 'rb') as f:
            files = {'file': f}
            response = requests.post(url, files=files, timeout=60)
        
        if response.status_code != 200:
            logging.error(f"ConvertAPI error: {response.status_code} - {response.text[:200]}")
            # Check if it's an auth error and rotate key
            if response.status_code == 401 or response.status_code == 403:
                logging.warning("ConvertAPI authentication failed - rotating key")
                fail_and_rotate_key(CONVERTAPI_KEY_FILE)
            return False, "❌ فشل في تحويل ملف DOCX إلى PDF. يرجى المحاولة مرة أخرى."
        
        # ConvertAPI returns JSON with base64-encoded PDF or PDF directly
        try:
            # Try parsing as JSON first
            if response.headers.get('content-type', '').startswith('application/json'):
                response_data = response.json()
                
                # Extract PDF from JSON response
                if 'Files' in response_data and len(response_data['Files']) > 0:
                    file_data = response_data['Files'][0]
                    pdf_base64 = file_data.get('FileData')
                    
                    if pdf_base64:
                        # Decode base64 to PDF bytes
                        import base64
                        pdf_bytes = base64.b64decode(pdf_base64)
                        
                        # Save PDF
                        with open(output_pdf, 'wb') as pdf_file:
                            pdf_file.write(pdf_bytes)
                        
                        file_size = os.path.getsize(output_pdf)
                        if file_size > 1000:
                            # تتبع استخدام المفتاح
                            increment_usage(CONVERTAPI_KEY_FILE)
                            usage_count = get_usage(CONVERTAPI_KEY_FILE)
                            logging.info(f"PDF successfully created with ConvertAPI: {output_pdf}, size: {file_size} bytes. Usage count: {usage_count}")
                            
                            # فحص التدوير التلقائي
                            rotated, new_key, msg = check_and_rotate_convertapi_key()
                            if rotated:
                                logging.info(f"Auto-rotated ConvertAPI key: {msg}")
                            
                            return True, output_pdf
                        else:
                            os.remove(output_pdf)
                            return False, "❌ فشل في تحويل ملف DOCX إلى PDF. الملف أصغر من المتوقع."
            
            # If not JSON, assume direct PDF binary
            elif response.content.startswith(b'%PDF'):
                with open(output_pdf, 'wb') as pdf_file:
                    pdf_file.write(response.content)
                
                file_size = os.path.getsize(output_pdf)
                if file_size > 1000:
                    # تتبع استخدام المفتاح
                    increment_usage(CONVERTAPI_KEY_FILE)
                    usage_count = get_usage(CONVERTAPI_KEY_FILE)
                    logging.info(f"PDF successfully created with ConvertAPI: {output_pdf}, size: {file_size} bytes. Usage count: {usage_count}")
                    
                    # فحص التدوير التلقائي
                    rotated, new_key, msg = check_and_rotate_convertapi_key()
                    if rotated:
                        logging.info(f"Auto-rotated ConvertAPI key: {msg}")
                    
                    return True, output_pdf
                else:
                    os.remove(output_pdf)
                    return False, "❌ فشل في تحويل ملف DOCX إلى PDF. الملف أصغر من المتوقع."
            
            else:
                logging.error(f"Unexpected response format. Content-Type: {response.headers.get('content-type')}")
                return False, "❌ فشل في تحويل ملف DOCX إلى PDF. يرجى المحاولة مرة أخرى."
        
        except Exception as e:
            logging.error(f"Error processing ConvertAPI response: {type(e).__name__}: {e}")
            return False, f"❌ خطأ في معالجة الرد: {str(e)}"
        
    except Exception as e:
        logging.error(f"Error in ConvertAPI conversion: {type(e).__name__}: {e}")
        return False, f"❌ خطأ في التحويل: {str(e)}"


def convert_docx_to_pdf_fallback(docx_path, output_pdf):
    """Fallback DOCX to PDF conversion using python-docx and reportlab."""
    try:
        from docx import Document
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfgen import canvas
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import inch
        
        logging.info(f"Using fallback conversion method for: {docx_path}")
        
        # Load the DOCX file
        doc = Document(docx_path)
        
        # Create PDF using platypus for better formatting
        pdf_file = SimpleDocTemplate(output_pdf, pagesize=A4)
        styles = getSampleStyleSheet()
        story = []
        
        # Add paragraph style for Arabic text
        style = ParagraphStyle(
            'Arabic',
            parent=styles['BodyText'],
            fontSize=12,
            leading=16,
            alignment=4  # RTL alignment
        )
        
        for para in doc.paragraphs:
            text = para.text.strip()
            if text:
                # Create paragraph with the text
                p = Paragraph(text, style)
                story.append(p)
                story.append(Spacer(1, 12))
        
        # Handle tables if any
        for table in doc.tables:
            table_data = []
            for row in table.rows:
                row_data = []
                for cell in row.cells:
                    row_data.append(cell.text)
                table_data.append(row_data)
            
            if table_data:
                try:
                    t = Table(table_data)
                    t.setStyle(TableStyle([
                        ('BACKGROUND', (0, 0), (-1, 0), '#cccccc'),
                        ('TEXTCOLOR', (0, 0), (-1, -1), '#000000'),
                        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                        ('FONTSIZE', (0, 0), (-1, 0), 10),
                        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                        ('BACKGROUND', (0, 1), (-1, -1), '#ffffff'),
                        ('GRID', (0, 0), (-1, -1), 1, '#cccccc')
                    ]))
                    story.append(t)
                    story.append(Spacer(1, 12))
                except:
                    pass
        
        # Build PDF
        pdf_file.build(story)
        
        if os.path.exists(output_pdf):
            file_size = os.path.getsize(output_pdf)
            logging.info(f"PDF successfully created via fallback: {output_pdf}, size: {file_size} bytes")
            return True, output_pdf
        else:
            return False, "فشل في إنشاء ملف PDF"
        
    except Exception as e:
        logging.error(f"Error in fallback conversion: {type(e).__name__}: {e}")
        return False, f"خطأ في التحويل: {str(e)}"


# --- Template Renaming Functions ---
def create_paginated_file_list(user_files, page=1, files_per_page=10, file_type="all"):
    """Create a paginated file list with navigation buttons."""
    if not user_files:
        if file_type == "template":
            return "🖼️ لا توجد ملفات قوالب محفوظة.", None
        elif file_type == "regular":
            return "📄 لا توجد ملفات عادية محفوظة.", None
        else:
            return "📄 لا توجد ملفات محفوظة.", None
    
    total_files = len(user_files)
    total_pages = (total_files + files_per_page - 1) // files_per_page
    
    # Ensure page is within valid range
    page = max(1, min(page, total_pages))
    
    # Calculate start and end indices
    start_idx = (page - 1) * files_per_page
    end_idx = min(start_idx + files_per_page, total_files)
    
    # Get files for current page
    page_files = user_files[start_idx:end_idx]
    
    # Create file list message with appropriate header
    if file_type == "template":
        message = f"🖼️ ملفات القوالب المحفوظة (الصفحة {page} من {total_pages}):\n\n"
    elif file_type == "regular":
        message = f"📄 الملفات العادية المحفوظة (الصفحة {page} من {total_pages}):\n\n"
    else:
        message = f"📄 ملفاتك المحفوظة (الصفحة {page} من {total_pages}):\n\n"
    
    for i, file_info in enumerate(page_files, start=start_idx + 1):
        file_name = file_info.get('file_name', 'غير محدد')
        created_at = file_info.get('created_at', 'غير محدد')
        
        # Format date for display
        try:
            if created_at and created_at != 'غير محدد':
                # Parse the date and format it nicely
                from datetime import datetime
                dt = datetime.fromisoformat(created_at.replace(' ', 'T'))
                formatted_date = dt.strftime('%Y/%m/%d %H:%M')
            else:
                formatted_date = 'غير محدد'
        except:
            formatted_date = created_at
        
        # Use appropriate emoji based on file type
        if file_type == "template":
            message += f"{i}. 🖼️ {file_name}\n   📅 {formatted_date}\n\n"
        elif file_type == "regular":
            message += f"{i}. 📄 {file_name}\n   📅 {formatted_date}\n\n"
        else:
            message += f"{i}. 📄 {file_name}\n   📅 {formatted_date}\n\n"
    
    # Create navigation buttons
    buttons = []
    
    # Add navigation buttons if there are multiple pages
    if total_pages > 1:
        nav_row = []
        
        # Previous button
        if page > 1:
            nav_row.append({'text': '← السابق', 'callback_data': f'file_page_{page-1}_{file_type}'})
        
        # Next button
        if page < total_pages:
            nav_row.append({'text': 'التالي →', 'callback_data': f'file_page_{page+1}_{file_type}'})
        
        if nav_row:
            buttons.append(nav_row)
    
    # Add management buttons with improved order
    management_buttons = []
    
    # Add upload template button only for template files
    if file_type == "template":
        management_buttons.append([{'text': '📤 رفع قالب PDF مباشرة', 'callback_data': 'upload_template_pdf'}])
    
    management_buttons.extend([
        [{'text': '📝 تغيير اسم ملف', 'callback_data': f'rename_file_{file_type}'}],
        [{'text': '🗑️ حذف ملف', 'callback_data': f'delete_file_{file_type}'}],
        [{'text': '⚠️ حذف جميع ملفاتي', 'callback_data': f'delete_all_files_{file_type}'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'back_to_pdf_section'}]
    ])
    
    buttons.extend(management_buttons)
    
    return message, buttons

# 8 confirmation questions for bulk delete protection
DELETE_ALL_CONFIRMATIONS = [
    {"question": "هل أنت متأكد تمامًا من حذف جميع ملفاتك؟", "yes": "نعم احذف الكل", "no": "لا، إلغاء"},
    {"question": "هذا الإجراء لا يمكن التراجع عنه! هل تريد المتابعة؟", "yes": "نعم، أكمل", "no": "توقف"},
    {"question": "سيتم حذف جميع ملفاتك نهائيًا. هل توافق؟", "yes": "موافق", "no": "غير موافق"},
    {"question": "تحذير: الحذف نهائي وغير قابل للاستعادة!", "yes": "متفهم، احذف", "no": "أوقف العملية"},
    {"question": "بمجرد الحذف، لن تستطيع استعادة الملفات. هل تفهم؟", "yes": "أفهم، احذف", "no": "ألغِ"},
    {"question": "هل تدرك أنك ستفقد جميع ملفاتك إلى الأبد؟", "yes": "أدرك ذلك", "no": "إلغاء"},
    {"question": "تنبيه: لن يكون هناك نسخة احتياطية! هل تكمل؟", "yes": "أكمل", "no": "أوقف"},
    {"question": "التأكيد النهائي: احذف جميع الملفات الآن؟", "yes": "احذف الآن", "no": "لا، أبقِها"}
]

def handle_file_pagination_callback(chat_id, user_id, page_number, file_type="all"):
    """Handle file pagination callback."""
    try:
        # Get user files based on type
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            if file_type == "template":
                user_files = loop.run_until_complete(db.get_user_template_pdf_files(user_id))
            elif file_type == "regular":
                user_files = loop.run_until_complete(db.get_user_regular_pdf_files(user_id))
            else:
                user_files = loop.run_until_complete(db.get_user_pdf_files(user_id))
        finally:
            loop.close()
        
        # Create paginated list
        message, buttons = create_paginated_file_list(user_files, page_number, file_type=file_type)
        
        # Send updated message
        send_message(chat_id, message, inline_buttons=buttons)
        
    except Exception as e:
        logging.error(f"Error handling file pagination: {e}")
        send_message(chat_id, f"❌ حدث خطأ في عرض الملفات: {str(e)}")

def start_delete_all_confirmation(chat_id, user_id, file_type, message_id):
    """Start the 8-question confirmation process for deleting all files."""
    import random
    
    # Shuffle questions for randomness
    shuffled_questions = DELETE_ALL_CONFIRMATIONS.copy()
    random.shuffle(shuffled_questions)
    
    # Store in user state
    set_user_state(user_id, 'deleting_all_files', {
        'file_type': file_type,
        'question_index': 0,
        'questions': shuffled_questions,
        'message_id': message_id
    })
    
    # Show first question
    show_delete_confirmation_question(chat_id, user_id, message_id)

def show_delete_confirmation_question(chat_id, user_id, message_id):
    """Show the current confirmation question and edit the message."""
    import time
    
    # Add small delay before reading state
    time.sleep(0.2)
    
    state_data = get_user_state(user_id)
    
    if not state_data or state_data.get('state') != 'deleting_all_files':
        logging.warning(f"Invalid state for user {user_id} in show_delete_confirmation_question")
        return
    
    # Get data from state_data directly (not nested)
    question_index = state_data.get('data', {}).get('question_index', 0)
    questions = state_data.get('data', {}).get('questions', DELETE_ALL_CONFIRMATIONS)
    file_type = state_data.get('data', {}).get('file_type', 'all')
    
    logging.info(f"Showing question {question_index + 1} for user {user_id}")
    
    if question_index >= len(questions):
        # All questions answered YES - proceed with deletion
        perform_bulk_delete(chat_id, user_id, file_type, message_id)
        return
    
    current_q = questions[question_index]
    progress = question_index + 1
    total_questions = len(questions)
    
    # Create file type display name
    if file_type == "template":
        type_name = "ملفات القوالب"
    elif file_type == "regular":
        type_name = "الملفات العادية"
    else:
        type_name = "جميع الملفات"
    
    message = (f"⚠️ *تأكيد حذف {type_name}*\n\n"
               f"📊 السؤال {progress} من {total_questions}\n\n"
               f"❓ {current_q['question']}")
    
    buttons = [
        [
            {'text': f"✅ {current_q['yes']}", 'callback_data': f'confirm_delete_all_yes_{file_type}'},
            {'text': f"❌ {current_q['no']}", 'callback_data': f'confirm_delete_all_no_{file_type}'}
        ]
    ]
    
    # Edit the existing message instead of sending a new one
    edit_message(chat_id, message_id, message, inline_buttons=buttons, parse_mode='Markdown')

def handle_delete_all_confirmation(chat_id, user_id, answer, file_type, message_id):
    """Handle user's answer to confirmation question."""
    state_data = get_user_state(user_id)
    
    if not state_data or state_data.get('state') != 'deleting_all_files':
        send_message(chat_id, "❌ انتهت صلاحية جلسة التأكيد. الرجاء المحاولة مرة أخرى.")
        clear_user_state(user_id)
        return
    
    if answer == 'no':
        # User cancelled
        clear_user_state(user_id)
        message = "✅ تم إلغاء عملية الحذف. ملفاتك في أمان."
        buttons = [[{'text': '⬅️ رجوع للقائمة', 'callback_data': 'back_to_pdf_section'}]]
        edit_message(chat_id, message_id, message, inline_buttons=buttons)
        return
    
    # User answered YES - move to next question
    data_dict = state_data.get('data', {})
    question_index = data_dict.get('question_index', 0)
    
    # Increment the question index FIRST
    question_index += 1
    data_dict['question_index'] = question_index
    
    # Save the updated state BEFORE showing next question
    set_user_state(user_id, 'deleting_all_files', data_dict)
    
    # Longer delay to ensure state is properly saved
    import time
    time.sleep(0.5)
    
    # Verify the state was saved correctly
    verify_state = get_user_state(user_id)
    verify_index = verify_state.get('data', {}).get('question_index', 0)
    
    if verify_index != question_index:
        logging.error(f"State not saved correctly. Expected {question_index}, got {verify_index}")
        # Try saving again
        set_user_state(user_id, 'deleting_all_files', data_dict)
        time.sleep(0.5)
    
    # Show next question
    show_delete_confirmation_question(chat_id, user_id, message_id)

def perform_bulk_delete(chat_id, user_id, file_type, message_id):
    """Perform the actual bulk deletion after all confirmations."""
    try:
        # Update message to show deletion in progress
        edit_message(chat_id, message_id, "🔄 جاري حذف جميع ملفاتك...")
        
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        deleted_count = 0
        failed_count = 0
        
        try:
            # Get files to delete
            if file_type == "template":
                files = loop.run_until_complete(db.get_user_template_pdf_files(user_id))
            elif file_type == "regular":
                files = loop.run_until_complete(db.get_user_regular_pdf_files(user_id))
            else:
                # Get both types
                regular_files = loop.run_until_complete(db.get_user_regular_pdf_files(user_id))
                template_files = loop.run_until_complete(db.get_user_template_pdf_files(user_id))
                files = regular_files + template_files
            
            # Delete each file
            for file_info in files:
                file_name = file_info.get('file_name')
                file_url = file_info.get('file_url', '')
                
                try:
                    # Determine if it's a template file
                    is_template = 'template_type' in file_info
                    
                    # Delete from storage using the supabase storage API directly
                    if file_url:
                        storage_file_name = file_url.split('/')[-1]
                        try:
                            bucket_name = "template-pdf-files" if is_template else "pdf-files"
                            db.supabase.storage.from_(bucket_name).remove([storage_file_name])
                            logging.info(f"Deleted from storage: {storage_file_name}")
                        except Exception as storage_error:
                            logging.warning(f"Failed to delete from storage {storage_file_name}: {storage_error}")
                    
                    # Delete from database
                    if is_template:
                        success = loop.run_until_complete(db.delete_template_pdf_file(user_id, file_name))
                    else:
                        success = loop.run_until_complete(db.delete_regular_pdf_file(user_id, file_name))
                    
                    if success:
                        deleted_count += 1
                    else:
                        failed_count += 1
                        
                except Exception as e:
                    logging.error(f"Error deleting file {file_name}: {e}")
                    failed_count += 1
        
        finally:
            loop.close()
        
        # Clear user state
        clear_user_state(user_id)
        
        # Show final result
        if file_type == "template":
            type_name = "ملفات القوالب"
        elif file_type == "regular":
            type_name = "الملفات العادية"
        else:
            type_name = "جميع الملفات"
        
        result_message = (f"✅ *اكتملت عملية الحذف*\n\n"
                         f"📁 النوع: {type_name}\n"
                         f"✅ تم حذفها: {deleted_count} ملف\n"
                         f"❌ فشل الحذف: {failed_count} ملف")
        
        buttons = [[{'text': '⬅️ رجوع للقائمة', 'callback_data': 'back_to_pdf_section'}]]
        edit_message(chat_id, message_id, result_message, inline_buttons=buttons, parse_mode='Markdown')
        
    except Exception as e:
        logging.error(f"Error in bulk delete: {e}")
        message = f"❌ حدث خطأ أثناء حذف الملفات: {str(e)}"
        buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'back_to_pdf_section'}]]
        edit_message(chat_id, message_id, message, inline_buttons=buttons)
        clear_user_state(user_id)


def get_template_info():
    return {
        'original': {
            'name': 'قالب المعاملات',
            'size': 'قالب 3×4 (9 صور)',
            'description': 'مثالي للمعاملات الرسمية والهويات والبطاقات\nتوزيع احترافي لـ 9 صور بنفس المقاس',
            'callback': 'template_original'
        },
        'new': {
            'name': 'قالب الجوازات', 
            'size': 'قالب 3.5×4.5 (6 صور)',
            'description': 'مخصص لصور جوازات السفر والوثائق الرسمية\nتوزيع 6 صور بمقاس الجواز القياسي',
            'callback': 'template_new'
        },
        'multi_person': {
            'name': 'أكثر من شخص؟',
            'size': 'تخطيطات متعددة',
            'description': 'لشخصين فقط - قوالب مرنة\nالقياسات المتوفرة: 6×3، 5×4',
            'callback': 'template_multi_person'
        }
    }


# --- 2. Helper Functions for Telegram API Interaction ---

def make_request(url, method='GET', headers=None, data=None, files=None, json_data=None, params=None, timeout=30):
    """
    Makes an HTTP request to a specified URL.

    Args:
        url (str): The URL to request.
        method (str): The HTTP method (GET, POST, PUT, etc.).
        headers (dict, optional): A dictionary of HTTP headers. Defaults to None.
        data (dict, optional): Dictionary of form data (for POST/PUT). Defaults to None.
        files (dict, optional): Dictionary of files for multipart/form-data uploads. Defaults to None.
        json_data (dict, optional): Dictionary for JSON request body. Defaults to None.
        params (dict, optional): Dictionary for URL query parameters. Defaults to None.
        timeout (int): Request timeout in seconds.

    Returns:
        dict: Contains 'response' (requests.Response object), 'http_code', and 'error' (error message).
    """
    if headers is None:
        headers = {}

    try:
        if method.upper() == 'GET':
            response = requests.get(url, headers=headers, params=params, timeout=timeout)
        elif method.upper() == 'POST':
            if json_data:
                response = requests.post(url, headers=headers, json=json_data, timeout=timeout)
            elif files:
                response = requests.post(url, headers=headers, data=data, files=files, timeout=timeout)
            else:
                response = requests.post(url, headers=headers, data=data, timeout=timeout)
        elif method.upper() == 'PUT':
            response = requests.put(url, headers=headers, data=data, timeout=timeout)
        else:
            logging.error(f"Unsupported HTTP method: {method}")
            return {'response': None, 'http_code': 0, 'error': 'Unsupported HTTP method'}

        # Log full response for non-200 HTTP codes for better debugging
        if not response.ok:
            logging.error(f"HTTP Error for URL {url} (Method: {method}). Code: {response.status_code}. Response: {response.text}")

        return {'response': response, 'http_code': response.status_code, 'error': None}

    except requests.exceptions.ConnectionError as e: # Catch connection related errors
        logging.error(f"Connection error for URL {url} (Method: {method}): {e}")
        return {'response': None, 'http_code': 0, 'error': str(e)}
    except requests.exceptions.Timeout as e: # Catch timeout errors
        logging.error(f"Timeout error for URL {url} (Method: {method}): {e}")
        return {'response': None, 'http_code': 0, 'error': str(e)}
    except requests.exceptions.RequestException as e:
        logging.error(f"General Request Error for URL {url} (Method: {method}): {e}")
        return {'response': None, 'http_code': 0, 'error': str(e)}

def delete_message_after_delay(chat_id, message_id, delay_seconds=5):
    """
    Delete a message after a specified delay (in seconds) without blocking.
    Runs in a background thread.
    
    Args:
        chat_id (int): The chat ID.
        message_id (int): The message ID to delete.
        delay_seconds (int): Time to wait before deleting (default: 5 seconds).
    """
    import threading
    
    def delete_task():
        try:
            time.sleep(delay_seconds)
            delete_message(chat_id, message_id)
            logging.info(f"Auto-deleted message {message_id} from chat {chat_id} after {delay_seconds}s")
        except Exception as e:
            logging.error(f"Failed to auto-delete message {message_id}: {e}")
    
    # Start deletion in a background thread to avoid blocking
    thread = threading.Thread(target=delete_task, daemon=True)
    thread.start()

def send_message(chat_id, text, buttons=None, parse_mode=None, inline_buttons=None, message_id=None, remove_keyboard=False):
    """
    Sends a text message to a Telegram chat, or edits an existing one.
    If editing fails, automatically sends a new message and deletes the old one.

    Args:
        chat_id (int): The chat ID.
        text (str): The message text.
        buttons (list, optional): Optional list of lists for keyboard markup. Defaults to None.
        parse_mode (str, optional): Optional parse mode (e.g., 'MarkdownV2', 'HTML'). Defaults to None.
        inline_buttons (list, optional): Optional list of lists for inline keyboard markup. Defaults to None.
        message_id (int, optional): If provided, attempts to edit this message instead of sending a new one.
        remove_keyboard (bool, optional): If True, removes the reply keyboard. Defaults to False.

    Returns:
        int or None: The message ID if successful, None otherwise.
    """
    # Always convert to English numerals before sending
    text = to_english_numerals(text)
    
    payload = {
        'chat_id': chat_id,
        'text': text,
    }

    if buttons:
        keyboard = [[{'text': b} for b in row] for row in buttons]
        payload['reply_markup'] = json.dumps({
            'keyboard': keyboard,
            'resize_keyboard': True
        })
    elif inline_buttons:
        payload['reply_markup'] = json.dumps({
            'inline_keyboard': inline_buttons
        })
    elif remove_keyboard:
        payload['reply_markup'] = json.dumps({
            'remove_keyboard': True
        })

    if parse_mode:
        payload['parse_mode'] = parse_mode

    if message_id:
        # Try to edit the existing message first
        edit_payload = payload.copy()
        edit_payload['message_id'] = message_id
        response = make_request(f"{API_URL}/editMessageText", 'POST',
                                headers={'Content-Type': 'application/json'},
                                json_data=edit_payload)
        
        # Check if editing was successful
        if response['error']:
            logging.warning(f"Edit message failed due to network error: {response['error']}. Sending new message.")
        elif response['response'] is None or not isinstance(response['response'], requests.Response):
            logging.warning(f"Edit message failed: Invalid response. Sending new message.")
        else:
            try:
                response_data = response['response'].json()
                if response_data.get('ok'):
                    # Edit was successful
                    logging.info(f"Successfully edited message {message_id}")
                    return message_id
                else:
                    # Edit failed - log the reason and fallback to new message
                    logging.warning(f"Edit message failed: {response_data.get('description', 'Unknown error')}. Sending new message.")
            except json.JSONDecodeError:
                logging.warning(f"Edit message failed: Invalid JSON response. Sending new message.")
        
        # If we reach here, editing failed - send new message and delete old one
        logging.info(f"Attempting to send new message and delete old message {message_id}")
        
        # Send new message
        new_response = make_request(f"{API_URL}/sendMessage", 'POST',
                                    headers={'Content-Type': 'application/json'},
                                    json_data=payload)
        
        if new_response['error']:
            logging.error(f"Failed to send new message after edit failure: {new_response['error']}")
            return None
        
        if new_response['response'] is None or not isinstance(new_response['response'], requests.Response):
            logging.error(f"Invalid response when sending new message after edit failure")
            return None
        
        try:
            new_response_data = new_response['response'].json()
            if new_response_data.get('ok'):
                new_message_id = new_response_data['result']['message_id']
                logging.info(f"Successfully sent new message {new_message_id} after edit failure")
                
                # Delete the old message
                delete_message(chat_id, message_id)
                
                return new_message_id
            else:
                logging.error(f"Failed to send new message: {new_response_data.get('description', 'Unknown error')}")
                return None
        except json.JSONDecodeError:
            logging.error(f"Failed to decode JSON response for new message")
            return None
    else:
        # Normal message sending
        response = make_request(f"{API_URL}/sendMessage", 'POST',
                                headers={'Content-Type': 'application/json'},
                                json_data=payload)

        if response['error']:
            logging.error(f"send_message cURL error: {response['error']}")
            return None

        try:
            if response['response'] is None or not isinstance(response['response'], requests.Response):
                logging.error(f"send_message: Invalid or None response object for chat_id {chat_id}, text: {text}")
                return None

            response_data = response['response'].json()
            if not response_data.get('ok'):
                logging.error(f"send_message API error: {response_data.get('description', 'Unknown error')} for chat_id {chat_id}, text: {text}")
                return None
            
            return response_data['result']['message_id'] if isinstance(response_data.get('result'), dict) else None
        except json.JSONDecodeError:
            logging.error(f"send_message: Failed to decode JSON response: {response['response'].text}")
            return None
        except AttributeError:
            logging.error(f"send_message: AttributeError on response object for chat_id {chat_id}, text: {text}")
            return None


def send_inline_menu_with_hidden_keyboard(chat_id, text, inline_buttons, parse_mode=None):
    """
    Sends a message with inline buttons while removing the reply keyboard.
    This ensures that text buttons (reply keyboard) are hidden when using inline mode.
    
    Args:
        chat_id (int): The chat ID.
        text (str): The message text.
        inline_buttons (list): The inline keyboard buttons.
        parse_mode (str, optional): Parse mode for the message.
    
    Returns:
        int or None: The message ID if successful, None otherwise.
    """
    try:
        # First, send a temporary message to remove the reply keyboard
        text_converted = to_english_numerals(text)
        
        remove_kb_payload = {
            'chat_id': chat_id,
            'text': '.',
            'reply_markup': json.dumps({'remove_keyboard': True})
        }
        
        temp_response = make_request(f"{API_URL}/sendMessage", method='POST', 
                                     headers={'Content-Type': 'application/json'},
                                     json_data=remove_kb_payload)
        
        temp_msg_id = None
        if temp_response and not temp_response.get('error'):
            try:
                temp_data = temp_response['response'].json()
                if temp_data.get('ok'):
                    temp_msg_id = temp_data['result']['message_id']
            except Exception as e:
                logging.warning(f"Failed to get temp message ID: {e}")
        
        # Now send the actual message with inline buttons
        payload = {
            'chat_id': chat_id,
            'text': text_converted,
            'reply_markup': json.dumps({'inline_keyboard': inline_buttons})
        }
        
        if parse_mode:
            payload['parse_mode'] = parse_mode
        
        response = make_request(f"{API_URL}/sendMessage", 'POST',
                                headers={'Content-Type': 'application/json'},
                                json_data=payload)
        
        result_msg_id = None
        if not response.get('error') and response.get('response'):
            try:
                response_data = response['response'].json()
                if response_data.get('ok'):
                    result_msg_id = response_data['result']['message_id']
            except Exception as e:
                logging.error(f"Failed to parse send message response: {e}")
        
        # Delete the temporary message
        if temp_msg_id:
            delete_message(chat_id, temp_msg_id)
        
        return result_msg_id
        
    except Exception as e:
        logging.error(f"Error in send_inline_menu_with_hidden_keyboard: {e}")
        return None


def edit_message_reply_markup(chat_id, message_id, inline_buttons=None):
    """
    Edits the reply markup of an existing message.

    Args:
        chat_id (int): The chat ID.
        message_id (int): The message ID to edit.
        inline_buttons (list, optional): New list of lists for inline keyboard markup. Defaults to None.

    Returns:
        bool: True on success, False otherwise.
    """
    payload = {
        'chat_id': chat_id,
        'message_id': message_id,
    }
    if inline_buttons:
        payload['reply_markup'] = json.dumps({
            'inline_keyboard': inline_buttons
        })
    else:
        payload['reply_markup'] = '{}' # Remove markup if None

    response = make_request(f"{API_URL}/editMessageReplyMarkup", 'POST',
                            headers={'Content-Type': 'application/json'},
                            json_data=payload)

    if response['error']:
        logging.error(f"editMessageReplyMarkup cURL error: {response['error']}")
        return False

    try:
        if response['response'] is None or not isinstance(response['response'], requests.Response): # Added check
            logging.error(f"editMessageReplyMarkup: Received None or invalid response object for chat_id {chat_id}, message_id {message_id}. Full response_obj: {response}")
            return False

        response_data = response['response'].json()
        if not response_data.get('ok'):
            # Specific handling for "Bad Request: message to edit not found"
            if response_data.get('error_code') == 400 and "message to edit not found" in response_data.get('description', '').lower():
                logging.warning(f"editMessageReplyMarkup: Message to edit {message_id} not found for chat_id {chat_id}. Description: {response_data.get('description')}")
                return False
            else:
                logging.error(f"editMessageReplyMarkup API error: {response_data.get('description', 'Unknown error')} for chat_id {chat_id}, message_id {message_id}. Full response: {response['response'].text}")
                return False
        return True
    except json.JSONDecodeError:
        logging.error(f"editMessageReplyMarkup: Failed to decode JSON response: {response['response'].text}")
        return False
    except AttributeError:
        logging.error(f"editMessageReplyMarkup: AttributeError on response object for chat_id {chat_id}, message_id {message_id}. Full response: {response}")
        return False


def send_photo(chat_id, photo_path, caption='', inline_buttons=None, parse_mode=None): # Added parse_mode
    """
    Sends a photo to a Telegram chat.

    Args:
        chat_id (int): The chat ID.
        photo_path (str): The local path to the photo file.
        caption (str, optional): Optional caption for the photo. Defaults to ''.
        inline_buttons (list, optional): Optional list of lists for inline keyboard markup. Defaults to None.
        parse_mode (str, optional): Optional parse mode for the caption. Defaults to None. # New
    Returns:
        bool: True on success, False on failure.
    """
    if not os.path.exists(photo_path):
        logging.error(f"Photo file not found: {photo_path}")
        return False

    # Convert caption to English numerals
    caption = to_english_numerals(caption)

    try:
        with open(photo_path, 'rb') as f:
            files = {'photo': f}
            data = {'chat_id': chat_id, 'caption': caption}

            if inline_buttons:
                data['reply_markup'] = json.dumps({
                    'inline_keyboard': inline_buttons
                })
            if parse_mode: # Apply parse_mode to caption
                data['parse_mode'] = parse_mode

            response = make_request(f"{API_URL}/sendPhoto", 'POST', data=data, files=files)

            if response['error']:
                logging.error(f"sendPhoto cURL error: {response['error']}")
                return False

            if response['response'] is None or not isinstance(response['response'], requests.Response): # Added check
                logging.error(f"sendPhoto: Received None or invalid response object for chat_id {chat_id}, photo: {photo_path}")
                return False

            response_data = response['response'].json()
            if not response_data.get('ok'):
                logging.error(f"sendPhoto API error: {response_data.get('description', 'Unknown error')} for chat_id {chat_id}, photo: {photo_path}. Full response: {response['response'].text}")
                return False
            return True
    except json.JSONDecodeError: # Added to catch JSON decode errors
        logging.error(f"sendPhoto: Failed to decode JSON response: {response['response'].text}")
        return False
    except Exception as e:
        logging.error(f"Error sending photo {photo_path}: {e}")
        return False

def send_document(chat_id, file_path, caption=''):
    """
    Sends a document to a Telegram chat.

    Args:
        chat_id (int): The chat ID.
        file_path (str): The local path to the document file.
        caption (str, optional): Optional caption for the document. Defaults to ''.

    Returns:
        bool: True on success, False on failure.
    """
    if not os.path.exists(file_path):
        logging.error(f"Document file not found: {file_path}")
        return False

    # Convert caption to English numerals
    caption = to_english_numerals(caption)

    try:
        with open(file_path, 'rb') as f:
            files = {'document': f}
            data = {'chat_id': chat_id, 'caption': caption}

            response = make_request(f"{API_URL}/sendDocument", 'POST', data=data, files=files)

            if response['error']:
                logging.error(f"sendDocument cURL error: {response['error']}")
                return False

            if response['response'] is None or not isinstance(response['response'], requests.Response): # Added check
                logging.error(f"sendDocument: Received None or invalid response object for chat_id {chat_id}, file: {file_path}")
                return False

            response_data = response['response'].json()
            if not response_data.get('ok'):
                logging.error(f"sendDocument API error: {response_data.get('description', 'Unknown error')} for chat_id {chat_id}, file: {file_path}. Full response: {response['response'].text}")
                return False
            return True
    except json.JSONDecodeError: # Added to catch JSON decode errors
        logging.error(f"sendDocument: Failed to decode JSON response: {response['response'].text}")
        return False
    except Exception as e:
        logging.error(f"Error sending document {file_path}: {e}")
        return False


def send_template_png(chat_id, image_path):
    """
    Sends a template image as a PNG document to preserve quality.
    Converts to PNG if needed before sending.

    Args:
        chat_id (int): The chat ID.
        image_path (str): The local path to the template image.
    """
    try:
        if not image_path or not os.path.exists(image_path):
            logging.warning(f"send_template_png: Image not found: {image_path}")
            return

        # Ensure the file is a PNG; convert if necessary
        if image_path.lower().endswith('.png'):
            png_path = image_path
            temp_created = False
        else:
            png_path = image_path.rsplit('.', 1)[0] + '_hq.png'
            img = Image.open(image_path).convert('RGBA')
            img.save(png_path, format='PNG', optimize=False)
            temp_created = True

        send_chat_action(chat_id, 'upload_document')
        send_document(chat_id, png_path, caption='📎 نسخة PNG عالية الجودة')

        if temp_created and os.path.exists(png_path):
            os.remove(png_path)

    except Exception as e:
        logging.error(f"send_template_png error: {e}")


def delete_message(chat_id, message_id):
    """
    Deletes a message from a Telegram chat.

    Args:
        chat_id (int): The chat ID.
        message_id (int): The message ID to delete.
    """
    payload = {'chat_id': chat_id, 'message_id': message_id}
    response = make_request(f"{API_URL}/deleteMessage", 'POST',
                            headers={'Content-Type': 'application/json'},
                            json_data=payload)

    if response['error']:
        logging.error(f"deleteMessage cURL error: {response['error']}")
    else:
        try:
            if response['response'] is None or not isinstance(response['response'], requests.Response): # Added check
                logging.error(f"deleteMessage: Received None or invalid response object for chat_id {chat_id}, message_id {message_id}")
                return
            response_data = response['response'].json()
            if not response_data.get('ok'):
                logging.error(f"deleteMessage API error: {response_data.get('description', 'Unknown error')} for chat_id {chat_id}, message_id {message_id}. Full response: {response['response'].text}")
        except json.JSONDecodeError:
            logging.error(f"deleteMessage: Failed to decode JSON response: {response['response'].text}")
        except AttributeError:
            logging.error(f"deleteMessage: AttributeError on response object for chat_id {chat_id}, message_id {message_id}. Full response: {response}")

def send_chat_action(chat_id, action):
    """
    Sends a chat action (e.g., 'typing', 'upload_photo') to a Telegram chat.

    Args:
        chat_id (int): The chat ID.
        action (str): The chat action to send.
    """
    payload = {'chat_id': chat_id, 'action': action}
    response = make_request(f"{API_URL}/sendChatAction", 'POST',
                            headers={'Content-Type': 'application/json'},
                            json_data=payload)

    if response['error']:
        logging.error(f"sendChatAction cURL error: {response['error']}")
    else:
        try:
            if response['response'] is None or not isinstance(response['response'], requests.Response): # Added check
                logging.error(f"sendChatAction: Received None or invalid response object for chat_id {chat_id}, action: {action}")
                return
            response_data = response['response'].json()
            if not response_data.get('ok'):
                logging.error(f"sendChatAction API error: {response_data.get('description', 'Unknown error')} for chat_id {chat_id}, action: {action}. Full response: {response['response'].text}")
        except json.JSONDecodeError:
            logging.error(f"sendChatAction: Failed to decode JSON response: {response['response'].text}")
        except AttributeError:
            logging.error(f"sendChatAction: AttributeError on response object for chat_id {chat_id}, action: {action}. Full response: {response}")

def get_user_profile_photo(user_id):
    """
    Gets the largest profile photo of a user and saves it locally.
    Returns the local path to the photo or None if no photo found/error.
    """
    try:
        # Get user profile photos
        response_obj = make_request(f"{API_URL}/getUserProfilePhotos", method='GET', params={'user_id': user_id})
        response = response_obj['response']

        if response_obj['error'] or response is None or not response.ok: # Added check for response being None
            logging.error(f"Failed to get user profile photos for {user_id}: {response_obj['error'] or (response.text if response else 'No response')}")
            return None

        data = response.json()
        if not data.get('ok') or not data['result']['photos']:
            logging.info(f"No profile photos found for user {user_id}.")
            return None

        # Get the largest photo (last element in the first array)
        largest_photo = data['result']['photos'][0][-1]
        file_id = largest_photo['file_id']

        # Get file path
        file_info_response_obj = make_request(f"{API_URL}/getFile", method='GET', params={'file_id': file_id})
        file_info_response = file_info_response_obj['response']

        if file_info_response_obj['error'] or file_info_response is None or not file_info_response.ok: # Added check for file_info_response being None
            logging.error(f"Failed to get file info for photo {file_id}: {file_info_response_obj['error'] or (file_info_response.text if file_info_response else 'No response')}")
            return None

        file_info = file_info_response.json()
        if not file_info.get('ok') or 'file_path' not in file_info.get('result', {}):
            logging.error(f"Telegram getFile API error for photo: {file_info.get('description', 'Unknown error')}")
            return None

        file_path_tg = file_info['result']['file_path']
        url = f"https://api.telegram.org/file/bot{BOT_TOKEN}/{file_path_tg}"

        # Download the photo
        img_content_response_obj = make_request(url, 'GET')
        img_content_response = img_content_response_obj['response']

        if img_content_response_obj['error'] or img_content_response is None or not img_content_response.ok or not img_content_response.content: # Added check for img_content_response being None
            logging.error(f"Failed to download profile photo from Telegram. URL: {url}, HTTP Code: {img_content_response.status_code if img_content_response else 'N/A'}, Error: {img_content_response_obj['error']}")
            return None

        ext = os.path.splitext(file_path_tg)[1] or '.jpg'
        local_path = os.path.join(PENDING_USER_PHOTOS_DIR, f"profile_{user_id}_{uuid.uuid4()}{ext}")

        with open(local_path, 'wb') as f:
            f.write(img_content_response.content)
        logging.info(f"User {user_id} profile photo downloaded to {local_path}")
        return local_path

    except Exception as e:
        logging.error(f"Error getting user profile photo for {user_id}: {e}")
        return None

# --- 3. User State Management ---

def load_user_states():
    """Loads user states from the JSON file."""
    if os.path.exists(USER_STATE_FILE):
        with open(USER_STATE_FILE, 'r', encoding='utf-8') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logging.error(f"Error decoding JSON from {USER_STATE_FILE}. Returning empty states.")
                return {}
    return {}

def save_user_states(states):
    """Saves user states to the JSON file."""
    try:
        with open(USER_STATE_FILE, 'w', encoding='utf-8') as f:
            json.dump(states, f, indent=4, ensure_ascii=False)
    except IOError as e:
        logging.error(f"Failed to save user states to {USER_STATE_FILE}: {e}")

def set_user_state(user_id, state, data=None):
    """
    Sets the user's current state and associated data.
    Preserves menu_mode, command_mode and image_received_time from previous state if not provided.

    Args:
        user_id (int): The user ID.
        state (str): The state string.
        data (mixed, optional): Optional data to store with the state. Defaults to None.
    """
    states = load_user_states()
    if data is None:
        data = {}
    
    # Preserve menu_mode and image_received_time from previous state if not in new data
    previous_state = states.get(str(user_id), {})
    previous_data = previous_state.get('data', {})
    
    if 'menu_mode' not in data and 'menu_mode' in previous_data:
        data['menu_mode'] = previous_data['menu_mode']
    
    if 'image_received_time' not in data and 'image_received_time' in previous_data:
        data['image_received_time'] = previous_data['image_received_time']
    
    if 'start_timestamp' not in data:
        data['start_timestamp'] = time.time()
    
    # Preserve command_mode from previous state
    preserved_command_mode = previous_state.get('command_mode', 'inline')
    states[str(user_id)] = {'state': state, 'data': data, 'command_mode': preserved_command_mode}
    save_user_states(states)
    logging.info(f"User {user_id} state set to: {state} with data: {data}")


def get_elapsed_time(user_id):
    """
    حساب الزمن المستغرق منذ استلام الصورة (أو بدء الحالة إذا لم يتم استلام صورة).
    
    Args:
        user_id (int): معرف المستخدم
    
    Returns:
        float: الزمن المستغرق بالثواني، أو None إذا لم يوجد timestamp
    """
    user_state = get_user_state(user_id)
    # Use image_received_time if available, otherwise fall back to start_timestamp
    start_timestamp = user_state.get('data', {}).get('image_received_time') or user_state.get('data', {}).get('start_timestamp')
    
    if start_timestamp:
        return time.time() - start_timestamp
    return None


def get_user_state(user_id):
    """
    Gets the user's current state and associated data.

    Args:
        user_id (int): The user ID.

    Returns:
        dict: A dictionary containing 'state' and 'data', or a default dict if no state exists.
    """
    states = load_user_states()
    user_state = states.get(str(user_id))
    if user_state is None:
        # If no state exists, return a default structure to prevent NoneType errors
        return {'state': 'main', 'data': {}}
    # Ensure 'data' key exists and is a dictionary
    if 'data' not in user_state or not isinstance(user_state['data'], dict):
        user_state['data'] = {}
    return user_state


def cleanup_pending_docx_files(chat_id, user_id=None):
    """
    تنظيف الملفات المعلقة والرسائل عند تغيير حالة المستخدم.
    حذف جميع الملفات المؤقتة من القرص فعليًا.
    
    Args:
        chat_id (int): معرف المحادثة
        user_id (int): معرف المستخدم (اختياري)
    """
    global pending_docx_files, pending_docx_message_ids
    import glob
    
    # 1. حذف الملفات المعلقة من القاموس
    if chat_id in pending_docx_files:
        # حذف الملفات المؤقتة من القرص
        for docx_path, _ in pending_docx_files[chat_id]:
            try:
                if os.path.exists(docx_path):
                    os.remove(docx_path)
                    logging.info(f"🗑️ Cleaned up temporary DOCX file: {docx_path}")
            except Exception as e:
                logging.warning(f"⚠️ Could not delete temporary file {docx_path}: {e}")
        
        # حذف من القاموس
        del pending_docx_files[chat_id]
        logging.info(f"🧹 Cleared pending DOCX files for chat {chat_id}")
    
    if chat_id in pending_docx_message_ids:
        del pending_docx_message_ids[chat_id]
        logging.info(f"🧹 Cleared pending DOCX message ID for chat {chat_id}")
    
    # 2. حذف جميع الملفات المؤقتة للمستخدم من TEMP_PDF_DIR
    if user_id and os.path.exists(TEMP_PDF_DIR):
        try:
            # البحث عن جميع الملفات المتعلقة بـ user_id
            user_patterns = [
                os.path.join(TEMP_PDF_DIR, f"*_{user_id}_*"),
                os.path.join(TEMP_PDF_DIR, f"temp_*_{user_id}*"),
                os.path.join(TEMP_PDF_DIR, f"converted_pdf_{user_id}_*"),
            ]
            
            for pattern in user_patterns:
                for file_path in glob.glob(pattern):
                    try:
                        if os.path.isfile(file_path):
                            os.remove(file_path)
                            logging.info(f"🗑️ Deleted temporary file: {file_path}")
                    except Exception as e:
                        logging.warning(f"⚠️ Could not delete {file_path}: {e}")
        except Exception as e:
            logging.warning(f"⚠️ Error during TEMP_PDF_DIR cleanup: {e}")
    
    # 3. حذف جميع الملفات المؤقتة للمستخدم من WORD_FILES_DIR
    if user_id and os.path.exists(WORD_FILES_DIR):
        try:
            # البحث عن جميع ملفات الوورد المتعلقة بـ user_id
            word_patterns = [
                os.path.join(WORD_FILES_DIR, f"*_{user_id}_*"),
                os.path.join(WORD_FILES_DIR, f"temp_*_{user_id}*"),
            ]
            
            for pattern in word_patterns:
                for file_path in glob.glob(pattern):
                    try:
                        if os.path.isfile(file_path):
                            os.remove(file_path)
                            logging.info(f"🗑️ Deleted DOCX file: {file_path}")
                    except Exception as e:
                        logging.warning(f"⚠️ Could not delete {file_path}: {e}")
        except Exception as e:
            logging.warning(f"⚠️ Error during WORD_FILES_DIR cleanup: {e}")
    
    logging.info(f"✅ Cleanup completed for chat {chat_id}, user {user_id}")

def clear_user_state(user_id):
    """
    Clears the user's state but preserves command_mode.
    Uses the default command mode if no mode was previously set.

    Args:
        user_id (int): The user ID.
    """
    states = load_user_states()
    user_id_str = str(user_id)
    if user_id_str in states:
        # Preserve command_mode before clearing, use default if not set
        command_mode = states[user_id_str].get('command_mode')
        if command_mode is None:
            command_mode = _get_default_command_mode_internal()
        # Clear the user's state
        del states[user_id_str]
        # Restore the user with preserved command_mode
        states[user_id_str] = {'state': 'main', 'data': {}, 'command_mode': command_mode}
        save_user_states(states)
        logging.info(f"User {user_id} state cleared.")

# --- Command Mode Management ---

COMMAND_MODE_CONFIG_FILE = os.path.join(CONFIG_DIR, "command_mode_config.json")

def _get_default_command_mode_internal():
    """Internal function to get default command mode without circular dependency."""
    if os.path.exists(COMMAND_MODE_CONFIG_FILE):
        try:
            with open(COMMAND_MODE_CONFIG_FILE, 'r', encoding='utf-8') as f:
                config = json.load(f)
                return config.get('default_mode', 'inline')
        except (json.JSONDecodeError, IOError):
            return 'inline'
    return 'inline'

def get_command_mode(user_id):
    """
    Get user's preferred command mode (buttons or inline).
    Uses the default command mode for new users.
    
    Args:
        user_id (int): The user ID
    
    Returns:
        str: 'buttons' or 'inline'
    """
    states = load_user_states()
    user_data = states.get(str(user_id), {})
    if 'command_mode' in user_data:
        return user_data.get('command_mode')
    return _get_default_command_mode_internal()

def set_command_mode(user_id, mode):
    """
    Set user's preferred command mode.
    
    Args:
        user_id (int): The user ID
        mode (str): 'buttons' or 'inline'
    """
    states = load_user_states()
    user_id_str = str(user_id)
    
    if user_id_str not in states:
        states[user_id_str] = {'state': 'main', 'data': {}}
    
    states[user_id_str]['command_mode'] = mode
    save_user_states(states)
    logging.info(f"User {user_id} command mode set to: {mode}")

def toggle_command_mode(user_id):
    """
    Toggle user's command mode between buttons and inline.
    
    Args:
        user_id (int): The user ID
    
    Returns:
        str: The new mode
    """
    current_mode = get_command_mode(user_id)
    new_mode = 'inline' if current_mode == 'buttons' else 'buttons'
    set_command_mode(user_id, new_mode)
    return new_mode

# --- Admin Command Mode Management Functions ---

def load_command_mode_config():
    """تحميل إعدادات أوضاع الأوامر من الملف."""
    if os.path.exists(COMMAND_MODE_CONFIG_FILE):
        with open(COMMAND_MODE_CONFIG_FILE, 'r', encoding='utf-8') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logging.error("خطأ في قراءة ملف إعدادات أوضاع الأوامر.")
                return {"default_mode": "inline"}
    return {"default_mode": "inline"}

def save_command_mode_config(config):
    """حفظ إعدادات أوضاع الأوامر إلى الملف."""
    try:
        with open(COMMAND_MODE_CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=4, ensure_ascii=False)
        return True
    except IOError as e:
        logging.error(f"فشل في حفظ إعدادات أوضاع الأوامر: {e}")
        return False

def get_default_command_mode():
    """الحصول على الوضع الافتراضي للمستخدمين الجدد."""
    config = load_command_mode_config()
    return config.get('default_mode', 'inline')

def set_default_command_mode(mode):
    """تعيين الوضع الافتراضي للمستخدمين الجدد."""
    config = load_command_mode_config()
    config['default_mode'] = mode
    success = save_command_mode_config(config)
    if success:
        logging.info(f"تم تعيين الوضع الافتراضي إلى: {mode}")
    return success

def get_command_mode_stats():
    """
    الحصول على إحصائيات توزيع أوضاع المستخدمين.
    
    Returns:
        dict: إحصائيات تتضمن عدد المستخدمين في كل وضع
    """
    states = load_user_states()
    inline_count = 0
    buttons_count = 0
    
    for user_id, user_data in states.items():
        mode = user_data.get('command_mode', 'inline')
        if mode == 'inline':
            inline_count += 1
        else:
            buttons_count += 1
    
    total = inline_count + buttons_count
    default_mode = get_default_command_mode()
    
    return {
        'inline_count': inline_count,
        'buttons_count': buttons_count,
        'total': total,
        'default_mode': default_mode
    }

def toggle_all_users_command_mode():
    """
    تبديل وضع جميع المستخدمين دفعة واحدة.
    
    Returns:
        dict: معلومات عن العملية (عدد المستخدمين المتأثرين، الوضع القديم، الوضع الجديد)
    """
    states = load_user_states()
    
    stats = get_command_mode_stats()
    if stats['inline_count'] >= stats['buttons_count']:
        old_mode = 'inline'
        new_mode = 'buttons'
    else:
        old_mode = 'buttons'
        new_mode = 'inline'
    
    count = 0
    for user_id in states:
        current_mode = states[user_id].get('command_mode', 'inline')
        if current_mode == old_mode:
            states[user_id]['command_mode'] = new_mode
            count += 1
    
    save_user_states(states)
    logging.info(f"تم تبديل وضع {count} مستخدم من {old_mode} إلى {new_mode}")
    
    return {
        'count': count,
        'old_mode': old_mode,
        'new_mode': new_mode
    }

def toggle_specific_user_mode(target_user_id):
    """
    تبديل وضع مستخدم محدد.
    
    Args:
        target_user_id (int): معرف المستخدم المراد تبديل وضعه
    
    Returns:
        dict: معلومات عن العملية (نجاح، الوضع القديم، الوضع الجديد)
    """
    states = load_user_states()
    user_id_str = str(target_user_id)
    
    if user_id_str not in states:
        return {
            'success': False,
            'error': 'المستخدم غير موجود'
        }
    
    old_mode = states[user_id_str].get('command_mode', 'inline')
    new_mode = 'inline' if old_mode == 'buttons' else 'buttons'
    states[user_id_str]['command_mode'] = new_mode
    
    save_user_states(states)
    logging.info(f"تم تبديل وضع المستخدم {target_user_id} من {old_mode} إلى {new_mode}")
    
    return {
        'success': True,
        'user_id': target_user_id,
        'old_mode': old_mode,
        'new_mode': new_mode
    }

def reset_all_to_default_mode():
    """
    إعادة تعيين جميع المستخدمين للوضع الافتراضي.
    
    Returns:
        dict: معلومات عن العملية (عدد المستخدمين المتأثرين، الوضع الافتراضي)
    """
    states = load_user_states()
    default_mode = get_default_command_mode()
    
    count = 0
    for user_id in states:
        current_mode = states[user_id].get('command_mode', 'inline')
        if current_mode != default_mode:
            states[user_id]['command_mode'] = default_mode
            count += 1
    
    save_user_states(states)
    logging.info(f"تم إعادة تعيين {count} مستخدم للوضع الافتراضي: {default_mode}")
    
    return {
        'count': count,
        'default_mode': default_mode
    }

def show_admin_command_mode_menu(chat_id, user_id, message_id=None):
    """عرض قائمة إدارة أوضاع المستخدمين."""
    stats = get_command_mode_stats()
    default_mode = get_default_command_mode()
    
    default_mode_text = "أزرار شفافة" if default_mode == 'inline' else "أزرار نصية"
    majority_mode = "inline" if stats['inline_count'] >= stats['buttons_count'] else "buttons"
    majority_mode_text = "أزرار شفافة" if majority_mode == 'inline' else "أزرار نصية"
    
    text = f"*⚙️ إدارة أوضاع المستخدمين*\n\n"
    text += f"📊 *الإحصائيات الحالية:*\n"
    text += f"• 🔘 أزرار شفافة (inline): {to_english_numerals(stats['inline_count'])} مستخدم\n"
    text += f"• 🔘 أزرار نصية (buttons): {to_english_numerals(stats['buttons_count'])} مستخدم\n"
    text += f"• 📊 الإجمالي: {to_english_numerals(stats['total'])} مستخدم\n\n"
    text += f"⚙️ *الوضع الافتراضي:* {default_mode_text}\n\n"
    text += "اختر العملية المطلوبة:"
    
    buttons = [
        [{'text': f'🔄 تبديل وضع الجميع (حالي: {majority_mode_text})', 'callback_data': 'admin_toggle_all_command_modes'}],
        [{'text': '👤 تبديل وضع مستخدم محدد', 'callback_data': 'admin_toggle_specific_user_mode'}],
        [{'text': '📊 تحديث الإحصائيات', 'callback_data': 'admin_refresh_mode_stats'}],
        [{'text': f'⚙️ تعيين الوضع الافتراضي (حالي: {default_mode_text})', 'callback_data': 'admin_set_default_mode_menu'}],
        [{'text': '🔁 إعادة تعيين الجميع للافتراضي', 'callback_data': 'admin_reset_all_modes'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_section_side_settings'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, text, buttons, message_id, 'admin_command_mode_menu')

def show_set_default_mode_menu(chat_id, user_id, message_id=None):
    """عرض قائمة تعيين الوضع الافتراضي."""
    default_mode = get_default_command_mode()
    
    inline_icon = "✅" if default_mode == 'inline' else "⬜"
    buttons_icon = "✅" if default_mode == 'buttons' else "⬜"
    
    text = "*⚙️ تعيين الوضع الافتراضي*\n\n"
    text += "اختر الوضع الذي سيتم تعيينه كافتراضي للمستخدمين الجدد:\n\n"
    text += f"{inline_icon} *أزرار شفافة (inline):* أزرار تظهر داخل الرسالة\n"
    text += f"{buttons_icon} *أزرار نصية (buttons):* أزرار تظهر أسفل الشاشة"
    
    buttons = [
        [{'text': f'{inline_icon} أزرار شفافة (inline)', 'callback_data': 'admin_set_default_mode_inline'}],
        [{'text': f'{buttons_icon} أزرار نصية (buttons)', 'callback_data': 'admin_set_default_mode_buttons'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_section_command_modes'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, text, buttons, message_id, 'admin_set_default_mode_menu')

def create_main_menu_keyboard(user_id, force_mode=None):
    """
    Create main menu keyboard based on user's command mode preference.
    
    Args:
        user_id (int): The user ID
        force_mode (str): Optional. Force a specific mode ('inline' or 'buttons')
    
    Returns:
        dict or list: Inline keyboard markup or reply keyboard markup
    """
    # Use forced mode if provided, otherwise get from user preference
    if force_mode:
        mode = force_mode
    else:
        mode = get_command_mode(user_id)
    
    menu_items = [
        ['تعديل الصورة ✏️'],
        ['إزالة الخلفية 🖼️', 'تحسين الجودة 🪄'],
        ['توزيع في القالب 🧩'],
        ['المعالجة التلقائية 🤖'],
        ['قسم الملفات 📄']
    ]
    
    if mode == 'inline':
        inline_keyboard = []
        
        # Add menu items
        for row in menu_items:
            button_row = []
            for item in row:
                button_row.append({'text': item, 'callback_data': f'main_menu_{item}'})
            inline_keyboard.append(button_row)
        
        return {'inline_keyboard': inline_keyboard, 'mode': 'inline_menu'}
    else:
        return {'buttons': menu_items, 'mode': 'buttons_menu'}

# --- New: User Permission Management ---

def load_allowed_users():
    """Loads allowed, banned, and pending users from the JSON file."""
    if os.path.exists(ALLOWED_USERS_FILE):
        with open(ALLOWED_USERS_FILE, 'r', encoding='utf-8') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logging.error(f"Error decoding JSON from {ALLOWED_USERS_FILE}. Returning default structure.")
                return {'allowed': [], 'banned': [], 'pending': {}}
    return {'allowed': [], 'banned': [], 'pending': {}}

def save_allowed_users(data):
    """Saves allowed, banned, and pending users to the JSON file."""
    try:
        with open(ALLOWED_USERS_FILE, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
    except IOError as e:
        logging.error(f"Failed to save allowed users to {ALLOWED_USERS_FILE}: {e}")

def is_user_allowed(user_id):
    """Checks if a user is explicitly allowed to use the bot."""
    data = load_allowed_users()
    return str(user_id) in data['allowed']

def is_user_banned(user_id):
    """Checks if a user is banned from using the bot."""
    data = load_allowed_users()
    return str(user_id) in data['banned']

def add_allowed_user(user_id, user_info=None):
    """Adds a user to the allowed list and removes from banned/pending."""
    data = load_allowed_users()
    user_id_str = str(user_id)
    if user_id_str not in data['allowed']:
        data['allowed'].append(user_id_str)
    if user_id_str in data['banned']:
        data['banned'].remove(user_id_str)
    if user_id_str in data['pending']:
        # Clean up profile photo if it exists
        photo_path = data['pending'][user_id_str].get('profile_photo_path')
        if photo_path and os.path.exists(photo_path):
            os.remove(photo_path)
        del data['pending'][user_id_str]
    save_allowed_users(data)
    logging.info(f"User {user_id} added to allowed list.")

def remove_allowed_user(user_id):
    """Removes a user from the allowed list."""
    data = load_allowed_users()
    user_id_str = str(user_id)
    if user_id_str in data['allowed']:
        data['allowed'].remove(user_id_str)
        save_allowed_users(data)
        logging.info(f"User {user_id} removed from allowed list.")
        return True
    return False

def ban_user(user_id, user_info=None):
    """Bans a user, removing them from allowed/pending lists."""
    data = load_allowed_users()
    user_id_str = str(user_id)
    if user_id_str not in data['banned']:
        data['banned'].append(user_id_str)
    if user_id_str in data['allowed']:
        data['allowed'].remove(user_id_str)
    if user_id_str in data['pending']:
        # Clean up profile photo if it exists
        photo_path = data['pending'][user_id_str].get('profile_photo_path')
        if photo_path and os.path.exists(photo_path):
            os.remove(photo_path)
        del data['pending'][user_id_str]
    save_allowed_users(data)
    logging.info(f"User {user_id} banned.")

def unban_user(user_id):
    """Unbans a user."""
    data = load_allowed_users()
    user_id_str = str(user_id)
    if user_id_str in data['banned']:
        data['banned'].remove(user_id_str)
        save_allowed_users(data)
        logging.info(f"User {user_id} unbanned.")
        return True
    return False

def add_pending_user(user_id, user_info):
    """Adds a user to the pending list."""
    data = load_allowed_users()
    data['pending'][str(user_id)] = user_info
    save_allowed_users(data)
    logging.info(f"User {user_id} added to pending list.")

def get_pending_user(user_id):
    """Gets information for a pending user."""
    data = load_allowed_users()
    return data['pending'].get(str(user_id))

def remove_pending_user(user_id):
    """Removes a user from the pending list and cleans up their photo."""
    data = load_allowed_users()
    user_id_str = str(user_id)
    if user_id_str in data['pending']:
        photo_path = data['pending'][user_id_str].get('profile_photo_path')
        if photo_path and os.path.exists(photo_path):
            try:
                os.remove(photo_path)
                logging.info(f"Cleaned up pending user photo: {photo_path}")
            except OSError as e:
                logging.error(f"Error deleting pending user photo {photo_path}: {e}")
        del data['pending'][user_id_str]
        save_allowed_users(data)
        logging.info(f"User {user_id} removed from pending list.")
        return True
    return False

# --- 4. API Key Management (Existing functions, no changes needed) ---

def get_key_data(file):
    """
    Retrieves key data from a JSON file.
    Includes 'expired_keys' array.

    Args:
        file (str): The path to the key JSON file.

    Returns:
        dict: An associative array with 'current_key', 'backup_keys', 'expired_keys', and 'used_count'.
    """
    if os.path.exists(file):
        with open(file, 'r', encoding='utf-8') as f:
            try:
                return json.load(f)
            except json.JSONDecodeError:
                logging.error(f"Error decoding JSON from {file}. Returning default key data.")
                return {}
    return {'current_key': None, 'backup_keys': [], 'expired_keys': [], 'used_count': 0, 'total_usage_count': 0, 'usage_history': []}

def set_key_data(file, data):
    """
    Saves key data to a JSON file.

    Args:
        file (str): The path to the key JSON file.
        data (dict): The associative array of key data.
    """
    try:
        with open(file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4, ensure_ascii=False)
    except IOError as e:
        logging.error(f"Failed to save key data to {file}: {e}")

def get_active_key(file):
    """
    Gets the currently active API key from a file.

    Args:
        file (str): The path to the key JSON file.

    Returns:
        str or None: The active key, or None if no keys available at all.
    """
    data = get_key_data(file)
    return data['current_key']

def add_key_to_pool(file, new_key, is_primary=False):
    """
    Adds a new API key to the pool, optionally setting it as primary.

    Args:
        file (str): The path to the key JSON file.
        new_key (str): The new API key.
        is_primary (bool): If True, sets the new key as the current primary key.
    """
    data = get_key_data(file)
    if is_primary:
        if data['current_key'] is not None:
            data['backup_keys'].append(data['current_key'])
        data['current_key'] = new_key
        data['used_count'] = 0  # Reset usage count for the new active key only
    else:
        data['backup_keys'].append(new_key)
    set_key_data(file, data)
    logging.info(f"Added key to {file}. Primary: {is_primary}")

def rotate_active_key(file):
    """
    Rotates the active API key, moving the current key to backups and activating the next backup.
    This is typically for manual rotation or successful rotation.

    Args:
        file (str): The path to the key JSON file.

    Returns:
        str or False: The new active key on success, False if no backup keys are available.
    """
    data = get_key_data(file)
    if not data['backup_keys']:
        logging.warning(f"No backup keys to rotate for {file}.")
        return False  # No backup keys to rotate

    old_key = data['current_key']
    # حفظ الإجمالي الكلي قبل التعيين الجديد
    current_key_usage = data.get('used_count', 0)
    data['total_usage_count'] = data.get('total_usage_count', 0) + current_key_usage
    
    new_key = data['backup_keys'].pop(0)  # Get first backup key
    if old_key is not None:
        data['backup_keys'].append(old_key)  # Move old key to end of backup list
    data['current_key'] = new_key
    data['used_count'] = 0  # Reset usage for new active key only
    set_key_data(file, data)
    logging.info(f"Rotated active key for {file} to {new_key}. Previous key usage: {current_key_usage}, Total: {data['total_usage_count']}")
    return new_key

def fail_and_rotate_key(file):
    """
    Marks the current active key as expired and attempts to rotate to a new key from backups.
    This function is called when an API key encounters an error (e.g., invalid, rate-limited).

    Args:
        file (str): The path to the key JSON file.

    Returns:
        str or False: The new active key on success, False if no more keys are available.
    """
    data = get_key_data(file)
    failed_key = data['current_key']
    # حفظ الإجمالي قبل الفشل
    current_key_usage = data.get('used_count', 0)
    data['total_usage_count'] = data.get('total_usage_count', 0) + current_key_usage

    if failed_key is not None:
        data['expired_keys'].append(failed_key)  # Move failed key to expired list
        logging.info(f"❌ Key '{failed_key}' moved to expired_keys. Used: {current_key_usage} times")

    if not data['backup_keys']:
        data['current_key'] = None  # No more keys
        data['used_count'] = 0
        set_key_data(file, data)
        logging.warning(f"❌ No more backup keys available for file: {file}. Total usage: {data['total_usage_count']}")
        return False

    new_key = data['backup_keys'].pop(0)  # Get first backup key
    data['current_key'] = new_key
    data['used_count'] = 0  # Reset usage for new active key only
    set_key_data(file, data)
    logging.info(f"🔄 Rotated to new key due to failure. Previous key used: {current_key_usage} times, Total: {data['total_usage_count']}")
    return new_key

def increment_usage(file, chat_id=None, file_name=None, success=True):
    """
    Increments the usage count for the current active API key مع تتبع الاستخدام الكامل.

    Args:
        file (str): The path to the key JSON file.
        chat_id (int): Chat ID (optional) for tracking.
        file_name (str): File name (optional) for tracking.
        success (bool): Whether conversion was successful (default: True).
    """
    data = get_key_data(file)
    if data['current_key'] is not None:
        data['used_count'] = data.get('used_count', 0) + 1
        data['total_usage_count'] = data.get('total_usage_count', 0) + 1  # زيادة الإجمالي أيضاً
        
        # إضافة سجل استخدام مع التفاصيل
        if 'usage_history' not in data:
            data['usage_history'] = []
        
        history_entry = {
            'timestamp': datetime.now(IRAQ_TZ).strftime('%Y-%m-%d %H:%M:%S'),
            'chat_id': chat_id,
            'file_name': file_name,
            'success': success
        }
        data['usage_history'].append(history_entry)
        
        # احفظ آخر 100 إدخال فقط لتجنب ملف ضخم
        if len(data['usage_history']) > 100:
            data['usage_history'] = data['usage_history'][-100:]
        
        set_key_data(file, data)
        logging.info(f"✅ Usage incremented for {file}. Current key: {data['used_count']}, Total: {data['total_usage_count']} | File: {file_name}")


def get_usage(file):
    """
    Gets the current usage count for the active API key.

    Args:
        file (str): The path to the key JSON file.

    Returns:
        int: The usage count.
    """
    data = get_key_data(file)
    return data.get('used_count', 0)

def check_and_rotate_convertapi_key():
    """
    Checks ConvertAPI key usage and automatically rotates if limit reached.
    This ensures continuous service using backup keys.
    
    Returns:
        tuple: (rotated: bool, new_key: str or None, message: str)
    """
    data = get_key_data(CONVERTAPI_KEY_FILE)
    usage_count = data.get('used_count', 0)
    
    if usage_count >= CONVERTAPI_USAGE_LIMIT:
        logging.info(f"🔄 ConvertAPI usage limit reached ({usage_count}/{CONVERTAPI_USAGE_LIMIT}) - attempting rotation")
        
        # محاولة التدوير التلقائي
        new_key = rotate_active_key(CONVERTAPI_KEY_FILE)
        if new_key:
            message = f"✅ تم تدوير مفتاح ConvertAPI تلقائياً! (الاستخدام السابق: {usage_count})"
            logging.info(f"✅ ConvertAPI key rotated successfully. New key: {new_key[:20]}...")
            return True, new_key, message
        else:
            message = f"⚠️ لا توجد مفاتيح احتياطية لـ ConvertAPI. الاستخدام الحالي: {usage_count}/{CONVERTAPI_USAGE_LIMIT}"
            logging.warning(f"⚠️ No backup ConvertAPI keys available for rotation!")
            return False, None, message
    
    return False, None, None

def clear_all_keys(file):
    """
    Clears all API keys (current, backups, and expired) from a file.

    Args:
        file (str): The path to the key JSON file.
    """
    set_key_data(file, {'current_key': None, 'backup_keys': [], 'expired_keys': [], 'used_count': 0})
    logging.info(f"All keys cleared for {file}.")

def delete_specific_backup_key(file, index):
    """
    Deletes a specific backup key by its index.

    Args:
        file (str): The path to the key JSON file.
        index (int): The 0-based index of the backup key to delete.

    Returns:
        bool: True on success, False if index is invalid.
    """
    data = get_key_data(file)
    if 0 <= index < len(data['backup_keys']):
        deleted_key = data['backup_keys'].pop(index)
        set_key_data(file, data)
        logging.info(f"Deleted specific backup key '{deleted_key}' from {file}.")
        return True
    logging.warning(f"Invalid index {index} for deleting backup key from {file}.")
    return False

def delete_all_backup_keys(file):
    """
    Deletes all backup keys.

    Args:
        file (str): The path to the key JSON file.
    """
    data = get_key_data(file)
    data['backup_keys'] = []
    set_key_data(file, data)
    logging.info(f"All backup keys cleared for {file}.")

def delete_primary_key(file):
    """
    Deletes the current primary key.

    Args:
        file (str): The path to the key JSON file.
    """
    data = get_key_data(file)
    deleted_key = data['current_key']
    if data['backup_keys']:
        data['current_key'] = data['backup_keys'].pop(0)
    else:
        data['current_key'] = None
    data['used_count'] = 0
    set_key_data(file, data)
    logging.info(f"Primary key '{deleted_key}' deleted from {file}.")

def clear_expired_keys(file):
    """
    Deletes all expired keys from a file.

    Args:
        file (str): The path to the key JSON file.
    """
    data = get_key_data(file)
    data['expired_keys'] = []
    set_key_data(file, data)
    logging.info(f"All expired keys cleared for {file}.")

def restore_specific_expired_key(file, index):
    """
    Restores a specific expired key by its index, moving it to backup keys.

    Args:
        file (str): The path to the key JSON file.
        index (int): The 0-based index of the expired key to restore.

    Returns:
        bool: True on success, False if index is invalid.
    """
    data = get_key_data(file)
    if 0 <= index < len(data['expired_keys']):
        key_to_restore = data['expired_keys'].pop(index)  # Remove from expired
        data['backup_keys'].append(key_to_restore)  # Add to backup
        set_key_data(file, data)
        logging.info(f"Restored expired key '{key_to_restore}' to backup keys for {file}.")
        return True
    logging.warning(f"Invalid index {index} for restoring expired key from {file}.")
    return False


# --- Enhanced Key Retry Mechanism Functions ---
def validate_api_key(service_name, api_key):
    """Validate an API key by making a test request."""
    try:
        if service_name == 'removebg':
            # Test Remove.bg API
            response = requests.post(
                'https://api.remove.bg/v1.0/removebg',
                headers={'X-Api-Key': api_key},
                data={'size': 'auto'},
                files={'image_file': ('test.jpg', b'fake_image_data', 'image/jpeg')},
                timeout=10
            )
            # Even if it fails due to invalid image, we can check if the key is valid
            return response.status_code != 401  # 401 means unauthorized/invalid key
            
        elif service_name == 'picsart':
            # Test Picsart API
            response = requests.get(
                'https://api.picsart.io/tools/1.0/removebg',
                headers={'X-Picsart-API-Key': api_key},
                timeout=10
            )
            return response.status_code != 401
            
    except Exception as e:
        logging.error(f"Error validating {service_name} key: {e}")
        return False
    
    return False

def handle_key_failure_with_retry(service_name, file_path, user_id=None, operation_name="عملية", attempt_number=1, max_attempts=10):
    """Handle key failure with automatic retry and user notification."""
    key_data = get_key_data(file_path)
    current_key = key_data.get('current_key')
    backup_keys_count = len(key_data.get('backup_keys', []))
    
    if not current_key:
        # No current key available
        if user_id:
            send_message(user_id, f"❌ لا يوجد مفتاح متاح لخدمة {service_name}. يرجى الاتصال بالمالك.")
        notify_admin_key_failure(service_name, "لا يوجد مفتاح متاح", user_id)
        return False
    
    # Show error detection message to user (only on first attempt)
    if user_id and attempt_number == 1:
        error_message = f"🚨 *تم اكتشاف خطأ في الخدمة*\n\n"
        error_message += f"🔧 *الخدمة:* {service_name}\n"
        error_message += f"⚙️ *العملية:* {operation_name}\n"
        error_message += f"📦 *المفاتيح الاحتياطية المتوفرة:* {backup_keys_count}\n"
        error_message += f"🔄 *الحالة:* جاري محاولة الإصلاح تلقائيًا...\n\n"
        error_message += f"⏳ {create_progress_indicator(10, 'اكتشاف المشكلة')}"
        
        progress_msg = send_message(user_id, error_message, parse_mode='Markdown')
        progress_msg_id = progress_msg.get('result', {}).get('message_id') if progress_msg else None
    else:
        progress_msg_id = None
    
    # Prevent infinite loop
    if attempt_number > max_attempts:
        if user_id:
            send_message(user_id, f"❌ تم تجاوز الحد الأقصى من المحاولات ({max_attempts}). يرجى الاتصال بالمالك.")
        notify_admin_key_failure(service_name, f"تم تجاوز الحد الأقصى من المحاولات ({max_attempts})", user_id)
        return False
    
    # Try to rotate to backup key
    new_key = fail_and_rotate_key(file_path)
    
    if not new_key:
        # No more keys available
        if user_id:
            final_message = f"❌ *فشل في الإصلاح*\n\n"
            final_message += f"🔧 *الخدمة:* {service_name}\n"
            final_message += f"⚠️ *السبب:* تم استنفاد جميع المفاتيح الاحتياطية\n"
            final_message += f"🔢 *عدد المحاولات:* {attempt_number}\n"
            final_message += f"📞 *الحل:* يرجى الاتصال بالمالك لإضافة مفاتيح جديدة\n\n"
            final_message += f"⏳ {create_progress_indicator(0, 'فشل الإصلاح')}"
            
            send_message(user_id, final_message, parse_mode='Markdown')
        notify_admin_key_failure(service_name, f"تم استنفاد جميع المفاتيح بعد {attempt_number} محاولة", user_id)
        return False
    
    # Update progress - testing new key
    if user_id:
        test_message = f"🧪 *جاري اختبار المفتاح #{attempt_number}*\n\n"
        test_message += f"🔧 *الخدمة:* {service_name}\n"
        test_message += f"🔑 *المفتاح الجديد:* `{new_key[:15]}...`\n"
        test_message += f"🔢 *المحاولة:* {attempt_number} من {backup_keys_count + 1}\n"
        test_message += f"⏳ {create_progress_indicator(50, 'اختبار المفتاح')}"
        
        send_message(user_id, test_message, parse_mode='Markdown')
    
    # Notify admin about key rotation attempt
    if attempt_number == 1:
        notify_admin_operation_start(service_name, operation_name, user_id, backup_keys_count)
    
    if validate_api_key(service_name, new_key):
        # New key works
        if user_id:
            success_message = f"✅ *تم الإصلاح بنجاح!*\n\n"
            success_message += f"🔧 *الخدمة:* {service_name}\n"
            success_message += f"🔑 *المفتاح الجديد:* `{new_key[:15]}...`\n"
            success_message += f"🔢 *المحاولة الناجحة:* #{attempt_number}\n"
            success_message += f"🎯 *الحالة:* يعمل بشكل صحيح\n\n"
            success_message += f"⏳ {create_progress_indicator(100, 'تم الإصلاح بنجاح')}"
            
            send_message(user_id, success_message, parse_mode='Markdown')
        
        # Log the key change
        log_key_change(service_name, current_key, new_key, f"successful_rotation_attempt_{attempt_number}")
        
        # Notify admin with enhanced details
        notify_admin_key_success_enhanced(service_name, current_key, new_key, attempt_number)
        notify_admin_operation_complete(service_name, operation_name, user_id, True, attempt_number)
        
        return True
    else:
        # New key also failed, try next one
        if user_id:
            retry_message = f"⚠️ *المفتاح #{attempt_number} لا يعمل*\n\n"
            retry_message += f"🔧 *الخدمة:* {service_name}\n"
            retry_message += f"🔄 *الحالة:* جاري المحاولة التلقائية مع المفتاح التالي...\n"
            retry_message += f"📊 *المفاتيح المتبقية:* {len(key_data.get('backup_keys', []))}\n\n"
            retry_message += f"⏳ {create_progress_indicator(30, 'محاولة أخرى')}"
            
            send_message(user_id, retry_message, parse_mode='Markdown')
        
        # Log failed attempt
        log_key_change(service_name, current_key, new_key, f"failed_rotation_attempt_{attempt_number}")
        
        # Recursively try the next key with incremented attempt number
        return handle_key_failure_with_retry(service_name, file_path, user_id, operation_name, attempt_number + 1, max_attempts)

def notify_admin_key_failure(service_name, reason, user_id=None):
    """Notify admin about key failure."""
    current_time = get_iraq_time()
    
    message = f"🚨 *تنبيه فشل المفتاح*\n\n"
    message += f"🔧 *الخدمة:* {service_name}\n"
    message += f"⚠️ *السبب:* {reason}\n"
    message += f"📅 *التاريخ:* {current_time.strftime('%Y-%m-%d')}\n"
    message += f"🕐 *الوقت:* {current_time.strftime('%H:%M:%S')}\n"
    if user_id:
        message += f"👤 *المستخدم المتأثر:* `{user_id}`"
    
    send_message(ADMIN_ID, message, parse_mode='Markdown')

def notify_admin_key_success(service_name, new_key):
    """Notify admin about successful key rotation."""
    current_time = get_iraq_time()
    message = f"✅ *تم تبديل المفتاح بنجاح*\n\n"
    message += f"🔧 *الخدمة:* {service_name}\n"
    message += f"🔑 *المفتاح الجديد (كامل):*\n`{new_key}`\n\n"
    message += f"🕐 *الوقت:* {current_time.strftime('%Y-%m-%d %H:%M:%S')}"
    send_message(ADMIN_ID, message, parse_mode='Markdown')

def notify_admin_key_success_enhanced(service_name, old_key, new_key, attempt_number=1):
    """Notify admin about successful key rotation with enhanced details."""
    current_time = get_iraq_time()
    date_str = current_time.strftime('%Y-%m-%d')
    time_str = current_time.strftime('%H:%M:%S')
    
    message = f"✅ *تم إصلاح الخدمة بنجاح*\n\n"
    message += f"🔧 *الخدمة:* {service_name}\n"
    message += f"🔑 *المفتاح الجديد (كامل):*\n`{new_key}`\n\n"
    message += f"🗑️ *المفتاح القديم (تم التخلي عنه):*\n`{old_key}`\n\n"
    message += f"🔢 *عدد المحاولات:* {attempt_number}\n"
    message += f"📅 *التاريخ:* {date_str}\n"
    message += f"🕐 *الوقت:* {time_str}\n"
    message += f"🔄 *الحالة:* تم نقل المفتاح القديم إلى قائمة المفاتيح منتهية الصلاحية"
    
    send_message(ADMIN_ID, message, parse_mode='Markdown')

def notify_admin_operation_start(service_name, operation_name, user_id, backup_keys_count):
    """Notify admin when an operation starts with key retry."""
    current_time = get_iraq_time()
    
    message = f"🔄 *بدء عملية إصلاح تلقائي*\n\n"
    message += f"🔧 *الخدمة:* {service_name}\n"
    message += f"⚙️ *العملية:* {operation_name}\n"
    message += f"📦 *المفاتيح الاحتياطية المتوفرة:* {backup_keys_count}\n"
    if user_id:
        message += f"👤 *المستخدم:* `{user_id}`\n"
    message += f"🕐 *الوقت:* {current_time.strftime('%Y-%m-%d %H:%M:%S')}\n"
    message += f"🤖 *الحالة:* جاري محاولة جميع المفاتيح الاحتياطية تلقائيًا"
    
    send_message(ADMIN_ID, message, parse_mode='Markdown')

def notify_admin_operation_complete(service_name, operation_name, user_id, success, attempt_number=1):
    """Notify admin when an operation completes."""
    current_time = get_iraq_time()
    
    if success:
        message = f"✅ *اكتملت العملية بنجاح*\n\n"
        emoji = "✅"
    else:
        message = f"❌ *فشلت العملية*\n\n"
        emoji = "❌"
    
    message += f"🔧 *الخدمة:* {service_name}\n"
    message += f"⚙️ *العملية:* {operation_name}\n"
    message += f"🔢 *عدد المحاولات:* {attempt_number}\n"
    if user_id:
        message += f"👤 *المستخدم:* `{user_id}`\n"
    message += f"🕐 *الوقت:* {current_time.strftime('%Y-%m-%d %H:%M:%S')}\n"
    message += f"{emoji} *النتيجة:* {'تم الإصلاح بنجاح' if success else 'فشل الإصلاح'}"
    
    send_message(ADMIN_ID, message, parse_mode='Markdown')

def log_key_change(service_name, old_key, new_key, change_type):
    """Log key changes for tracking."""
    # Convert service_name to lowercase to match KEY_TYPE_MAP keys
    service_key = service_name.lower().replace('.', '').replace(' ', '')
    
    # Get file path if service is in KEY_TYPE_MAP, otherwise use None
    usage_count = 0
    if service_key in KEY_TYPE_MAP:
        try:
            usage_count = get_usage(KEY_TYPE_MAP[service_key]['file'])
        except:
            usage_count = 0
    
    log_entry = {
        'service': service_name,
        'old_key': old_key[:10] + '...' if old_key else 'None',
        'new_key': new_key[:10] + '...' if new_key else 'None',
        'change_type': change_type,
        'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'usage_count': usage_count
    }
    
    # Save to a log file
    log_file = f"{service_name}_key_changes.json"
    try:
        if os.path.exists(log_file):
            with open(log_file, 'r', encoding='utf-8') as f:
                logs = json.load(f)
        else:
            logs = []
        
        logs.append(log_entry)
        
        # Keep only last 100 entries
        if len(logs) > 100:
            logs = logs[-100:]
        
        with open(log_file, 'w', encoding='utf-8') as f:
            json.dump(logs, f, indent=4, ensure_ascii=False)
            
    except Exception as e:
        logging.error(f"Failed to log key change: {e}")

def get_key_usage_stats(service_name):
    """Get usage statistics for a service."""
    # Convert service_name to lowercase to match KEY_TYPE_MAP keys
    service_key = service_name.lower().replace('.', '').replace(' ', '')
    
    if service_key not in KEY_TYPE_MAP:
        return {
            'current_key': 'None',
            'backup_keys_count': 0,
            'expired_keys_count': 0,
            'usage_count': 0
        }
    
    file_path = KEY_TYPE_MAP[service_key]['file']
    key_data = get_key_data(file_path)
    
    return {
        'current_key': key_data.get('current_key', 'None'),
        'backup_keys_count': len(key_data.get('backup_keys', [])),
        'expired_keys_count': len(key_data.get('expired_keys', [])),
        'usage_count': key_data.get('used_count', 0)
    }

# --- Key Management Helper Functions ---
def handle_key_admin_actions(chat_id, user_id, action, key_file_info, admin_message_id):
    """Handle key management actions."""
    key_type_raw = key_file_info['file']
    display_name = key_file_info['display_name']
    
    if action == 'initial_display' or action.startswith('view_keys_btn_'):
        # Display key information
        key_data = get_key_data(key_file_info['file'])
        current_key = key_data.get('current_key', 'لا يوجد')
        backup_count = len(key_data.get('backup_keys', []))
        expired_count = len(key_data.get('expired_keys', []))
        usage_count = key_data.get('used_count', 0)
        
        key_info_text = (
            f"🔑 *إدارة مفاتيح {display_name}*\n\n"
            f"🔐 المفتاح الحالي: `{current_key[:20] if current_key != 'لا يوجد' else 'لا يوجد'}...`\n"
            f"📦 عدد المفاتيح الاحتياطية: {to_english_numerals(str(backup_count))}\n"
            f"❌ عدد المفاتيح منتهية الصلاحية: {to_english_numerals(str(expired_count))}\n"
            f"📊 عدد الاستخدامات: {to_english_numerals(str(usage_count))}"
        )
        
        key_buttons = [
            [{'text': '➕ إضافة مفتاح رئيسي', 'callback_data': f'add_primary_key_btn_{key_type_raw}'}],
            [{'text': '➕ إضافة مفتاح احتياطي', 'callback_data': f'add_backup_key_btn_{key_type_raw}'}],
            [{'text': '👁️ عرض المفاتيح', 'callback_data': f'view_keys_btn_{key_type_raw}'}],
            [{'text': '🔄 تدوير المفتاح', 'callback_data': f'rotate_key_btn_{key_type_raw}'}],
            [{'text': '🗑️ حذف مفاتيح', 'callback_data': f'delete_keys_btn_{key_type_raw}'}],
            [{'text': '⬅️ رجوع', 'callback_data': 'admin_back_to_keys_menu'}]
        ]
        
        update_admin_message_and_state(chat_id, user_id, key_info_text, key_buttons, admin_message_id, f'{key_type_raw}_keys_admin', {'key_type_raw': key_type_raw})
    
    elif action.startswith('add_primary_key_btn_'):
        set_user_state(user_id, f'add_primary_key_{key_type_raw}', {'admin_message_id': admin_message_id, 'key_type_raw': key_type_raw})
        send_message(chat_id, f"🔑 أرسل المفتاح الرئيسي الجديد لـ {display_name}:")
    
    elif action.startswith('add_backup_key_btn_'):
        set_user_state(user_id, f'add_backup_key_{key_type_raw}', {'admin_message_id': admin_message_id, 'key_type_raw': key_type_raw})
        send_message(chat_id, f"🔑 أرسل المفتاح الاحتياطي الجديد لـ {display_name}:")
    
    elif action.startswith('rotate_key_btn_'):
        new_key = rotate_active_key(key_file_info['file'])
        if new_key:
            send_message(chat_id, f"✅ تم تدوير المفتاح بنجاح! المفتاح الجديد: `{new_key[:20]}...`")
        else:
            send_message(chat_id, "❌ لا توجد مفاتيح احتياطية للتدوير.")
        handle_key_admin_actions(chat_id, user_id, 'initial_display', key_file_info, admin_message_id)
    
    elif action.startswith('delete_keys_btn_'):
        delete_buttons = [
            [{'text': '🗑️ حذف مفتاح رئيسي', 'callback_data': f'delete_primary_{key_type_raw}'}],
            [{'text': '🗑️ حذف جميع المفاتيح الاحتياطية', 'callback_data': f'delete_all_backup_{key_type_raw}'}],
            [{'text': '🗑️ حذف مفتاح احتياطي محدد', 'callback_data': f'delete_specific_backup_{key_type_raw}'}],
            [{'text': '🗑️ حذف جميع المفاتيح منتهية الصلاحية', 'callback_data': f'clear_expired_{key_type_raw}'}],
            [{'text': '↩️ استعادة مفتاح منتهي الصلاحية', 'callback_data': f'restore_expired_{key_type_raw}'}],
            [{'text': '⬅️ رجوع', 'callback_data': f'back_to_key_admin_{key_type_raw}'}]
        ]
        update_admin_message_and_state(chat_id, user_id, f"🗑️ *خيارات الحذف لمفاتيح {display_name}*\n\nاختر العملية:", delete_buttons, admin_message_id, f'delete_keys_{key_type_raw}', {'key_type_raw': key_type_raw})


def handle_add_key_input(chat_id, user_id, key_text, key_file_info, is_primary, admin_message_id, message_id):
    """Handle adding a new key."""
    try:
        add_key_to_pool(key_file_info['file'], key_text, is_primary)
        key_type = "رئيسي" if is_primary else "احتياطي"
        send_message(chat_id, f"✅ تم إضافة المفتاح {key_type} بنجاح!")
        handle_key_admin_actions(chat_id, user_id, 'initial_display', key_file_info, admin_message_id)
    except Exception as e:
        logging.error(f"Error adding key: {e}")
        send_message(chat_id, "❌ فشل في إضافة المفتاح.")


def process_key_deletion_callback(chat_id, user_id, data, key_file_info, admin_message_id):
    """Process key deletion callbacks."""
    key_type_raw = key_file_info['file']
    
    if data.startswith('delete_primary_'):
        delete_primary_key(key_file_info['file'])
        send_message(chat_id, "✅ تم حذف المفتاح الرئيسي.")
        handle_key_admin_actions(chat_id, user_id, 'initial_display', key_file_info, admin_message_id)
    
    elif data.startswith('delete_all_backup_'):
        delete_all_backup_keys(key_file_info['file'])
        send_message(chat_id, "✅ تم حذف جميع المفاتيح الاحتياطية.")
        handle_key_admin_actions(chat_id, user_id, 'initial_display', key_file_info, admin_message_id)
    
    elif data.startswith('delete_specific_backup_'):
        set_user_state(user_id, f'awaiting_backup_key_index_{key_type_raw}', {'admin_message_id': admin_message_id, 'key_type_raw': key_type_raw})
        send_message(chat_id, "🔢 أرسل رقم المفتاح الاحتياطي الذي تريد حذفه (0 للأول، 1 للثاني، إلخ):")
    
    elif data.startswith('clear_expired_'):
        clear_expired_keys(key_file_info['file'])
        send_message(chat_id, "✅ تم حذف جميع المفاتيح منتهية الصلاحية.")
        handle_key_admin_actions(chat_id, user_id, 'initial_display', key_file_info, admin_message_id)
    
    elif data.startswith('restore_expired_'):
        set_user_state(user_id, f'awaiting_expired_key_index_{key_type_raw}', {'admin_message_id': admin_message_id, 'key_type_raw': key_type_raw})
        send_message(chat_id, "🔢 أرسل رقم المفتاح منتهي الصلاحية الذي تريد استعادته:")


def handle_awaiting_key_index_input(chat_id, user_id, text, state_data, message_id, key_type):
    """Handle key index input for deletion or restoration."""
    try:
        index = int(text.strip())
        key_type_raw = state_data.get('key_type_raw')
        admin_message_id = state_data.get('admin_message_id')
        key_file_info = KEY_TYPE_MAP.get(key_type_raw)
        
        if key_file_info:
            if key_type == 'backup':
                if delete_specific_backup_key(key_file_info['file'], index):
                    send_message(chat_id, f"✅ تم حذف المفتاح الاحتياطي رقم {index}.")
                else:
                    send_message(chat_id, "❌ رقم غير صحيح أو فشل في الحذف.")
            else:  # expired
                if restore_specific_expired_key(key_file_info['file'], index):
                    send_message(chat_id, f"✅ تم استعادة المفتاح رقم {index} من المفاتيح منتهية الصلاحية.")
                else:
                    send_message(chat_id, "❌ رقم غير صحيح أو فشل في الاستعادة.")
            
            handle_key_admin_actions(chat_id, user_id, 'initial_display', key_file_info, admin_message_id)
        else:
            send_message(chat_id, "❌ خطأ في تحديد نوع المفتاح.")
    except ValueError:
        send_message(chat_id, "❌ الرجاء إدخال رقم صحيح.")


# --- PDF Backup Functions ---
async def create_pdf_backup():
    """Create a backup of all PDF files (both regular and template) from database."""
    try:
        import zipfile
        from datetime import datetime
        
        backup_filename = f"pdf_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
        
        # Get all files from both tables using async properly
        try:
            # Get regular files from pdf_files table ONLY
            regular_files = await db.get_all_regular_pdf_files()
            logging.info(f"Fetched {len(regular_files) if regular_files else 0} regular files from pdf_files table")
            
            # Get template files from template_pdf_files table
            template_files = await db.get_all_template_pdf_files()
            logging.info(f"Fetched {len(template_files) if template_files else 0} template files from template_pdf_files table")
        except Exception as fetch_error:
            logging.error(f"Error fetching files: {fetch_error}")
            regular_files = []
            template_files = []
        
        # Ensure we have lists (not None)
        regular_files = regular_files if regular_files else []
        template_files = template_files if template_files else []
        
        total_files = len(regular_files) + len(template_files)
        
        logging.info(f"Starting backup: {len(regular_files)} regular files, {len(template_files)} template files, total: {total_files}")
        
        if total_files == 0:
            logging.warning("No files to backup - both tables are empty")
            return False, None
        
        # Track successful downloads
        successful_regular = 0
        successful_template = 0
        
        # Create zip file
        with zipfile.ZipFile(backup_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
            # Create metadata file
            metadata = {
                'backup_date': datetime.now().isoformat(),
                'regular_files_count': len(regular_files),
                'template_files_count': len(template_files),
                'total_files': total_files,
                'regular_files': [],
                'template_files': []
            }
            
            # Add regular PDF files to zip in regular_files/ folder
            logging.info(f"Processing {len(regular_files)} regular files...")
            for idx, file_info in enumerate(regular_files, 1):
                file_url = file_info.get('file_url', '')
                file_name = file_info.get('file_name', 'unknown')
                logging.info(f"[{idx}/{len(regular_files)}] Processing regular file: {file_name}")
                
                if not file_url:
                    logging.warning(f"Regular file missing URL: {file_name}")
                    continue
                
                # Try to download using the full URL first
                try:
                    pdf_data = await db.download_pdf_from_storage(file_url, is_template=False)
                    
                    if pdf_data:
                        # Add to zip with original file name in regular_files folder
                        original_name = file_info.get('file_name', 'unknown')
                        user_id = file_info.get('user_id', 'unknown')
                        zip_path = f"regular_files/{user_id}/{original_name}"
                        
                        zipf.writestr(zip_path, pdf_data)
                        
                        metadata['regular_files'].append({
                            'user_id': user_id,
                            'file_name': original_name,
                            'file_url': file_url,
                            'created_at': file_info.get('created_at', '')
                        })
                        successful_regular += 1
                        logging.info(f"✓ Successfully backed up regular file: {file_name}")
                    else:
                        logging.warning(f"✗ Failed to download regular file: {file_name}")
                except Exception as e:
                    logging.error(f"✗ Error processing regular file {file_name}: {e}")
            
            # Add template PDF files to zip in template_files/ folder
            logging.info(f"Processing {len(template_files)} template files...")
            for idx, file_info in enumerate(template_files, 1):
                file_url = file_info.get('file_url', '')
                file_name = file_info.get('file_name', 'unknown')
                template_type = file_info.get('template_type', 'unknown')
                logging.info(f"[{idx}/{len(template_files)}] Processing template file: {file_name} (type: {template_type})")
                
                if not file_url:
                    logging.warning(f"Template file missing URL: {file_name}")
                    continue
                
                # Try to download using the full URL first
                try:
                    pdf_data = await db.download_pdf_from_storage(file_url, is_template=True)
                    
                    if pdf_data:
                        # Add to zip with original file name in template_files folder
                        original_name = file_info.get('file_name', 'unknown')
                        user_id = file_info.get('user_id', 'unknown')
                        zip_path = f"template_files/{user_id}/{original_name}"
                        
                        zipf.writestr(zip_path, pdf_data)
                        
                        metadata['template_files'].append({
                            'user_id': user_id,
                            'file_name': original_name,
                            'file_url': file_url,
                            'template_type': template_type,
                            'image_count': file_info.get('image_count', 0),
                            'created_at': file_info.get('created_at', '')
                        })
                        successful_template += 1
                        logging.info(f"✓ Successfully backed up template file: {file_name}")
                    else:
                        logging.warning(f"✗ Failed to download template file: {file_name}")
                except Exception as e:
                    logging.error(f"✗ Error processing template file {file_name}: {e}")
            
            # Check if we successfully backed up any files
            total_successful = successful_regular + successful_template
            if total_successful == 0:
                logging.error("❌ No files were successfully downloaded for backup")
                return False, None
            
            # Update metadata with actual counts
            metadata['successful_regular'] = successful_regular
            metadata['successful_template'] = successful_template
            metadata['total_successful'] = total_successful
            
            # Add metadata file
            import json
            zipf.writestr('backup_metadata.json', json.dumps(metadata, indent=2, ensure_ascii=False))
        
        logging.info(f"✅ PDF backup created: {backup_filename} with {total_successful}/{total_files} files ({successful_regular} regular, {successful_template} template)")
        return True, backup_filename
        
    except Exception as e:
        logging.error(f"❌ Error creating PDF backup: {e}", exc_info=True)
        return False, None


# --- 5. Image Processing and API Integrations (Existing functions, no changes needed) ---

def remove_background(image_path, key_file, chat_id=None, progress_msg_id=None):
    """
    Removes the background from an image using the Remove.bg API.
    This function includes automatic API key rotation on failure (e.g., 401, 403, 429, or API errors).

    Args:
        image_path (str): The local path to the input image.
        key_file (str): The path to the Remove.bg API key file.
        chat_id (int, optional): Chat ID to send progress updates.
        progress_msg_id (int, optional): Message ID for updating progress.

    Returns:
        str or False: The local path to the output image on success, False on failure.
    """
    service_name = "Remove.bg"
    
    # Get total number of available keys
    key_data = get_key_data(key_file)
    total_keys = 1 + len(key_data.get('backup_keys', []))  # current + backups
    
    if key_data.get('current_key') is None:
        total_keys = len(key_data.get('backup_keys', []))
    
    max_attempts = max(total_keys, 50)  # Try all keys or 50 times max
    attempt = 0

    while attempt < max_attempts:
        attempt += 1
        key = get_active_key(key_file)
        
        if not key:
            logging.error(f"{service_name} API Key not available - no keys in pool after {attempt} attempts.")
            if chat_id:
                send_message(chat_id, f"❌ تم استنفاد جميع المفاتيح المتاحة ({attempt-1} محاولة)\n💡 لا يوجد مفتاح صالح لخدمة {service_name}")
            notify_admin_key_failure(service_name, f"تم استنفاد جميع المفاتيح بعد {attempt-1} محاولة")
            return False

        try:
            # Show progress
            if chat_id and progress_msg_id:
                progress = min(30 + (attempt * 15), 95)
                progress_msg_id = send_progress_update(chat_id, progress_msg_id, progress, f"⏳ محاولة {attempt}/{total_keys}")

            with open(image_path, 'rb') as img_file:
                files = {'image_file': img_file}
                data = {'size': 'auto'}
                headers = {"X-Api-Key": key}

                response_obj = make_request("https://api.remove.bg/v1.0/removebg", 'POST', data=data, files=files, headers=headers, timeout=30)
                response = response_obj['response']

                if response_obj['error'] or response is None:
                    logging.error(f"Remove.bg request error or no response (attempt {attempt}): {response_obj['error'] or 'No response object'}")
                    
                    # Try next key on network error
                    old_key = key
                    new_key = fail_and_rotate_key(key_file)
                    if new_key:
                        logging.info(f"Rotated to new key for Remove.bg due to network error (attempt {attempt})")
                        notify_admin_key_success_enhanced(service_name, old_key, new_key, attempt)
                        log_key_change(service_name, old_key, new_key, f"automatic_rotation_on_network_error_attempt_{attempt}")
                        if chat_id and progress_msg_id:
                            progress_msg_id = send_progress_update(chat_id, progress_msg_id, min(progress + 5, 90), f"🔄 خطأ اتصال - محاولة {attempt+1}/{total_keys}")
                        continue
                    else:
                        # No more keys available
                        if chat_id:
                            send_message(chat_id, f"❌ تم استنفاد جميع المفاتيح ({attempt} محاولة)\n💡 جميع المفاتيح فشلت بسبب أخطاء في الاتصال")
                        notify_admin_key_failure(service_name, f"تم استنفاد جميع المفاتيح بعد {attempt} محاولة - أخطاء اتصال")
                        return False

                # Check for API key issues
                if response.headers.get('Content-Type') and 'application/json' in response.headers.get('Content-Type'):
                    try:
                        json_response = response.json()
                    except json.JSONDecodeError:
                        logging.error(f"Remove.bg API returned non-JSON response when expected: {response.text}")
                        # Try next key
                        old_key = key
                        new_key = fail_and_rotate_key(key_file)
                        if new_key:
                            if chat_id and progress_msg_id:
                                progress_msg_id = send_progress_update(chat_id, progress_msg_id, min(progress + 5, 90), f"🔄 استجابة غير صالحة - محاولة {attempt+1}/{total_keys}")
                            continue
                        else:
                            if chat_id:
                                send_message(chat_id, f"❌ تم استنفاد جميع المفاتيح ({attempt} محاولة)")
                            return False

                    # التمييز بين الصورة المرفوضة ونفاد الرصيد
                    if response.status_code in [401, 402, 403, 429] or json_response.get('errors'):
                        if json_response.get('errors'):
                            error_details = json_response.get('errors', [{}])[0] if isinstance(json_response.get('errors'), list) else {}
                            error_code = error_details.get('code', '')
                            error_title = error_details.get('title', '')
                            
                            # التحقق من نوع الخطأ
                            # أخطاء الصورة المرفوضة (لا نغير المفتاح)
                            image_rejection_errors = [
                                'invalid_image_file',
                                'image_too_small',
                                'image_too_large', 
                                'foreground_type_not_allowed',
                                'unknown_foreground',
                                'no_foreground_found'
                            ]
                            
                            # أخطاء نفاد الرصيد (نغير المفتاح)
                            credit_errors = [
                                'insufficient_credits',
                                'no_credits',
                                'rate_limit_exceeded'
                            ]
                            
                            # حالة الصورة المرفوضة - لا نغير المفتاح
                            if error_code in image_rejection_errors:
                                error_msg = error_title or error_details.get('detail', 'الصورة غير مناسبة')
                                logging.warning(f"Remove.bg rejected image (attempt {attempt}): {error_code} - {error_msg}")
                                
                                if chat_id:
                                    send_message(chat_id, f"❌ *الصورة غير مناسبة للمعالجة*\n\n"
                                                        f"📝 السبب: {error_msg}\n\n"
                                                        f"💡 نصائح:\n"
                                                        f"• تأكد من أن الصورة واضحة\n"
                                                        f"• تأكد من أن الصورة تحتوي على شخص أو كائن واضح\n"
                                                        f"• تجنب الصور الصغيرة جدًا أو الكبيرة جدًا\n"
                                                        f"• تأكد من جودة الصورة",
                                                        parse_mode='Markdown')
                                
                                # لا نغير المفتاح في حالة الصورة المرفوضة
                                return False
                            
                            # حالة نفاد الرصيد - نغير المفتاح
                            elif error_code in credit_errors or response.status_code == 402:
                                error_reason = "نفاد الرصيد"
                                logging.error(f"Remove.bg API Key failed ({error_reason}) on attempt {attempt}. Code: {error_code}")
                                
                                # محاولة تدوير المفتاح
                                old_key = key
                                new_key = fail_and_rotate_key(key_file)
                                if new_key:
                                    logging.info(f"Rotated to new key for Remove.bg due to: {error_reason} (attempt {attempt})")
                                    notify_admin_key_success_enhanced(service_name, old_key, new_key, attempt)
                                    log_key_change(service_name, old_key, new_key, f"automatic_rotation_on_{error_reason}_attempt_{attempt}")
                                    
                                    if chat_id and progress_msg_id:
                                        progress_msg_id = send_progress_update(chat_id, progress_msg_id, min(progress + 5, 90), f"🔄 {error_reason} - محاولة {attempt+1}/{total_keys}")
                                    
                                    continue  # Try next key
                                else:
                                    logging.error(f"No more backup keys for Remove.bg after {attempt} attempts. Last error: {error_reason}")
                                    if chat_id:
                                        send_message(chat_id, f"❌ تم استنفاد جميع مفاتيح {service_name} ({attempt} محاولة)\n💡 السبب: {error_reason}")
                                    notify_admin_key_failure(service_name, f"تم استنفاد جميع المفاتيح بعد {attempt} محاولة - {error_reason}")
                                    return False
                        
                        # حالات الأخطاء الأخرى (خطأ في المفتاح، وصول غير مصرح به، إلخ)
                        error_reason = "خطأ في المفتاح" if response.status_code in [401, 403] else "خطأ في الخدمة"
                        logging.error(f"Remove.bg API Key failed ({error_reason}) on attempt {attempt}. HTTP Code: {response.status_code}")
                        
                        # Try to rotate key
                        old_key = key
                        new_key = fail_and_rotate_key(key_file)
                        if new_key:
                            logging.info(f"Rotated to new key for Remove.bg due to: {error_reason} (attempt {attempt})")
                            notify_admin_key_success_enhanced(service_name, old_key, new_key, attempt)
                            log_key_change(service_name, old_key, new_key, f"automatic_rotation_on_{error_reason}_attempt_{attempt}")
                            
                            if chat_id and progress_msg_id:
                                send_progress_update(chat_id, progress_msg_id, min(progress + 5, 90), f"🔄 {error_reason} - محاولة {attempt+1}/{total_keys}")
                            
                            continue  # Try next key
                        else:
                            logging.error(f"No more backup keys for Remove.bg after {attempt} attempts. Last error: {error_reason}")
                            if chat_id:
                                send_message(chat_id, f"❌ تم استنفاد جميع مفاتيح {service_name} ({attempt} محاولة)\n💡 السبب الأخير: {error_reason}")
                            notify_admin_key_failure(service_name, f"تم استنفاد جميع المفاتيح بعد {attempt} محاولة - {error_reason}")
                            return False
                    else:
                        logging.error(f"Remove.bg API returned unexpected JSON: {response.text}")
                        # Try next key
                        old_key = key
                        new_key = fail_and_rotate_key(key_file)
                        if new_key:
                            if chat_id and progress_msg_id:
                                progress_msg_id = send_progress_update(chat_id, progress_msg_id, min(progress + 5, 90), f"🔄 خطأ غير متوقع - محاولة {attempt+1}/{total_keys}")
                            continue
                        else:
                            if chat_id:
                                send_message(chat_id, f"❌ تم استنفاد جميع المفاتيح ({attempt} محاولة)")
                            return False

                # Success case
                if response.status_code == 200:
                    out_path = os.path.join(TEMP_PDF_DIR, f"temp_removed_{uuid.uuid4()}.png")
                    with open(out_path, 'wb') as f:
                        f.write(response.content)
                    increment_usage(key_file)
                    
                    if chat_id and progress_msg_id:
                        progress_msg_id = send_progress_update(chat_id, progress_msg_id, 100, "✅ اكتمل بنجاح")
                    
                    logging.info(f"Background removed successfully on attempt {attempt}. Output: {out_path}")
                    return out_path
                else:
                    logging.error(f"Remove.bg API returned non-200 HTTP code: {response.status_code}, Response: {response.text}")
                    # Try next key
                    old_key = key
                    new_key = fail_and_rotate_key(key_file)
                    if new_key:
                        if chat_id and progress_msg_id:
                            progress_msg_id = send_progress_update(chat_id, progress_msg_id, min(progress + 5, 90), f"🔄 كود خطأ {response.status_code} - محاولة {attempt+1}/{total_keys}")
                        continue
                    else:
                        if chat_id:
                            send_message(chat_id, f"❌ تم استنفاد جميع المفاتيح ({attempt} محاولة)")
                        return False

        except requests.exceptions.RequestException as e:
            logging.error(f"Remove.bg request error on attempt {attempt}: {e}")
            
            # Try next key on request exception
            old_key = key
            new_key = fail_and_rotate_key(key_file)
            if new_key:
                logging.info(f"Rotated to new key for Remove.bg due to request exception (attempt {attempt})")
                notify_admin_key_success_enhanced(service_name, old_key, new_key, attempt)
                log_key_change(service_name, old_key, new_key, f"automatic_rotation_on_request_exception_attempt_{attempt}")
                if chat_id and progress_msg_id:
                    progress_msg_id = send_progress_update(chat_id, progress_msg_id, min(progress + 5, 90), f"🔄 خطأ طلب - محاولة {attempt+1}/{total_keys}")
                continue
            else:
                if chat_id:
                    send_message(chat_id, f"❌ تم استنفاد جميع المفاتيح ({attempt} محاولة)\n💡 أخطاء في الاتصال")
                notify_admin_key_failure(service_name, f"تم استنفاد جميع المفاتيح بعد {attempt} محاولة - أخطاء طلب")
                return False
        except Exception as e:
            logging.error(f"An unexpected error occurred during Remove.bg processing on attempt {attempt}: {e}")
            logging.error(f"Error details: {type(e).__name__}")
            # Try next key
            old_key = key
            new_key = fail_and_rotate_key(key_file)
            if new_key:
                logging.info(f"Rotated to new key for Remove.bg due to unexpected error: {type(e).__name__} (attempt {attempt})")
                notify_admin_key_success_enhanced(service_name, old_key, new_key, attempt)
                log_key_change(service_name, old_key, new_key, f"automatic_rotation_on_unexpected_error_attempt_{attempt}")
                if chat_id and progress_msg_id:
                    send_progress_update(chat_id, progress_msg_id, min(progress + 5, 90), f"🔄 خطأ غير متوقع - محاولة {attempt+1}/{total_keys}")
                continue
            else:
                if chat_id:
                    send_message(chat_id, f"❌ تم استنفاد جميع المفاتيح ({attempt} محاولة)")
                notify_admin_key_failure(service_name, f"تم استنفاد جميع المفاتيح بعد {attempt} محاولة - خطأ غير متوقع: {type(e).__name__}: {str(e)}")
                return False

    # If we've exhausted max attempts
    if chat_id:
        send_message(chat_id, f"❌ تم تجاوز الحد الأقصى من المحاولات ({max_attempts})")
    return False

def composite_on_white_background(transparent_image_path):
    """
    Composites a transparent PNG image onto a white background.

    Args:
        transparent_image_path (str): The path to the input transparent PNG image.

    Returns:
        str or False: The path to the new image with a white background, or False on failure.
    """
    if not os.path.exists(transparent_image_path):
        logging.error(f"Transparent image file not found: {transparent_image_path}")
        return False

    try:
        img = Image.open(transparent_image_path).convert("RGBA")

        # Create a white background image
        white_bg = Image.new("RGB", img.size, (255, 255, 255))

        # Composite the transparent image onto the white background
        white_bg.paste(img, (0, 0), img) # The third argument (mask) uses the alpha channel

        output_path = os.path.join(TEMP_PDF_DIR, f"temp_white_bg_{uuid.uuid4()}.png")
        white_bg.save(output_path)
        logging.info(f"Composited image on white background. Output: {output_path}")
        return output_path
    except Exception as e:
        logging.error(f"Failed to composite image on white background: {e}")
        return False

def enhance_image(image_path, key_file, chat_id=None, progress_msg_id=None):
    """
    Enhances an image using the Picsart API.
    This function includes automatic API key rotation on failure.

    Args:
        image_path (str): The local path to the input image.
        key_file (str): The path to the Picsart API key file.
        chat_id (int, optional): Chat ID to send progress updates.
        progress_msg_id (int, optional): Message ID for updating progress.

    Returns:
        str or False: The local path to the enhanced output image on success, False on failure.
    """
    service_name = "Picsart"
    
    # Get total number of available keys
    key_data = get_key_data(key_file)
    total_keys = 1 + len(key_data.get('backup_keys', []))  # current + backups
    
    if key_data.get('current_key') is None:
        total_keys = len(key_data.get('backup_keys', []))
    
    max_attempts = max(total_keys, 50)  # Try all keys or 50 times max
    attempt = 0
    
    while attempt < max_attempts:
        attempt += 1
        key = get_active_key(key_file)
        
        if not key:
            logging.error(f"{service_name} API Key not available - no keys in pool after {attempt} attempts.")
            if chat_id:
                send_message(chat_id, f"❌ تم استنفاد جميع المفاتيح المتاحة ({attempt-1} محاولة)\n💡 لا يوجد مفتاح صالح لخدمة {service_name}")
            notify_admin_key_failure(service_name, f"تم استنفاد جميع المفاتيح بعد {attempt-1} محاولة")
            return False

        try:
            # Show progress
            if chat_id and progress_msg_id:
                progress = min(30 + (attempt * 15), 95)
                progress_msg_id = send_progress_update(chat_id, progress_msg_id, progress, f"⏳ محاولة {attempt}/{total_keys}")

            with open(image_path, 'rb') as img_file:
                files = {'image': img_file}
                data = {'upscale_factor': 2}
                headers = {"X-Picsart-API-Key": key}

                response_obj = make_request("https://api.picsart.io/tools/1.0/upscale", 'POST', data=data, files=files, headers=headers, timeout=30)
                response = response_obj['response']

                if response_obj['error'] or response is None:
                    logging.error(f"Picsart request error or no response (attempt {attempt}): {response_obj['error'] or 'No response object'}")
                    
                    # Try next key on network error
                    old_key = key
                    new_key = fail_and_rotate_key(key_file)
                    if new_key:
                        logging.info(f"Rotated to new key for Picsart due to network error (attempt {attempt})")
                        notify_admin_key_success_enhanced(service_name, old_key, new_key, attempt)
                        log_key_change(service_name, old_key, new_key, f"automatic_rotation_on_network_error_attempt_{attempt}")
                        if chat_id and progress_msg_id:
                            progress_msg_id = send_progress_update(chat_id, progress_msg_id, min(progress + 5, 90), f"🔄 خطأ اتصال - محاولة {attempt+1}/{total_keys}")
                        continue
                    else:
                        if chat_id:
                            send_message(chat_id, f"❌ تم استنفاد جميع المفاتيح ({attempt} محاولة)\n💡 جميع المفاتيح فشلت بسبب أخطاء في الاتصال")
                        notify_admin_key_failure(service_name, f"تم استنفاد جميع المفاتيح بعد {attempt} محاولة - أخطاء اتصال")
                        return False

                # Check for API key issues
                if response.headers.get('Content-Type') and 'application/json' in response.headers.get('Content-Type'):
                    try:
                        json_response = response.json()
                    except json.JSONDecodeError:
                        logging.error(f"Picsart API returned non-JSON response when expected: {response.text}")
                        old_key = key
                        new_key = fail_and_rotate_key(key_file)
                        if new_key:
                            if chat_id and progress_msg_id:
                                progress_msg_id = send_progress_update(chat_id, progress_msg_id, min(progress + 5, 90), f"🔄 استجابة غير صالحة - محاولة {attempt+1}/{total_keys}")
                            continue
                        else:
                            if chat_id:
                                send_message(chat_id, f"❌ تم استنفاد جميع المفاتيح ({attempt} محاولة)")
                            return False

                    # التمييز بين الصورة المرفوضة ونفاد الرصيد
                    if response.status_code in [401, 402, 403, 429] or json_response:
                        error_message = json_response.get('message', '') if json_response else ''
                        error_code = json_response.get('code', '') if json_response else ''
                        
                        # أخطاء الصورة المرفوضة (لا نغير المفتاح)
                        image_rejection_errors = [
                            'invalid_image',
                            'image_too_small',
                            'image_too_large',
                            'unsupported_format',
                            'corrupted_image',
                            'invalid_file'
                        ]
                        
                        # أخطاء نفاد الرصيد (نغير المفتاح)
                        credit_errors = [
                            'insufficient_credits',
                            'no_credits',
                            'rate_limit_exceeded',
                            'quota_exceeded'
                        ]
                        
                        # حالة الصورة المرفوضة - لا نغير المفتاح
                        is_image_rejection = any(err in error_message.lower() or err in error_code.lower() 
                                                for err in image_rejection_errors)
                        
                        if is_image_rejection:
                            logging.warning(f"Picsart rejected image (attempt {attempt}): {error_message}")
                            
                            if chat_id:
                                send_message(chat_id, f"❌ *الصورة غير مناسبة للمعالجة*\n\n"
                                                    f"📝 السبب: {error_message}\n\n"
                                                    f"💡 نصائح:\n"
                                                    f"• تأكد من أن الصورة بتنسيق صحيح (JPG, PNG)\n"
                                                    f"• تأكد من أن حجم الصورة مناسب\n"
                                                    f"• تجنب الصور التالفة أو المعطوبة\n"
                                                    f"• استخدم صورة واضحة وعالية الجودة",
                                            parse_mode='Markdown')
                            
                            # لا نغير المفتاح في حالة الصورة المرفوضة
                            return False
                        
                        # حالة نفاد الرصيد - نغير المفتاح
                        is_credit_error = (response.status_code == 402 or 
                                         any(err in error_message.lower() or err in error_code.lower() 
                                             for err in credit_errors))
                        
                        if is_credit_error or response.status_code in [401, 403, 429]:
                            error_reason = "نفاد الرصيد" if is_credit_error else "خطأ في المفتاح"
                            logging.error(f"Picsart API Key failed ({error_reason}) on attempt {attempt}. HTTP Code: {response.status_code}, Response: {response.text}")
                            
                            old_key = key
                            new_key = fail_and_rotate_key(key_file)
                            if new_key:
                                logging.info(f"Rotated to new key for Picsart due to: {error_reason} (attempt {attempt})")
                                notify_admin_key_success_enhanced(service_name, old_key, new_key, attempt)
                                log_key_change(service_name, old_key, new_key, f"automatic_rotation_on_{error_reason}_attempt_{attempt}")
                                
                                if chat_id and progress_msg_id:
                                    send_progress_update(chat_id, progress_msg_id, min(progress + 5, 90), f"🔄 {error_reason} - محاولة {attempt+1}/{total_keys}")
                                
                                continue
                            else:
                                logging.error(f"No more backup keys for Picsart after {attempt} attempts. Last error: {error_reason}")
                                if chat_id:
                                    send_message(chat_id, f"❌ تم استنفاد جميع مفاتيح {service_name} ({attempt} محاولة)\n💡 السبب الأخير: {error_reason}")
                                notify_admin_key_failure(service_name, f"تم استنفاد جميع المفاتيح بعد {attempt} محاولة - {error_reason}")
                                return False
                    else:
                        logging.error(f"Picsart API returned unexpected JSON: {response.text}")
                        old_key = key
                        new_key = fail_and_rotate_key(key_file)
                        if new_key:
                            logging.info(f"Rotated to new key for Picsart due to unexpected JSON (attempt {attempt})")
                            notify_admin_key_success_enhanced(service_name, old_key, new_key, attempt)
                            log_key_change(service_name, old_key, new_key, f"automatic_rotation_on_unexpected_json_attempt_{attempt}")
                            if chat_id and progress_msg_id:
                                progress_msg_id = send_progress_update(chat_id, progress_msg_id, min(progress + 5, 90), f"🔄 خطأ غير متوقع - محاولة {attempt+1}/{total_keys}")
                            continue
                        else:
                            if chat_id:
                                send_message(chat_id, f"❌ تم استنفاد جميع المفاتيح ({attempt} محاولة)")
                            notify_admin_key_failure(service_name, f"تم استنفاد جميع المفاتيح بعد {attempt} محاولة - استجابة غير متوقعة")
                            return False

                # Success case
                if response.status_code == 200:
                    if 'data' not in json_response or 'url' not in json_response['data']:
                        logging.error(f"Picsart API returned success but missing data. Response: {response.text}")
                        old_key = key
                        new_key = fail_and_rotate_key(key_file)
                        if new_key:
                            continue
                        else:
                            return False
                    
                    enhanced_image_url = json_response['data']['url']

                    # Download the enhanced image
                    try:
                        image_content_response = requests.get(enhanced_image_url, timeout=30)
                        image_content_response.raise_for_status()

                        ext = os.path.splitext(image_path)[1] or '.png'
                        out_path = os.path.join(TEMP_PDF_DIR, f"temp_enhanced_{uuid.uuid4()}{ext}")
                        with open(out_path, 'wb') as f:
                            f.write(image_content_response.content)

                        increment_usage(key_file)
                        
                        if chat_id and progress_msg_id:
                            progress_msg_id = send_progress_update(chat_id, progress_msg_id, 100, "✅ اكتمل بنجاح")
                        
                        logging.info(f"Image enhanced successfully on attempt {attempt}. Output: {out_path}")
                        return out_path
                    except Exception as download_error:
                        logging.error(f"Error downloading enhanced image: {download_error}")
                        # Try next key if download fails
                        old_key = key
                        new_key = fail_and_rotate_key(key_file)
                        if new_key:
                            logging.info(f"Rotated to new key for Picsart due to download error (attempt {attempt})")
                            notify_admin_key_success_enhanced(service_name, old_key, new_key, attempt)
                            log_key_change(service_name, old_key, new_key, f"automatic_rotation_on_download_error_attempt_{attempt}")
                            if chat_id and progress_msg_id:
                                send_progress_update(chat_id, progress_msg_id, min(progress + 5, 90), f"🔄 خطأ تحميل - محاولة {attempt+1}/{total_keys}")
                            continue
                        else:
                            if chat_id:
                                send_message(chat_id, f"❌ تم استنفاد جميع المفاتيح ({attempt} محاولة)")
                            notify_admin_key_failure(service_name, f"تم استنفاد جميع المفاتيح بعد {attempt} محاولة - خطأ تحميل")
                            return False
                else:
                    logging.error(f"Picsart API returned non-200 HTTP code: {response.status_code}, Response: {response.text}")
                    old_key = key
                    new_key = fail_and_rotate_key(key_file)
                    if new_key:
                        logging.info(f"Rotated to new key for Picsart due to non-200 status (attempt {attempt})")
                        notify_admin_key_success_enhanced(service_name, old_key, new_key, attempt)
                        log_key_change(service_name, old_key, new_key, f"automatic_rotation_on_http_{response.status_code}_attempt_{attempt}")
                        if chat_id and progress_msg_id:
                            progress_msg_id = send_progress_update(chat_id, progress_msg_id, min(progress + 5, 90), f"🔄 كود خطأ {response.status_code} - محاولة {attempt+1}/{total_keys}")
                        continue
                    else:
                        if chat_id:
                            send_message(chat_id, f"❌ تم استنفاد جميع المفاتيح ({attempt} محاولة)")
                        notify_admin_key_failure(service_name, f"تم استنفاد جميع المفاتيح بعد {attempt} محاولة - HTTP {response.status_code}")
                        return False

        except requests.exceptions.RequestException as e:
            logging.error(f"Picsart request error on attempt {attempt}: {e}")
            
            old_key = key
            new_key = fail_and_rotate_key(key_file)
            if new_key:
                logging.info(f"Rotated to new key for Picsart due to request exception (attempt {attempt})")
                notify_admin_key_success_enhanced(service_name, old_key, new_key, attempt)
                log_key_change(service_name, old_key, new_key, f"automatic_rotation_on_request_exception_attempt_{attempt}")
                if chat_id and progress_msg_id:
                    progress_msg_id = send_progress_update(chat_id, progress_msg_id, min(progress + 5, 90), f"🔄 خطأ طلب - محاولة {attempt+1}/{total_keys}")
                continue
            else:
                if chat_id:
                    send_message(chat_id, f"❌ تم استنفاد جميع المفاتيح ({attempt} محاولة)\n💡 أخطاء في الاتصال")
                notify_admin_key_failure(service_name, f"تم استنفاد جميع المفاتيح بعد {attempt} محاولة - أخطاء طلب")
                return False
        except Exception as e:
            # Unexpected errors - rotate to next key and continue trying
            logging.error(f"Unexpected error in Picsart on attempt {attempt}: {e}")
            logging.error(f"Error details: {type(e).__name__}")
            old_key = key
            new_key = fail_and_rotate_key(key_file)
            if new_key:
                logging.info(f"Rotated to new key for Picsart due to unexpected error: {type(e).__name__} (attempt {attempt})")
                notify_admin_key_success_enhanced(service_name, old_key, new_key, attempt)
                log_key_change(service_name, old_key, new_key, f"automatic_rotation_on_unexpected_error_attempt_{attempt}")
                if chat_id and progress_msg_id:
                    send_progress_update(chat_id, progress_msg_id, min(progress + 5, 90), f"🔄 خطأ غير متوقع - محاولة {attempt+1}/{total_keys}")
                continue
            else:
                if chat_id:
                    send_message(chat_id, f"❌ تم استنفاد جميع المفاتيح ({attempt} محاولة)")
                notify_admin_key_failure(service_name, f"تم استنفاد جميع المفاتيح بعد {attempt} محاولة - خطأ غير متوقع: {type(e).__name__}: {str(e)}")
                return False
    
    # If we've exhausted max attempts
    if chat_id:
        send_message(chat_id, f"❌ تم تجاوز الحد الأقصى من المحاولات ({max_attempts})")
    return False

def cm_to_px(cm, dpi=300):
    """
    Converts centimeters to pixels at a given DPI.

    Args:
        cm (float): Value in centimeters.
        dpi (int): Dots per inch.

    Returns:
        int: Value in pixels.
    """
    return int(round((cm / 2.54) * dpi))

def create_real_3x4_template(image_path, user_id):
    """
    Creates a 3x4 photo template from an input image (المعاملات template).

    Args:
        image_path (str): The local path to the input image.
        user_id (int): The ID of the user (for unique output file naming).

    Returns:
        str or False: The local path to the generated template image on success, False on failure.
    """
    dpi = 300
    paper_w_cm, paper_h_cm = 10, 15
    img_w_cm, img_h_cm = 3, 4

    paper_w_px = cm_to_px(paper_w_cm, dpi)
    paper_h_px = cm_to_px(paper_h_cm, dpi)
    img_w_px = cm_to_px(img_w_cm, dpi)
    img_h_px = cm_to_px(img_h_cm, dpi)

    cols = 3
    rows = 3
    spacing = 6 # Pixels
    border = 4 # Pixels

    try:
        # Create a white canvas
        canvas = Image.new('RGB', (paper_w_px, paper_h_px), (255, 255, 255))
        draw = ImageDraw.Draw(canvas)

        # Open and process the source image
        src_img = Image.open(image_path).convert("RGB")
        src_w, src_h = src_img.size

        target_ratio = img_w_cm / img_h_cm # 3/4
        current_ratio = src_w / src_h

        # Crop image to 3:4 aspect ratio if significantly different
        if abs(current_ratio - target_ratio) > 0.01:
            if current_ratio > target_ratio: # Image is wider than 3:4, crop width
                crop_w = int(src_h * target_ratio)
                crop_x = int((src_w - crop_w) / 2)
                src_img = src_img.crop((crop_x, 0, crop_x + crop_w, src_h))
            else: # Image is taller than 3:4, crop height
                crop_h = int((src_w / target_ratio))
                crop_y = int((src_h - crop_h) / 2)
                src_img = src_img.crop((0, crop_y, src_w, crop_y + crop_h))

        # Resize to target photo size
        resized_img = src_img.resize((img_w_px, img_h_px), Image.Resampling.LANCZOS)

        for y in range(rows):
            for x in range(cols):
                pos_x = x * (img_w_px + spacing) + spacing
                pos_y = y * (img_h_px + spacing) + spacing

                canvas.paste(resized_img, (pos_x, pos_y))

                # Draw border
                draw.rectangle([pos_x - border // 2, pos_y - border // 2,
                                pos_x + img_w_px + border // 2, pos_y + img_h_px + border // 2],
                                outline=(200, 200, 200), width=border)

        output_path = os.path.join(TEMP_PDF_DIR, f"template_{user_id}_{uuid.uuid4()}.png")
        canvas.save(output_path)
        logging.info(f"قالب المعاملات (3x4) created. Output: {output_path}")
        return output_path
    except Exception as e:
        logging.error(f"Failed to create قالب المعاملات (3x4) template: {e}")
        return False

def add_white_space_to_image(image_path, user_id, space_height_cm=2):
    """
    Add white space above the image while preserving original image quality and dimensions.
    
    Args:
        image_path (str): The local path to the input image.
        user_id (int): The ID of the user (for unique output file naming).
        space_height_cm (float): Height of white space to add in cm.
    
    Returns:
        str or False: The local path to the modified image on success, False on failure.
    """
    try:
        dpi = 300
        space_height_px = cm_to_px(space_height_cm, dpi)
        
        # Open the image and preserve original mode
        with Image.open(image_path) as img_original:
            # Store original mode and metadata
            original_mode = img_original.mode
            original_dpi = img_original.info.get('dpi', (dpi, dpi))
            
            # Convert to RGB only if needed (preserve transparency if present)
            if original_mode == 'RGBA':
                img = img_original.convert("RGB")
            elif original_mode in ('LA', 'P'):
                img = img_original.convert("RGB")
            elif original_mode != 'RGB':
                img = img_original.convert("RGB")
            else:
                img = img_original.copy()
            
            img_width, img_height = img.size
        
        # Create a new image with white space on top (keep same width)
        new_height = img_height + space_height_px
        new_img = Image.new('RGB', (img_width, new_height), (255, 255, 255))
        
        # Paste the original image below the white space (preserves exact positioning)
        new_img.paste(img, (0, space_height_px))
        
        # Save with high quality settings
        output_path = os.path.join(TEMP_PDF_DIR, f"white_space_{user_id}_{uuid.uuid4()}.png")
        
        # Save with maximum quality
        new_img.save(
            output_path,
            format='PNG',
            optimize=False,  # Don't optimize to preserve quality
            quality=95  # High quality
        )
        
        logging.info(f"White space added to image. Original: {img_width}x{img_height}px, New: {img_width}x{new_height}px. Output: {output_path}")
        return output_path
        
    except Exception as e:
        logging.error(f"Failed to add white space to image: {e}")
        return False

def convert_image_to_pdf(image_path, user_id, dpi=300, max_size_kb=300):
    """
    Converts a single image to PDF using img2pdf (lossless – exact colors preserved).
    The PDF page size matches the image's physical dimensions at the given DPI.

    Args:
        image_path (str): Path to the input image.
        user_id (int): Used for unique output filename.
        dpi (int): DPI for PDF page-size calculation (default 300).
        max_size_kb (int): Kept for API compatibility; img2pdf is lossless so no
                           quality reduction is applied.

    Returns:
        str or False: Path to the generated PDF on success, False on failure.
    """
    import img2pdf
    from PIL import Image

    if not os.path.exists(image_path):
        logging.error(f"convert_image_to_pdf: file not found: {image_path}")
        return False

    tmp_png = None
    try:
        img = Image.open(image_path)

        # Composite transparency onto white background (img2pdf doesn't support alpha)
        if img.mode in ('RGBA', 'LA', 'P'):
            bg = Image.new('RGB', img.size, (255, 255, 255))
            if img.mode == 'P':
                img = img.convert('RGBA')
            bg.paste(img, mask=img.split()[-1] if 'A' in img.mode else None)
            img = bg
        elif img.mode not in ('RGB', 'L'):
            img = img.convert('RGB')

        # Save as lossless PNG – zero color loss
        tmp_png = os.path.join(TEMP_PDF_DIR, f"tmp_i2p_{user_id}_{uuid.uuid4()}.png")
        img.save(tmp_png, 'PNG')

        output_path = os.path.join(TEMP_PDF_DIR, f"temp_pdf_{user_id}_{uuid.uuid4()}.pdf")
        layout = img2pdf.get_fixed_dpi_layout_fun((dpi, dpi))
        with open(output_path, 'wb') as f:
            f.write(img2pdf.convert(tmp_png, layout_fun=layout))

        pdf_kb = os.path.getsize(output_path) / 1024
        logging.info(f"convert_image_to_pdf: lossless PDF created, size: {pdf_kb:.1f} KB, dpi: {dpi}")
        return output_path

    except Exception as e:
        logging.error(f"convert_image_to_pdf error: {e}")
        return False
    finally:
        if tmp_png and os.path.exists(tmp_png):
            try:
                os.remove(tmp_png)
            except Exception:
                pass

def create_new_template(image_path, user_id):
    """
    Creates a new photo template from an input image.
    New template: 3.5cm width x 4.5cm height photos, 3 rows x 2 columns = 6 photos total (vertical layout).

    Args:
        image_path (str): The local path to the input image.
        user_id (int): The ID of the user (for unique output file naming).

    Returns:
        str or False: The local path to the generated template image on success, False on failure.
    """
    dpi = 300
    paper_w_cm, paper_h_cm = 10, 15
    img_w_cm, img_h_cm = 3.5, 4.5  # الآن العرض 3.5 والطول 4.5

    paper_w_px = cm_to_px(paper_w_cm, dpi)
    paper_h_px = cm_to_px(paper_h_cm, dpi)
    img_w_px = cm_to_px(img_w_cm, dpi)
    img_h_px = cm_to_px(img_h_cm, dpi)

    cols = 2  # عمودين
    rows = 3  # 3 صفوف
    spacing = 8 # Slightly more spacing for larger photos
    border = 4 # Pixels

    try:
        # Create a white canvas
        canvas = Image.new('RGB', (paper_w_px, paper_h_px), (255, 255, 255))
        draw = ImageDraw.Draw(canvas)

        # Open and process the source image
        src_img = Image.open(image_path).convert("RGB")
        src_w, src_h = src_img.size

        target_ratio = img_w_cm / img_h_cm # 3.5/4.5
        current_ratio = src_w / src_h

        # Crop image to 3.5:4.5 aspect ratio if significantly different
        if abs(current_ratio - target_ratio) > 0.01:
            if current_ratio > target_ratio: # Image is wider, crop width
                crop_w = int(src_h * target_ratio)
                crop_x = int((src_w - crop_w) / 2)
                src_img = src_img.crop((crop_x, 0, crop_x + crop_w, src_h))
            else: # Image is taller, crop height
                crop_h = int((src_w / target_ratio))
                crop_y = int((src_h - crop_h) / 2)
                src_img = src_img.crop((0, crop_y, src_w, crop_y + crop_h))

        # Resize to target photo size
        resized_img = src_img.resize((img_w_px, img_h_px), Image.Resampling.LANCZOS)

        # Start from top-left corner with spacing (remove center alignment)
        start_x = spacing
        start_y = spacing

        for y in range(rows):
            for x in range(cols):
                pos_x = start_x + x * (img_w_px + spacing)
                pos_y = start_y + y * (img_h_px + spacing)

                canvas.paste(resized_img, (pos_x, pos_y))

                # Draw border
                draw.rectangle([pos_x - border // 2, pos_y - border // 2,
                                pos_x + img_w_px + border // 2, pos_y + img_h_px + border // 2],
                                outline=(200, 200, 200), width=border)

        output_path = os.path.join(TEMP_PDF_DIR, f"template_new_{user_id}_{uuid.uuid4()}.png")
        canvas.save(output_path)
        logging.info(f"قالب الجوازات (3.5x4.5) created. Output: {output_path}")
        return output_path
    except Exception as e:
        logging.error(f"Failed to create new template: {e}")
        return False

def create_multi_person_template(image_paths, user_id, layout_type="6x3"):
    """
    Create a multi-person template with 6x3 or 5x4 layout using multiple images.
    
    Args:
        image_paths (list): List of paths to source images
        user_id (int): User ID for file naming
        layout_type (str): Either "6x3" or "5x4"
    
    Returns:
        str or False: Path to created template or False on failure
    """
    try:
        # Template dimensions (same as قالب المعاملات 3x4 template)
        dpi = 300
        paper_w_cm, paper_h_cm = 10, 15
        paper_w_px = cm_to_px(paper_w_cm, dpi)
        paper_h_px = cm_to_px(paper_h_cm, dpi)
        
        # Create canvas
        canvas = Image.new('RGB', (paper_w_px, paper_h_px), 'white')
        draw = ImageDraw.Draw(canvas)
        
        # Photo dimensions (3x4 cm - same as قالب المعاملات template)
        img_w_cm = 3
        img_h_cm = 4
        img_w_px = cm_to_px(img_w_cm, dpi)
        img_h_px = cm_to_px(img_h_cm, dpi)
        
        # Spacing and border (same as original template)
        spacing = 6
        border = 4
        
        # Define layout patterns (3x3 grid, 9 total positions)
        cols = 3
        rows = 3
        total_photos = 9
        
        # Start from top-left corner with spacing
        start_x = spacing
        start_y = spacing
        
        # Determine distribution based on layout type
        if layout_type == "6x3":
            # First 6 positions for person 1, last 3 for person 2
            person_distribution = [0, 0, 0, 0, 0, 0, 1, 1, 1]
        elif layout_type == "5x4":
            # First 5 positions for person 1, last 4 for person 2
            person_distribution = [0, 0, 0, 0, 0, 1, 1, 1, 1]
        else:
            logging.error(f"Invalid layout type: {layout_type}")
            return False
        
        # Ensure we have at least 2 images
        num_images = len(image_paths)
        if num_images < 2:
            logging.error(f"Multi-person template requires at least 2 images, got {num_images}")
            return False
        
        # Pre-process and cache images
        processed_images = []
        for img_path in image_paths:
            try:
                src_img = Image.open(img_path).convert("RGB")
                src_w, src_h = src_img.size
                
                # Crop to 3:4 aspect ratio
                target_ratio = img_w_cm / img_h_cm  # 3/4
                current_ratio = src_w / src_h
                
                if abs(current_ratio - target_ratio) > 0.01:
                    if current_ratio > target_ratio:  # Image is wider, crop width
                        crop_w = int(src_h * target_ratio)
                        crop_x = int((src_w - crop_w) / 2)
                        src_img = src_img.crop((crop_x, 0, crop_x + crop_w, src_h))
                    else:  # Image is taller, crop height
                        crop_h = int((src_w / target_ratio))
                        crop_y = int((src_h - crop_h) / 2)
                        src_img = src_img.crop((0, crop_y, src_w, crop_y + crop_h))
                
                # Resize to target photo size
                resized_img = src_img.resize((img_w_px, img_h_px), Image.Resampling.LANCZOS)
                processed_images.append(resized_img)
                
            except Exception as e:
                logging.error(f"Failed to process image {img_path}: {e}")
                return False
        
        # Place images in a 3x3 grid
        position_index = 0
        for y in range(rows):
            for x in range(cols):
                pos_x = start_x + x * (img_w_px + spacing)
                pos_y = start_y + y * (img_h_px + spacing)
                
                # Determine which image to use based on distribution
                person_idx = person_distribution[position_index]
                
                # Use the processed image directly
                if person_idx < len(processed_images):
                    canvas.paste(processed_images[person_idx], (pos_x, pos_y))
                
                # Draw border
                draw.rectangle([pos_x - border // 2, pos_y - border // 2,
                               pos_x + img_w_px + border // 2, pos_y + img_h_px + border // 2],
                              outline=(200, 200, 200), width=border)
                
                position_index += 1
        
        output_path = os.path.join(TEMP_PDF_DIR, f"template_multi_{layout_type}_{user_id}_{uuid.uuid4()}.png")
        canvas.save(output_path)
        logging.info(f"Multi-person template ({layout_type}) created with {len(image_paths)} images. Output: {output_path}")
        return output_path
        
    except Exception as e:
        logging.error(f"Failed to create multi-person template: {e}")
        return False


def apply_whitening_local(image_path: str, whitening: float = 0.6, retouch: float = 0.5):
    """معالجة محلية للصورة باستخدام PIL"""
    try:
        img = Image.open(image_path).convert('RGB')
        brightness = ImageEnhance.Brightness(img)
        brightness_factor = 1.0 + (whitening * 0.5)
        img = brightness.enhance(brightness_factor)
        color = ImageEnhance.Color(img)
        color_factor = 1.0 - (whitening * 0.2)
        img = color.enhance(color_factor)
        output_path = os.path.join(TEMP_PDF_DIR, f"whitened_local_{uuid.uuid4()}.jpg")
        img.save(output_path, format='JPEG', quality=95)
        return output_path, "المكتبة"
    except Exception as e:
        logging.error(f"Local whitening error: {e}")
        return False, "خطأ"


def apply_whitening(image_path: str, whitening: float = 0.6, retouch: float = 0.5, user_id=None):
    """تبييض الصورة باستخدام AILabAPI مع نسخة محلية احتياطية + إعادة محاولة وتحكم بالمفاتيح"""
    service_name = "AILabAPI"
    key_data = get_key_data(AILAB_API_KEY_FILE)
    total_keys = 1 + len(key_data.get('backup_keys', []))
    if key_data.get('current_key') is None:
        total_keys = len(key_data.get('backup_keys', []))
    max_attempts = max(total_keys, 5)
    attempt = 0
    
    while attempt < max_attempts:
        attempt += 1
        ailab_api_key = get_active_key(AILAB_API_KEY_FILE)
        
        if not ailab_api_key:
            logging.error(f"{service_name} API Key not available - no keys in pool after {attempt} attempts.")
            notify_admin_key_failure(service_name, f"تم استنفاد جميع المفاتيح بعد {attempt-1} محاولة")
            return apply_whitening_local(image_path, whitening, retouch)
        
        try:
            headers = {"ailabapi-api-key": ailab_api_key}
            with open(image_path, "rb") as f:
                files = {"image": f}
                data = {"whitening_degree": whitening, "retouch_degree": retouch}
                response = requests.post(AILAB_ENDPOINT, headers=headers, files=files, data=data, timeout=60)
                
                if response.status_code == 200:
                    j = response.json()
                    result_url = j.get("data", {}).get("image_url")
                    if result_url:
                        result_image = requests.get(result_url, timeout=60)
                        result_image.raise_for_status()
                        
                        # فتح الصورة وحفظها بجودة عالية جداً
                        img = Image.open(io.BytesIO(result_image.content)).convert('RGB')
                        output_path = os.path.join(TEMP_PDF_DIR, f"whitened_api_{uuid.uuid4()}.jpg")
                        img.save(output_path, format='JPEG', quality=100, optimize=False)
                        
                        # تسجيل الاستخدام الناجح
                        increment_usage(AILAB_API_KEY_FILE, user_id, "skin_whitening", success=True)
                        increment_operation_count("تبييض البشرة", user_id)
                        logging.info(f"✅ تبييض البشرة بنجاح عبر {service_name} (محاولة {attempt})")
                        return output_path, "AILabAPI"
        except Exception as e:
            logging.warning(f"❌ محاولة {attempt} فشلت: {e}")
            increment_usage(AILAB_API_KEY_FILE, user_id, "skin_whitening", success=False)
            
            if attempt < max_attempts:
                old_key = get_active_key(AILAB_API_KEY_FILE)
                fail_and_rotate_key(AILAB_API_KEY_FILE)
                new_key = get_active_key(AILAB_API_KEY_FILE)
                if old_key and new_key:
                    notify_admin_key_success_enhanced(service_name, old_key, new_key, attempt)
                elif not new_key:
                    notify_admin_key_failure(service_name, f"تم استنفاد جميع المفاتيح بعد {attempt} محاولة - أخطاء اتصال")
                continue
            else:
                logging.warning(f"🔄 {service_name} متعذر - الانتقال للمعالجة المحلية")
                return apply_whitening_local(image_path, whitening, retouch)
    
    return apply_whitening_local(image_path, whitening, retouch)


def check_api_balance():
    """التحقق من رصيد AILabAPI"""
    try:
        ailab_api_key = get_active_key(AILAB_API_KEY_FILE)
        if not ailab_api_key:
            return None, "❌ لا توجد مفاتيح AILabAPI متاحة"
        headers = {"ailabapi-api-key": ailab_api_key}
        response = requests.get(AILAB_BALANCE_ENDPOINT, headers=headers, timeout=30)
        if response.status_code != 200:
            return None, f"❌ خطأ في الاتصال: {response.status_code}"
        data = response.json()
        if data.get("error_code") != 0:
            return None, f"❌ خطأ API: {data.get('error_msg', 'خطأ غير معروف')}"
        credits_data = data.get("data", [])
        if not credits_data:
            return None, "❌ لم يتم العثور على بيانات الرصيد"
        credit_info = credits_data[0]
        balance = credit_info.get("balance", 0)
        total = credit_info.get("total", 0)
        warning_level = credit_info.get("balance_warning", 0)
        return {"balance": balance, "total": total, "warning": warning_level}, None
    except Exception as e:
        logging.error(f"Error checking balance: {e}")
        return None, f"❌ خطأ: {str(e)}"


# --- Gemini Image Generation and Editing Functions ---

def get_gemini_client():
    """الحصول على عميل Gemini مع المفتاح النشط"""
    try:
        from google import genai
        gemini_api_key = get_active_key(GEMINI_API_KEY_FILE)
        if not gemini_api_key:
            logging.error("Gemini API Key not available")
            return None
        client = genai.Client(api_key=gemini_api_key)
        return client
    except ImportError:
        logging.error("google-genai library not installed")
        return None
    except Exception as e:
        logging.error(f"Failed to initialize Gemini Client: {e}")
        return None


def generate_image_gemini(prompt: str, chat_id=None, progress_msg_id=None, user_id=None):
    """
    إنشاء صورة جديدة باستخدام Gemini AI
    
    Args:
        prompt: وصف الصورة المراد إنشاؤها
        chat_id: معرف المحادثة لإرسال رسائل التقدم
        progress_msg_id: معرف رسالة التقدم
        user_id: معرف المستخدم
    
    Returns:
        tuple: (output_path, error_message) - مسار الصورة أو None مع رسالة الخطأ
    """
    try:
        from google import genai
        from google.genai import types
        
        client = get_gemini_client()
        if not client:
            return None, "❌ خدمة إنشاء الصور غير متاحة حالياً"
        
        if chat_id and progress_msg_id:
            send_progress_update(chat_id, progress_msg_id, 30, "جاري إنشاء الصورة...")
        
        response = client.models.generate_content(
            model=GEMINI_IMAGE_MODEL,
            contents=[prompt],
            config=types.GenerateContentConfig(
                response_modalities=['TEXT', 'IMAGE']
            )
        )
        
        if chat_id and progress_msg_id:
            send_progress_update(chat_id, progress_msg_id, 70, "جاري معالجة النتيجة...")
        
        if response is None:
            logging.warning("Gemini returned None response for image generation")
            return None, "⚠️ لم يتمكن النظام من إنشاء الصورة. جرب وصفاً مختلفاً."
        
        prompt_feedback = getattr(response, 'prompt_feedback', None)
        if prompt_feedback:
            block_reason = getattr(prompt_feedback, 'block_reason', None)
            if block_reason:
                logging.warning(f"Gemini blocked prompt. Reason: {block_reason}")
                return None, "⚠️ لم يتمكن النظام من معالجة الطلب. جرب وصفاً مختلفاً."
        
        candidates = getattr(response, 'candidates', None)
        if not candidates or len(candidates) == 0:
            logging.warning("Gemini returned empty candidates list for image generation")
            return None, "⚠️ لم يتمكن النظام من إنشاء الصورة. جرب وصفاً مختلفاً."
        
        text_response = None
        for candidate in candidates:
            finish_reason = getattr(candidate, 'finish_reason', None)
            content = getattr(candidate, 'content', None)
            
            if not content:
                logging.warning(f"Candidate has no content. Finish reason: {finish_reason}")
                continue
            
            parts = getattr(content, 'parts', None)
            if not parts:
                logging.warning(f"Candidate content has no parts. Finish reason: {finish_reason}")
                continue
            
            for part in parts:
                inline_data = getattr(part, 'inline_data', None)
                if inline_data is not None and hasattr(inline_data, 'data'):
                    generated_image_bytes = inline_data.data
                    
                    output_path = os.path.join(TEMP_PDF_DIR, f"gemini_generated_{uuid.uuid4()}.png")
                    with open(output_path, 'wb') as f:
                        f.write(generated_image_bytes)
                    
                    increment_usage(GEMINI_API_KEY_FILE, user_id, "image_generation", success=True)
                    increment_operation_count('إنشاء صورة AI', user_id)
                    logging.info(f"✅ تم إنشاء الصورة بنجاح: {prompt[:50]}...")
                    return output_path, None
                
                text_part = getattr(part, 'text', None)
                if text_part:
                    text_response = text_part
        
        if text_response:
            logging.info(f"Gemini returned text only (no image): {text_response[:100]}...")
            return None, f"⚠️ لم يتمكن النظام من إنشاء الصورة. رد النظام: {text_response[:200]}"
        
        return None, "⚠️ لم يتمكن النظام من إنشاء الصورة. جرب وصفاً مختلفاً."
        
    except Exception as e:
        error_str = str(e).lower()
        logging.error(f"Gemini image generation error: {e}")
        increment_usage(GEMINI_API_KEY_FILE, user_id, "image_generation", success=False)
        
        is_auth_error = any(x in error_str for x in ['api key', 'authentication', 'unauthorized', 'quota', 'rate limit', '401', '403', '429'])
        
        if is_auth_error:
            old_key = get_active_key(GEMINI_API_KEY_FILE)
            new_key = fail_and_rotate_key(GEMINI_API_KEY_FILE)
            if old_key and new_key:
                notify_admin_key_success_enhanced("Gemini AI", old_key, new_key, 1)
        
        return None, f"❌ حدث خطأ أثناء إنشاء الصورة. يرجى المحاولة مرة أخرى."


def edit_image_gemini(image_path: str, edit_prompt: str, chat_id=None, progress_msg_id=None, user_id=None):
    """
    تعديل صورة موجودة باستخدام Gemini AI
    
    Args:
        image_path: مسار الصورة المراد تعديلها
        edit_prompt: وصف التعديل المطلوب
        chat_id: معرف المحادثة لإرسال رسائل التقدم
        progress_msg_id: معرف رسالة التقدم
        user_id: معرف المستخدم
    
    Returns:
        tuple: (output_path, error_message) - مسار الصورة المعدلة أو None مع رسالة الخطأ
    """
    try:
        from google import genai
        from google.genai import types
        
        if not os.path.exists(image_path):
            return None, "❌ لم يتم العثور على الصورة"
        
        client = get_gemini_client()
        if not client:
            return None, "❌ خدمة تعديل الصور غير متاحة حالياً"
        
        if chat_id and progress_msg_id:
            send_progress_update(chat_id, progress_msg_id, 20, "جاري قراءة الصورة...")
        
        with open(image_path, 'rb') as f:
            image_bytes = f.read()
        
        if chat_id and progress_msg_id:
            send_progress_update(chat_id, progress_msg_id, 40, "جاري تعديل الصورة...")
        
        image_part = types.Part(
            inline_data=types.Blob(
                mime_type="image/jpeg",
                data=image_bytes
            )
        )
        
        enhanced_prompt = f"Edit this image: {edit_prompt}. Keep the original image structure and only apply the requested modification."
        
        response = client.models.generate_content(
            model=GEMINI_IMAGE_MODEL,
            contents=[image_part, enhanced_prompt],
            config=types.GenerateContentConfig(
                response_modalities=['TEXT', 'IMAGE']
            )
        )
        
        if chat_id and progress_msg_id:
            send_progress_update(chat_id, progress_msg_id, 80, "جاري حفظ النتيجة...")
        
        if response is None:
            logging.warning("Gemini returned None response for image editing")
            return None, "⚠️ لم يتمكن النظام من تعديل الصورة. جرب وصفاً مختلفاً."
        
        prompt_feedback = getattr(response, 'prompt_feedback', None)
        if prompt_feedback:
            block_reason = getattr(prompt_feedback, 'block_reason', None)
            if block_reason:
                logging.warning(f"Gemini blocked edit prompt. Reason: {block_reason}")
                return None, "⚠️ لم يتمكن النظام من معالجة الطلب. جرب وصفاً مختلفاً."
        
        candidates = getattr(response, 'candidates', None)
        if not candidates or len(candidates) == 0:
            logging.warning("Gemini returned empty candidates list for image editing")
            return None, "⚠️ لم يتمكن النظام من تعديل الصورة. جرب وصفاً مختلفاً."
        
        text_response = None
        for candidate in candidates:
            finish_reason = getattr(candidate, 'finish_reason', None)
            content = getattr(candidate, 'content', None)
            
            if not content:
                logging.warning(f"Edit candidate has no content. Finish reason: {finish_reason}")
                continue
            
            parts = getattr(content, 'parts', None)
            if not parts:
                logging.warning(f"Edit candidate content has no parts. Finish reason: {finish_reason}")
                continue
            
            for part in parts:
                inline_data = getattr(part, 'inline_data', None)
                if inline_data is not None and hasattr(inline_data, 'data'):
                    edited_image_bytes = inline_data.data
                    
                    output_path = os.path.join(TEMP_PDF_DIR, f"gemini_edited_{uuid.uuid4()}.png")
                    with open(output_path, 'wb') as f:
                        f.write(edited_image_bytes)
                    
                    increment_usage(GEMINI_API_KEY_FILE, user_id, "image_editing", success=True)
                    increment_operation_count('تعديل صورة AI', user_id)
                    logging.info(f"✅ تم تعديل الصورة بنجاح: {edit_prompt[:50]}...")
                    return output_path, None
                
                text_part = getattr(part, 'text', None)
                if text_part:
                    text_response = text_part
        
        if text_response:
            logging.info(f"Gemini returned text only (no edited image): {text_response[:100]}...")
            return None, f"⚠️ لم يتمكن النظام من تعديل الصورة. رد النظام: {text_response[:200]}"
        
        return None, "⚠️ لم يتمكن النظام من تعديل الصورة. جرب وصفاً مختلفاً."
        
    except Exception as e:
        error_str = str(e).lower()
        logging.error(f"Gemini image editing error: {e}")
        increment_usage(GEMINI_API_KEY_FILE, user_id, "image_editing", success=False)
        
        is_auth_error = any(x in error_str for x in ['api key', 'authentication', 'unauthorized', 'quota', 'rate limit', '401', '403', '429'])
        
        if is_auth_error:
            old_key = get_active_key(GEMINI_API_KEY_FILE)
            new_key = fail_and_rotate_key(GEMINI_API_KEY_FILE)
            if old_key and new_key:
                notify_admin_key_success_enhanced("Gemini AI", old_key, new_key, 1)
        
        return None, f"❌ حدث خطأ أثناء تعديل الصورة. يرجى المحاولة مرة أخرى."


# --- 6. Backup and Restore Functions (Existing functions, no changes needed) ---

def create_zip_archive(zip_file_name, files):
    """
    Creates a zip archive of specified files.

    Args:
        zip_file_name (str): The name of the zip file to create.
        files (list): An array of file paths to include in the zip.

    Returns:
        str or False: The path to the created zip file on success, False on failure.
    """
    try:
        with ZipFile(zip_file_name, 'w', ZIP_DEFLATED) as zipf:
            for file_path in files:
                if os.path.exists(file_path):
                    zipf.write(file_path, os.path.basename(file_path))
                else:
                    logging.warning(f"File not found for backup: {file_path}")
        logging.info(f"Zip archive created: {zip_file_name}")
        return zip_file_name
    except Exception as e:
        logging.error(f"Failed to create zip archive {zip_file_name}: {e}")
        return False

def create_zip_archive_with_dirs(zip_file_name, items):
    """
    Creates a zip archive of specified files and directories with relative path structure.
    Preserves directory structure in the archive using relative paths from PROJECT_ROOT.

    Args:
        zip_file_name (str): The name of the zip file to create.
        items (list): An array of file and directory paths to include in the zip.

    Returns:
        str or False: The path to the created zip file on success, False on failure.
    """
    try:
        with ZipFile(zip_file_name, 'w', ZIP_DEFLATED) as zipf:
            for item_path in items:
                if not os.path.exists(item_path):
                    logging.warning(f"Item not found for backup: {item_path}")
                    continue
                
                if os.path.isfile(item_path):
                    # استخدام المسار النسبي من جذر المشروع
                    arcname = os.path.relpath(item_path, PROJECT_ROOT)
                    zipf.write(item_path, arcname)
                    logging.info(f"Added file to backup: {arcname}")
                elif os.path.isdir(item_path):
                    # For directories, recursively add all files
                    for root, dirs, files in os.walk(item_path):
                        for file in files:
                            file_path = os.path.join(root, file)
                            # استخدام المسار النسبي من جذر المشروع
                            arcname = os.path.relpath(file_path, PROJECT_ROOT)
                            zipf.write(file_path, arcname)
                            logging.info(f"Added file to backup: {arcname}")
        
        logging.info(f"Zip archive with directories created: {zip_file_name}")
        return zip_file_name
    except Exception as e:
        logging.error(f"Failed to create zip archive with directories {zip_file_name}: {e}")
        return False

def create_organized_backup(zip_file_name):
    """
    إنشاء نسخة احتياطية منظمة بهيكل مجلدات واضح
    Creates an organized backup with clear folder structure:
    - bot/       : main.py, db.py
    - config/    : configuration files
    - keys/      : API keys
    - project/   : pyproject.toml, uv.lock
    
    Returns:
        str or False: path to zip file on success, False on failure
    """
    try:
        with ZipFile(zip_file_name, 'w', ZIP_DEFLATED) as zipf:
            files_added = 0
            
            # 1️⃣ مجلد bot/ - ملفات البوت الأساسية
            bot_files = ['main.py', 'db.py']
            for file_name in bot_files:
                file_path = os.path.join(PROJECT_ROOT, file_name)
                if os.path.exists(file_path):
                    arcname = f"bot/{file_name}"
                    zipf.write(file_path, arcname)
                    logging.info(f"✓ Added to bot/: {file_name}")
                    files_added += 1
            
            # 2️⃣ مجلد config/ - ملفات الإعدادات
            if os.path.isdir(CONFIG_DIR):
                for root, dirs, files in os.walk(CONFIG_DIR):
                    for file in files:
                        file_path = os.path.join(root, file)
                        rel_path = os.path.relpath(file_path, CONFIG_DIR)
                        arcname = f"config/{rel_path}"
                        zipf.write(file_path, arcname)
                        logging.info(f"✓ Added to config/: {rel_path}")
                        files_added += 1
            
            # 3️⃣ مجلد keys/ - مفاتيح API
            if os.path.isdir(KEYS_DIR):
                for root, dirs, files in os.walk(KEYS_DIR):
                    for file in files:
                        file_path = os.path.join(root, file)
                        rel_path = os.path.relpath(file_path, KEYS_DIR)
                        arcname = f"keys/{rel_path}"
                        zipf.write(file_path, arcname)
                        logging.info(f"✓ Added to keys/: {rel_path}")
                        files_added += 1
            
            # 4️⃣ مجلد project/ - ملفات المشروع
            project_files = ['pyproject.toml', 'uv.lock']
            for file_name in project_files:
                file_path = os.path.join(PROJECT_ROOT, file_name)
                if os.path.exists(file_path):
                    arcname = f"project/{file_name}"
                    zipf.write(file_path, arcname)
                    logging.info(f"✓ Added to project/: {file_name}")
                    files_added += 1
            
            logging.info(f"📦 Total files added to backup: {files_added}")
        
        return zip_file_name if files_added > 0 else False
    except Exception as e:
        logging.error(f"❌ Failed to create organized backup: {e}")
        return False

def perform_daily_backup(admin_id, force=False):
    """
    ينشئ نسخة احتياطية شاملة من جميع ملفات البوت الهامة ويرسلها للمالك
    Creates a complete backup of all important bot files and sends to admin
    
    Args:
        admin_id (int): معرف المالك في تليجرام
        force (bool): تجاوز فترة الانتظار وإنشاء نسخة فوراً
    
    Returns:
        bool: True إذا نجحت، False إذا فشلت
    """
    try:
        # التحقق من فترة الانتظار
        last_backup_time = 0
        if os.path.exists(LAST_BACKUP_TIME_FILE):
            try:
                with open(LAST_BACKUP_TIME_FILE, 'r') as f:
                    last_backup_time = int(f.read())
            except (ValueError, FileNotFoundError):
                logging.warning(f"لا يمكن قراءة ملف آخر نسخة احتياطية")

        current_time = int(time.time())
        backup_interval = 12 * 3600  # 12 ساعة

        if not force and (current_time - last_backup_time) < backup_interval:
            logging.info("لم يتم عمل نسخة احتياطية (لم تنقضِ المدة المطلوبة)")
            return False

        logging.info("🔄 بدء إنشاء النسخة الاحتياطية الشاملة...")

        # إنشاء مجلدات ضرورية
        os.makedirs(CONFIG_DIR, exist_ok=True)
        os.makedirs(KEYS_DIR, exist_ok=True)

        # إنشاء النسخة الاحتياطية المنظمة
        backup_zip = create_organized_backup(BACKUP_FILE)

        if backup_zip:
            timestamp = to_english_numerals(time.strftime('%Y-%m-%d %H:%M:%S'))
            backup_type = "نسخة يدوية" if force else "نسخة تلقائية"
            backup_size = os.path.getsize(backup_zip) / (1024 * 1024)  # MB
            
            caption = f"✅ {backup_type}: {timestamp}\n"
            caption += f"📊 الحجم: {backup_size:.2f} MB\n"
            caption += f"📁 المحتويات:\n"
            caption += f"  📂 bot/     (main.py, db.py)\n"
            caption += f"  📂 config/  (الإعدادات)\n"
            caption += f"  📂 keys/    (المفاتيح)\n"
            caption += f"  📂 project/ (pyproject.toml, uv.lock)\n"
            
            logging.info(f"📤 إرسال النسخة الاحتياطية للمالك ({backup_size:.2f} MB)...")
            
            if send_document(admin_id, backup_zip, caption):
                with open(BACKUP_LOG_FILE, 'a', encoding='utf-8') as f:
                    f.write(f"✅ نسخة شاملة منظمة - {timestamp} ({backup_size:.2f} MB)\n")
                with open(LAST_BACKUP_TIME_FILE, 'w') as f:
                    f.write(str(current_time))
                os.remove(backup_zip)
                logging.info("✅ تم إرسال النسخة الاحتياطية بنجاح ونظفت الملفات المؤقتة")
                return True
            else:
                with open(BACKUP_LOG_FILE, 'a', encoding='utf-8') as f:
                    f.write(f"❌ فشل إرسال النسخة - {timestamp}\n")
                if os.path.exists(backup_zip):
                    os.remove(backup_zip)
                logging.error("❌ فشل إرسال النسخة الاحتياطية للمالك")
                return False
        else:
            with open(BACKUP_LOG_FILE, 'a', encoding='utf-8') as f:
                f.write(f"❌ فشل إنشاء ملف النسخة - {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            logging.error("❌ فشل إنشاء ملف النسخة الاحتياطية")
            return False
            
    except Exception as e:
        logging.error(f"❌ خطأ في عملية النسخ الاحتياطي: {str(e)}")
        with open(BACKUP_LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(f"❌ خطأ: {str(e)} - {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        return False

def restore_from_backup(zip_file_path):
    """
    استعادة جميع البيانات من ملف النسخة الاحتياطية بشكل منظم
    Restores all data from backup zip file with proper structure
    
    الهيكل المتوقع:
    - bot/       : main.py, db.py -> يُستخرج إلى جذر المشروع
    - config/    : ملفات الإعدادات -> يُستخرج إلى config/
    - keys/      : مفاتيح API -> يُستخرج إلى keys/
    - project/   : pyproject.toml, uv.lock -> يُستخرج إلى جذر المشروع
    
    Args:
        zip_file_path (str): مسار ملف النسخة الاحتياطية
    
    Returns:
        bool: True إذا نجحت الاستعادة، False إذا فشلت
    """
    if not os.path.exists(zip_file_path):
        logging.error(f"❌ ملف النسخة الاحتياطية غير موجود: {zip_file_path}")
        return False

    try:
        logging.info(f"🔄 بدء استعادة البيانات الشاملة من النسخة الاحتياطية...")
        
        # التأكد من وجود جميع المجلدات الضرورية
        required_dirs = [CONFIG_DIR, KEYS_DIR]
        for directory in required_dirs:
            os.makedirs(directory, exist_ok=True)
            logging.info(f"✓ مجلد جاهز: {directory}")

        with ZipFile(zip_file_path, 'r') as zipf:
            all_files = zipf.namelist()
            
            if not all_files:
                logging.error(f"❌ ملف النسخة الاحتياطية فارغ: {zip_file_path}")
                return False
            
            logging.info(f"📦 عدد العناصر في النسخة: {len(all_files)}")
            
            extracted_count = 0
            protected_count = 0
            failed_items = []
            categories = {"bot": 0, "config": 0, "keys": 0, "project": 0, "other": 0}
            
            for file_name in all_files:
                # تخطي المجلدات الفارغة
                if file_name.endswith('/'):
                    continue
                    
                basename = os.path.basename(file_name)
                
                # حماية main.py (لا نستبدله للأمان)
                if basename == 'main.py':
                    logging.info(f"🛡️  ملف محمي (لا يُستبدل): {file_name}")
                    protected_count += 1
                    continue
                
                try:
                    # تحديد المسار الهدف بناءً على مجلد المصدر
                    if file_name.startswith('bot/'):
                        # ملفات البوت -> جذر المشروع
                        target_path = os.path.join(PROJECT_ROOT, basename)
                        categories["bot"] += 1
                    elif file_name.startswith('config/'):
                        # ملفات الإعدادات -> مجلد config
                        rel_path = file_name[7:]  # إزالة 'config/'
                        target_path = os.path.join(CONFIG_DIR, rel_path)
                        categories["config"] += 1
                    elif file_name.startswith('keys/'):
                        # مفاتيح API -> مجلد keys
                        rel_path = file_name[5:]  # إزالة 'keys/'
                        target_path = os.path.join(KEYS_DIR, rel_path)
                        categories["keys"] += 1
                    elif file_name.startswith('project/'):
                        # ملفات المشروع -> جذر المشروع
                        target_path = os.path.join(PROJECT_ROOT, basename)
                        categories["project"] += 1
                    else:
                        # ملفات أخرى -> استخراج كما هي
                        target_path = os.path.join(PROJECT_ROOT, file_name)
                        categories["other"] += 1
                    
                    # إنشاء المجلد الأب إذا لم يكن موجوداً
                    target_dir = os.path.dirname(target_path)
                    if target_dir:
                        os.makedirs(target_dir, exist_ok=True)
                    
                    # استخراج الملف وكتابته في المكان الصحيح
                    with zipf.open(file_name) as source:
                        with open(target_path, 'wb') as target:
                            target.write(source.read())
                    
                    logging.info(f"✓ استخراج: {file_name} -> {target_path}")
                    extracted_count += 1
                    
                except Exception as e:
                    logging.error(f"❌ فشل استخراج {file_name}: {str(e)}")
                    failed_items.append(file_name)
            
            # تلخيص النتائج بشكل منظم
            summary = f"\n{'='*60}\n"
            summary += f"📊 ملخص الاستعادة الشاملة\n"
            summary += f"{'='*60}\n"
            summary += f"✅ تم استخراج: {extracted_count} عنصر\n"
            summary += f"   📂 bot/     : {categories['bot']} ملف\n"
            summary += f"   📂 config/  : {categories['config']} ملف\n"
            summary += f"   📂 keys/    : {categories['keys']} ملف\n"
            summary += f"   📂 project/ : {categories['project']} ملف\n"
            summary += f"   📂 أخرى    : {categories['other']} ملف\n"
            summary += f"🛡️  ملفات محمية (لم تُستبدل): {protected_count}\n"
            
            if failed_items:
                summary += f"❌ فشل استخراج: {len(failed_items)} عنصر\n"
                for item in failed_items[:5]:
                    summary += f"   • {item}\n"
                if len(failed_items) > 5:
                    summary += f"   ... و {len(failed_items) - 5} أخرى\n"
            
            summary += f"{'='*60}\n"
            success = len(failed_items) == 0
            summary += f"النتيجة النهائية: {'✅ نجاح كامل' if success else '⚠️  مع أخطاء'}\n"
            summary += f"{'='*60}\n"
            
            logging.info(summary)
            
            # كتابة ملخص الاستعادة في السجل
            with open(BACKUP_LOG_FILE, 'a', encoding='utf-8') as f:
                f.write(f"\n📥 استعادة شاملة - {time.strftime('%Y-%m-%d %H:%M:%S')}:\n")
                f.write(f"  ✅ استخراج: {extracted_count}\n")
                f.write(f"  🛡️  محمي: {protected_count}\n")
                f.write(f"  ❌ فشل: {len(failed_items)}\n")
                f.write(f"  تصنيف: bot={categories['bot']}, config={categories['config']}, keys={categories['keys']}, project={categories['project']}\n")
            
            return success
            
    except Exception as e:
        logging.error(f"❌ خطأ في استعادة النسخة الاحتياطية: {str(e)}")
        with open(BACKUP_LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(f"❌ خطأ في الاستعادة: {str(e)} - {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        return False

# --- Global Helper for Admin Message and State Update ---
def update_admin_message_and_state(chat_id, user_id, text_content, buttons_list, current_admin_msg_id, target_state, new_state_data=None):
    """
    Helper function to update the admin panel message by editing it in place.
    The send_message function now handles edit failures automatically.

    Args:
        chat_id (int): The chat ID.
        user_id (int): The user ID.
        text_content (str): The text for the message.
        buttons_list (list): List of inline keyboard buttons.
        current_admin_msg_id (int): The message ID to attempt to edit.
        target_state (str): The state to set for the user.
        new_state_data (dict, optional): Additional data to merge into the user's state.
    Returns:
        int: The message ID of the updated/new message.
    """
    # Try to edit existing message or send new one
    if current_admin_msg_id and current_admin_msg_id > 0:
        final_msg_id = send_message(chat_id, text_content, inline_buttons=buttons_list, parse_mode='Markdown', message_id=current_admin_msg_id)
    else:
        final_msg_id = send_message(chat_id, text_content, inline_buttons=buttons_list, parse_mode='Markdown')

    if not final_msg_id:
        logging.error("Failed to send/edit admin message")
        final_msg_id = current_admin_msg_id  # Fallback to current ID

    # Get current state data safely
    try:
        current_user_state = get_user_state(user_id)
        state_data = current_user_state['data'].copy() if current_user_state.get('data') else {}
    except Exception as e:
        logging.error(f"Error getting user state for {user_id}: {e}")
        state_data = {}

    # Update state_data with the message ID and any additional data
    if final_msg_id:
        state_data['admin_message_id'] = final_msg_id
    if new_state_data:
        state_data.update(new_state_data)

    try:
        set_user_state(user_id, target_state, state_data)
    except Exception as e:
        logging.error(f"Error setting user state for {user_id}: {e}")

    return final_msg_id


# --- 7. Main Bot Logic ---

def process_telegram_update(update):
    """
    Processes a single incoming Telegram update.
    """
    logging.info(f"Received update: {update.get('update_id')}")

    # Ignore chat_member updates (channel join/leave events)
    if 'chat_member' in update:
        return

    chat_id = None
    user_id = None
    text = None
    photo = None
    document = None
    data = None # For callback_query data
    user_first_name = ''
    user_last_name = ''
    user_username = ''
    current_message_id = None # To store message_id for editing

    message = update.get('message')
    callback_query = update.get('callback_query')

    if message:
        chat = message.get('chat')
        user_from = message.get('from')
        if chat and user_from: # Ensure chat and from objects exist
            chat_id = chat.get('id')
            user_id = user_from.get('id')
            text = message.get('text')
            photo = message.get('photo')
            document = message.get('document')
            user_first_name = user_from.get('first_name', '')
            user_last_name = user_from.get('last_name', '')
            user_username = user_from.get('username', '')
            current_message_id = message.get('message_id')
            logging.info(f"Message from chat_id {chat_id}, user_id {user_id}. Text: '{text}' Photo: {bool(photo)} Document: {bool(document)}")
    elif callback_query:
        message_in_callback = callback_query.get('message')
        user_from_callback = callback_query.get('from')
        if message_in_callback and user_from_callback: # Ensure message and from objects exist
            chat = message_in_callback.get('chat')
            if chat: # Ensure chat object exists within message
                chat_id = chat.get('id')
            user_id = user_from_callback.get('id')
            data = callback_query.get('data')
            user_first_name = user_from_callback.get('first_name', '')
            user_last_name = user_from_callback.get('last_name', '')
            user_username = user_from_callback.get('username', '')
            current_message_id = message_in_callback.get('message_id')
            # Acknowledge callback query immediately with text feedback
            callback_text = "✅"  # Default acknowledgment
            if data == 'template_original':
                callback_text = "✅ تم اختيار قالب المعاملات"
            elif data == 'template_new':
                callback_text = "✅ تم اختيار قالب الجوازات"
            elif data == 'ai_edit_image':
                callback_text = "✏️ تعديل الصورة"
            elif data == 'image_edit_ai':
                callback_text = "🤖 الذكاء الاصطناعي"
            elif data == 'image_edit_whitening':
                callback_text = "💫 التبييض والتنعيم"
            elif data == 'back_to_image_edit':
                callback_text = "⬅️ العودة"
            elif data == 'back_to_main_menu':
                callback_text = "🏠 القائمة الرئيسية"
            elif data.startswith('cancel'):
                callback_text = "❌ تم الإلغاء"
            elif data.startswith('admin'):
                callback_text = "⚙️"

            try:
                make_request(f"{API_URL}/answerCallbackQuery", method='POST',
                            json_data={
                                'callback_query_id': callback_query['id'],
                                'text': callback_text,
                                'show_alert': False
                            })
            except Exception as e:
                logging.error(f"Failed to answer callback query: {e}")
            logging.info(f"Callback query from chat_id {chat_id}, user_id {user_id}. Data: '{data}'")


    if chat_id is None or user_id is None: # Use 'is None' for explicit check
        logging.error(f"Received update with missing chat_id or user_id: {json.dumps(update)}")
        return # Exit if essential IDs are missing

    current_user_state = get_user_state(user_id) # This now returns a dict, never None
    current_state = current_user_state['state']
    state_data = current_user_state['data']
    logging.info(f"User {user_id} current state: {current_state}")
    
    # If current_message_id is None from callback but state has message_id, use it
    if current_message_id is None and state_data.get('message_id'):
        current_message_id = state_data.get('message_id')

    # Retrieve admin_message_id from state_data if available
    admin_message_id = state_data.get('admin_message_id')

    # --- Global Access Control ---
    # Admin always has full access
    if user_id != ADMIN_ID:
        # Check maintenance mode first (before ban check)
        if is_maintenance_mode_enabled():
            maintenance_msg = get_maintenance_message()
            send_message(chat_id, maintenance_msg)
            return # Block all users during maintenance except admin
        
        if is_user_banned(user_id):
            send_message(chat_id, "🚫 عذرًا، لقد تم حظرك من استخدام هذا البوت.")
            return # Block all further processing for banned users

        # Check if user is pending or not allowed
        # Allow /start and specific approval/rejection callbacks for pending users
        if not is_user_allowed(user_id) and text != '/start' and not (data and (data.startswith('approve_user_') or data.startswith('reject_user_'))):
            # If not allowed and not sending /start or a callback (which might be for approval)
            send_message(chat_id, "✋ عذرًا، هذا البوت متاح للمستخدمين الموافق عليهم فقط. يرجى الانتظار حتى تتم الموافقة على طلبك.")
            return

    # --- Handle /start command ---
    if text == '/start':
        cleanup_pending_docx_files(chat_id, user_id)  # تنظيف الملفات المعلقة
        clear_user_state(user_id) # Clear any previous state including stale message IDs

        # Get custom start message
        start_message_text = get_start_message_text()
        
        # Get user's command mode and create appropriate menu
        keyboard_markup = create_main_menu_keyboard(user_id)
        
        # Removed '⚙️ لوحة تحكم المالك' button from here entirely as per user request.
        if user_id == ADMIN_ID:
            welcome_text = f"{start_message_text}\n\n💡 يمكنك التحقق من حالة البوت بإرسال /status"
            if keyboard_markup.get('mode') == 'inline_menu':
                send_inline_menu_with_hidden_keyboard(chat_id, welcome_text, keyboard_markup['inline_keyboard'], parse_mode='Markdown')
            else:
                send_message(chat_id, welcome_text, buttons=keyboard_markup['buttons'])
        elif is_user_allowed(user_id):
            welcome_text = f"{start_message_text}\n\n💡 يمكنك التحقق من حالة البوت بإرسال /status"
            if keyboard_markup.get('mode') == 'inline_menu':
                # Use the function that removes reply keyboard when showing inline buttons
                send_inline_menu_with_hidden_keyboard(chat_id, welcome_text, keyboard_markup['inline_keyboard'], parse_mode='Markdown')
            else:
                # Send main menu with text keyboard first - NO TOGGLE BUTTON for regular users
                send_message(chat_id, welcome_text, buttons=keyboard_markup['buttons'])
        elif is_user_banned(user_id):
            send_message(chat_id, "🚫 عذرًا، لقد تم حظرك من استخدام هذا البوت.")
            return
        else: # New user, not admin, not allowed, not banned
            # Check if already pending
            if get_pending_user(user_id):
                send_message(chat_id, "✋ طلبك قيد المراجعة حاليًا. يرجى الانتظار حتى تتم الموافقة عليه من قبل المالك.")
                return

            # Process new user request
            logging.info(f"New user {user_id} ({user_first_name} {user_last_name}) initiated /start. Requesting approval.")

            user_full_name = f"{user_first_name} {user_last_name}".strip()
            # Escape user_full_name and user_username for MarkdownV2
            escaped_user_full_name = escape_markdown_v2(user_full_name)
            escaped_user_username = escape_markdown_v2(user_username)

            user_link = f"[{escaped_user_full_name or 'حساب المستخدم'}]({(f'tg://user?id={user_id}')})"
            user_username_display = f"\\@{escaped_user_username}" if user_username else "لا يوجد يوزر"
            entry_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            # Get user profile photo
            profile_photo_path = get_user_profile_photo(user_id)

            user_info_for_admin = {
                'user_id': user_id,
                'first_name': user_first_name,
                'last_name': user_last_name,
                'username': user_username,
                'entry_time': entry_time,
                'profile_photo_path': profile_photo_path # Store path to cleanup later
            }
            add_pending_user(user_id, user_info_for_admin)

            admin_caption = (
                f"🚨 *طلب وصول مستخدم جديد:*\n\n"
                f"الاسم: {escaped_user_full_name}\n"
                f"الرابط: {user_link}\n"
                f"اليوزر: {user_username_display}\n"
                f"الآيدي: `{user_id}`\n"
                f"وقت الدخول: {escape_markdown_v2(entry_time)}\n\n"
                f"هل توافق على وصول هذا المستخدم؟"
            )

            inline_buttons = [
                [
                    {'text': '✅ موافقة', 'callback_data': f'approve_user_{user_id}'},
                    {'text': '❌ رفض', 'callback_data': f'reject_user_{user_id}'}
                ]
            ]

            if profile_photo_path:
                send_photo(ADMIN_ID, profile_photo_path, caption=admin_caption, inline_buttons=inline_buttons, parse_mode='MarkdownV2')
            else:
                send_message(ADMIN_ID, admin_caption, inline_buttons=inline_buttons, parse_mode='MarkdownV2')

            send_message(chat_id, "✋ طلبك قيد المراجعة حاليًا. يرجى الانتظار حتى تتم الموافقة عليه من قبل المالك.")
        return

    # --- Handle /status command ---
    if text and text.lower() == '/status':
        if user_id == ADMIN_ID or is_user_allowed(user_id):
            # Show loading indicator
            loading_msg_id = None
            for i in range(0, 110, 10):
                progress_text = create_status_loading_indicator(min(i, 100))
                if loading_msg_id:
                    make_request(f"{API_URL}/editMessageText", method='POST',
                                json_data={
                                    'chat_id': chat_id,
                                    'message_id': loading_msg_id,
                                    'text': progress_text
                                })
                else:
                    response = make_request(f"{API_URL}/sendMessage", method='POST',
                                          json_data={
                                              'chat_id': chat_id,
                                              'text': progress_text
                                          })
                    if response and response.get('http_code') == 200:
                        loading_msg_id = response['response'].json().get('result', {}).get('message_id')
                time.sleep(0.1)
            
            # Delete loading message
            if loading_msg_id:
                make_request(f"{API_URL}/deleteMessage", method='POST',
                            json_data={
                                'chat_id': chat_id,
                                'message_id': loading_msg_id
                            })
            
            # Get and send status
            status_message = get_bot_status()
            # Send animated status with professional wave effect (15 minutes = 900 seconds)
            send_animated_status(chat_id, status_message, duration=900)
        else:
            send_message(chat_id, "🚫 هذا الأمر متاح للمستخدمين المسموح لهم فقط.")
        return

    # --- Handle Admin Panel Command ---
    if text == '/admin':
        cleanup_pending_docx_files(chat_id, user_id)  # تنظيف الملفات المعلقة
        if user_id == ADMIN_ID:
            # Clear any existing admin state to start fresh
            clear_user_state(user_id)
            # The show_admin_panel function now handles sending a new message if editing fails.
            # Pass None as message_id to force sending a new message instead of trying to edit
            show_admin_panel(chat_id, user_id, message_id=None)
        else:
            send_message(chat_id, "🚫 هذا الأمر مقيد وغير متاح لك.")
        return

    # --- Handle Callback Queries (including admin approval/rejection and admin panel navigation) ---
    if data:
        # PDF conversion callback for enhanced images
        if data and data.startswith('convert_enhanced_to_pdf_'):
            callback_user_id = int(data.replace('convert_enhanced_to_pdf_', ''))
            if callback_user_id == user_id:
                current_user_state = get_user_state(user_id)
                enhanced_path = current_user_state.get('data', {}).get('enhanced_path')

                if enhanced_path and os.path.exists(enhanced_path):
                    send_chat_action(chat_id, 'upload_document')
                    # Show PDF conversion progress
                    pdf_msg_id = None
                    for pdf_prog in [0, 30, 60, 90, 100]:
                        pdf_text = create_progress_indicator(pdf_prog, "📄 جاري تحويل إلى PDF...")
                        if pdf_msg_id:
                            make_request(f"{API_URL}/editMessageText", method='POST',
                                        json_data={'chat_id': chat_id, 'message_id': pdf_msg_id, 'text': pdf_text})
                        else:
                            response = make_request(f"{API_URL}/sendMessage", method='POST',
                                                  json_data={'chat_id': chat_id, 'text': pdf_text})
                            if response and response.get('http_code') == 200:
                                pdf_msg_id = response['response'].json().get('result', {}).get('message_id')
                        time.sleep(0.15)
                    pdf_processing_msg = pdf_msg_id

                    pdf_path = convert_image_to_pdf(enhanced_path, user_id, dpi=300, max_size_kb=300)

                    if pdf_path:
                        file_size_kb = os.path.getsize(pdf_path) / 1024
                        
                        elapsed = get_elapsed_time(user_id)
                        time_str = f"⏱️ الزمن المستغرق: {elapsed:.1f} ثانية" if elapsed else ""
                        
                        caption = f"📄 ملف PDF جاهز!\n🔧 الحجم: {file_size_kb:.1f} كيلوبايت\n⚡ محسّن للحجم والجودة"
                        if time_str:
                            caption += f"\n{time_str}"

                        if send_document(chat_id, pdf_path, caption):
                            if pdf_processing_msg:
                                delete_message(chat_id, pdf_processing_msg)

                            # Now ask if user wants to save to database
                            save_buttons = [
                                [{'text': '💾 نعم، احفظ في قاعدة البيانات', 'callback_data': f'save_enhanced_pdf_yes_{user_id}'}],
                                [{'text': '❌ لا، شكرًا', 'callback_data': f'save_enhanced_pdf_no_{user_id}'}]
                            ]

                            ask_message_id = send_message(chat_id, "💾 هل تريد حفظ نسخة من هذا الملف في قاعدة البيانات؟", inline_buttons=save_buttons)

                            # Store PDF data for potential saving
                            with open(pdf_path, 'rb') as f:
                                pdf_data = f.read()

                            set_user_state(user_id, 'awaiting_enhanced_pdf_save_decision', {
                                'pdf_data': pdf_data.hex(),
                                'ask_message_id': ask_message_id,
                                'enhanced_path': enhanced_path
                            })

                            # Clean up PDF file after reading
                            os.remove(pdf_path)
                        else:
                            send_message(chat_id, "❌ فشل في إرسال ملف PDF.")
                            if pdf_processing_msg:
                                delete_message(chat_id, pdf_processing_msg)
                    else:
                        send_message(chat_id, "❌ فشل في تحويل الصورة إلى PDF.")
                        if pdf_processing_msg:
                            delete_message(chat_id, pdf_processing_msg)
                    
                    # Clean up enhanced image
                    if os.path.exists(enhanced_path):
                        os.remove(enhanced_path)
                else:
                    send_message(chat_id, "❌ لم يتم العثور على الصورة المحسنة. يرجى تحسين الصورة مرة أخرى.")
                    clear_user_state(user_id)
            return

        # PDF conversion callback - Handle FIRST before other callbacks
        if data and data.startswith('convert_to_pdf_'):
            # Extract user_id from callback data
            parts = data.split('_', 3)  # split on first 3 underscores: convert_to_pdf_userid
            if len(parts) >= 4:
                callback_user_id = int(parts[3])
                if callback_user_id == user_id:  # Security check
                    current_user_state = get_user_state(user_id)
                    template_path = current_user_state.get('data', {}).get('template_path')

                    if template_path and os.path.exists(template_path):
                        # First ask if user wants to save to database
                        save_buttons = [
                            [{'text': '💾 نعم، احفظ في قاعدة البيانات', 'callback_data': f'save_pdf_yes_{user_id}'}],
                            [{'text': '📄 لا، فقط حوّل إلى PDF', 'callback_data': f'save_pdf_no_{user_id}'}]
                        ]

                        new_msg_id = edit_or_send_message(chat_id, current_message_id, "💾 هل تريد حفظ ملف PDF في قاعدة البيانات؟", inline_buttons=save_buttons)

                        # Update state to remember the question message and template path
                        set_user_state(user_id, 'awaiting_save_decision', {
                            'template_path': template_path,
                            'ask_message_id': new_msg_id or current_message_id
                        })
                    else:
                        buttons = [[{'text': '⬅️ العودة للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]]
                        edit_or_send_message(chat_id, current_message_id, "❌ لم يتم العثور على الصورة. يرجى إنشاء قالب جديد.", inline_buttons=buttons)
                        clear_user_state(user_id)
            return

        # Handle "My Files" button callback for TEMPLATE files
        if data and data.startswith('show_my_files_'):
            callback_user_id = int(data.replace('show_my_files_', ''))
            if callback_user_id == user_id:
                send_chat_action(chat_id, 'typing')
                # Show fetching progress
                fetch_msg_id = None
                for fetch_prog in [0, 50, 100]:
                    fetch_text = create_progress_indicator(fetch_prog, "📂 جاري جلب قائمة الملفات...")
                    if fetch_msg_id:
                        make_request(f"{API_URL}/editMessageText", method='POST',
                                    json_data={'chat_id': chat_id, 'message_id': fetch_msg_id, 'text': fetch_text})
                    else:
                        response = make_request(f"{API_URL}/sendMessage", method='POST',
                                              json_data={'chat_id': chat_id, 'text': fetch_text})
                        if response and response.get('http_code') == 200:
                            fetch_msg_id = response['response'].json().get('result', {}).get('message_id')
                    time.sleep(0.1)
                processing_message_id = fetch_msg_id

                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                try:
                    # Get TEMPLATE PDF files only
                    user_files = loop.run_until_complete(db.get_user_template_pdf_files(user_id))
                except Exception as e:
                    logging.error(f"Error getting user PDF files: {e}")
                    send_message(chat_id, "❌ حدث خطأ أثناء جلب قائمة الملفات.")
                    user_files = []
                finally:
                    loop.close()

                if processing_message_id:
                    delete_message(chat_id, processing_message_id)
                
                # Create paginated file list for template files
                message, buttons = create_paginated_file_list(user_files, 1, file_type="template")
                edit_message(chat_id, current_message_id, message, inline_buttons=buttons)
            return

        # Handle show regular files callback with visual progress indicator
        if data and data.startswith('show_my_regular_files_'):
            callback_user_id = int(data.replace('show_my_regular_files_', ''))
            if callback_user_id == user_id:
                send_chat_action(chat_id, 'typing')
                # Show fetching progress with visual indicator
                fetch_msg_id = None
                for fetch_prog in [0, 30, 60, 90, 100]:
                    fetch_text = create_progress_indicator(fetch_prog, "📂 جاري جلب قائمة الملفات العادية...")
                    if fetch_msg_id:
                        make_request(f"{API_URL}/editMessageText", method='POST',
                                    json_data={'chat_id': chat_id, 'message_id': fetch_msg_id, 'text': fetch_text})
                    else:
                        response = make_request(f"{API_URL}/sendMessage", method='POST',
                                              json_data={'chat_id': chat_id, 'text': fetch_text})
                        if response and response.get('http_code') == 200:
                            fetch_msg_id = response['response'].json().get('result', {}).get('message_id')
                    time.sleep(0.15)
                processing_message_id = fetch_msg_id

                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                try:
                    # Get REGULAR PDF files only
                    user_files = loop.run_until_complete(db.get_user_regular_pdf_files(user_id))
                except Exception as e:
                    logging.error(f"Error getting user regular PDF files: {e}")
                    send_message(chat_id, "❌ حدث خطأ أثناء جلب قائمة الملفات.")
                    user_files = []
                finally:
                    loop.close()

                if processing_message_id:
                    delete_message(chat_id, processing_message_id)
                
                # Create paginated file list for regular files
                message, buttons = create_paginated_file_list(user_files, 1, file_type="regular")
                edit_message(chat_id, current_message_id, message, inline_buttons=buttons)
            return

        # Handle user file deletion callback - المرحلة الأولى
        if data and data.startswith('delete_my_files_'):
            callback_user_id = int(data.replace('delete_my_files_', ''))
            if callback_user_id == user_id:
                # المرحلة 1: التحذير الأولي
                confirmation_buttons = [
                    [{'text': '⚠️ نعم، أريد حذف ملفاتي', 'callback_data': f'delete_step1_{user_id}'}],
                    [{'text': '❌ لا، أبقي على ملفاتي', 'callback_data': f'cancel_delete_files_{user_id}'}]
                ]
                
                edit_message(chat_id, current_message_id, "⚠️ *تحذير: هذا الإجراء سيحذف جميع ملفاتك من قاعدة البيانات نهائيًا ولا يمكن التراجع عنه\\.*\n\nهل أنت متأكد من المتابعة؟", 
                           inline_buttons=confirmation_buttons, parse_mode='MarkdownV2')
                
                # حفظ معرف الرسالة في حالة المستخدم
                set_user_state(user_id, 'delete_confirmation_step1', {'delete_message_id': current_message_id})
            return

        # المرحلة الثانية: تأكيد الفهم
        if data and data.startswith('delete_step1_'):
            callback_user_id = int(data.replace('delete_step1_', ''))
            if callback_user_id == user_id:
                confirmation_buttons = [
                    [{'text': '✅ نعم، أفهم المخاطر', 'callback_data': f'delete_step2_{user_id}'}],
                    [{'text': '🛡️ لا، أحتفظ بملفاتي', 'callback_data': f'cancel_delete_files_{user_id}'}]
                ]
                
                edit_message(chat_id, current_message_id, "🚨 *هل تفهم أنه بمجرد حذف الملفات لن تتمكن من استعادتها مرة أخرى؟*\n\nجميع ملفاتك PDF ستختفي نهائيًا من النظام\\!", 
                           inline_buttons=confirmation_buttons, parse_mode='MarkdownV2')
                
                set_user_state(user_id, 'delete_confirmation_step2', {'delete_message_id': current_message_id})
            return

        # المرحلة الثالثة: التأكد من العدد
        if data and data.startswith('delete_step2_'):
            callback_user_id = int(data.replace('delete_step2_', ''))
            if callback_user_id == user_id:
                # Get file count first
                try:
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    pdf_files = loop.run_until_complete(db.get_user_pdf_files(user_id))
                    file_count = len(pdf_files)
                    loop.close()
                    
                    confirmation_buttons = [
                        [{'text': f'🗑️ نعم، احذف {file_count} ملف', 'callback_data': f'delete_step3_{user_id}'}],
                        [{'text': '💾 لا، أريد الاحتفاظ بها', 'callback_data': f'cancel_delete_files_{user_id}'}]
                    ]
                    
                    edit_message(chat_id, current_message_id, f"📊 *لديك {file_count} ملف محفوظ حاليًا\\.*\n\n🔥 هل تريد حذف جميع هذه الملفات من قاعدة البيانات؟", 
                                   inline_buttons=confirmation_buttons, parse_mode='MarkdownV2')
                    
                    set_user_state(user_id, 'delete_confirmation_step3', {'delete_message_id': current_message_id, 'file_count': file_count})
                except:
                    edit_message(chat_id, current_message_id, "❌ حدث خطأ في جلب معلومات الملفات.")
            return

        # المرحلة الرابعة: التحذير النهائي
        if data and data.startswith('delete_step3_'):
            callback_user_id = int(data.replace('delete_step3_', ''))
            if callback_user_id == user_id:
                confirmation_buttons = [
                    [{'text': '💥 نعم، امسح كل شيء', 'callback_data': f'delete_step4_{user_id}'}],
                    [{'text': '🔒 لا، أريد حماية ملفاتي', 'callback_data': f'cancel_delete_files_{user_id}'}]
                ]
                
                edit_message(chat_id, current_message_id, "🔴 *تحذير أخير: هذه فرصتك الأخيرة\\!*\n\nبعد الضغط على التالي، ستبدأ عملية الحذف فورًا ولن تتمكن من إيقافها\\.", 
                           inline_buttons=confirmation_buttons, parse_mode='MarkdownV2')
                
                set_user_state(user_id, 'delete_confirmation_step4', {'delete_message_id': current_message_id})
            return

        # المرحلة الخامسة: السؤال المباشر
        if data and data.startswith('delete_step4_'):
            callback_user_id = int(data.replace('delete_step4_', ''))
            if callback_user_id == user_id:
                confirmation_buttons = [
                    [{'text': '🎯 أجل، احذف الآن', 'callback_data': f'delete_step5_{user_id}'}],
                    [{'text': '🛑 توقف، لا تحذف', 'callback_data': f'cancel_delete_files_{user_id}'}]
                ]
                
                edit_message(chat_id, current_message_id, "❓ *سؤال مباشر: هل تريد فعلًا فقدان جميع ملفاتك إلى الأبد؟*\n\nهذا قرار لا يمكن التراجع عنه\\!", 
                           inline_buttons=confirmation_buttons, parse_mode='MarkdownV2')
                
                set_user_state(user_id, 'delete_confirmation_step5', {'delete_message_id': current_message_id})
            return

        # المرحلة السادسة: التأكيد النهائي النهائي
        if data and data.startswith('delete_step5_'):
            callback_user_id = int(data.replace('delete_step5_', ''))
            if callback_user_id == user_id:
                confirmation_buttons = [
                    [{'text': '💀 تأكيد الحذف النهائي', 'callback_data': f'confirm_delete_my_files_{user_id}'}],
                    [{'text': '🚨 إلغاء والعودة للأمان', 'callback_data': f'cancel_delete_files_{user_id}'}]
                ]
                
                edit_message(chat_id, current_message_id, "⚡ *المرحلة الأخيرة: هذا آخر تحذير\\!*\n\n🔥 الضغط على \\'تأكيد الحذف النهائي\\' سيمسح كل شيء فورًا\\.\n💡 إذا كانت لديك أدنى شك، اضغط إلغاء\\.", 
                           inline_buttons=confirmation_buttons, parse_mode='MarkdownV2')
                
                set_user_state(user_id, 'delete_confirmation_step6', {'delete_message_id': current_message_id})
            return

        # Handle confirmed user file deletion - التنفيذ النهائي
        if data and data.startswith('confirm_delete_my_files_'):
            callback_user_id = int(data.replace('confirm_delete_my_files_', ''))
            if callback_user_id == user_id:
                current_user_state = get_user_state(user_id)
                delete_message_id = current_user_state.get('data', {}).get('delete_message_id')
                
                # حذف رسالة التأكيد الأصلية
                if delete_message_id:
                    delete_message(chat_id, delete_message_id)
                
                send_chat_action(chat_id, 'typing')
                processing_message_id = send_message(chat_id, "🗑️ جاري حذف جميع ملفاتك...")

                try:
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)

                    success = loop.run_until_complete(db.delete_user_files(user_id))

                    if success:
                        send_message(chat_id, "✅ تم حذف جميع ملفاتك من قاعدة البيانات بنجاح!")
                    else:
                        send_message(chat_id, "❌ حدث خطأ أثناء حذف ملفاتك. يرجى المحاولة مرة أخرى.")

                    loop.close()

                except Exception as e:
                    logging.error(f"Error deleting user files: {e}")
                    send_message(chat_id, "❌ حدث خطأ أثناء حذف الملفات.")

                if processing_message_id:
                    delete_message(chat_id, processing_message_id)
                
                clear_user_state(user_id)
            return

        # Handle cancel file deletion
        if data and data.startswith('cancel_delete_files_'):
            callback_user_id = int(data.replace('cancel_delete_files_', ''))
            if callback_user_id == user_id:
                current_user_state = get_user_state(user_id)
                delete_message_id = current_user_state.get('data', {}).get('delete_message_id')
                
                buttons = [[{'text': '⬅️ العودة للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]]
                edit_message(chat_id, current_message_id, "✅ تم إلغاء عملية الحذف.", inline_buttons=buttons)
                clear_user_state(user_id)
            return

        # Handle PDF Image Files Section
        if data == 'pdf_image_files':
            buttons = [
                [{'text': '📁 ملفاتي', 'callback_data': f'show_my_files_{user_id}'}],
                [{'text': '📷 إنشاء قالب الجوازات', 'callback_data': 'create_new_template'}],
                [{'text': '📤 رفع قالب PDF مباشرة', 'callback_data': 'upload_template_pdf'}],
                [{'text': '⬅️ العودة لقسم PDF', 'callback_data': 'back_to_pdf_section'}]
            ]
            edit_message(chat_id, current_message_id, "🖼️ *قسم ملفات الصور*\n\nهنا يمكنك إدارة ملفات PDF المبنية على الصور والقالب.", inline_buttons=buttons, parse_mode='Markdown')
            return

        # Handle PDF Regular Files Section
        if data == 'pdf_regular_files':
            buttons = [
                [{'text': '📄 إنشاء ملف PDF جديد', 'callback_data': 'create_new_pdf'}],
                [{'text': '💾 حفظ ملف PDF موجود', 'callback_data': 'store_existing_pdf'}],
                [{'text': '📁 ملفاتي المحفوظة', 'callback_data': f'show_my_regular_files_{user_id}'}],
                [{'text': '⬅️ العودة لقسم PDF', 'callback_data': 'back_to_pdf_section'}]
            ]
            edit_message(chat_id, current_message_id, "📄 *قسم الملفات العادية*\n\nفي هذا القسم يمكنك إنشاء أو حفظ ملفات PDF عادية. هذه الملفات محفوظة في قاعدة البيانات للوصول إليها لاحقًا.", inline_buttons=buttons, parse_mode='Markdown')
            return

        # Handle PDF Conversion Section
        if data == 'pdf_conversion_section':
            buttons = [
                [{'text': 'Word ➜ PDF 📄', 'callback_data': 'pdf_to_word_conversion'}],
                [{'text': 'PDF ➜ Picture 🖼️', 'callback_data': 'pdf_to_images_conversion'}],
                [{'text': '⬅️ العودة لقسم PDF', 'callback_data': 'back_to_pdf_section'}]
            ]
            edit_message(chat_id, current_message_id, "♻ *قسم التحويل*\n\nاختر نوع التحويل الذي تريده:", inline_buttons=buttons, parse_mode='Markdown')
            return

        # Handle Word to PDF conversion
        if data == 'pdf_to_word_conversion':
            set_user_state(user_id, 'awaiting_docx_for_pdf_conversion', {'menu_mode': get_command_mode(user_id)})
            conversion_message = """📄 *تحويل وورد إلى PDF*

أرسل ملف وورد الذي تريد تحويله إلى صيغة PDF.

✅ *الامتدادات المقبولة:*
• DOCX (الملفات الحديثة)
• DOC (الملفات القديمة)
• ODT (ملفات Open Office)
• RTF (ملفات Rich Text)"""
            buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'pdf_conversion_section'}]]
            edit_message(chat_id, current_message_id, conversion_message, inline_buttons=buttons, parse_mode='Markdown')
            return

        # Handle PDF to Images conversion
        if data == 'pdf_to_images_conversion':
            set_user_state(user_id, 'awaiting_pdf_for_images_conversion', {'menu_mode': get_command_mode(user_id)})
            buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'pdf_conversion_section'}]]
            edit_message(chat_id, current_message_id, "🖼️ *تحويل PDF إلى صور*\n\nأرسل ملف PDF الذي تريد تحويله إلى صور (كل صفحة تصبح صورة).", inline_buttons=buttons, parse_mode='Markdown')
            return


        # Handle back to PDF section
        if data == 'back_to_pdf_section':
            # تنظيف الملفات المعلقة من DOCX
            cleanup_pending_docx_files(chat_id, user_id)
            
            # Get the current command mode and store it in the PDF section state
            current_command_mode = get_command_mode(user_id)
            set_user_state(user_id, 'pdf_section', {'current_mode': current_command_mode})
            buttons = [
                [{'text': 'مـــــــلــفــات الــصــــــور', 'callback_data': 'pdf_template_files'}],
                [{'text': 'الــمـــلـــفــات الــعــاديـّـة', 'callback_data': 'pdf_regular_files'}],
                [{'text': '♻ قسم التحويل', 'callback_data': 'pdf_conversion_section'}],
                [{'text': '⬅️ العودة للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]
            ]
            edit_message(chat_id, current_message_id, "📄 *قسم الملفات*\n\nاختر النوع الذي تريد العمل معه:", inline_buttons=buttons, parse_mode='Markdown')
            return

        # Handle back to main menu
        if data == 'back_to_main_menu':
            # تنظيف الملفات المعلقة من DOCX/PDF
            cleanup_pending_docx_files(chat_id, user_id)
            
            # First, check if there's a stored mode in the state (from the section the user came from)
            current_state = get_user_state(user_id)
            stored_mode = current_state.get('data', {}).get('menu_mode') if current_state else None
            
            # If no stored mode in state, use the user's command mode preference
            if not stored_mode:
                stored_mode = get_command_mode(user_id)
            
            clear_user_state(user_id)
            
            start_message_text = get_start_message_text()
            welcome_text = f"{start_message_text}\n\n💡 يمكنك التحقق من حالة البوت بإرسال /status"
            
            # Create menu with the stored/preferred mode
            keyboard_markup = create_main_menu_keyboard(user_id, force_mode=stored_mode)
            
            # تعديل الرسالة الحالية بدلاً من حذفها
            if keyboard_markup.get('mode') == 'inline_menu':
                # Inline mode - تعديل الرسالة مع الأزرار الجديدة
                edit_message(chat_id, current_message_id, welcome_text, inline_buttons=keyboard_markup['inline_keyboard'], parse_mode='Markdown')
            else:
                # Buttons mode - تعديل الرسالة ثم إرسال رسالة جديدة للكيبورد
                edit_message(chat_id, current_message_id, welcome_text, parse_mode='Markdown')
                send_message(chat_id, "⬇️ استخدم الأزرار أدناه:", buttons=keyboard_markup['buttons'])
            
            return

        # Handle PDF help
        if data == 'pdf_help':
            help_text = """📄 *مساعدة قسم الملفات*

*🖼️ قسم ملفات الصور:*
• ملفات PDF مبنية على الصور والقالب
• يمكنك إنشاء قوالب جديدة أو عرض ملفاتك

*📄 قسم الملفات العادية:*
• إنشاء ملفات PDF من صور متعددة
• حفظ ملفات PDF موجودة
• إدارة ملفاتك المحفوظة

*🔍 البحث في ملفات PDF:*
• البحث في ملفاتك حسب النوع
• عرض وإدارة الملفات المحفوظة

💡 *نصائح:*
• يمكنك إرسال عدة صور لإنشاء PDF واحد
• جميع الملفات محفوظة في قاعدة البيانات
• يمكنك إعادة تسمية أو حذف الملفات"""
            buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'back_to_pdf_section'}]]
            edit_message(chat_id, current_message_id, help_text, inline_buttons=buttons, parse_mode='Markdown')
            return

        # Handle cancel PDF section
        if data == 'cancel_pdf_section':
            clear_user_state(user_id)
            buttons = [[{'text': '⬅️ العودة للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]]
            edit_message(chat_id, current_message_id, "❌ تم إلغاء العملية.", inline_buttons=buttons)
            return

        # Handle remove background help
        if data == 'remove_bg_help':
            help_text = """🛠️ *مساعدة إزالة الخلفية*

*الوظيفة:*
• إزالة الخلفية من الصور تلقائيًا
• استخدام تقنية الذكاء الاصطناعي المتقدمة

*كيفية الاستخدام:*
1. أرسل صورة واضحة
2. انتظر معالجة الصورة
3. احصل على الصورة بدون خلفية

*نصائح للحصول على أفضل النتائج:*
• استخدم صور عالية الجودة
• تأكد من وضوح الشخص أو الكائن
• تجنب الصور المعقدة أو المزدحمة"""
            buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'back_to_main_menu'}]]
            edit_message(chat_id, current_message_id, help_text, inline_buttons=buttons, parse_mode='Markdown')
            return

        # Handle cancel remove background
        if data == 'cancel_remove_bg':
            clear_user_state(user_id)
            buttons = [[{'text': '⬅️ العودة للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]]
            edit_message(chat_id, current_message_id, "❌ تم إلغاء عملية إزالة الخلفية.", inline_buttons=buttons)
            return

        # Handle enhance help
        if data == 'enhance_help':
            help_text = """✨ *مساعدة تحسين الجودة*

*الوظيفة:*
• تحسين جودة الصور تلقائيًا
• زيادة الوضوح والتفاصيل
• تحسين الألوان والإضاءة

*كيفية الاستخدام:*
1. أرسل الصورة التي تريد تحسينها
2. انتظر معالجة الصورة
3. احصل على الصورة المحسنة

*نصائح للحصول على أفضل النتائج:*
• استخدم صور بجودة متوسطة أو منخفضة
• الصور الضبابية أو غير الواضحة تعطي نتائج أفضل
• تجنب الصور عالية الجودة جدًا"""
            buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'back_to_main_menu'}]]
            edit_message(chat_id, current_message_id, help_text, inline_buttons=buttons, parse_mode='Markdown')
            return

        # Handle cancel enhance
        if data == 'cancel_enhance':
            clear_user_state(user_id)
            buttons = [[{'text': '⬅️ العودة للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]]
            edit_message(chat_id, current_message_id, "❌ تم إلغاء عملية تحسين الجودة.", inline_buttons=buttons)
            return
        
        # Handle enhancement method selection - AI (Gemini)
        if data == 'enhance_method_ai':
            buttons = [
                [{'text': '⬅️ رجوع', 'callback_data': 'main_menu_تحسين الجودة 🪄'}],
                [{'text': 'إلغاء ✖', 'callback_data': 'cancel_enhance'}]
            ]
            msg_id = edit_or_send_message(chat_id, current_message_id, "🤖 *تحسين الجودة بالذكاء الاصطناعي*\n\nأرسل الصورة المراد تحسين جودتها.", inline_buttons=buttons, parse_mode='Markdown')
            set_user_state(user_id, 'awaiting_enhance_image_ai', {'menu_mode': get_command_mode(user_id), 'message_id': msg_id})
            return
        
        # Handle enhancement method selection - Picsart
        if data == 'enhance_method_picsart':
            buttons = [
                [{'text': '⬅️ رجوع', 'callback_data': 'main_menu_تحسين الجودة 🪄'}],
                [{'text': 'إلغاء ✖', 'callback_data': 'cancel_enhance'}]
            ]
            msg_id = edit_or_send_message(chat_id, current_message_id, "🎨 *تحسين الجودة بـ Picsart*\n\nأرسل الصورة المراد تحسين جودتها.", inline_buttons=buttons, parse_mode='Markdown')
            set_user_state(user_id, 'enhance', {'menu_mode': get_command_mode(user_id), 'message_id': msg_id})
            return

        # Handle cancel white space
        if data == 'cancel_white_space':
            clear_user_state(user_id)
            buttons = [[{'text': '⬅️ العودة للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]]
            edit_message(chat_id, current_message_id, "❌ تم إلغاء عملية إضافة الفراغ الأبيض.", inline_buttons=buttons)
            return

        # Handle image editing submenu - whitening option
        if data == 'image_edit_whitening':
            buttons = [
                [{'text': '🤖 الذكاء الاصطناعي', 'callback_data': 'whitening_system_ailab'}],
                [{'text': '📚 المكتبة الداخلية', 'callback_data': 'whitening_system_pil'}],
                [{'text': '⬅️ رجوع', 'callback_data': 'back_to_image_edit'}]
            ]
            description = """💫 <b>تبييض وتنعيم البشرة</b>

❗️ <b><u>زر الذكاء الاصطناعي</u></b> :
هذا الزر راح يعالج الصورة بالذكاء الاصطناعي، يبيضها، وينعمها كذلك، بس تبييضه معقول ومو اوڤر جدًا، وعمله مقتصر على الوجه فقط، يعني ما يتدخل بتفاصيل الصورة الاخرى.

❕ <b><u>زر المكتبة الداخلية</u></b> :
هذا الزر راح يعالج الصورة بواسطة خوارزميات، مثل ما چنتوا تغيرون الوان الصورة بـ Photopea ، بس ارقى، هذا تكدر تستفاد منه بالتبييض، وبالعكس، هذا يغير الوان الصورة كلها."""
            msg_id = edit_or_send_message(chat_id, current_message_id, description, inline_buttons=buttons, parse_mode='HTML')
            set_user_state(user_id, 'whitening_system_selection', {'menu_mode': get_command_mode(user_id), 'message_id': msg_id})
            return
        
        # Handle whitening system selection - AI
        if data == 'whitening_system_ailab':
            buttons = [
                [{'text': '⬅️ رجوع', 'callback_data': 'image_edit_whitening'}],
                [{'text': 'إلغاء ✖', 'callback_data': 'cancel_whitening'}]
            ]
            msg_id = edit_or_send_message(chat_id, current_message_id, "🤖 *الذكاء الاصطناعي للتبييض والتنعيم*\n\nأرسل الصورة المراد معالجتها.", inline_buttons=buttons, parse_mode='Markdown')
            set_user_state(user_id, 'whitening', {'menu_mode': get_command_mode(user_id), 'message_id': msg_id, 'system': 'ailab'})
            return
        
        # Handle whitening system selection - Internal Library
        if data == 'whitening_system_pil':
            buttons = [
                [{'text': '⬅️ رجوع', 'callback_data': 'image_edit_whitening'}],
                [{'text': 'إلغاء ✖', 'callback_data': 'cancel_whitening'}]
            ]
            msg_id = edit_or_send_message(chat_id, current_message_id, "📚 *المكتبة الداخلية للتبييض والتنعيم*\n\nأرسل الصورة المراد معالجتها.", inline_buttons=buttons, parse_mode='Markdown')
            set_user_state(user_id, 'whitening', {'menu_mode': get_command_mode(user_id), 'message_id': msg_id, 'system': 'pil'})
            return

        # Handle image editing submenu - AI option
        if data == 'image_edit_ai':
            buttons = [
                [{'text': '🎨 إنشاء صورة جديدة', 'callback_data': 'ai_generate_image'}],
                [{'text': '✏️ تعديل صورة موجودة', 'callback_data': 'ai_edit_image'}],
                [{'text': '⬅️ رجوع', 'callback_data': 'back_to_image_edit'}]
            ]
            msg_id = edit_or_send_message(chat_id, current_message_id, "🤖 *تعديل بالذكاء الاصطناعي*\n\nاختر ما تريد القيام به:", inline_buttons=buttons, parse_mode='Markdown')
            set_user_state(user_id, 'ai_edit_menu', {'menu_mode': get_command_mode(user_id), 'message_id': msg_id})
            return

        # Handle AI generate image
        if data == 'ai_generate_image':
            buttons = [
                [{'text': '⬅️ رجوع', 'callback_data': 'image_edit_ai'}],
                [{'text': 'إلغاء ✖', 'callback_data': 'cancel_ai_generate'}]
            ]
            msg_id = edit_or_send_message(chat_id, current_message_id, "🎨 *إنشاء صورة جديدة*\n\nاكتب وصفاً تفصيلياً للصورة التي تريد إنشاءها:\n\n💡 *مثال:* قطة بيضاء جالسة على نافذة تطل على مدينة ليلاً", inline_buttons=buttons, parse_mode='Markdown')
            set_user_state(user_id, 'awaiting_ai_generate_prompt', {'menu_mode': get_command_mode(user_id), 'message_id': msg_id})
            return

        # Handle cancel AI generate
        if data == 'cancel_ai_generate':
            buttons = [[{'text': '⬅️ العودة للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]]
            edit_or_send_message(chat_id, current_message_id, "❌ تم إلغاء عملية إنشاء الصورة.", inline_buttons=buttons)
            clear_user_state(user_id)
            return

        # Handle AI edit image
        if data == 'ai_edit_image':
            buttons = [
                [{'text': '⬅️ رجوع', 'callback_data': 'image_edit_ai'}],
                [{'text': 'إلغاء ✖', 'callback_data': 'cancel_ai_edit'}]
            ]
            msg_id = edit_or_send_message(chat_id, current_message_id, "💤 دز الصورة الي تريد تعدلها، تكدر تغير اي تفصيلة معينة بيها ، بناءًا على وصفك", inline_buttons=buttons)
            set_user_state(user_id, 'awaiting_ai_edit_image', {'menu_mode': get_command_mode(user_id), 'message_id': msg_id})
            return

        # Handle cancel AI edit
        if data == 'cancel_ai_edit':
            buttons = [[{'text': '⬅️ العودة للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]]
            edit_or_send_message(chat_id, current_message_id, "❌ تم إلغاء عملية تعديل الصورة.", inline_buttons=buttons)
            clear_user_state(user_id)
            return

        # Handle cancel whitening
        if data == 'cancel_whitening':
            buttons = [[{'text': '⬅️ العودة للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]]
            edit_or_send_message(chat_id, current_message_id, "❌ تم إلغاء عملية تبييض البشرة.", inline_buttons=buttons)
            clear_user_state(user_id)
            return

        # Handle back to image edit menu
        if data == 'back_to_image_edit':
            buttons = [
                [{'text': '🤖 تعديل بالذكاء الاصطناعي', 'callback_data': 'image_edit_ai'}],
                [{'text': '💫 تبييض وتنعيم', 'callback_data': 'image_edit_whitening'}],
                [{'text': '🏠 العودة للقائمة', 'callback_data': 'back_to_main_menu'}]
            ]
            msg_id = edit_or_send_message(chat_id, current_message_id, "✏️ *تعديل الصورة*\n\nاختر نوع التعديل الذي تريده:", inline_buttons=buttons, parse_mode='Markdown')
            set_user_state(user_id, 'image_edit_menu', {'menu_mode': get_command_mode(user_id), 'message_id': msg_id})
            return

        # Handle white space height selection
        if data and data.startswith('white_space_height_'):
            try:
                parts = data.split('_')
                height_cm = int(parts[3])
                original_user_id = int(parts[4]) if len(parts) > 4 else user_id
                
                # Get the original user's state to find the image
                original_user_state = get_user_state(original_user_id)
                input_path = original_user_state.get('data', {}).get('input_path')
                
                if not input_path or not os.path.exists(input_path):
                    send_message(chat_id, "❌ فشل في إيجاد الصورة. يرجى المحاولة مرة أخرى.")
                    clear_user_state(original_user_id)
                    return
                
                # Show progress
                processing_msg_id = send_progress_update(chat_id, None, 10, f"إضافة فراغ أبيض ({height_cm} سم)")
                
                # Add white space
                output_path = add_white_space_to_image(input_path, original_user_id, height_cm)
                
                if output_path:
                    # Update progress
                    processing_msg_id = send_progress_update(chat_id, processing_msg_id, 100, "اكتمل بنجاح")
                    time.sleep(0.5)
                    # Delete progress message
                    if processing_msg_id:
                        delete_message(chat_id, processing_msg_id)
                    send_photo(chat_id, output_path, f"✅ تم إضافة فراغ أبيض ({height_cm} سم)")
                    os.remove(output_path)
                    increment_operation_count('فراغ أبيض', user_id)
                else:
                    # Delete progress message
                    if processing_msg_id:
                        delete_message(chat_id, processing_msg_id)
                    send_message(chat_id, "❌ فشل في إضافة الفراغ الأبيض. يرجى المحاولة مرة أخرى.")
                
                os.remove(input_path)
                clear_user_state(original_user_id)
            except Exception as e:
                logging.error(f"Error handling white space height: {e}")
                send_message(chat_id, f"❌ حدث خطأ: {str(e)}")
                clear_user_state(user_id)
            return

        # Handle create new PDF
        if data == 'create_new_pdf':
            set_user_state(user_id, 'awaiting_images_for_pdf', {'images': [], 'image_count': 0})
            buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'pdf_regular_files'}]]
            edit_message(chat_id, current_message_id, "📸 أرسل الصور التي تريد إدراجها في ملف PDF.\n\n💡 يمكنك إرسال عدة صور، وسأجمعها في ملف PDF واحد.\n\n📝 بعد إرسال جميع الصور، اضغط على 'إنشاء PDF الآن'", inline_buttons=buttons)
            return

        # Handle store existing PDF
        if data == 'store_existing_pdf':
            set_user_state(user_id, 'awaiting_pdf_file', {})
            buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'pdf_regular_files'}]]
            edit_message(chat_id, current_message_id, "📤 أرسل ملف PDF الذي تريد حفظه في قاعدة البيانات:", inline_buttons=buttons)
            return
        
        # Handle upload template PDF directly
        if data == 'upload_template_pdf':
            set_user_state(user_id, 'awaiting_template_pdf_upload', {})
            buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'pdf_template_files'}]]
            edit_message(chat_id, current_message_id, "📤 أرسل ملف PDF الذي تريد حفظه كقالب في قاعدة البيانات:\n\n💡 سيتم حفظ هذا الملف كقالب يمكنك استخدامه لاحقًا.", inline_buttons=buttons)
            return

        # Handle PDF template files section
        if data == 'pdf_template_files':
            # Preserve menu_mode from current state
            current_state = get_user_state(user_id)
            menu_mode = current_state.get('data', {}).get('menu_mode', 'inline') if current_state else 'inline'
            set_user_state(user_id, 'pdf_template_files', {'menu_mode': menu_mode})
            send_chat_action(chat_id, 'typing')
            # Show fetching progress
            fetch_msg_id = None
            for fetch_prog in [0, 50, 100]:
                fetch_text = create_progress_indicator(fetch_prog, "🖼️ جاري جلب قائمة الملفات...")
                if fetch_msg_id:
                    make_request(f"{API_URL}/editMessageText", method='POST',
                                json_data={'chat_id': chat_id, 'message_id': fetch_msg_id, 'text': fetch_text})
                else:
                    response = make_request(f"{API_URL}/sendMessage", method='POST',
                                          json_data={'chat_id': chat_id, 'text': fetch_text})
                    if response and response.get('http_code') == 200:
                        fetch_msg_id = response['response'].json().get('result', {}).get('message_id')
                time.sleep(0.1)
            processing_message_id = fetch_msg_id
            
            # Get TEMPLATE PDF files only
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                user_files = loop.run_until_complete(db.get_user_template_pdf_files(user_id))
            finally:
                loop.close()
            
            if processing_message_id:
                delete_message(chat_id, processing_message_id)
            
            # Create paginated file list for template files
            message, buttons = create_paginated_file_list(user_files, 1, file_type="template")
            send_message(chat_id, message, inline_buttons=buttons)
            
            # Save user state to receive file number or name
            if user_files:
                set_user_state(user_id, 'awaiting_file_selection', {'file_type': 'template'})
            return

        # Handle PDF regular files section
        if data == 'pdf_regular_files':
            # Preserve menu_mode from current state
            current_state = get_user_state(user_id)
            menu_mode = current_state.get('data', {}).get('menu_mode', 'inline') if current_state else 'inline'
            set_user_state(user_id, 'pdf_regular_files', {'menu_mode': menu_mode})
            send_chat_action(chat_id, 'typing')
            # Show fetching progress
            fetch_msg_id = None
            for fetch_prog in [0, 50, 100]:
                fetch_text = create_progress_indicator(fetch_prog, "📄 جاري جلب قائمة الملفات...")
                if fetch_msg_id:
                    make_request(f"{API_URL}/editMessageText", method='POST',
                                json_data={'chat_id': chat_id, 'message_id': fetch_msg_id, 'text': fetch_text})
                else:
                    response = make_request(f"{API_URL}/sendMessage", method='POST',
                                          json_data={'chat_id': chat_id, 'text': fetch_text})
                    if response and response.get('http_code') == 200:
                        fetch_msg_id = response['response'].json().get('result', {}).get('message_id')
                time.sleep(0.1)
            processing_message_id = fetch_msg_id
            
            # Get REGULAR PDF files only
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                user_files = loop.run_until_complete(db.get_user_regular_pdf_files(user_id))
            finally:
                loop.close()
            
            if processing_message_id:
                delete_message(chat_id, processing_message_id)
            
            # Create paginated file list for regular files
            message, buttons = create_paginated_file_list(user_files, 1, file_type="regular")
            edit_message(chat_id, current_message_id, message, inline_buttons=buttons)
            
            # Save user state to receive file number or name
            if user_files:
                set_user_state(user_id, 'awaiting_file_selection', {'file_type': 'regular'})
            return

        # Handle show my regular files - SEPARATE from template files
        if data and data.startswith('show_my_regular_files_'):
            callback_user_id = int(data.replace('show_my_regular_files_', ''))
            if callback_user_id == user_id:
                send_chat_action(chat_id, 'typing')
                
                # Get REGULAR PDF files only
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                try:
                    user_files = loop.run_until_complete(db.get_user_regular_pdf_files(user_id))
                finally:
                    loop.close()
                
                # Create paginated file list
                message, buttons = create_paginated_file_list(user_files, 1, file_type="regular")
                edit_message(chat_id, current_message_id, message, inline_buttons=buttons)
            return

        # Handle file pagination
        if data and data.startswith('file_page_'):
            # Parse page number and file type from callback data
            parts = data.replace('file_page_', '').split('_')
            if len(parts) >= 2:
                page_number = int(parts[0])
                file_type = parts[1]
            else:
                page_number = int(parts[0])
                file_type = "all"
            handle_file_pagination_callback(chat_id, user_id, page_number, file_type)
            return
        
        # Handle delete all files confirmation start
        if data and data.startswith('delete_all_files_'):
            file_type = data.replace('delete_all_files_', '')
            start_delete_all_confirmation(chat_id, user_id, file_type, current_message_id)
            return
        
        # Handle delete all confirmation YES answer
        if data and data.startswith('confirm_delete_all_yes_'):
            file_type = data.replace('confirm_delete_all_yes_', '')
            handle_delete_all_confirmation(chat_id, user_id, 'yes', file_type, current_message_id)
            return
        
        # Handle delete all confirmation NO answer
        if data and data.startswith('confirm_delete_all_no_'):
            file_type = data.replace('confirm_delete_all_no_', '')
            handle_delete_all_confirmation(chat_id, user_id, 'no', file_type, current_message_id)
            return

        # Handle rename file
        if data == 'rename_file' or data.startswith('rename_file_'):
            file_type = "all"
            if data.startswith('rename_file_'):
                file_type = data.replace('rename_file_', '')
            set_user_state(user_id, 'awaiting_file_number_for_rename', {'file_type': file_type})
            buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'back_to_pdf_section'}]]
            edit_message(chat_id, current_message_id, "📝 أرسل رقم الملف الذي تريد إعادة تسميته:", inline_buttons=buttons)
            return

        # Handle delete file
        if data == 'delete_file' or data.startswith('delete_file_'):
            file_type = "all"
            if data.startswith('delete_file_'):
                file_type = data.replace('delete_file_', '')
            set_user_state(user_id, 'awaiting_file_number_for_delete', {'file_type': file_type})
            buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'back_to_pdf_section'}]]
            send_message(chat_id, "🗑️ أرسل رقم الملف الذي تريد حذفه:", inline_buttons=buttons)
            return

        # Handle start DOCX conversion - نقل الملفات المعلقة للقائمة الحقيقية
        if data and data.startswith('start_docx_conversion_'):
            conversion_chat_id = int(data.replace('start_docx_conversion_', ''))
            if conversion_chat_id == chat_id and conversion_chat_id in pending_docx_files:
                files = pending_docx_files[conversion_chat_id]
                total = len(files)
                
                send_message(chat_id, f"✅ تم بدء التحويل لـ {total} ملف/ملفات\n⏳ جاري معالجة الملفات...")
                
                # أضف جميع الملفات للقائمة الحقيقية
                for idx, (docx_path, file_name) in enumerate(files, 1):
                    docx_conversion_queue.put((docx_path, file_name, chat_id, idx, total))
                    logging.info(f"Queued DOCX: {file_name} ({idx}/{total})")
                
                # امسح القائمة المؤقتة
                del pending_docx_files[conversion_chat_id]
                clear_user_state(user_id)
            return
        
        # Handle continue DOCX upload - السماح برسالة جديدة
        if data == 'continue_docx_upload':
            buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'pdf_conversion_section'}]]
            edit_message(chat_id, current_message_id, "📨 أرسل المزيد من ملفات الوورد:", inline_buttons=buttons)
            return
        
        # Handle PDF conversion choices
        if data == 'pdf_convert_all':
            handle_pdf_conversion('all', user_id, chat_id, current_state)
            return
        
        if data == 'pdf_convert_single':
            page_count = get_user_state(user_id).get('data', {}).get('page_count', 1)
            buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'pdf_conversion_section'}]]
            edit_message(chat_id, current_message_id, "🔢 أرسل رقم الصفحة المراد تحويلها (من 1 إلى " + str(page_count) + "):", inline_buttons=buttons)
            set_user_state(user_id, 'awaiting_pdf_single_page', get_user_state(user_id).get('data', {}))
            return
        
        if data == 'pdf_convert_range':
            buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'pdf_conversion_section'}]]
            edit_message(chat_id, current_message_id, "📊 أرسل نطاق الصفحات بصيغة: 1-5 (مثلاً من 1 إلى 5):", inline_buttons=buttons)
            set_user_state(user_id, 'awaiting_pdf_page_range', get_user_state(user_id).get('data', {}))
            return

        # Handle download file from file selection menu
        if data and data.startswith('download_file_'):
            parts = data.replace('download_file_', '').split('_')
            file_index = int(parts[0])
            file_type = '_'.join(parts[1:]) if len(parts) > 1 else 'regular'
            
            # Get user files based on type
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                if file_type == "template":
                    user_files = loop.run_until_complete(db.get_user_template_pdf_files(user_id))
                elif file_type == "regular":
                    user_files = loop.run_until_complete(db.get_user_regular_pdf_files(user_id))
                else:
                    user_files = loop.run_until_complete(db.get_user_pdf_files(user_id))
            finally:
                loop.close()
            
            if file_index < 0 or file_index >= len(user_files):
                send_message(chat_id, "❌ الملف غير موجود.")
                return
            
            selected_file = user_files[file_index]
            file_name = selected_file.get('file_name', '')
            file_url = selected_file.get('file_url', '')
            
            # Download and send the file
            send_chat_action(chat_id, 'upload_document')
            processing_msg = send_message(chat_id, "📥 جاري تحميل الملف...")
            
            if '/public/' in file_url:
                storage_path = file_url.split('/public/')[-1]
                if storage_path.startswith('pdf-files/'):
                    storage_path = storage_path.replace('pdf-files/', '', 1)
            else:
                storage_path = file_url.split('/')[-1]
            
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                pdf_data = loop.run_until_complete(db.download_pdf_from_storage(storage_path))
                
                if pdf_data:
                    temp_pdf_path = os.path.join(TEMP_PDF_DIR, f"temp_download_{user_id}.pdf")
                    with open(temp_pdf_path, 'wb') as f:
                        f.write(pdf_data)
                    
                    send_document(chat_id, temp_pdf_path, f"📄 {file_name}")
                    os.remove(temp_pdf_path)
                    
                    if processing_msg:
                        delete_message(chat_id, processing_msg)
                    
                    send_message(chat_id, "✅ تم تحميل الملف بنجاح!")
                else:
                    if processing_msg:
                        delete_message(chat_id, processing_msg)
                    send_message(chat_id, "❌ فشل في تحميل الملف من التخزين.")
            finally:
                loop.close()
            return

        # Handle edit file name from file selection menu
        if data and data.startswith('edit_file_name_'):
            parts = data.replace('edit_file_name_', '').split('_')
            file_index = int(parts[0])
            file_type = '_'.join(parts[1:]) if len(parts) > 1 else 'regular'
            
            set_user_state(user_id, 'awaiting_new_file_name', {
                'file_index': file_index,
                'file_type': file_type
            })
            send_message(chat_id, "📝 أرسل الاسم الجديد للملف:")
            return

        # Handle delete single file from file selection menu
        if data and data.startswith('delete_single_file_'):
            parts = data.replace('delete_single_file_', '').split('_')
            file_index = int(parts[0])
            file_type = '_'.join(parts[1:]) if len(parts) > 1 else 'regular'
            
            set_user_state(user_id, 'deleting_single_file', {
                'file_index': file_index,
                'file_type': file_type
            })
            send_message(chat_id, "🔥 هل أنت متأكد من حذف هذا الملف؟", inline_buttons=[[
                {'text': '✅ نعم، احذفه', 'callback_data': f'confirm_delete_single_yes_{file_index}_{file_type}'},
                {'text': '❌ لا، إلغاء', 'callback_data': f'confirm_delete_single_no'}
            ]])
            return

        # Handle back to file list from file selection menu
        if data and data.startswith('back_to_file_list_'):
            file_type = data.replace('back_to_file_list_', '')
            handle_file_pagination_callback(chat_id, user_id, 1, file_type)
            return

        # Handle reminder acknowledgment
        if data and data.startswith('acknowledge_reminder_'):
            reminder_id = data.replace('acknowledge_reminder_', '')
            if acknowledge_reminder(reminder_id):
                send_message(chat_id, "✅ تم الإقرار بالتذكير.")
            else:
                send_message(chat_id, "❌ فشل في الإقرار بالتذكير.")
            return

        # Handle PDF creation callbacks
        if data and data.startswith('create_pdf_now_'):
            callback_user_id = int(data.replace('create_pdf_now_', ''))
            if callback_user_id == user_id:
                current_user_state = get_user_state(user_id)
                state_data = current_user_state.get('data', {})
                images = state_data.get('images', [])
                
                if not images:
                    send_message(chat_id, "❌ لا توجد صور لإنشاء PDF.")
                    clear_user_state(user_id)
                    return
                
                send_chat_action(chat_id, 'upload_document')
                processing_msg = send_message(chat_id, "📄 جاري إنشاء ملف PDF...")
                
                try:
                    # Convert images to PDF
                    success, result = handle_image_to_pdf_conversion(user_id, images)
                    
                    if success and os.path.exists(result):
                        file_size_kb = os.path.getsize(result) / 1024
                        caption = f"📄 تم إنشاء ملف PDF بنجاح!\n🔧 الحجم: {file_size_kb:.1f} كيلوبايت\n📸 عدد الصور: {len(images)}"
                        
                        if send_document(chat_id, result, caption):
                            # Ask if user wants to save to database
                            save_buttons = [
                                [{'text': '💾 نعم، احفظ في قاعدة البيانات', 'callback_data': f'save_new_pdf_yes_{user_id}'}],
                                [{'text': '❌ لا، شكرًا', 'callback_data': f'save_new_pdf_no_{user_id}'}]
                            ]
                            
                            ask_message_id = send_message(chat_id, "💾 هل تريد حفظ هذا الملف في قاعدة البيانات؟", inline_buttons=save_buttons)
                            
                            # Store PDF data for potential saving
                            with open(result, 'rb') as f:
                                pdf_data = f.read()
                            
                            set_user_state(user_id, 'awaiting_new_pdf_save_decision', {
                                'pdf_data': pdf_data.hex(),
                                'ask_message_id': ask_message_id,
                                'pdf_path': result
                            })
                        else:
                            send_message(chat_id, "❌ فشل في إرسال ملف PDF.")
                        
                        # Clean up PDF file
                        os.remove(result)
                    else:
                        send_message(chat_id, f"❌ فشل في إنشاء PDF: {result}")
                    
                    # Clean up image files
                    for img_path in images:
                        if os.path.exists(img_path):
                            os.remove(img_path)
                    
                    if processing_msg:
                        delete_message(chat_id, processing_msg)
                    
                    clear_user_state(user_id)
                    
                except Exception as e:
                    logging.error(f"Error creating PDF: {e}")
                    send_message(chat_id, f"❌ حدث خطأ أثناء إنشاء PDF: {str(e)}")
                    if processing_msg:
                        delete_message(chat_id, processing_msg)
                    clear_user_state(user_id)
            return
            
        if data and data.startswith('add_more_images_'):
            callback_user_id = int(data.replace('add_more_images_', ''))
            if callback_user_id == user_id:
                send_message(chat_id, "📸 أرسل المزيد من الصور...")
            return
            
        if data and data.startswith('cancel_pdf_creation_'):
            callback_user_id = int(data.replace('cancel_pdf_creation_', ''))
            if callback_user_id == user_id:
                current_user_state = get_user_state(user_id)
                state_data = current_user_state.get('data', {})
                images = state_data.get('images', [])
                
                # Clean up image files
                for img_path in images:
                    if os.path.exists(img_path):
                        os.remove(img_path)
                
                send_message(chat_id, "❌ تم إلغاء إنشاء PDF.")
                clear_user_state(user_id)
            return
            
        if data and data.startswith('save_new_pdf_yes_'):
            callback_user_id = int(data.replace('save_new_pdf_yes_', ''))
            if callback_user_id == user_id:
                current_user_state = get_user_state(user_id)
                state_data = current_user_state.get('data', {})
                ask_message_id = state_data.get('ask_message_id')
                
                if ask_message_id:
                    delete_message(chat_id, ask_message_id)
                
                # Keep PDF data when transitioning to name input
                new_state_data = {
                    'pdf_data': state_data.get('pdf_data'),
                    'pdf_path': state_data.get('pdf_path')
                }
                set_user_state(user_id, 'awaiting_new_pdf_name', new_state_data)
                send_message(chat_id, "📝 أرسل اسمًا لحفظ ملف PDF في قاعدة البيانات:")
            return
            
        if data and data.startswith('save_new_pdf_no_'):
            callback_user_id = int(data.replace('save_new_pdf_no_', ''))
            if callback_user_id == user_id:
                current_user_state = get_user_state(user_id)
                ask_message_id = current_user_state.get('data', {}).get('ask_message_id')
                
                if ask_message_id:
                    delete_message(chat_id, ask_message_id)
                
                confirmation_buttons = [
                    [{'text': '💾 نعم، احفظه من فضلك', 'callback_data': f'save_new_pdf_yes_{user_id}'}],
                    [{'text': '🚫 لا، لست متأكد', 'callback_data': f'save_new_pdf_no_confirm1_{user_id}'}]
                ]
                new_ask_msg = send_message(chat_id, "⚠️ هل أنت متأكد أنك لا تريد حفظ الملف؟\n\nحفظ الملف يسمح لك بالوصول إليه لاحقًا.", inline_buttons=confirmation_buttons)
                
                current_data = current_user_state.get('data', {})
                current_data['ask_message_id'] = new_ask_msg
                set_user_state(user_id, current_user_state.get('state'), current_data)
            return
            
        if data and data.startswith('save_new_pdf_no_confirm1_'):
            callback_user_id = int(data.replace('save_new_pdf_no_confirm1_', ''))
            if callback_user_id == user_id:
                current_user_state = get_user_state(user_id)
                ask_message_id = current_user_state.get('data', {}).get('ask_message_id')
                
                if ask_message_id:
                    delete_message(chat_id, ask_message_id)
                
                confirmation_buttons = [
                    [{'text': '💚 راجعت، احفظه', 'callback_data': f'save_new_pdf_yes_{user_id}'}],
                    [{'text': '❌ متأكد، لا أريد الحفظ', 'callback_data': f'save_new_pdf_no_final_{user_id}'}]
                ]
                new_ask_msg = send_message(chat_id, "🔔 تأكيد نهائي:\n\nبدون حفظ الملف، لن تتمكن من الوصول إليه مرة أخرى.\nهل تريد فعلًا عدم حفظ الملف؟", inline_buttons=confirmation_buttons)
                
                current_data = current_user_state.get('data', {})
                current_data['ask_message_id'] = new_ask_msg
                set_user_state(user_id, current_user_state.get('state'), current_data)
            return
            
        if data and data.startswith('save_new_pdf_no_final_'):
            callback_user_id = int(data.replace('save_new_pdf_no_final_', ''))
            if callback_user_id == user_id:
                current_user_state = get_user_state(user_id)
                ask_message_id = current_user_state.get('data', {}).get('ask_message_id')
                pdf_path = current_user_state.get('data', {}).get('pdf_path')
                
                if ask_message_id:
                    delete_message(chat_id, ask_message_id)
                
                if pdf_path and os.path.exists(pdf_path):
                    os.remove(pdf_path)
                
                send_message(chat_id, "✅ تم إرسال الملف بنجاح! شكرًا لاستخدامك البوت.")
                clear_user_state(user_id)
            return

        # Handle rename confirmation callbacks
        if data and data.startswith('confirm_rename_'):
            callback_user_id = int(data.replace('confirm_rename_', ''))
            if callback_user_id == user_id:
                current_user_state = get_user_state(user_id)
                state_data = current_user_state.get('data', {})
                old_name = state_data.get('old_file_name')
                file_type = state_data.get('file_type', 'regular')
                
                if old_name:
                    set_user_state(user_id, 'awaiting_new_file_name', {'old_file_name': old_name, 'file_type': file_type})
                    send_message(chat_id, f"📝 أرسل الاسم الجديد للملف:\n\n📄 الاسم الحالي: {old_name}")
                else:
                    send_message(chat_id, "❌ لم يتم العثور على اسم الملف.")
                    clear_user_state(user_id)
            return
            
        if data and data.startswith('cancel_rename_'):
            callback_user_id = int(data.replace('cancel_rename_', ''))
            if callback_user_id == user_id:
                send_message(chat_id, "❌ تم إلغاء عملية تغيير الاسم.")
                clear_user_state(user_id)
            return

        # Handle delete confirmation callbacks
        if data and data.startswith('confirm_delete_'):
            callback_user_id = int(data.replace('confirm_delete_', ''))
            if callback_user_id == user_id:
                current_user_state = get_user_state(user_id)
                state_data = current_user_state.get('data', {})
                file_name = state_data.get('file_name')
                file_type = state_data.get('file_type', 'regular')
                
                if file_name:
                    # Delete file from database
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    try:
                        if file_type == "template":
                            success = loop.run_until_complete(db.delete_template_pdf_file(user_id, file_name))
                        else:
                            success = loop.run_until_complete(db.delete_regular_pdf_file(user_id, file_name))
                        
                        if success:
                            send_message(chat_id, f"✅ تم حذف الملف '{file_name}' بنجاح!")
                        else:
                            send_message(chat_id, "❌ فشل في حذف الملف من قاعدة البيانات.")
                    except Exception as e:
                        logging.error(f"Error deleting file {file_name}: {e}")
                        send_message(chat_id, f"❌ حدث خطأ أثناء حذف الملف: {str(e)}")
                    finally:
                        loop.close()
                else:
                    send_message(chat_id, "❌ لم يتم العثور على اسم الملف.")
                
                clear_user_state(user_id)
            return
            
        if data and data.startswith('cancel_delete_'):
            callback_user_id = int(data.replace('cancel_delete_', ''))
            if callback_user_id == user_id:
                send_message(chat_id, "❌ تم إلغاء عملية الحذف.")
                clear_user_state(user_id)
            return
        elif data and data.startswith('cancel_rename_operation_'):
            callback_user_id = int(data.replace('cancel_rename_operation_', ''))
            if callback_user_id == user_id:
                send_message(chat_id, "❌ تم إلغاء عملية تغيير الاسم.")
                clear_user_state(user_id)
            return
        elif data and data.startswith('cancel_delete_operation_'):
            callback_user_id = int(data.replace('cancel_delete_operation_', ''))
            if callback_user_id == user_id:
                send_message(chat_id, "❌ تم إلغاء عملية الحذف.")
                clear_user_state(user_id)
            return

        # Handle database save decision callbacks
        if data and data.startswith('save_to_db_yes_'):
            callback_user_id = int(data.replace('save_to_db_yes_', ''))
            if callback_user_id == user_id:
                current_user_state = get_user_state(user_id)
                ask_message_id = current_user_state.get('data', {}).get('ask_message_id')

                # Delete the question message
                if ask_message_id:
                    delete_message(chat_id, ask_message_id)

                # Ask for file name
                set_user_state(user_id, 'awaiting_pdf_name_for_db', current_user_state.get('data', {}))
                send_message(chat_id, "📝 أرسل اسمًا لحفظ الملف في قاعدة البيانات:")
            return

        if data and data.startswith('save_to_db_no_') and not data.startswith('save_to_db_no_confirm'):
            try:
                callback_user_id = int(data.split('_')[-1])
            except (ValueError, IndexError):
                logging.error(f"Failed to parse user_id from callback data: {data}")
                return
            if callback_user_id == user_id:
                current_user_state = get_user_state(user_id)
                current_state = current_user_state.get('state', 'awaiting_db_save_decision')
                ask_message_id = current_user_state.get('data', {}).get('ask_message_id')
                
                confirmation_buttons = [
                    [{'text': '💾 بالتأكيد، احفظه', 'callback_data': f'save_to_db_yes_{user_id}'}],
                    [{'text': '⚠️ لا، أكمل بدون حفظ', 'callback_data': f'save_to_db_no_confirm1_{user_id}'}]
                ]
                
                # Edit the message instead of deleting and sending new one
                if ask_message_id:
                    edit_message(chat_id, ask_message_id, "🤔 هل أنت واثق من قرارك؟\n\nالحفظ في قاعدة البيانات يسهل الوصول لملفاتك.", inline_buttons=confirmation_buttons)
                else:
                    new_ask_msg = send_message(chat_id, "🤔 هل أنت واثق من قرارك؟\n\nالحفظ في قاعدة البيانات يسهل الوصول لملفاتك.", inline_buttons=confirmation_buttons)
                    current_data = current_user_state.get('data', {})
                    current_data['ask_message_id'] = new_ask_msg
                    set_user_state(user_id, current_state, current_data)
            return
            
        if data and data.startswith('save_to_db_no_confirm1_'):
            try:
                callback_user_id = int(data.split('_')[-1])
            except (ValueError, IndexError):
                logging.error(f"Failed to parse user_id from callback data: {data}")
                return
            if callback_user_id == user_id:
                current_user_state = get_user_state(user_id)
                current_state = current_user_state.get('state', 'awaiting_db_save_decision')
                ask_message_id = current_user_state.get('data', {}).get('ask_message_id')
                
                template_path = current_user_state.get('data', {}).get('template_path')
                
                if template_path and os.path.exists(template_path):
                    os.remove(template_path)
                
                # Edit the message instead of deleting it
                if ask_message_id:
                    edit_message(chat_id, ask_message_id, "✅ تم إرسال الملف بنجاح بدون حفظ في قاعدة البيانات. شكرًا لاستخدامك البوت.")
                else:
                    send_message(chat_id, "✅ تم إرسال الملف بنجاح بدون حفظ في قاعدة البيانات. شكرًا لاستخدامك البوت.")
                
                clear_user_state(user_id)
            return
            
        if data and data.startswith('save_to_db_no_final_'):
            callback_user_id = int(data.replace('save_to_db_no_final_', ''))
            if callback_user_id == user_id:
                current_user_state = get_user_state(user_id)
                ask_message_id = current_user_state.get('data', {}).get('ask_message_id')
                template_path = current_user_state.get('data', {}).get('template_path')

                if template_path and os.path.exists(template_path):
                    os.remove(template_path)

                # Edit the message instead of deleting it
                if ask_message_id:
                    edit_message(chat_id, ask_message_id, "✅ تم إرسال الملف بنجاح! شكرًا لاستخدامك البوت.")
                else:
                    send_message(chat_id, "✅ تم إرسال الملف بنجاح! شكرًا لاستخدامك البوت.")
                
                clear_user_state(user_id)
            return

        # Handle enhanced PDF save decision callbacks
        if data and data.startswith('save_enhanced_pdf_yes_'):
            callback_user_id = int(data.replace('save_enhanced_pdf_yes_', ''))
            if callback_user_id == user_id:
                current_user_state = get_user_state(user_id)
                ask_message_id = current_user_state.get('data', {}).get('ask_message_id')

                # Delete the question message
                if ask_message_id:
                    delete_message(chat_id, ask_message_id)

                # Ask for file name
                set_user_state(user_id, 'awaiting_enhanced_pdf_name', current_user_state.get('data', {}))
                send_message(chat_id, "📝 أرسل اسمًا لحفظ الملف في قاعدة البيانات:")
            return

        if data and data.startswith('save_enhanced_pdf_no_'):
            callback_user_id = int(data.replace('save_enhanced_pdf_no_', ''))
            if callback_user_id == user_id:
                current_user_state = get_user_state(user_id)
                current_state = current_user_state.get('state', 'awaiting_enhanced_pdf_save_decision')
                ask_message_id = current_user_state.get('data', {}).get('ask_message_id')
                
                confirmation_buttons = [
                    [{'text': '💚 غيرت رأيي، احفظه', 'callback_data': f'save_enhanced_pdf_yes_{user_id}'}],
                    [{'text': '⛔ لا، تابع', 'callback_data': f'save_enhanced_pdf_no_confirm1_{user_id}'}]
                ]
                
                # Edit the message instead of deleting and sending new one
                if ask_message_id:
                    edit_message(chat_id, ask_message_id, "💡 فكر مرة أخرى:\n\nحفظ الملف يتيح لك استعادته في أي وقت.", inline_buttons=confirmation_buttons)
                else:
                    new_ask_msg = send_message(chat_id, "💡 فكر مرة أخرى:\n\nحفظ الملف يتيح لك استعادته في أي وقت.", inline_buttons=confirmation_buttons)
                    current_data = current_user_state.get('data', {})
                    current_data['ask_message_id'] = new_ask_msg
                    set_user_state(user_id, current_state, current_data)
            return
            
        if data and data.startswith('save_enhanced_pdf_no_confirm1_'):
            callback_user_id = int(data.replace('save_enhanced_pdf_no_confirm1_', ''))
            if callback_user_id == user_id:
                current_user_state = get_user_state(user_id)
                current_state = current_user_state.get('state', 'awaiting_enhanced_pdf_save_decision')
                ask_message_id = current_user_state.get('data', {}).get('ask_message_id')
                
                confirmation_buttons = [
                    [{'text': '🎯 احفظ الملف الآن', 'callback_data': f'save_enhanced_pdf_yes_{user_id}'}],
                    [{'text': '🚨 تأكيد: لا تحفظ', 'callback_data': f'save_enhanced_pdf_no_final_{user_id}'}]
                ]
                
                # Edit the message instead of deleting and sending new one
                if ask_message_id:
                    edit_message(chat_id, ask_message_id, "⚠️ تأكيد نهائي:\n\nهذا الملف سيضيع إذا لم تحفظه. هل تريد المتابعة؟", inline_buttons=confirmation_buttons)
                else:
                    new_ask_msg = send_message(chat_id, "⚠️ تأكيد نهائي:\n\nهذا الملف سيضيع إذا لم تحفظه. هل تريد المتابعة؟", inline_buttons=confirmation_buttons)
                    current_data = current_user_state.get('data', {})
                    current_data['ask_message_id'] = new_ask_msg
                    set_user_state(user_id, current_state, current_data)
            return
            
        if data and data.startswith('save_enhanced_pdf_no_final_'):
            callback_user_id = int(data.replace('save_enhanced_pdf_no_final_', ''))
            if callback_user_id == user_id:
                current_user_state = get_user_state(user_id)
                ask_message_id = current_user_state.get('data', {}).get('ask_message_id')
                enhanced_path = current_user_state.get('data', {}).get('enhanced_path')

                if enhanced_path and os.path.exists(enhanced_path):
                    os.remove(enhanced_path)

                # Edit the message instead of deleting it
                if ask_message_id:
                    edit_message(chat_id, ask_message_id, "✅ تم إرسال الملف بنجاح! شكرًا لاستخدامك البوت.")
                else:
                    send_message(chat_id, "✅ تم إرسال الملف بنجاح! شكرًا لاستخدامك البوت.")
                
                clear_user_state(user_id)
            return

        # Handle skip whitening
        if data and data.startswith('skip_whitening_'):
            try:
                callback_user_id = int(data.replace('skip_whitening_', ''))
                if callback_user_id == user_id:
                    current_user_state = get_user_state(user_id)
                    input_path = current_user_state.get('data', {}).get('input_path')
                    system_type = current_user_state.get('data', {}).get('system', 'ailab')
                    msg_id = current_user_state.get('data', {}).get('msg_id')
                    
                    # If PIL (local), skip entirely
                    if system_type == 'pil':
                        if input_path and os.path.exists(input_path):
                            os.remove(input_path)
                        if msg_id:
                            edit_message(chat_id, msg_id, "⏭️ تم تخطي معالجة الصورة.")
                        else:
                            send_message(chat_id, "⏭️ تم تخطي معالجة الصورة.")
                        clear_user_state(user_id)
                    else:
                        # If AILabAPI, show retouch menu with whitening = 0
                        whitening = 0
                        retouch_values = [0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4, 1.5]
                        retouch_options = []
                        for i in range(0, len(retouch_values), 3):
                            row = []
                            for j in range(3):
                                if i + j < len(retouch_values):
                                    val = retouch_values[i + j]
                                    row.append({'text': f'✨ {val}', 'callback_data': f'retouch_{whitening}_{val}_{user_id}'})
                            if row:
                                retouch_options.append(row)
                        
                        # Add skip button
                        retouch_options.append([{'text': '⏭️ تخطي التنعيم', 'callback_data': f'skip_retouch_{whitening}_{user_id}'}])
                        
                        set_user_state(user_id, 'awaiting_retouch_degree', {'input_path': input_path, 'whitening': whitening, 'system': system_type, 'msg_id': msg_id})
                        if msg_id:
                            edit_message(chat_id, msg_id, f"✅ تم تخطي التبييض: 0\n\n✨ اختر درجة التنعيم:\n0.7 = خفيف | 1.5 = قوي جداً", inline_buttons=retouch_options)
                        else:
                            send_message(chat_id, f"✅ تم تخطي التبييض: 0\n\n✨ اختر درجة التنعيم:\n0.7 = خفيف | 1.5 = قوي جداً", inline_buttons=retouch_options)
            except ValueError as e:
                logging.error(f"Error parsing skip whitening callback: {e}")
            return

        # Handle system selection (API vs Local)
        if data and data.startswith('system_'):
            try:
                parts = data.replace('system_', '').rsplit('_', 1)
                if len(parts) == 2:
                    system_type, callback_user_id_str = parts
                    callback_user_id = int(callback_user_id_str)
                    
                    if callback_user_id == user_id:
                        current_user_state = get_user_state(user_id)
                        input_path = current_user_state.get('data', {}).get('input_path')
                        msg_id = current_message_id
                        
                        # Get whitening values based on system
                        if system_type == 'pil':
                            whitening_values = [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4, 1.5]
                            recommendation = "📌 الموصى به: 0.7"
                        else:  # ailab
                            whitening_values = [0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4, 1.5]
                            recommendation = "📌 الموصى به: 1.5"
                        
                        # Build keyboard with 3 columns
                        degree_options = []
                        for i in range(0, len(whitening_values), 3):
                            row = []
                            for j in range(3):
                                if i + j < len(whitening_values):
                                    val = whitening_values[i + j]
                                    row.append({'text': f'🎨 {val}', 'callback_data': f'whitening_{system_type}_{val}_{user_id}'})
                            if row:
                                degree_options.append(row)
                        
                        # Add skip button
                        degree_options.append([{'text': '⏭️ تخطي التبييض', 'callback_data': f'skip_whitening_{user_id}'}])
                        
                        set_user_state(user_id, 'awaiting_whitening_degree', {'input_path': input_path, 'system': system_type, 'msg_id': msg_id})
                        if msg_id:
                            edit_message(chat_id, msg_id, f"✅ تم اختيار النظام!\n\n🎨 اختر درجة التبييض:\n0.4 = خفيف جداً | 1.5 = قوي جداً\n{recommendation}", inline_buttons=degree_options)
                        else:
                            send_message(chat_id, f"✅ تم اختيار النظام!\n\n🎨 اختر درجة التبييض:\n0.4 = خفيف جداً | 1.5 = قوي جداً\n{recommendation}", inline_buttons=degree_options)
            except (ValueError, IndexError) as e:
                logging.error(f"Error parsing system callback: {e}")
            return

        # Handle whitening degree selection
        if data and data.startswith('whitening_'):
            try:
                # Format: whitening_ailab_0.7_userid or whitening_pil_0.6_userid
                parts = data.replace('whitening_', '').rsplit('_', 2)
                if len(parts) == 3:
                    system_type, whitening_str, callback_user_id_str = parts
                    callback_user_id = int(callback_user_id_str)
                    whitening = float(whitening_str)
                    
                    if callback_user_id == user_id:
                        current_user_state = get_user_state(user_id)
                        input_path = current_user_state.get('data', {}).get('input_path')
                        msg_id = current_user_state.get('data', {}).get('msg_id')
                        
                        # If PIL (local), skip retouch and process directly
                        if system_type == 'pil':
                            if input_path and os.path.exists(input_path):
                                send_chat_action(chat_id, 'upload_photo')
                                processing_msg_id = send_progress_update(chat_id, None, 10, "تبييض البشرة (محلي)")
                                try:
                                    result = apply_whitening_local(input_path, whitening=whitening, retouch=0)
                                    result_path, processing_type = result if isinstance(result, tuple) else (result, "محلي")
                                    if result_path:
                                        processing_msg_id = send_progress_update(chat_id, processing_msg_id, 100, "اكتمل بنجاح")
                                        time.sleep(0.5)
                                        if processing_msg_id:
                                            delete_message(chat_id, processing_msg_id)
                                        send_photo(chat_id, result_path, f"✨ تم التبييض بنجاح!\n\n🎨 التبييض: {whitening}\n✨ التنعيم: 0\n📱 تمت المعالجة بواسطة: {processing_type}")
                                        os.remove(result_path)
                                        increment_operation_count('تبييض البشرة', user_id)
                                    else:
                                        if processing_msg_id:
                                            delete_message(chat_id, processing_msg_id)
                                        if msg_id:
                                            edit_message(chat_id, msg_id, "❌ فشل تبييض الصورة. حاول مع صورة أخرى.")
                                        else:
                                            send_message(chat_id, "❌ فشل تبييض الصورة. حاول مع صورة أخرى.")
                                except Exception as e:
                                    logging.error(f"Error whitening image locally: {e}")
                                    if processing_msg_id:
                                        delete_message(chat_id, processing_msg_id)
                                    if msg_id:
                                        edit_message(chat_id, msg_id, "❌ حدث خطأ أثناء معالجة الصورة.")
                                    else:
                                        send_message(chat_id, "❌ حدث خطأ أثناء معالجة الصورة.")
                                finally:
                                    if input_path and os.path.exists(input_path):
                                        os.remove(input_path)
                                    clear_user_state(user_id)
                        else:  # ailab - show retouch options
                            retouch_values = [0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4, 1.5]
                            retouch_options = []
                            for i in range(0, len(retouch_values), 3):
                                row = []
                                for j in range(3):
                                    if i + j < len(retouch_values):
                                        val = retouch_values[i + j]
                                        row.append({'text': f'✨ {val}', 'callback_data': f'retouch_{whitening}_{val}_{user_id}'})
                                if row:
                                    retouch_options.append(row)
                            
                            # Add skip button
                            retouch_options.append([{'text': '⏭️ تخطي التنعيم', 'callback_data': f'skip_retouch_{whitening}_{user_id}'}])
                            
                            set_user_state(user_id, 'awaiting_retouch_degree', {'input_path': input_path, 'whitening': whitening, 'system': system_type, 'msg_id': msg_id})
                            if msg_id:
                                edit_message(chat_id, msg_id, f"✅ تم اختيار التبييض: {whitening}\n\n✨ اختر درجة التنعيم:\n0.7 = خفيف | 1.5 = قوي جداً", inline_buttons=retouch_options)
                            else:
                                send_message(chat_id, f"✅ تم اختيار التبييض: {whitening}\n\n✨ اختر درجة التنعيم:\n0.7 = خفيف | 1.5 = قوي جداً", inline_buttons=retouch_options)
            except (ValueError, IndexError) as e:
                logging.error(f"Error parsing whitening callback: {e}")
            return

        # Handle retouch degree selection
        if data and data.startswith('retouch_'):
            try:
                # Format: retouch_0.7_1.0_userid
                parts = data.replace('retouch_', '').rsplit('_', 2)
                if len(parts) == 3:
                    whitening_str, retouch_str, callback_user_id_str = parts
                    callback_user_id = int(callback_user_id_str)
                    whitening = float(whitening_str)
                    retouch = float(retouch_str)
                    
                    if callback_user_id == user_id:
                        current_user_state = get_user_state(user_id)
                        input_path = current_user_state.get('data', {}).get('input_path')
                        msg_id = current_user_state.get('data', {}).get('msg_id')
                        
                        if input_path and os.path.exists(input_path):
                            send_chat_action(chat_id, 'upload_photo')
                            if msg_id:
                                edit_message(chat_id, msg_id, f"⏳ جاري المعالجة...\n🎨 التبييض: {whitening}\n✨ التنعيم: {retouch}")
                            processing_msg_id = send_progress_update(chat_id, msg_id, 10, "تبييض البشرة (API)") if msg_id else send_progress_update(chat_id, None, 10, "تبييض البشرة (API)")
                            try:
                                result = apply_whitening(input_path, whitening=whitening, retouch=retouch, user_id=user_id)
                                result_path, processing_type = result if isinstance(result, tuple) else (result, "محلي")
                                if result_path:
                                    if processing_msg_id:
                                        send_progress_update(chat_id, processing_msg_id, 100, "اكتمل بنجاح")
                                        time.sleep(0.5)
                                        delete_message(chat_id, processing_msg_id)
                                    send_photo(chat_id, result_path, f"✨ تم التبييض بنجاح!\n\n🎨 التبييض: {whitening}\n✨ التنعيم: {retouch}\n📱 تمت المعالجة بواسطة: {processing_type}")
                                    os.remove(result_path)
                                    increment_operation_count('تبييض البشرة', user_id)
                                else:
                                    if msg_id:
                                        edit_message(chat_id, msg_id, "❌ فشل تبييض الصورة. حاول مع صورة أخرى.")
                                    else:
                                        send_message(chat_id, "❌ فشل تبييض الصورة. حاول مع صورة أخرى.")
                            except Exception as e:
                                logging.error(f"Error whitening image via API: {e}")
                                if msg_id:
                                    edit_message(chat_id, msg_id, "❌ حدث خطأ أثناء معالجة الصورة.")
                                else:
                                    send_message(chat_id, "❌ حدث خطأ أثناء معالجة الصورة.")
                            finally:
                                if input_path and os.path.exists(input_path):
                                    os.remove(input_path)
                                clear_user_state(user_id)
            except (ValueError, IndexError) as e:
                logging.error(f"Error parsing retouch callback: {e}")
            return

        # Handle skip retouch
        if data and data.startswith('skip_retouch_'):
            try:
                parts = data.replace('skip_retouch_', '').rsplit('_', 1)
                if len(parts) == 2:
                    whitening_str, callback_user_id_str = parts
                    callback_user_id = int(callback_user_id_str)
                    whitening = float(whitening_str)
                    
                    if callback_user_id == user_id:
                        current_user_state = get_user_state(user_id)
                        input_path = current_user_state.get('data', {}).get('input_path')
                        msg_id = current_user_state.get('data', {}).get('msg_id')
                        
                        if input_path and os.path.exists(input_path):
                            send_chat_action(chat_id, 'upload_photo')
                            if msg_id:
                                edit_message(chat_id, msg_id, f"⏳ جاري المعالجة...\n🎨 التبييض: {whitening}\n✨ التنعيم: 0")
                            processing_msg_id = send_progress_update(chat_id, msg_id, 10, "تبييض البشرة (API)") if msg_id else send_progress_update(chat_id, None, 10, "تبييض البشرة (API)")
                            try:
                                result = apply_whitening(input_path, whitening=whitening, retouch=0, user_id=user_id)
                                result_path, processing_type = result if isinstance(result, tuple) else (result, "محلي")
                                if result_path:
                                    if processing_msg_id:
                                        send_progress_update(chat_id, processing_msg_id, 100, "اكتمل بنجاح")
                                        time.sleep(0.5)
                                        delete_message(chat_id, processing_msg_id)
                                    send_photo(chat_id, result_path, f"✨ تم التبييض بنجاح!\n\n🎨 التبييض: {whitening}\n✨ التنعيم: 0\n📱 تمت المعالجة بواسطة: {processing_type}")
                                    os.remove(result_path)
                                    increment_operation_count('تبييض البشرة', user_id)
                                else:
                                    if msg_id:
                                        edit_message(chat_id, msg_id, "❌ فشل تبييض الصورة. حاول مع صورة أخرى.")
                                    else:
                                        send_message(chat_id, "❌ فشل تبييض الصورة. حاول مع صورة أخرى.")
                            except Exception as e:
                                logging.error(f"Error whitening image via API: {e}")
                                if msg_id:
                                    edit_message(chat_id, msg_id, "❌ حدث خطأ أثناء معالجة الصورة.")
                                else:
                                    send_message(chat_id, "❌ حدث خطأ أثناء معالجة الصورة.")
                            finally:
                                if input_path and os.path.exists(input_path):
                                    os.remove(input_path)
                                clear_user_state(user_id)
            except (ValueError, IndexError) as e:
                logging.error(f"Error parsing skip retouch callback: {e}")
            return

        # Handle toggle command mode callback - ONLY for admin
        if data == 'toggle_command_mode':
            if user_id != ADMIN_ID:
                send_message(chat_id, "❌ هذه الميزة متاحة للمالك فقط.")
                return
            
            new_mode = toggle_command_mode(user_id)
            
            # Clear state and reset to main while preserving command_mode
            clear_user_state(user_id)
            
            # Get custom start message
            start_message_text = get_start_message_text()
            welcome_text = f"{start_message_text}\n\n💡 يمكنك التحقق من حالة البوت بإرسال /status"
            
            # Create appropriate keyboard based on new mode
            keyboard_markup = create_main_menu_keyboard(user_id)
            
            # Delete the old message if possible
            if current_message_id:
                delete_message(chat_id, current_message_id)
            
            if keyboard_markup.get('mode') == 'inline_menu':
                mode_text = f"✅ تم التبديل إلى وضع الأزرار الشفافة\n\n{welcome_text}"
                send_inline_menu_with_hidden_keyboard(chat_id, mode_text, keyboard_markup['inline_keyboard'], parse_mode='Markdown')
            else:
                mode_text = f"✅ تم التبديل إلى وضع الأزرار العادية\n\n{welcome_text}"
                send_message(chat_id, mode_text, buttons=keyboard_markup['buttons'])
            return

        # Handle main menu callbacks in inline mode
        if data and data.startswith('main_menu_'):
            menu_item = data.replace('main_menu_', '')
            current_mode = get_command_mode(user_id)
            
            # Map menu items to their corresponding actions
            if menu_item == 'تحسين الجودة 🪄':
                track_user_activity(user_id, 'تحسين الجودة')
                set_user_state(user_id, 'enhance_method_selection', {'menu_mode': current_mode, 'message_id': current_message_id})
                message_text = """✨ <b>خدمة تحسين جودة الصور</b>

اختار الطريقة الي تريد تحسن بيها الجودة.

⚠️ <b><u>ملاحظة</u></b>: زر زيادة جودة الصور بواسطة الذكاء الاصطناعي هو لاغراض تجريبية بحتة، يمكن ما يستمر."""
                buttons = [
                    [{'text': '🤖 الذكاء الاصطناعي', 'callback_data': 'enhance_method_ai'}],
                    [{'text': '🎨 Picsart', 'callback_data': 'enhance_method_picsart'}],
                    [{'text': '⬅️ رجوع للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]
                ]
                edit_message(chat_id, current_message_id, message_text, inline_buttons=buttons, parse_mode='HTML')
                
            elif menu_item == 'إزالة الخلفية 🖼️':
                track_user_activity(user_id, 'إزالة الخلفية')
                set_user_state(user_id, 'awaiting_remove_bg_image', {'menu_mode': current_mode})
                message_text = "🛠️ *خدمة إزالة الخلفية*\n\nأرسل الصورة المراد إزالة خلفيتها."
                buttons = [
                    [{'text': '⬅️ رجوع للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]
                ]
                edit_message(chat_id, current_message_id, message_text, inline_buttons=buttons, parse_mode='Markdown')
                
            elif menu_item == 'تبييض البشرة 💫':
                track_user_activity(user_id, 'تبييض البشرة')
                set_user_state(user_id, 'awaiting_whitening_image', {'menu_mode': current_mode})
                message_text = "💫 *خدمة تبييض البشرة*\n\nأرسل الصورة المراد تبييضها وتنعيمها."
                buttons = [
                    [{'text': '⬅️ رجوع للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]
                ]
                edit_message(chat_id, current_message_id, message_text, inline_buttons=buttons, parse_mode='Markdown')
                
            elif menu_item == 'فراغ أبيض ⬜':
                track_user_activity(user_id, 'فراغ أبيض')
                set_user_state(user_id, 'awaiting_white_space_image', {'menu_mode': current_mode})
                message_text = "⬜ *خدمة إضافة فراغ أبيض*\n\nضفت هذا الزر حتى يفيدكم من واحد يجيبلكم صورة، وتسوولها سكنر، بس الوجه طالع چبير جدا.\n\nأرسل الصورة المراد إضافة فراغ أبيض أعلاها."
                buttons = [
                    [{'text': '⬅️ رجوع للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]
                ]
                edit_message(chat_id, current_message_id, message_text, inline_buttons=buttons, parse_mode='Markdown')
                
            elif menu_item == 'قسم الملفات 📄':
                track_user_activity(user_id, 'PDF')
                set_user_state(user_id, 'pdf_section', {'menu_mode': current_mode})
                buttons = [
                    [{'text': 'مـــــــلــفــات الــصــــــور', 'callback_data': 'pdf_template_files'}],
                    [{'text': 'الــمـــلـــفــات الــعــاديـّـة', 'callback_data': 'pdf_regular_files'}],
                    [{'text': '♻ قسم التحويل', 'callback_data': 'pdf_conversion_section'}],
                    [{'text': '⬅️ العودة للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]
                ]
                message_text = "📄 *قسم الملفات*\n\nاختر النوع الذي تريد العمل معه:"
                edit_message(chat_id, current_message_id, message_text, inline_buttons=buttons, parse_mode='Markdown')
                
            elif menu_item == 'البحث عن ملف PDF 🔍':
                set_user_state(user_id, 'awaiting_pdf_search', {'menu_mode': current_mode})
                message_text = "🔍 *البحث في ملفات PDF*\n\nأرسل اسم الملف الذي تريد البحث عنه:"
                buttons = [
                    [{'text': '⬅️ رجوع للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]
                ]
                edit_message(chat_id, current_message_id, message_text, inline_buttons=buttons, parse_mode='Markdown')
                
            elif menu_item == 'حالة البوت 📊':
                # Show bot status
                status_message = get_bot_status()
                buttons = [
                    [{'text': '⬅️ رجوع للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]
                ]
                edit_message(chat_id, current_message_id, status_message, inline_buttons=buttons, parse_mode='Markdown')
                
            elif menu_item == 'توزيع في القالب 🧩':
                # Show template selection
                template_info = get_template_info()
                template_buttons = [
                    [{'text': f'{template_info["original"]["name"]} 📷', 'callback_data': 'template_original'}],
                    [{'text': f'{template_info["new"]["name"]} 📷', 'callback_data': 'template_new'}],
                    [{'text': f'{template_info["multi_person"]["name"]} 👥', 'callback_data': 'template_multi_person'}],
                    [{'text': '⬅️ رجوع للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]
                ]
                template_info_msg = get_template_message_text('regular')
                set_user_state(user_id, 'template_selection', {'current_mode': current_mode})
                edit_message(chat_id, current_message_id, template_info_msg, inline_buttons=template_buttons, parse_mode='Markdown')
                
            elif menu_item == 'المعالجة التلقائية 🤖':
                # Show template selection for auto processing
                track_user_activity(user_id, 'معالجة تلقائية')
                template_info = get_template_info()
                template_buttons = [
                    [{'text': f'المعالجة التلقائية - {template_info["original"]["name"]} 🤖', 'callback_data': 'auto_template_original'}],
                    [{'text': f'المعالجة التلقائية - {template_info["new"]["name"]} 🤖', 'callback_data': 'auto_template_new'}],
                    [{'text': f'المعالجة التلقائية - {template_info["multi_person"]["name"]} 🤖', 'callback_data': 'auto_template_multi_person'}],
                    [{'text': '⬅️ رجوع للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]
                ]
                template_info_msg = get_template_message_text('auto')
                set_user_state(user_id, 'auto_template_selection', {'current_mode': current_mode})
                edit_message(chat_id, current_message_id, template_info_msg, inline_buttons=template_buttons, parse_mode='Markdown')
            
            elif menu_item == 'تعديل الصورة ✏️':
                # Show image editing submenu
                track_user_activity(user_id, 'تعديل الصورة')
                buttons = [
                    [{'text': '🤖 تعديل بالذكاء الاصطناعي', 'callback_data': 'image_edit_ai'}],
                    [{'text': '💫 تبييض وتنعيم', 'callback_data': 'image_edit_whitening'}],
                    [{'text': '⬅️ رجوع للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]
                ]
                set_user_state(user_id, 'image_edit_menu', {'menu_mode': current_mode, 'message_id': current_message_id})
                edit_message(chat_id, current_message_id, "✏️ *تعديل الصورة*\n\nاختر نوع التعديل الذي تريده:", inline_buttons=buttons, parse_mode='Markdown')
            
            return

        # Template selection callbacks - Handle these FIRST before any other callbacks
        if data == 'template_original':
            # Check if we came from inline menu
            current_state = get_user_state(user_id)
            menu_mode = current_state.get('data', {}).get('menu_mode', 'inline') if current_state else 'inline'
            track_user_activity(user_id, 'قالب 3x4')
            set_user_state(user_id, 'template3x4', {'menu_mode': menu_mode})
            buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'main_menu_توزيع في القالب 🧩'}]]
            edit_message(chat_id, current_message_id, "📸 أرسل الصورة لإنشاء قالب المعاملات (3×4 سم):", inline_buttons=buttons)
            logging.info(f"User {user_id} state set to template3x4")
            return
        elif data == 'template_new':
            # Check if we came from inline menu
            current_state = get_user_state(user_id)
            menu_mode = current_state.get('data', {}).get('menu_mode', 'inline') if current_state else 'inline'
            track_user_activity(user_id, 'قالب جديد')
            set_user_state(user_id, 'template_new', {'menu_mode': menu_mode})
            buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'main_menu_توزيع في القالب 🧩'}]]
            edit_message(chat_id, current_message_id, "📸 أرسل الصورة لإنشاء قالب الجوازات (3.5×4.5 سم):", inline_buttons=buttons)
            logging.info(f"User {user_id} state set to template_new")
            return
        elif data == 'auto_template_original':
            # Check if we came from inline menu
            current_state = get_user_state(user_id)
            menu_mode = current_state.get('data', {}).get('menu_mode', 'inline') if current_state else 'inline'
            track_user_activity(user_id, 'معالجة تلقائية أصلي')
            set_user_state(user_id, 'auto_process_original', {'menu_mode': menu_mode})
            buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'main_menu_المعالجة التلقائية 🤖'}]]
            edit_message(chat_id, current_message_id, "📸 أرسل الصورة للمعالجة التلقائية مع قالب المعاملات:", inline_buttons=buttons)
            logging.info(f"User {user_id} state set to auto_process_original")
            return
        elif data == 'auto_template_new':
            # Check if we came from inline menu
            current_state = get_user_state(user_id)
            menu_mode = current_state.get('data', {}).get('menu_mode', 'inline') if current_state else 'inline'
            track_user_activity(user_id, 'معالجة تلقائية جديد')
            set_user_state(user_id, 'auto_process_new', {'menu_mode': menu_mode})
            buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'main_menu_المعالجة التلقائية 🤖'}]]
            edit_message(chat_id, current_message_id, "📸 أرسل الصورة للمعالجة التلقائية مع قالب الجوازات:", inline_buttons=buttons)
            logging.info(f"User {user_id} state set to auto_process_new")
            return
        elif data == 'template_multi_person':
            # Show layout options for multi-person template (without auto-processing)
            layout_buttons = [
                [{'text': '6 بـ3 (6 للأول، 3 للثاني)', 'callback_data': 'multi_layout_6x3'}],
                [{'text': '5 بـ4 (5 للأول، 4 للثاني)', 'callback_data': 'multi_layout_5x4'}],
                [{'text': '⬅️ رجوع للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]
            ]
            edit_message(chat_id, current_message_id, "👥 *قالب أكثر من شخص*\n\nاختر التخطيط المناسب:\n\n• *6×3:* 6 صور للشخص الأول + 3 صور للشخص الثاني\n• *5×4:* 5 صور للشخص الأول + 4 صور للشخص الثاني", inline_buttons=layout_buttons, parse_mode='Markdown')
            return
        elif data == 'multi_layout_6x3':
            # Check if we came from inline menu
            current_state = get_user_state(user_id)
            menu_mode = current_state.get('data', {}).get('menu_mode', 'inline') if current_state else 'inline'
            track_user_activity(user_id, 'قالب متعدد 6x3')
            set_user_state(user_id, 'multi_person_6x3', {'photos_received': 0, 'photos_needed': 2, 'menu_mode': menu_mode})
            buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'template_multi_person'}]]
            edit_message(chat_id, current_message_id, "📸 *تخطيط 6×3*\n\nأرسل الصورة الأولى (ستتم توزيعها على المواضع الـ6 الأولى):", inline_buttons=buttons, parse_mode='Markdown')
            return
        elif data == 'multi_layout_5x4':
            # Check if we came from inline menu
            current_state = get_user_state(user_id)
            menu_mode = current_state.get('data', {}).get('menu_mode', 'inline') if current_state else 'inline'
            track_user_activity(user_id, 'قالب متعدد 5x4')
            set_user_state(user_id, 'multi_person_5x4', {'photos_received': 0, 'photos_needed': 2, 'menu_mode': menu_mode})
            buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'template_multi_person'}]]
            edit_message(chat_id, current_message_id, "📸 *تخطيط 5×4*\n\nأرسل الصورة الأولى (ستتم توزيعها على المواضع الـ5 الأولى):", inline_buttons=buttons, parse_mode='Markdown')
            return
        elif data == 'auto_template_multi_person':
            # Show layout options for multi-person template WITH auto-processing
            layout_buttons = [
                [{'text': '6 بـ3 (6 للأول، 3 للثاني)', 'callback_data': 'auto_multi_layout_6x3'}],
                [{'text': '5 بـ4 (5 للأول، 4 للثاني)', 'callback_data': 'auto_multi_layout_5x4'}],
                [{'text': '⬅️ رجوع للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]
            ]
            edit_message(chat_id, current_message_id, "👥 *قالب أكثر من شخص - مع معالجة تلقائية*\n\nاختر التخطيط المناسب:\n\n• *6×3:* 6 صور للشخص الأول + 3 صور للشخص الثاني\n• *5×4:* 5 صور للشخص الأول + 4 صور للشخص الثاني", inline_buttons=layout_buttons, parse_mode='Markdown')
            return
        elif data == 'auto_multi_layout_6x3':
            # Check if we came from inline menu
            current_state = get_user_state(user_id)
            menu_mode = current_state.get('data', {}).get('menu_mode', 'inline') if current_state else 'inline'
            track_user_activity(user_id, 'معالجة تلقائية متعدد 6x3')
            set_user_state(user_id, 'auto_multi_person_6x3', {'photos_received': 0, 'photos_needed': 2, 'menu_mode': menu_mode})
            buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'auto_template_multi_person'}]]
            edit_message(chat_id, current_message_id, "🤖 *المعالجة التلقائية - تخطيط 6×3*\n\nأرسل الصورة الأولى (ستتم معالجتها وتوزيعها على المواضع الـ6 الأولى):", inline_buttons=buttons, parse_mode='Markdown')
            return
        elif data == 'auto_multi_layout_5x4':
            # Check if we came from inline menu
            current_state = get_user_state(user_id)
            menu_mode = current_state.get('data', {}).get('menu_mode', 'inline') if current_state else 'inline'
            track_user_activity(user_id, 'معالجة تلقائية متعدد 5x4')
            set_user_state(user_id, 'auto_multi_person_5x4', {'photos_received': 0, 'photos_needed': 2, 'menu_mode': menu_mode})
            buttons = [[{'text': '⬅️ رجوع', 'callback_data': 'auto_template_multi_person'}]]
            edit_message(chat_id, current_message_id, "🤖 *المعالجة التلقائية - تخطيط 5×4*\n\nأرسل الصورة الأولى (ستتم معالجتها وتوزيعها على المواضع الـ5 الأولى):", inline_buttons=buttons, parse_mode='Markdown')
            return

        # Admin approval/rejection callbacks (can be from /start or from admin_view_pending)
        if data.startswith('approve_user_'):
            target_user_id = int(data.replace('approve_user_', ''))
            user_info = get_pending_user(target_user_id)

            if user_info:
                add_allowed_user(target_user_id, user_info)
                remove_pending_user(target_user_id) # Clean up pending entry and photo
                send_message(chat_id, f"✅ تم الموافقة على المستخدم `{target_user_id}`.")
                # Notify the approved user
                send_message(target_user_id, "🎉 تهانينا! لقد تمت إضافتك إلى قائمة المستخدمين المسموح لهم في البوت. يمكنك الآن استخدام جميع الميزات.")
            else:
                send_message(chat_id, "❌ لم يتم العثور على طلب معلق لهذا المستخدم.")
            # If the admin was in the lists menu, refresh it
            if current_state == 'admin_lists_menu' and admin_message_id:
                show_admin_lists_menu(chat_id, user_id, admin_message_id)
            return
        elif data.startswith('reject_user_'):
            target_user_id = int(data.replace('reject_user_', ''))
            user_info = get_pending_user(target_user_id)

            if user_info:
                remove_pending_user(target_user_id) # Clean up pending entry and photo
                send_message(chat_id, f"❌ تم رفض المستخدم `{target_user_id}`.")
                # Notify the rejected user
                send_message(target_user_id, "😔 عذرًا، لقد تم رفض طلب وصولك إلى البوت.")
            else:
                send_message(chat_id, "❌ لم يتم العثور على طلب معلق لهذا المستخدم.")
            # If the admin was in the lists menu, refresh it
            if current_state == 'admin_lists_menu' and admin_message_id:
                show_admin_lists_menu(chat_id, user_id, admin_message_id)
            return

        # Admin panel navigation callbacks (only for ADMIN_ID)
        if user_id == ADMIN_ID:
            if data == 'admin_back_to_main':
                show_admin_panel(chat_id, user_id, admin_message_id)
                return
            elif data == 'back_to_main_menu': # From main admin panel to bot main menu
                # Just clear the user state without changing the menu interface
                # Keep the user on the same menu mode they were using
                clear_user_state(user_id)
                
                # Send a temporary "returned to main menu" message and auto-delete it after 5 seconds
                # This confirms the action without changing the interface
                msg_id = send_message(chat_id, "عدت إلى القائمة الرئيسية ⬅️")
                if msg_id:
                    delete_message_after_delay(chat_id, msg_id, delay_seconds=5)
                return
            elif data == 'admin_section_members':
                show_admin_members_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_section_users':
                show_admin_users_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_section_ban':
                show_admin_ban_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_section_lists':
                show_admin_lists_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_section_stats':
                # إحصائيات مبسطة وموثوقة
                try:
                    stats = load_statistics()
                    total_users = get_total_users_count()
                    
                    # إحصائيات الخدمات
                    operations = stats.get('operations', {})
                    total_operations = sum(operations.values())
                    
                    current_time = get_iraq_time()
                    current_time_str = to_english_numerals(current_time.strftime('%d/%m/%Y - %H:%M:%S'))
                    
                    stats_msg = f"📊 إحصائيات البوت\n\n"
                    stats_msg += f"👥 إجمالي المستخدمين: {total_users}\n"
                    stats_msg += f"🔧 إجمالي الخدمات: {total_operations}\n"
                    stats_msg += f"⏰ الوقت: {current_time_str}\n"
                    stats_msg += f"🚀 حالة البوت: ✅ يعمل بشكل طبيعي\n\n"
                    
                    # إحصائيات الخدمات
                    if operations:
                        stats_msg += "📈 إحصائيات الخدمات حسب الاستخدام:\n"
                        service_names = {
                            'remove_bg': '🖼️ إزالة الخلفية',
                            'enhance': '🪄 تحسين الجودة',
                            'template3x4': '🧩 قالب المعاملات',
                            'template_new': '🧩 قالب الجوازات',
                            'auto_process': '🤖 المعالجة التلقائية',
                            'white_space': '⬜ فراغ أبيض',
                            'PDF': '📄 خدمات PDF',
                            'conversion': '♻️ التحويلات'
                        }
                        
                        # ترتيب الخدمات حسب الاستخدام - جميع الخدمات
                        sorted_ops = sorted(operations.items(), key=lambda x: x[1], reverse=True)
                        for operation, count in sorted_ops:
                            service_name = service_names.get(operation, operation)
                            stats_msg += f"• {service_name}: {count} استخداماً\n"
                    else:
                        stats_msg += "📝 لا توجد عمليات مسجلة بعد\n"
                    
                except Exception as e:
                    logging.error(f"Error loading statistics: {e}")
                    stats_msg = f"📊 إحصائيات البوت\n\n"
                    stats_msg += f"✅ حالة البوت: يعمل بشكل طبيعي\n"
                    stats_msg += f"⏰ الوقت: {to_english_numerals(get_iraq_time().strftime('%d/%m/%Y - %H:%M:%S'))}\n"
                    stats_msg += f"ملاحظة: البيانات الإحصائية قيد التحديث"

                # تعديل الرسالة الحالية بدلاً من إرسال جديدة
                buttons = [
                    [{'text': '⬅️ رجوع', 'callback_data': 'admin_back_to_main'}]
                ]
                edit_message(chat_id, admin_message_id, stats_msg, inline_buttons=buttons)
                return
            elif data == 'admin_section_backup':
                show_admin_backup_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_section_keys':
                show_admin_keys_menu(chat_id, user_id, admin_message_id)
                return
            # Handle new database section callbacks
            elif data == 'admin_section_database':
                show_admin_database_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_section_start_message':
                show_start_message_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_edit_start_message':
                set_user_state(user_id, 'admin_awaiting_start_message', {'admin_message_id': admin_message_id})
                send_message(chat_id, "✏️ أرسل الرسالة الجديدة التي تريد أن تظهر عند /start:")
                return
            elif data == 'admin_toggle_start_message':
                toggle_start_message()
                show_start_message_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_reset_start_message':
                reset_start_message()
                send_message(chat_id, "♻️ تم إعادة تعيين رسالة البدء للافتراضية بنجاح!")
                show_start_message_menu(chat_id, user_id, admin_message_id)
                return
            # Template Message handlers
            elif data == 'admin_section_template_message':
                show_template_message_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_edit_regular_template_message':
                set_user_state(user_id, 'admin_awaiting_regular_template_message', {'admin_message_id': admin_message_id})
                send_message(chat_id, "✏️ أرسل الرسالة الجديدة للتوزيع العادي:")
                return
            elif data == 'admin_edit_auto_template_message':
                set_user_state(user_id, 'admin_awaiting_auto_template_message', {'admin_message_id': admin_message_id})
                send_message(chat_id, "✏️ أرسل الرسالة الجديدة للمعالجة التلقائية:")
                return
            elif data == 'admin_toggle_template_message':
                toggle_template_message()
                show_template_message_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_reset_template_message':
                reset_template_message()
                send_message(chat_id, "♻️ تم إعادة تعيين رسالة القوالب للافتراضية بنجاح!")
                show_template_message_menu(chat_id, user_id, admin_message_id)
                return
            # Side Settings Menu
            elif data == 'admin_section_side_settings':
                show_side_settings_menu(chat_id, user_id, admin_message_id)
                return
            # Command Modes Management
            elif data == 'admin_section_command_modes':
                show_admin_command_mode_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_toggle_all_command_modes':
                result = toggle_all_users_command_mode()
                old_mode_text = "أزرار شفافة" if result['old_mode'] == 'inline' else "أزرار نصية"
                new_mode_text = "أزرار شفافة" if result['new_mode'] == 'inline' else "أزرار نصية"
                send_message(chat_id, f"✅ تم تبديل {to_english_numerals(result['count'])} مستخدم من {old_mode_text} إلى {new_mode_text}")
                show_admin_command_mode_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_toggle_specific_user_mode':
                set_user_state(user_id, 'admin_awaiting_user_id_for_mode_toggle', {'admin_message_id': admin_message_id})
                send_message(chat_id, "👤 *تبديل وضع مستخدم محدد*\n\nأرسل معرف المستخدم (User ID) الذي تريد تبديل وضعه:", parse_mode='Markdown')
                return
            elif data == 'admin_refresh_mode_stats':
                show_admin_command_mode_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_set_default_mode_menu':
                show_set_default_mode_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_set_default_mode_inline':
                if set_default_command_mode('inline'):
                    send_message(chat_id, "✅ تم تعيين الوضع الافتراضي إلى: أزرار شفافة (inline)")
                else:
                    send_message(chat_id, "❌ فشل في تعيين الوضع الافتراضي")
                show_set_default_mode_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_set_default_mode_buttons':
                if set_default_command_mode('buttons'):
                    send_message(chat_id, "✅ تم تعيين الوضع الافتراضي إلى: أزرار نصية (buttons)")
                else:
                    send_message(chat_id, "❌ فشل في تعيين الوضع الافتراضي")
                show_set_default_mode_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_reset_all_modes':
                result = reset_all_to_default_mode()
                default_mode_text = "أزرار شفافة" if result['default_mode'] == 'inline' else "أزرار نصية"
                send_message(chat_id, f"🔁 تم إعادة تعيين {to_english_numerals(result['count'])} مستخدم للوضع الافتراضي: {default_mode_text}")
                show_admin_command_mode_menu(chat_id, user_id, admin_message_id)
                return
            # Broadcast Section
            elif data == 'admin_section_broadcast':
                show_broadcast_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_broadcast_all':
                set_user_state(user_id, 'admin_awaiting_broadcast_all', {'admin_message_id': admin_message_id})
                send_message(chat_id, "📣 *إرسال رسالة جماعية*\n\nأرسل الآن الرسالة التي تريد إذاعتها لجميع الأعضاء.\n\n*يمكنك إرسال:*\n• نص عادي\n• صورة\n• فيديو\n• ملف\n• صوت\n• رسالة صوتية\n• صورة متحركة (GIF)", parse_mode='Markdown')
                return
            elif data == 'admin_broadcast_user':
                set_user_state(user_id, 'admin_awaiting_broadcast_user_id', {'admin_message_id': admin_message_id})
                send_message(chat_id, "👤 *إرسال لشخص معين*\n\nأرسل معرف المستخدم (User ID) الذي تريد إرسال الرسالة له:", parse_mode='Markdown')
                return
            # Maintenance Mode
            elif data == 'admin_section_maintenance':
                show_maintenance_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_toggle_maintenance':
                toggle_maintenance_mode()
                show_maintenance_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_edit_maintenance_message':
                set_user_state(user_id, 'admin_awaiting_maintenance_message', {'admin_message_id': admin_message_id})
                send_message(chat_id, "✏️ أرسل رسالة الصيانة الجديدة:")
                return
            # Summary Mode
            elif data == 'admin_section_summary':
                show_summary_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_summary_add_user':
                set_user_state(user_id, 'admin_awaiting_summary_user_add', {'admin_message_id': admin_message_id})
                send_message(chat_id, "🆔 أرسل معرف المستخدم (ID) لإضافته لقائمة الموجز:")
                return
            elif data == 'admin_summary_remove_user':
                set_user_state(user_id, 'admin_awaiting_summary_user_remove', {'admin_message_id': admin_message_id})
                send_message(chat_id, "🆔 أرسل معرف المستخدم (ID) لإزالته من قائمة الموجز:")
                return
            elif data == 'admin_summary_set_time':
                set_user_state(user_id, 'admin_awaiting_summary_hour', {'admin_message_id': admin_message_id})
                send_message(chat_id, "⏰ أرسل الساعة (من 1 إلى 12):")
                return
            elif data == 'admin_summary_view_users':
                summary_data = load_summary_mode()
                enabled_users = summary_data.get('enabled_users', {})
                if enabled_users:
                    user_list = "\n".join([f"• {uid}" for uid in enabled_users.keys()])
                    send_message(chat_id, f"👥 *المستخدمون في قائمة الموجز:*\n\n{user_list}", parse_mode='Markdown')
                else:
                    send_message(chat_id, "📭 لا يوجد مستخدمون في قائمة الموجز.")
                show_summary_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'summary_time_am' or data == 'summary_time_pm':
                current_user_state = get_user_state(user_id)
                if current_user_state.get('state') == 'admin_awaiting_summary_ampm':
                    current_data = current_user_state.get('data', {})
                    hour = current_data.get('hour', 0)
                    minute = current_data.get('minute', 0)
                    admin_message_id = current_data.get('admin_message_id')
                    
                    if data == 'summary_time_am':
                        hour_24 = 0 if hour == 12 else hour
                    else:
                        hour_24 = hour if hour == 12 else hour + 12
                    
                    time_str = f"{hour_24:02d}:{minute:02d}"
                    if set_summary_send_time(time_str):
                        hour_12 = hour
                        period = "صباحًا" if data == 'summary_time_am' else "مساءً"
                        send_message(chat_id, f"✅ تم تحديد وقت إرسال الموجز: {hour_12}:{minute:02d} {period}")
                    else:
                        send_message(chat_id, "❌ فشل في تحديد الوقت")
                    show_summary_menu(chat_id, user_id, admin_message_id)
                    clear_user_state(user_id)
                return
            # Scheduled Reminder
            elif data == 'admin_scheduled_reminder':
                show_scheduled_reminder_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_toggle_scheduled':
                toggle_scheduled_reminder()
                show_scheduled_reminder_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_scheduled_interval_1':
                set_scheduled_interval(1)
                send_message(chat_id, "✅ تم تحديد الفترة لـ 1 يوم")
                show_scheduled_reminder_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_scheduled_interval_2':
                set_scheduled_interval(2)
                send_message(chat_id, "✅ تم تحديد الفترة لـ 2 يوم")
                show_scheduled_reminder_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_scheduled_interval_3':
                set_scheduled_interval(3)
                send_message(chat_id, "✅ تم تحديد الفترة لـ 3 أيام")
                show_scheduled_reminder_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_scheduled_interval_4':
                set_scheduled_interval(4)
                send_message(chat_id, "✅ تم تحديد الفترة لـ 4 أيام")
                show_scheduled_reminder_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_edit_scheduled_content':
                set_user_state(user_id, 'admin_awaiting_scheduled_content', {'admin_message_id': admin_message_id})
                send_message(chat_id, "✏️ أرسل محتوى التذكير المجدول بالصيغة:\nالعنوان|الرسالة\n\nمثال:\nتذكير يومي|هذا تذكير يومي مهم")
                return
            elif data == 'admin_section_reminders':
                show_admin_reminders_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_section_version':
                show_admin_version_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_version_major':
                show_version_component_menu(chat_id, user_id, 'major', admin_message_id)
                return
            elif data == 'admin_version_minor':
                show_version_component_menu(chat_id, user_id, 'minor', admin_message_id)
                return
            elif data == 'admin_version_patch':
                show_version_component_menu(chat_id, user_id, 'patch', admin_message_id)
                return
            elif data == 'admin_version_build':
                show_version_component_menu(chat_id, user_id, 'build', admin_message_id)
                return
            elif data == 'admin_show_major':
                toggle_component_display('major', True)
                send_message(chat_id, "✅ تم تفعيل عرض الرقم الرئيسي في /STATUS")
                show_version_component_menu(chat_id, user_id, 'major', admin_message_id)
                return
            elif data == 'admin_hide_major':
                toggle_component_display('major', False)
                send_message(chat_id, "🚫 تم تعطيل عرض الرقم الرئيسي في /STATUS")
                show_version_component_menu(chat_id, user_id, 'major', admin_message_id)
                return
            elif data == 'admin_show_minor':
                toggle_component_display('minor', True)
                send_message(chat_id, "✅ تم تفعيل عرض الرقم الثانوي في /STATUS")
                show_version_component_menu(chat_id, user_id, 'minor', admin_message_id)
                return
            elif data == 'admin_hide_minor':
                toggle_component_display('minor', False)
                send_message(chat_id, "🚫 تم تعطيل عرض الرقم الثانوي في /STATUS")
                show_version_component_menu(chat_id, user_id, 'minor', admin_message_id)
                return
            elif data == 'admin_show_patch':
                toggle_component_display('patch', True)
                send_message(chat_id, "✅ تم تفعيل عرض رقم الإصلاح في /STATUS")
                show_version_component_menu(chat_id, user_id, 'patch', admin_message_id)
                return
            elif data == 'admin_hide_patch':
                toggle_component_display('patch', False)
                send_message(chat_id, "🚫 تم تعطيل عرض رقم الإصلاح في /STATUS")
                show_version_component_menu(chat_id, user_id, 'patch', admin_message_id)
                return
            elif data == 'admin_show_build':
                toggle_component_display('build', True)
                send_message(chat_id, "✅ تم تفعيل عرض رقم البناء في /STATUS")
                show_version_component_menu(chat_id, user_id, 'build', admin_message_id)
                return
            elif data == 'admin_hide_build':
                toggle_component_display('build', False)
                send_message(chat_id, "🚫 تم تعطيل عرض رقم البناء في /STATUS")
                show_version_component_menu(chat_id, user_id, 'build', admin_message_id)
                return
            elif data == 'admin_add_reminder':
                set_user_state(user_id, 'admin_awaiting_reminder_title', {'admin_message_id': admin_message_id})
                send_message(chat_id, "📝 أرسل عنوان التذكير:")
                return
            elif data and data.startswith('confirm_reminder_time_'):
                # User confirmed the parsed reminder time
                reminder_title = state_data.get('reminder_title', 'تذكير')
                reminder_description = state_data.get('reminder_description', '')
                reminder_time = state_data.get('reminder_time')
                display_time = state_data.get('display_time')
                
                if reminder_time:
                    reminder_id = str(uuid.uuid4())
                    if add_reminder(reminder_id, reminder_title, reminder_description, reminder_time):
                        send_message(chat_id, f"✅ تم إنشاء التذكير بنجاح!\n\nالعنوان: {reminder_title}\nالوقت: {display_time}")
                    else:
                        send_message(chat_id, "❌ فشل في إنشاء التذكير.")
                    
                    show_admin_reminders_menu(chat_id, user_id, admin_message_id)
                else:
                    send_message(chat_id, "❌ حدث خطأ: لم يتم العثور على وقت التذكير.")
                    show_admin_reminders_menu(chat_id, user_id, admin_message_id)
                return
            elif data and data.startswith('retry_reminder_time_'):
                # User wants to re-enter the reminder time
                reminder_title = state_data.get('reminder_title', 'تذكير')
                reminder_description = state_data.get('reminder_description', '')
                
                set_user_state(user_id, 'admin_awaiting_reminder_time', {
                    'admin_message_id': admin_message_id,
                    'reminder_title': reminder_title,
                    'reminder_description': reminder_description
                })
                
                send_message(chat_id, "⏰ أرسل وقت التذكير. يمكنك استخدام أي من التنسيقات التالية:\n\n• HH:MM (مثال: 18:30)\n• HH:MM AM/PM (مثال: 6:30 PM)\n• Tomorrow at HH:MM (مثال: Tomorrow at 8:00)\n• YYYY-MM-DD HH:MM (مثال: 2025-01-15 14:30)")
                return
            elif data == 'admin_edit_reminder':
                reminders = get_all_reminders()
                if reminders:
                    text = "✏️ اختر التذكير الذي تريد تعديله:\n\n"
                    for reminder_id, reminder_data in reminders.items():
                        title = reminder_data.get('title', 'تذكير')
                        text += f"• {title} (ID: {reminder_id})\n"
                    set_user_state(user_id, 'admin_awaiting_reminder_id_for_edit', {'admin_message_id': admin_message_id})
                    send_message(chat_id, text)
                else:
                    send_message(chat_id, "❌ لا توجد تذكيرات للتعديل.")
                return
            elif data == 'admin_delete_reminder':
                reminders = get_all_reminders()
                if reminders:
                    text = "🗑️ اختر التذكير الذي تريد حذفه:\n\n"
                    for reminder_id, reminder_data in reminders.items():
                        title = reminder_data.get('title', 'تذكير')
                        text += f"• {title} (ID: {reminder_id})\n"
                    set_user_state(user_id, 'admin_awaiting_reminder_id_for_delete', {'admin_message_id': admin_message_id})
                    send_message(chat_id, text)
                else:
                    send_message(chat_id, "❌ لا توجد تذكيرات للحذف.")
                return
            elif data == 'admin_view_reminders':
                reminders = get_all_reminders()
                if reminders:
                    text = "👀 *جميع التذكيرات:*\n\n"
                    for reminder_id, reminder_data in reminders.items():
                        title = reminder_data.get('title', 'تذكير')
                        description = reminder_data.get('description', 'لا يوجد وصف')
                        reminder_time = reminder_data.get('reminder_time', 'غير محدد')
                        created_at = reminder_data.get('created_at', 'غير محدد')
                        acknowledged = reminder_data.get('acknowledged', False)
                        status = "✅ تم الإقرار" if acknowledged else "⏰ نشط"
                        
                        text += f"*{title}*\n"
                        text += f"الوصف: {description}\n"
                        text += f"الوقت: {reminder_time}\n"
                        text += f"تاريخ الإنشاء: {created_at}\n"
                        text += f"الحالة: {status}\n\n"
                    
                    send_message(chat_id, text, parse_mode='Markdown')
                else:
                    send_message(chat_id, "📭 لا توجد تذكيرات حاليًا.")
                show_admin_reminders_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'version_increment_major':
                if increment_version('major'):
                    send_message(chat_id, f"✅ تم تحديث الإصدار الرئيسي بنجاح!\n\nالإصدار الجديد: {get_version_string()}")
                else:
                    send_message(chat_id, "❌ فشل في تحديث الإصدار")
                show_admin_version_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'version_increment_minor':
                if increment_version('minor'):
                    send_message(chat_id, f"✅ تم تحديث الإصدار الثانوي بنجاح!\n\nالإصدار الجديد: {get_version_string()}")
                else:
                    send_message(chat_id, "❌ فشل في تحديث الإصدار")
                show_admin_version_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'version_increment_patch':
                if increment_version('patch'):
                    send_message(chat_id, f"✅ تم تحديث رقم التصحيح بنجاح!\n\nالإصدار الجديد: {get_version_string()}")
                else:
                    send_message(chat_id, "❌ فشل في تحديث الإصدار")
                show_admin_version_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'version_increment_build':
                if increment_version('build'):
                    send_message(chat_id, f"✅ تم تحديث رقم البناء بنجاح!\n\nالإصدار الجديد: {get_version_string()}")
                else:
                    send_message(chat_id, "❌ فشل في تحديث الإصدار")
                show_admin_version_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'version_update_status':
                status_buttons = [
                    [{'text': '🟢 مستقر', 'callback_data': 'version_status_stable'}],
                    [{'text': '🟡 تجريبي', 'callback_data': 'version_status_beta'}],
                    [{'text': '🔴 قيد التطوير', 'callback_data': 'version_status_dev'}],
                    [{'text': '⬅️ رجوع', 'callback_data': 'admin_section_version'}]
                ]
                update_admin_message_and_state(chat_id, user_id, "🎯 *اختر حالة الإصدار:*", status_buttons, admin_message_id, 'version_status_selection')
                return
            elif data == 'version_status_stable':
                if update_version_status('مستقر'):
                    send_message(chat_id, "✅ تم تحديث حالة الإصدار إلى: مستقر")
                show_admin_version_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'version_status_beta':
                if update_version_status('تجريبي'):
                    send_message(chat_id, "✅ تم تحديث حالة الإصدار إلى: تجريبي")
                show_admin_version_menu(chat_id, user_id, admin_message_id)
                return
            # New decrement version handlers
            elif data == 'admin_decrement_major':
                if decrement_version('major'):
                    send_message(chat_id, f"✅ تم تقليل الإصدار الرئيسي بنجاح!\n\nالإصدار الجديد: {get_version_string()}")
                else:
                    send_message(chat_id, "❌ لا يمكن تقليل الإصدار الرئيسي أكثر من ذلك")
                show_version_component_menu(chat_id, user_id, 'major', admin_message_id)
                return
            elif data == 'admin_decrement_minor':
                if decrement_version('minor'):
                    send_message(chat_id, f"✅ تم تقليل الإصدار الثانوي بنجاح!\n\nالإصدار الجديد: {get_version_string()}")
                else:
                    send_message(chat_id, "❌ لا يمكن تقليل الإصدار الثانوي أكثر من ذلك")
                show_version_component_menu(chat_id, user_id, 'minor', admin_message_id)
                return
            elif data == 'admin_decrement_patch':
                if decrement_version('patch'):
                    send_message(chat_id, f"✅ تم تقليل رقم الإصلاح بنجاح!\n\nالإصدار الجديد: {get_version_string()}")
                else:
                    send_message(chat_id, "❌ لا يمكن تقليل رقم الإصلاح أكثر من ذلك")
                show_version_component_menu(chat_id, user_id, 'patch', admin_message_id)
                return
            elif data == 'admin_decrement_build':
                if decrement_version('build'):
                    send_message(chat_id, f"✅ تم تقليل رقم البناء بنجاح!\n\nالإصدار الجديد: {get_version_string()}")
                else:
                    send_message(chat_id, "❌ لا يمكن تقليل رقم البناء أكثر من ذلك")
                show_version_component_menu(chat_id, user_id, 'build', admin_message_id)
                return
            elif data == 'admin_increment_major':
                if increment_version('major'):
                    send_message(chat_id, f"✅ تم زيادة الإصدار الرئيسي بنجاح!\n\nالإصدار الجديد: {get_version_string()}")
                else:
                    send_message(chat_id, "❌ فشل في تحديث الإصدار")
                show_version_component_menu(chat_id, user_id, 'major', admin_message_id)
                return
            elif data == 'admin_increment_minor':
                if increment_version('minor'):
                    send_message(chat_id, f"✅ تم زيادة الإصدار الثانوي بنجاح!\n\nالإصدار الجديد: {get_version_string()}")
                else:
                    send_message(chat_id, "❌ فشل في تحديث الإصدار")
                show_version_component_menu(chat_id, user_id, 'minor', admin_message_id)
                return
            elif data == 'admin_increment_patch':
                if increment_version('patch'):
                    send_message(chat_id, f"✅ تم زيادة رقم الإصلاح بنجاح!\n\nالإصدار الجديد: {get_version_string()}")
                else:
                    send_message(chat_id, "❌ فشل في تحديث الإصدار")
                show_version_component_menu(chat_id, user_id, 'patch', admin_message_id)
                return
            elif data == 'admin_increment_build':
                if increment_version('build'):
                    send_message(chat_id, f"✅ تم زيادة رقم البناء بنجاح!\n\nالإصدار الجديد: {get_version_string()}")
                else:
                    send_message(chat_id, "❌ فشل في تحديث الإصدار")
                show_version_component_menu(chat_id, user_id, 'build', admin_message_id)
                return
            elif data == 'admin_change_release_date':
                set_user_state(user_id, 'admin_awaiting_release_date', {'admin_message_id': admin_message_id})
                send_message(chat_id, "📅 أرسل تاريخ الإصدار الجديد بالصيغة:\nYYYY-MM-DD\n\nمثال: 2025-10-22")
                return
            elif data == 'admin_change_status':
                status_buttons = [
                    [{'text': '🟢 مستقر', 'callback_data': 'admin_status_stable'}],
                    [{'text': '🟡 تجريبي', 'callback_data': 'admin_status_beta'}],
                    [{'text': '🔴 قيد التطوير', 'callback_data': 'admin_status_dev'}],
                    [{'text': '⬅️ رجوع', 'callback_data': 'admin_section_version'}]
                ]
                update_admin_message_and_state(chat_id, user_id, "🎯 *اختر حالة الإصدار:*", status_buttons, admin_message_id, 'admin_status_selection')
                return
            elif data == 'admin_status_stable':
                if set_version_status('مستقر'):
                    send_message(chat_id, "✅ تم تحديث حالة الإصدار إلى: مستقر")
                show_admin_version_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_status_beta':
                if set_version_status('تجريبي'):
                    send_message(chat_id, "✅ تم تحديث حالة الإصدار إلى: تجريبي")
                show_admin_version_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_status_dev':
                if set_version_status('قيد التطوير'):
                    send_message(chat_id, "✅ تم تحديث حالة الإصدار إلى: قيد التطوير")
                show_admin_version_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_toggle_status_display':
                if toggle_status_display():
                    version_data = load_bot_version()
                    show_status = version_data.get('show_in_status', True)
                    status_text = "مفعّل" if show_status else "معطّل"
                    send_message(chat_id, f"✅ تم تبديل عرض الإصدار في /STATUS\n\nالحالة الحالية: {status_text}")
                else:
                    send_message(chat_id, "❌ فشل في تبديل الحالة")
                show_admin_version_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'version_status_dev':
                if update_version_status('قيد التطوير'):
                    send_message(chat_id, "✅ تم تحديث حالة الإصدار إلى: قيد التطوير")
                show_admin_version_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'version_add_feature':
                set_user_state(user_id, 'awaiting_version_feature', {'admin_message_id': admin_message_id})
                send_message(chat_id, "✨ أرسل وصف الميزة الجديدة:")
                return
            elif data == 'version_show_changelog':
                changelog_info = get_version_info()
                send_message(chat_id, f"📋 *سجل التغييرات*\n\n{changelog_info}", parse_mode='Markdown')
                show_admin_version_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_section_version':
                show_admin_version_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_db_storage_info':
                send_chat_action(chat_id, 'typing')
                processing_msg = send_message(chat_id, "📊 جاري جلب معلومات مساحة التخزين...")
                
                try:
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    
                    # Get database size info (now includes separate counts)
                    db_size_info = loop.run_until_complete(db.get_database_size())
                    
                    # Get counts directly from db_size_info
                    total_count = db_size_info.get('file_count', 0)
                    regular_count = db_size_info.get('regular_count', 0)
                    template_count = db_size_info.get('template_count', 0)
                    
                    # Calculate sizes
                    size_mb = db_size_info.get('size_mb', 0)
                    size_kb = size_mb * 1024
                    max_size_mb = db_size_info.get('max_size_mb', 500)
                    max_size_gb = max_size_mb / 1024
                    remaining_mb = db_size_info.get('remaining_mb', 500)
                    usage_percent = db_size_info.get('usage_percent', 0)
                    status = db_size_info.get('status', '🟢 جيد')
                    
                    storage_msg = (f"*🗄️ إدارة قواعد البيانات*\n\n"
                                   f"*📊 إحصائيات التخزين:*\n"
                                   f"📁 إجمالي الملفات: `{total_count}` ملف\n"
                                   f"📄 عدد الملفات العادية: `{regular_count}` ملف\n"
                                   f"📋 عدد ملفات القوالب: `{template_count}` ملف\n"
                                   f"💾 المساحة المستخدمة: `{size_kb:.1f} KB`\n"
                                   f"📈 نسبة الاستخدام: `{usage_percent:.2f}%`\n"
                                   f"📊 المساحة المتبقية: `{remaining_mb:.1f} MB`\n"
                                   f"🗂️ الحد الأقصى: `{max_size_gb:.1f} GB` (Supabase مجاني)\n"
                                   f"{status}\n\n"
                                   f"*🔗 معلومات الاتصال:*\n"
                                   f"📡 حالة الاتصال: 🟢 متصل\n"
                                   f"🏷️ اسم المشروع: `Lbot1-db`\n"
                                   f"🆔 معرف المشروع: `bxfsjgiishddzfozknpd`")
                    
                    send_message(chat_id, storage_msg, parse_mode='Markdown')
                    loop.close()
                    
                except Exception as e:
                    logging.error(f"Error getting storage info: {e}")
                    send_message(chat_id, "❌ فشل في جلب معلومات مساحة التخزين.")
                
                if processing_msg:
                    delete_message(chat_id, processing_msg)
                
                show_admin_database_menu(chat_id, user_id, admin_message_id)
                return
                
            elif data == 'admin_db_all_files':
                send_chat_action(chat_id, 'typing')
                # Show fetching progress
                fetch_msg_id = None
                for fetch_prog in [0, 40, 80, 100]:
                    fetch_text = create_progress_indicator(fetch_prog, "📋 جاري جلب ملفات قاعدة البيانات...")
                    if fetch_msg_id:
                        make_request(f"{API_URL}/editMessageText", method='POST',
                                    json_data={'chat_id': chat_id, 'message_id': fetch_msg_id, 'text': fetch_text})
                    else:
                        response = make_request(f"{API_URL}/sendMessage", method='POST',
                                              json_data={'chat_id': chat_id, 'text': fetch_text})
                        if response and response.get('http_code') == 200:
                            fetch_msg_id = response['response'].json().get('result', {}).get('message_id')
                    time.sleep(0.1)
                processing_msg = fetch_msg_id
                
                try:
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    
                    all_files = loop.run_until_complete(db.get_all_pdf_files())
                    
                    if all_files:
                        # Group files by user
                        user_files = {}
                        for file_info in all_files:
                            user_id_file = file_info.get('user_id')
                            if user_id_file not in user_files:
                                user_files[user_id_file] = []
                            user_files[user_id_file].append(file_info)
                        
                        # Send files grouped by user
                        for user_id_file, files in user_files.items():
                            # Fetch user information from database
                            try:
                                user_info = loop.run_until_complete(db.get_user(int(user_id_file)))
                                if user_info:
                                    first_name = user_info.get('first_name', '')
                                    last_name = user_info.get('last_name', '')
                                    username = user_info.get('username', '')
                                    
                                    user_display = f"{first_name} {last_name}".strip()
                                    if username:
                                        user_display += f" (@{username})"
                                    if not user_display:
                                        user_display = f"ID: {user_id_file}"
                                    
                                    escaped_user_display = escape_markdown_v2(user_display)
                                    user_msg = f"*👤 ملفات المستخدم {escaped_user_display}:*\n\n"
                                else:
                                    escaped_user_id = escape_markdown_v2(str(user_id_file))
                                    user_msg = f"*👤 ملفات المستخدم ID: {escaped_user_id}:*\n\n"
                            except Exception as e:
                                logging.error(f"Error fetching user info for {user_id_file}: {e}")
                                escaped_user_id = escape_markdown_v2(str(user_id_file))
                                user_msg = f"*👤 ملفات المستخدم ID: {escaped_user_id}:*\n\n"
                            
                            for index, file_info in enumerate(files, 1):
                                file_name = file_info.get('file_name', 'ملف غير معروف')
                                created_date = file_info.get('created_at', '')[:10] if file_info.get('created_at') else 'غير متوفر'
                                escaped_file_name = escape_markdown_v2(file_name)
                                escaped_date = escape_markdown_v2(created_date)
                                user_msg += f"{index}\\. `{escaped_file_name}`\n📅 {escaped_date}\n\n"
                            
                            send_message(chat_id, user_msg, parse_mode='MarkdownV2')
                            time.sleep(0.5)  # Small delay between messages
                    else:
                        send_message(chat_id, "📂 لا توجد ملفات محفوظة في قاعدة البيانات حاليًا.")
                    
                    loop.close()
                    
                except Exception as e:
                    logging.error(f"Error getting all files: {e}")
                    send_message(chat_id, "❌ فشل في جلب ملفات قاعدة البيانات.")
                
                if processing_msg:
                    delete_message(chat_id, processing_msg)
                
                show_admin_database_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_create_pdf_backup':
                # إنشاء نسخة احتياطية لملفات PDF
                send_chat_action(chat_id, 'upload_document')
                processing_msg = send_message(chat_id, "⏳ جاري إنشاء نسخة احتياطية لملفات PDF...")
                
                try:
                    # استخدام asyncio لتشغيل الدالة غير المتزامنة
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    success, backup_file_path = loop.run_until_complete(create_pdf_backup())
                    loop.close()
                    
                    if success and backup_file_path:
                        # إرسال ملف النسخة الاحتياطية
                        caption = f"📦 نسخة احتياطية لملفات PDF\n🕐 تم الإنشاء: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                        
                        if send_document(chat_id, backup_file_path, caption):
                            send_message(chat_id, "✅ تم إنشاء وإرسال النسخة الاحتياطية بنجاح!")
                        else:
                            send_message(chat_id, "❌ فشل في إرسال النسخة الاحتياطية.")
                        
                        # تنظيف الملف المؤقت
                        if os.path.exists(backup_file_path):
                            os.remove(backup_file_path)
                    else:
                        send_message(chat_id, "❌ فشل في إنشاء النسخة الاحتياطية.")
                    
                except Exception as e:
                    logging.error(f"Error creating PDF backup: {e}")
                    send_message(chat_id, f"❌ حدث خطأ أثناء إنشاء النسخة الاحتياطية: {str(e)}")
                
                if processing_msg:
                    delete_message(chat_id, processing_msg)
                
                show_admin_database_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_restore_pdf_backup':
                # طلب استعادة نسخة احتياطية لملفات PDF
                set_user_state(user_id, 'awaiting_pdf_backup_file', {'admin_message_id': admin_message_id})
                send_message(chat_id, "📤 الرجاء إرسال ملف النسخة الاحتياطية لملفات PDF (ملف ZIP) الآن:")
                return
            elif data == 'admin_db_delete_menu':
                # عرض قائمة حذف الملفات
                show_admin_delete_files_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_db_delete_templates':
                # حذف ملفات القوالب فقط
                confirmation_buttons = [
                    [{'text': '⚠️ نعم، احذف ملفات القوالب', 'callback_data': 'admin_confirm_delete_templates'}],
                    [{'text': '❌ لا، ألغي العملية', 'callback_data': 'admin_db_delete_menu'}]
                ]
                admin_delete_message_id = send_message(chat_id, "⚠️ *تحذير: هذا الإجراء سيحذف جميع ملفات القوالب لجميع المستخدمين نهائيًا\\!*\n\nهل أنت متأكد من المتابعة؟", 
                           inline_buttons=confirmation_buttons, parse_mode='MarkdownV2')
                set_user_state(user_id, 'admin_delete_templates_confirmation', {'admin_delete_message_id': admin_delete_message_id})
                return
            elif data == 'admin_confirm_delete_templates':
                current_user_state = get_user_state(user_id)
                admin_delete_message_id = current_user_state.get('data', {}).get('admin_delete_message_id')
                
                if admin_delete_message_id:
                    delete_message(chat_id, admin_delete_message_id)
                
                send_chat_action(chat_id, 'typing')
                processing_msg = send_message(chat_id, "🗑️ جاري حذف ملفات القوالب من قاعدة البيانات...")
                
                try:
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    success = loop.run_until_complete(db.delete_all_template_files())
                    loop.close()
                    
                    if success:
                        send_message(chat_id, "✅ تم حذف جميع ملفات القوالب من قاعدة البيانات والتخزين بنجاح!")
                    else:
                        send_message(chat_id, "❌ حدث خطأ أثناء حذف ملفات القوالب.")
                except Exception as e:
                    logging.error(f"Error deleting template files: {e}")
                    send_message(chat_id, "❌ حدث خطأ أثناء حذف ملفات القوالب.")
                
                if processing_msg:
                    delete_message(chat_id, processing_msg)
                
                clear_user_state(user_id)
                show_admin_database_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_db_delete_regular':
                # حذف الملفات العادية فقط
                confirmation_buttons = [
                    [{'text': '⚠️ نعم، احذف الملفات العادية', 'callback_data': 'admin_confirm_delete_regular'}],
                    [{'text': '❌ لا، ألغي العملية', 'callback_data': 'admin_db_delete_menu'}]
                ]
                admin_delete_message_id = send_message(chat_id, "⚠️ *تحذير: هذا الإجراء سيحذف جميع الملفات العادية لجميع المستخدمين نهائيًا\\!*\n\nهل أنت متأكد من المتابعة؟", 
                           inline_buttons=confirmation_buttons, parse_mode='MarkdownV2')
                set_user_state(user_id, 'admin_delete_regular_confirmation', {'admin_delete_message_id': admin_delete_message_id})
                return
            elif data == 'admin_confirm_delete_regular':
                current_user_state = get_user_state(user_id)
                admin_delete_message_id = current_user_state.get('data', {}).get('admin_delete_message_id')
                
                if admin_delete_message_id:
                    delete_message(chat_id, admin_delete_message_id)
                
                send_chat_action(chat_id, 'typing')
                processing_msg = send_message(chat_id, "🗑️ جاري حذف الملفات العادية من قاعدة البيانات...")
                
                try:
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    success = loop.run_until_complete(db.delete_all_regular_files())
                    loop.close()
                    
                    if success:
                        send_message(chat_id, "✅ تم حذف جميع الملفات العادية من قاعدة البيانات والتخزين بنجاح!")
                    else:
                        send_message(chat_id, "❌ حدث خطأ أثناء حذف الملفات العادية.")
                except Exception as e:
                    logging.error(f"Error deleting regular files: {e}")
                    send_message(chat_id, "❌ حدث خطأ أثناء حذف الملفات العادية.")
                
                if processing_msg:
                    delete_message(chat_id, processing_msg)
                
                clear_user_state(user_id)
                show_admin_database_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_db_delete_all':
                # المرحلة 1: التحذير الأولي للمالك
                confirmation_buttons = [
                    [{'text': '⚠️ نعم، أريد حذف كل شيء', 'callback_data': 'admin_delete_step1'}],
                    [{'text': '❌ لا، ألغي العملية', 'callback_data': 'admin_section_database'}]
                ]
                
                admin_delete_message_id = send_message(chat_id, "⚠️ *تحذير خطر: هذا الإجراء سيحذف جميع ملفات جميع المستخدمين من قاعدة البيانات والتخزين نهائيًا ولا يمكن التراجع عنه\\.*\n\nهل أنت متأكد من المتابعة؟", 
                           inline_buttons=confirmation_buttons, parse_mode='MarkdownV2')
                
                # حفظ معرف الرسالة في حالة المستخدم
                set_user_state(user_id, 'admin_delete_confirmation_step1', {'admin_delete_message_id': admin_delete_message_id})
                return
            elif data == 'admin_delete_step1':
                # المرحلة 2: تأكيد فهم العواقب
                current_user_state = get_user_state(user_id)
                admin_delete_message_id = current_user_state.get('data', {}).get('admin_delete_message_id')
                
                confirmation_buttons = [
                    [{'text': '🔥 نعم، أفهم العواقب', 'callback_data': 'admin_delete_step2'}],
                    [{'text': '🛡️ لا، أحافظ على البيانات', 'callback_data': 'admin_cancel_delete_all'}]
                ]
                
                new_message_id = send_message(chat_id, "🚨 *هل تفهم أن هذا سيؤثر على جميع المستخدمين؟*\n\nسيفقد كل مستخدم جميع ملفاته المحفوظة نهائيًا\\!", 
                           inline_buttons=confirmation_buttons, parse_mode='MarkdownV2', message_id=admin_delete_message_id)
                
                if not new_message_id and admin_delete_message_id:
                    delete_message(chat_id, admin_delete_message_id)
                    new_message_id = send_message(chat_id, "🚨 *هل تفهم أن هذا سيؤثر على جميع المستخدمين؟*\n\nسيفقد كل مستخدم جميع ملفاته المحفوظة نهائيًا\\!", 
                               inline_buttons=confirmation_buttons, parse_mode='MarkdownV2')
                
                set_user_state(user_id, 'admin_delete_confirmation_step2', {'admin_delete_message_id': new_message_id or admin_delete_message_id})
                return
            elif data == 'admin_delete_step2':
                # المرحلة 3: عرض الإحصائيات
                current_user_state = get_user_state(user_id)
                admin_delete_message_id = current_user_state.get('data', {}).get('admin_delete_message_id')
                
                try:
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    
                    total_files = loop.run_until_complete(db.get_total_files_count())
                    storage_info = loop.run_until_complete(db.get_storage_info())
                    loop.close()
                    
                    confirmation_buttons = [
                        [{'text': f'💥 نعم، احذف {total_files} ملف', 'callback_data': 'admin_delete_step3'}],
                        [{'text': '📊 لا، أبقي على البيانات', 'callback_data': 'admin_cancel_delete_all'}]
                    ]
                    
                    used_mb = storage_info.get('size_mb', 0)
                    escaped_total_files = escape_markdown_v2(str(total_files))
                    escaped_used_mb = escape_markdown_v2(f"{used_mb:.2f}")
                    new_message_id = send_message(chat_id, f"📊 *ستحذف:*\n• {escaped_total_files} ملف PDF\n• {escaped_used_mb} ميجابايت من البيانات\n• جميع سجلات المستخدمين\n\n🔥 هل تريد المتابعة؟", 
                               inline_buttons=confirmation_buttons, parse_mode='MarkdownV2', message_id=admin_delete_message_id)
                    
                    if not new_message_id and admin_delete_message_id:
                        delete_message(chat_id, admin_delete_message_id)
                        new_message_id = send_message(chat_id, f"📊 *ستحذف:*\n• {escaped_total_files} ملف PDF\n• {escaped_used_mb} ميجابايت من البيانات\n• جميع سجلات المستخدمين\n\n🔥 هل تريد المتابعة؟", 
                                   inline_buttons=confirmation_buttons, parse_mode='MarkdownV2')
                    
                    set_user_state(user_id, 'admin_delete_confirmation_step3', {'admin_delete_message_id': new_message_id or admin_delete_message_id})
                except:
                    error_message_id = send_message(chat_id, "❌ حدث خطأ في جلب الإحصائيات.", message_id=admin_delete_message_id)
                    if not error_message_id and admin_delete_message_id:
                        send_message(chat_id, "❌ حدث خطأ في جلب الإحصائيات.")
                return
            elif data == 'admin_delete_step3':
                # المرحلة 4: التحذير من عدم الإمكانية للتراجع
                current_user_state = get_user_state(user_id)
                admin_delete_message_id = current_user_state.get('data', {}).get('admin_delete_message_id')
                
                confirmation_buttons = [
                    [{'text': '🎯 نعم، لا توجد نسخ احتياطية', 'callback_data': 'admin_delete_step4'}],
                    [{'text': '💾 لا، أعمل نسخة احتياطية أولًا', 'callback_data': 'admin_cancel_delete_all'}]
                ]
                
                new_message_id = send_message(chat_id, "🔴 *تحذير حرج: لا توجد طريقة لاستعادة البيانات بعد الحذف\\!*\n\nحتى النسخ الاحتياطية لن تستعيد ملفات PDF المحذوفة\\.", 
                           inline_buttons=confirmation_buttons, parse_mode='MarkdownV2', message_id=admin_delete_message_id)
                
                if not new_message_id and admin_delete_message_id:
                    delete_message(chat_id, admin_delete_message_id)
                    new_message_id = send_message(chat_id, "🔴 *تحذير حرج: لا توجد طريقة لاستعادة البيانات بعد الحذف\\!*\n\nحتى النسخ الاحتياطية لن تستعيد ملفات PDF المحذوفة\\.", 
                               inline_buttons=confirmation_buttons, parse_mode='MarkdownV2')
                
                set_user_state(user_id, 'admin_delete_confirmation_step4', {'admin_delete_message_id': new_message_id or admin_delete_message_id})
                return
            elif data == 'admin_delete_step4':
                # المرحلة 5: السؤال عن السبب
                current_user_state = get_user_state(user_id)
                admin_delete_message_id = current_user_state.get('data', {}).get('admin_delete_message_id')
                
                confirmation_buttons = [
                    [{'text': '🧹 نعم، لتنظيف قاعدة البيانات', 'callback_data': 'admin_delete_step5'}],
                    [{'text': '🤔 لا، سأعيد التفكير', 'callback_data': 'admin_cancel_delete_all'}]
                ]
                
                new_message_id = send_message(chat_id, "❓ *لماذا تريد حذف جميع البيانات؟*\n\nهل هذا لتنظيف قاعدة البيانات أم خطأ؟ فكر جيدًا\\!", 
                           inline_buttons=confirmation_buttons, parse_mode='MarkdownV2', message_id=admin_delete_message_id)
                
                if not new_message_id and admin_delete_message_id:
                    delete_message(chat_id, admin_delete_message_id)
                    new_message_id = send_message(chat_id, "❓ *لماذا تريد حذف جميع البيانات؟*\n\nهل هذا لتنظيف قاعدة البيانات أم خطأ؟ فكر جيدًا\\!", 
                               inline_buttons=confirmation_buttons, parse_mode='MarkdownV2')
                
                set_user_state(user_id, 'admin_delete_confirmation_step5', {'admin_delete_message_id': new_message_id or admin_delete_message_id})
                return
            elif data == 'admin_delete_step5':
                # المرحلة 6: التأكيد النهائي مع كلمة سر
                current_user_state = get_user_state(user_id)
                admin_delete_message_id = current_user_state.get('data', {}).get('admin_delete_message_id')
                
                confirmation_buttons = [
                    [{'text': '💀 تأكيد الحذف الشامل', 'callback_data': 'admin_confirm_delete_all'}],
                    [{'text': '🚨 إلغاء فوري', 'callback_data': 'admin_cancel_delete_all'}]
                ]
                
                new_message_id = send_message(chat_id, "⚡ *المرحلة الأخيرة: تأكيد نهائي\\!*\n\n🔥 سيتم حذف كل شيء خلال ثوانٍ بعد الضغط\\.\n💡 إذا لم تكن متأكدًا 100%، اضغط إلغاء فوري\\.", 
                           inline_buttons=confirmation_buttons, parse_mode='MarkdownV2', message_id=admin_delete_message_id)
                
                if not new_message_id and admin_delete_message_id:
                    delete_message(chat_id, admin_delete_message_id)
                    new_message_id = send_message(chat_id, "⚡ *المرحلة الأخيرة: تأكيد نهائي\\!*\n\n🔥 سيتم حذف كل شيء خلال ثوانٍ بعد الضغط\\.\n💡 إذا لم تكن متأكدًا 100%، اضغط إلغاء فوري\\.", 
                               inline_buttons=confirmation_buttons, parse_mode='MarkdownV2')
                
                set_user_state(user_id, 'admin_delete_confirmation_step6', {'admin_delete_message_id': new_message_id or admin_delete_message_id})
                return
            elif data == 'admin_confirm_delete_all':
                current_user_state = get_user_state(user_id)
                admin_delete_message_id = current_user_state.get('data', {}).get('admin_delete_message_id')
                
                # حذف رسالة التأكيد الأصلية
                if admin_delete_message_id:
                    delete_message(chat_id, admin_delete_message_id)
                
                send_chat_action(chat_id, 'typing')
                processing_msg = send_message(chat_id, "🗑️ جاري حذف جميع الملفات من قاعدة البيانات...")
                
                try:
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    
                    success = loop.run_until_complete(db.delete_all_files())
                    
                    if success:
                        send_message(chat_id, "✅ تم حذف جميع الملفات من قاعدة البيانات والتخزين بنجاح!\n\n📊 تم إعادة تعيين قاعدة البيانات بالكامل.")
                    else:
                        send_message(chat_id, "❌ حدث خطأ أثناء حذف الملفات. يرجى المحاولة مرة أخرى.")
                    
                    loop.close()
                    
                except Exception as e:
                    logging.error(f"Error deleting all files: {e}")
                    send_message(chat_id, "❌ حدث خطأ أثناء حذف جميع الملفات.")
                
                if processing_msg:
                    delete_message(chat_id, processing_msg)
                
                clear_user_state(user_id)
                show_admin_database_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_cancel_delete_all':
                current_user_state = get_user_state(user_id)
                admin_delete_message_id = current_user_state.get('data', {}).get('admin_delete_message_id')
                
                # حذف رسالة التأكيد الأصلية
                if admin_delete_message_id:
                    delete_message(chat_id, admin_delete_message_id)
                
                send_message(chat_id, "✅ تم إلغاء عملية حذف جميع الملفات.")
                clear_user_state(user_id)
                show_admin_database_menu(chat_id, user_id, admin_message_id)
                return
            elif data == 'admin_db_keepalive':
                # ── XKA Keep-Alive status panel ──
                status_text = xka_build_status_text()
                keepalive_buttons = [
                    [{'text': '📤 إرسال الآن يدوياً', 'callback_data': 'admin_db_keepalive_now'}],
                    [{'text': '🔄 تحديث', 'callback_data': 'admin_db_keepalive'}],
                    [{'text': '⬅️ رجوع', 'callback_data': 'admin_section_database'}]
                ]
                update_admin_message_and_state(
                    chat_id, user_id, status_text, keepalive_buttons,
                    admin_message_id, 'admin_keepalive_menu'
                )
                return
            elif data == 'admin_db_keepalive_now':
                # ── Manual XKA trigger ──
                send_chat_action(chat_id, 'typing')
                proc_msg = send_message(chat_id, "♻️ جاري تنفيذ دورة Keep-Alive يدوياً...")
                t = threading.Thread(target=xka_run_cycle, daemon=True)
                t.start()
                t.join(timeout=15)
                if proc_msg:
                    delete_message(chat_id, proc_msg)
                updated_text = xka_build_status_text()
                keepalive_buttons = [
                    [{'text': '📤 إرسال الآن يدوياً', 'callback_data': 'admin_db_keepalive_now'}],
                    [{'text': '🔄 تحديث', 'callback_data': 'admin_db_keepalive'}],
                    [{'text': '⬅️ رجوع', 'callback_data': 'admin_section_database'}]
                ]
                update_admin_message_and_state(
                    chat_id, user_id, updated_text, keepalive_buttons,
                    admin_message_id, 'admin_keepalive_menu'
                )
                return
            elif data == 'admin_back_to_keys_menu': # From specific key admin to general keys menu
                show_admin_keys_menu(chat_id, user_id, admin_message_id)
                return
            elif data.startswith('back_to_key_admin_'): # From key view back to key admin
                key_type_raw = data.replace('back_to_key_admin_', '')
                key_file_info = KEY_TYPE_MAP.get(key_type_raw)
                if key_file_info:
                    handle_key_admin_actions(chat_id, user_id, 'initial_display', key_file_info, admin_message_id)
                return

            # Handle specific actions within sub-menus
            if current_state == 'admin_members_menu':
                # This state is now just a gateway to other menus
                pass
            elif current_state == 'admin_users_menu':
                if data == 'admin_add_user':
                    set_user_state(user_id, 'admin_awaiting_add_user_id', {'admin_message_id': admin_message_id})
                    send_message(chat_id, "➕ أرسل آيدي المستخدم الذي تريد إضافته:")
                elif data == 'admin_delete_user':
                    set_user_state(user_id, 'admin_awaiting_delete_user_id', {'admin_message_id': admin_message_id})
                    send_message(chat_id, "🗑️ أرسل آيدي المستخدم الذي تريد حذفه:")
            elif current_state == 'admin_ban_menu':
                if data == 'admin_ban_user':
                    set_user_state(user_id, 'admin_awaiting_ban_user_id', {'admin_message_id': admin_message_id})
                    send_message(chat_id, "🚫 أرسل آيدي المستخدم الذي تريد حظره:")
                elif data == 'admin_unban_user':
                    set_user_state(user_id, 'admin_awaiting_unban_user_id', {'admin_message_id': admin_message_id})
                    send_message(chat_id, "✅ أرسل آيدي المستخدم الذي تريد إلغاء حظره:")
            elif current_state == 'admin_lists_menu':
                if data == 'admin_view_allowed':
                    allowed_users_data = load_allowed_users()['allowed']
                    msg = "*قائمة المستخدمين المسموح لهم:*\n\n"
                    if allowed_users_data:
                        for uid in allowed_users_data:
                            msg += f"- `{uid}`\n"
                    else:
                        msg += "لا يوجد مستخدمون مسموح لهم حاليًا."
                    send_message(chat_id, msg, parse_mode='Markdown') # This sends a new message as it's a list
                    show_admin_lists_menu(chat_id, user_id, admin_message_id) # Return to lists menu
                elif data == 'admin_view_banned':
                    banned_users_data = load_allowed_users()['banned']
                    msg = "*قائمة المستخدمين المحظورين:*\n\n"
                    if banned_users_data:
                        for uid in banned_users_data:
                            msg += f"- `{uid}`\n"
                    else:
                        msg += "لا يوجد مستخدمون محظورون حاليًا."
                    send_message(chat_id, msg, parse_mode='Markdown') # This sends a new message as it's a list
                    show_admin_lists_menu(chat_id, user_id, admin_message_id) # Return to lists menu
                elif data == 'admin_view_pending':
                    pending_users_data = load_allowed_users()['pending']
                    if pending_users_data:
                        # Instead of sending a new message "جاري عرض الطلبات المعلقة...",
                        # we directly prepare and send the list of pending requests.
                        # This avoids the extra message and makes it faster.
                        for uid, info in pending_users_data.items():
                            user_full_name = f"{info.get('first_name', '')} {info.get('last_name', '')}".strip()
                            escaped_user_full_name = escape_markdown_v2(user_full_name)
                            escaped_user_username = escape_markdown_v2(info.get('username', ''))
                            user_link = f"[{escaped_user_full_name or 'حساب المستخدم'}]({(f'tg://user?id={uid}')})"
                            user_username_display = f"\\@{escaped_user_username}" if info.get('username') else "لا يوجد يوزر"
                            entry_time = info.get('entry_time', 'غير متوفر')

                            admin_caption = (
                                f"🚨 *طلب وصول معلق:*\n\n"
                                f"الاسم: {escaped_user_full_name}\n"
                                f"الرابط: {user_link}\n"
                                f"اليوزر: {user_username_display}\n"
                                f"الآيدي: `{uid}`\n"
                                f"وقت الدخول: {escape_markdown_v2(entry_time)}\n\n"
                                f"هل توافق على وصول هذا المستخدم؟"
                            )
                            inline_buttons = [
                                [
                                    {'text': '✅ موافقة', 'callback_data': f'approve_user_{uid}'},
                                    {'text': '❌ رفض', 'callback_data': f'reject_user_{uid}'}
                                ]
                            ]
                            profile_photo_path = info.get('profile_photo_path')
                            if profile_photo_path and os.path.exists(profile_photo_path):
                                send_photo(chat_id, profile_photo_path, caption=admin_caption, inline_buttons=inline_buttons, parse_mode='MarkdownV2')
                            else:
                                send_message(chat_id, admin_caption, inline_buttons=inline_buttons, parse_mode='MarkdownV2')
                            # Removed time.sleep(0.5) for faster response
                    else:
                        send_message(chat_id, "لا توجد طلبات معلقة حاليًا.")
                    show_admin_lists_menu(chat_id, user_id, admin_message_id) # Return to lists menu
            elif current_state == 'admin_backup_menu':
                if data == 'admin_perform_backup':
                    send_chat_action(chat_id, 'upload_document')
                    # تعديل الرسالة الحالية بدلاً من إرسال رسالة جديدة
                    edit_message(chat_id, admin_message_id, "⏳ جاري إنشاء النسخة الاحتياطية وإرسالها...")
                    if perform_daily_backup(ADMIN_ID, force=True):
                        edit_message(chat_id, admin_message_id, "✅ تم إنشاء النسخة الاحتياطية وإرسالها بنجاح!")
                    else:
                        edit_message(chat_id, admin_message_id, "❌ فشل في إنشاء أو إرسال النسخة الاحتياطية. يرجى مراجعة سجلات الأخطاء.")
                    # الانتظار قليلاً ثم العودة لقائمة النسخ الاحتياطي
                    time.sleep(1.5)
                    show_admin_backup_menu(chat_id, user_id, admin_message_id) # Return to backup menu
                elif data == 'admin_restore_backup':
                    set_user_state(user_id, 'awaiting_backup_file', {'admin_message_id': admin_message_id})
                    send_message(chat_id, "📤 الرجاء إرسال ملف النسخة الاحتياطية (ملف ZIP) الآن:")
            elif current_state == 'admin_keys_menu':
                if data.startswith('admin_keys_'):
                    key_type_raw = data.replace('admin_keys_', '')
                    key_file_info = KEY_TYPE_MAP.get(key_type_raw)
                    if key_file_info:
                        # First update state, then get the new message ID for subsequent actions
                        new_msg_id = update_admin_message_and_state(chat_id, user_id, f"🔐 إدارة مفاتيح {key_file_info['display_name']}", [], admin_message_id, f'{key_type_raw}_keys_admin', {'key_type_raw': key_type_raw})
                        # Use the new message ID for key admin actions
                        handle_key_admin_actions(chat_id, user_id, 'initial_display', key_file_info, new_msg_id or admin_message_id)
                    else:
                        logging.error(f"Unknown key type in admin_keys_menu: {key_type_raw}")
                        send_message(chat_id, "❌ حدث خطأ داخلي في تحديد نوع المفتاح.")
                        show_admin_keys_menu(chat_id, user_id, admin_message_id)
                # This block handles all key management specific callbacks and states
            elif current_state.endswith('_keys_admin') or \
                 current_state.startswith('delete_keys_') or \
                 current_state.startswith('awaiting_backup_key_index_') or \
                 current_state.startswith('awaiting_expired_key_index_'):

                key_type_raw = state_data.get('key_type_raw') # Get from state data
                # Get the current admin message ID from state
                current_admin_msg_id = state_data.get('admin_message_id', admin_message_id)

                if key_type_raw and key_type_raw in KEY_TYPE_MAP:
                    key_file_info = KEY_TYPE_MAP[key_type_raw]
                else:
                    logging.error(f"Could not determine key type from state ({current_state}). Available types: {list(KEY_TYPE_MAP.keys())}")
                    send_message(chat_id, "❌ حدث خطأ داخلي في تحديد نوع المفتاح.")
                    show_admin_keys_menu(chat_id, user_id, current_admin_msg_id)
                    return

                # Handle all key management callbacks
                if data and (data.startswith('add_primary_key_btn_') or \
                             data.startswith('add_backup_key_btn_') or \
                             data.startswith('view_keys_btn_') or \
                             data.startswith('rotate_key_btn_') or \
                             data.startswith('delete_keys_btn_')):
                    handle_key_admin_actions(chat_id, user_id, data, key_file_info, current_admin_msg_id)
                elif data and (data.startswith('delete_primary_') or \
                               data.startswith('delete_all_backup_') or \
                               data.startswith('delete_specific_backup_') or \
                               data.startswith('clear_expired_') or \
                               data.startswith('restore_expired_')):
                    process_key_deletion_callback(chat_id, user_id, data, key_file_info, current_admin_msg_id)
                else:
                    # Re-display current menu based on state
                    if current_state.endswith('_keys_admin'):
                        handle_key_admin_actions(chat_id, user_id, 'initial_display', key_file_info, current_admin_msg_id)
                    elif current_state.startswith('delete_keys_'):
                        # Re-display delete options if in delete sub-menu
                        delete_options_buttons = [
                            [{'text': '🗑️ حذف مفتاح رئيسي', 'callback_data': f'delete_primary_{key_type_raw}'}],
                            [{'text': '🗑️ حذف جميع المفاتيح الاحتياطية', 'callback_data': f'delete_all_backup_{key_type_raw}'}],
                            [{'text': '🗑️ حذف مفتاح احتياطي محدد', 'callback_data': f'delete_specific_backup_{key_type_raw}'}],
                            [{'text': '🗑️ حذف جميع المفاتيح منتهية الصلاحية', 'callback_data': f'clear_expired_{key_type_raw}'}],
                            [{'text': '↩️ استعادة مفتاح منتهي الصلاحية', 'callback_data': f'restore_expired_{key_type_raw}'}],
                            [{'text': '⬅️ رجوع لقائمة المفاتيح', 'callback_data': 'admin_back_to_keys_menu'}]
                        ]
                        update_admin_message_and_state(chat_id, user_id, f"🗑️ اختر خيار الحذف لمفاتيح {key_file_info['display_name']}:", delete_options_buttons, current_admin_msg_id, f'delete_keys_{key_type_raw}', {'key_type_raw': key_type_raw})
                    else:
                        logging.warning(f"Unhandled key-related callback or state. State: {current_state}, Data: {data}")
                        send_message(chat_id, "🤔 أمر غير مفهوم في إدارة المفاتيح. الرجاء اختيار من القائمة.")
                        show_admin_keys_menu(chat_id, user_id, current_admin_msg_id) # Fallback to main keys menu
            return # Handled admin panel callback



    # --- Handle Admin Panel Text Inputs (after callback) ---
    if user_id == ADMIN_ID and text:
        # Delete user's text input message for admin commands
        if current_message_id:
            delete_message(chat_id, current_message_id)

        if current_state == 'admin_awaiting_start_message':
            new_message = text.strip()
            if update_start_message(new_message):
                send_message(chat_id, "✅ تم تحديث رسالة البدء بنجاح!")
            else:
                send_message(chat_id, "❌ فشل في تحديث رسالة البدء. يرجى المحاولة مرة أخرى.")
            show_start_message_menu(chat_id, user_id, admin_message_id)
            return
        elif current_state == 'admin_awaiting_regular_template_message':
            new_message = text.strip()
            if update_template_message(new_message, 'regular'):
                send_message(chat_id, "✅ تم تحديث رسالة التوزيع العادي بنجاح!")
            else:
                send_message(chat_id, "❌ فشل في تحديث رسالة القوالب.")
            show_template_message_menu(chat_id, user_id, admin_message_id)
            return
        elif current_state == 'admin_awaiting_auto_template_message':
            new_message = text.strip()
            if update_template_message(new_message, 'auto'):
                send_message(chat_id, "✅ تم تحديث رسالة المعالجة التلقائية بنجاح!")
            else:
                send_message(chat_id, "❌ فشل في تحديث رسالة القوالب.")
            show_template_message_menu(chat_id, user_id, admin_message_id)
            return
        elif current_state == 'admin_awaiting_maintenance_message':
            new_message = text.strip()
            if update_maintenance_message(new_message):
                send_message(chat_id, "✅ تم تحديث رسالة الصيانة بنجاح!")
            else:
                send_message(chat_id, "❌ فشل في تحديث رسالة الصيانة.")
            show_maintenance_menu(chat_id, user_id, admin_message_id)
            return
        elif current_state == 'admin_awaiting_summary_user_add':
            try:
                target_user_id = int(text.strip())
                if add_user_to_summary(target_user_id):
                    send_message(chat_id, f"✅ تم إضافة المستخدم {target_user_id} لقائمة الموجز")
                else:
                    send_message(chat_id, "❌ فشل في إضافة المستخدم")
                show_summary_menu(chat_id, user_id, admin_message_id)
            except ValueError:
                send_message(chat_id, "❌ معرف المستخدم غير صحيح. يرجى إدخال رقم صحيح.")
            return
        elif current_state == 'admin_awaiting_summary_user_remove':
            try:
                target_user_id = int(text.strip())
                if remove_user_from_summary(target_user_id):
                    send_message(chat_id, f"✅ تم إزالة المستخدم {target_user_id} من قائمة الموجز")
                else:
                    send_message(chat_id, "❌ فشل في إزالة المستخدم")
                show_summary_menu(chat_id, user_id, admin_message_id)
            except ValueError:
                send_message(chat_id, "❌ معرف المستخدم غير صحيح. يرجى إدخال رقم صحيح.")
            return
        elif current_state == 'admin_awaiting_summary_hour':
            try:
                hour = int(text.strip())
                if 1 <= hour <= 12:
                    current_data = get_user_state(user_id).get('data', {})
                    current_data['hour'] = hour
                    admin_message_id = current_data.get('admin_message_id')
                    set_user_state(user_id, 'admin_awaiting_summary_minute', current_data)
                    send_message(chat_id, "⏰ أرسل الدقيقة (من 00 إلى 59):")
                else:
                    send_message(chat_id, "❌ الساعة يجب أن تكون من 1 إلى 12")
            except ValueError:
                send_message(chat_id, "❌ يرجى إدخال رقم صحيح للساعة")
            return
        elif current_state == 'admin_awaiting_summary_minute':
            try:
                minute = int(text.strip())
                if 0 <= minute <= 59:
                    current_data = get_user_state(user_id).get('data', {})
                    current_data['minute'] = minute
                    admin_message_id = current_data.get('admin_message_id')
                    set_user_state(user_id, 'admin_awaiting_summary_ampm', current_data)
                    
                    ampm_buttons = [
                        [{'text': '🌅 صباحًا (AM)', 'callback_data': 'summary_time_am'}],
                        [{'text': '🌙 مساءً (PM)', 'callback_data': 'summary_time_pm'}]
                    ]
                    send_message(chat_id, "⏰ اختر الفترة:", inline_buttons=ampm_buttons)
                else:
                    send_message(chat_id, "❌ الدقيقة يجب أن تكون من 00 إلى 59")
            except ValueError:
                send_message(chat_id, "❌ يرجى إدخال رقم صحيح للدقيقة")
            return
        elif current_state == 'admin_awaiting_scheduled_content':
            content = text.strip()
            if '|' in content:
                parts = content.split('|', 1)
                title = parts[0].strip()
                message = parts[1].strip()
                if update_scheduled_reminder_content(title, message):
                    send_message(chat_id, "✅ تم تحديث محتوى التذكير المجدول بنجاح!")
                else:
                    send_message(chat_id, "❌ فشل في تحديث المحتوى")
                show_scheduled_reminder_menu(chat_id, user_id, admin_message_id)
            else:
                send_message(chat_id, "❌ صيغة غير صحيحة. يرجى استخدام: العنوان|الرسالة")
            return
        elif current_state == 'admin_awaiting_add_user_id':
            try:
                target_user_id = int(text.strip())
                add_allowed_user(target_user_id)
                send_message(chat_id, f"✅ تم إضافة المستخدم `{target_user_id}` إلى قائمة المسموح لهم.")
                send_message(target_user_id, "🎉 تهانينا! لقد تمت إضافتك إلى قائمة المستخدمين المسموح لهم في البوت. يمكنك الآن استخدام جميع الميزات.")
            except ValueError:
                send_message(chat_id, "❌ آيدي مستخدم غير صالح. الرجاء إدخال رقم صحيح.")
            show_admin_users_menu(chat_id, user_id, admin_message_id) # Return to users menu
            return
        elif current_state == 'admin_awaiting_delete_user_id':
            try:
                target_user_id = int(text.strip())
                if remove_allowed_user(target_user_id):
                    send_message(chat_id, f"✅ تم حذف المستخدم `{target_user_id}` من قائمة المسموح لهم.")
                    send_message(target_user_id, "ℹ️ تم حذف وصولك إلى البوت من قبل المالك.")
                else:
                    send_message(chat_id, "❌ المستخدم غير موجود في قائمة المسموح لهم.")
            except ValueError:
                send_message(chat_id, "❌ آيدي مستخدم غير صالح. الرجاء إدخال رقم صحيح.")
            show_admin_users_menu(chat_id, user_id, admin_message_id) # Return to users menu
            return
        elif current_state == 'admin_awaiting_ban_user_id':
            try:
                target_user_id = int(text.strip())
                ban_user(target_user_id)
                send_message(chat_id, f"🚫 تم حظر المستخدم `{target_user_id}`.")
                send_message(target_user_id, "🚫 عذرًا، لقد تم حظرك من استخدام هذا البوت.")
            except ValueError:
                send_message(chat_id, "❌ آيدي مستخدم غير صالح. الرجاء إدخال رقم صحيح.")
            show_admin_ban_menu(chat_id, user_id, admin_message_id) # Return to ban menu
            return
        elif current_state == 'admin_awaiting_broadcast_user_id':
            try:
                target_user_id = int(text.strip())
                set_user_state(user_id, 'admin_awaiting_broadcast_user', {'admin_message_id': admin_message_id, 'target_user_id': target_user_id})
                send_message(chat_id, f"✅ تم تحديد المستخدم: `{target_user_id}`\n\n📤 أرسل الآن الرسالة التي تريد إرساله لهذا المستخدم.\n\n*يمكنك إرسال:*\n• نص عادي\n• صورة\n• فيديو\n• ملف\n• صوت\n• رسالة صوتية\n• صورة متحركة (GIF)", parse_mode='Markdown')
            except ValueError:
                send_message(chat_id, "❌ معرف المستخدم غير صحيح. يرجى إدخال رقم صحيح.")
                show_broadcast_menu(chat_id, user_id, admin_message_id)
                clear_user_state(user_id)
            return
        elif current_state == 'admin_awaiting_user_id_for_mode_toggle':
            try:
                target_user_id = int(text.strip())
                result = toggle_specific_user_mode(target_user_id)
                if result.get('success'):
                    old_mode_text = "أزرار شفافة" if result['old_mode'] == 'inline' else "أزرار نصية"
                    new_mode_text = "أزرار شفافة" if result['new_mode'] == 'inline' else "أزرار نصية"
                    send_message(chat_id, f"✅ تم تبديل وضع المستخدم `{to_english_numerals(target_user_id)}`\n\n• الوضع السابق: {old_mode_text}\n• الوضع الجديد: {new_mode_text}")
                else:
                    send_message(chat_id, f"❌ {result.get('error', 'فشل في تبديل الوضع')}")
            except ValueError:
                send_message(chat_id, "❌ معرف المستخدم غير صحيح. يرجى إدخال رقم صحيح.")
            show_admin_command_mode_menu(chat_id, user_id, admin_message_id)
            clear_user_state(user_id)
            return
        elif current_state == 'admin_awaiting_unban_user_id':
            try:
                target_user_id = int(text.strip())
                if unban_user(target_user_id):
                    send_message(chat_id, f"✅ تم إلغاء حظر المستخدم `{target_user_id}`.")
                    send_message(target_user_id, "🎉 تهانينا! لقد تم إلغاء حظرك من البوت. يمكنك الآن استخدام الميزات.")
                else:
                    send_message(chat_id, "❌ المستخدم غير موجود في قائمة المحظورين.")
            except ValueError:
                send_message(chat_id, "❌ آيدي مستخدم غير صالح. الرجاء إدخال رقم صحيح.")
            show_admin_ban_menu(chat_id, user_id, admin_message_id) # Return to ban menu
            return
        elif current_state.startswith('add_primary_key_'):
            key_type_raw = state_data.get('key_type_raw')
            key_file_info = KEY_TYPE_MAP.get(key_type_raw)
            if key_file_info:
                handle_add_key_input(chat_id, user_id, text, key_file_info, True, admin_message_id, current_message_id)
            else:
                send_message(chat_id, "❌ حدث خطأ داخلي في تحديد نوع المفتاح.")
                show_admin_keys_menu(chat_id, user_id, admin_message_id)
            return
        elif current_state.startswith('add_backup_key_'):
            key_type_raw = state_data.get('key_type_raw')
            key_file_info = KEY_TYPE_MAP.get(key_type_raw)
            if key_file_info:
                handle_add_key_input(chat_id, user_id, text, key_file_info, False, admin_message_id, current_message_id)
            else:
                send_message(chat_id, "❌ حدث خطأ داخلي في تحديد نوع المفتاح.")
                show_admin_keys_menu(chat_id, user_id, admin_message_id)
            return
        elif current_state.startswith('awaiting_backup_key_index_'):
            handle_awaiting_key_index_input(chat_id, user_id, text, state_data, current_message_id, 'backup')
            return
        elif current_state.startswith('awaiting_expired_key_index_'):
            handle_awaiting_key_index_input(chat_id, user_id, text, state_data, current_message_id, 'expired')
            return
        elif current_state == 'admin_awaiting_reminder_title':
            set_user_state(user_id, 'admin_awaiting_reminder_description', {'admin_message_id': admin_message_id, 'reminder_title': text})
            send_message(chat_id, "📝 أرسل وصف التذكير:")
            return
        elif current_state == 'admin_awaiting_reminder_description':
            reminder_title = state_data.get('reminder_title', 'تذكير')
            set_user_state(user_id, 'admin_awaiting_reminder_time', {'admin_message_id': admin_message_id, 'reminder_title': reminder_title, 'reminder_description': text})
            send_message(chat_id, "⏰ أرسل وقت التذكير. يمكنك استخدام أي من التنسيقات التالية:\n\n• HH:MM (مثال: 18:30)\n• HH:MM AM/PM (مثال: 6:30 PM)\n• Tomorrow at HH:MM (مثال: Tomorrow at 8:00)\n• YYYY-MM-DD HH:MM (مثال: 2025-01-15 14:30)")
            return
        elif current_state == 'admin_awaiting_reminder_time':
            reminder_title = state_data.get('reminder_title', 'تذكير')
            reminder_description = state_data.get('reminder_description', '')
            
            # Parse the time input using the intelligent parser
            success, reminder_time, display_time, error_msg = parse_reminder_time(text)
            
            if success:
                # Confirm the parsed time with the user
                confirm_message = f"⏰ تم تحليل الوقت بنجاح!\n\n📅 الوقت المحدد: {display_time}\n\n✅ هل هذا صحيح؟"
                confirm_buttons = [
                    [{'text': '✅ نعم، أنشئ التذكير', 'callback_data': f'confirm_reminder_time_{user_id}'}],
                    [{'text': '❌ لا، أدخل الوقت مرة أخرى', 'callback_data': f'retry_reminder_time_{user_id}'}]
                ]
                
                # Store the parsed time for confirmation
                set_user_state(user_id, 'admin_confirming_reminder_time', {
                    'admin_message_id': admin_message_id,
                    'reminder_title': reminder_title,
                    'reminder_description': reminder_description,
                    'reminder_time': reminder_time,
                    'display_time': display_time
                })
                
                send_message(chat_id, confirm_message, inline_buttons=confirm_buttons)
            else:
                send_message(chat_id, f"❌ {error_msg}")
            return
        elif current_state == 'admin_awaiting_reminder_id_for_edit':
            try:
                reminder_id = text.strip()
                reminder = get_reminder(reminder_id)
                if reminder:
                    set_user_state(user_id, 'admin_awaiting_reminder_new_title', {'admin_message_id': admin_message_id, 'reminder_id': reminder_id})
                    send_message(chat_id, f"✏️ التذكير الحالي: {reminder.get('title', 'تذكير')}\n\nأرسل العنوان الجديد:")
                else:
                    send_message(chat_id, "❌ لم يتم العثور على التذكير.")
                    show_admin_reminders_menu(chat_id, user_id, admin_message_id)
            except Exception as e:
                send_message(chat_id, "❌ حدث خطأ في تعديل التذكير.")
                show_admin_reminders_menu(chat_id, user_id, admin_message_id)
            return
        elif current_state == 'admin_awaiting_reminder_id_for_delete':
            try:
                reminder_id = text.strip()
                if delete_reminder(reminder_id):
                    send_message(chat_id, f"✅ تم حذف التذكير بنجاح!")
                else:
                    send_message(chat_id, "❌ فشل في حذف التذكير أو لم يتم العثور عليه.")
                show_admin_reminders_menu(chat_id, user_id, admin_message_id)
            except Exception as e:
                send_message(chat_id, "❌ حدث خطأ في حذف التذكير.")
                show_admin_reminders_menu(chat_id, user_id, admin_message_id)
            return
        elif current_state == 'admin_awaiting_reminder_new_title':
            reminder_id = state_data.get('reminder_id')
            set_user_state(user_id, 'admin_awaiting_reminder_new_description', {'admin_message_id': admin_message_id, 'reminder_id': reminder_id, 'new_title': text})
            send_message(chat_id, "📝 أرسل الوصف الجديد:")
            return
        elif current_state == 'admin_awaiting_reminder_new_description':
            reminder_id = state_data.get('reminder_id')
            new_title = state_data.get('new_title')
            set_user_state(user_id, 'admin_awaiting_reminder_new_time', {'admin_message_id': admin_message_id, 'reminder_id': reminder_id, 'new_title': new_title, 'new_description': text})
            send_message(chat_id, "⏰ أرسل الوقت الجديد بالتنسيق التالي:\nYYYY-MM-DD HH:MM:SS")
            return
        elif current_state == 'awaiting_version_feature':
            feature_text = text.strip()
            admin_message_id = state_data.get('admin_message_id')
            
            if add_version_feature(feature_text):
                send_message(chat_id, f"✅ تم إضافة الميزة الجديدة بنجاح!\n\n✨ {feature_text}")
            else:
                send_message(chat_id, "❌ فشل في إضافة الميزة")
            
            show_admin_version_menu(chat_id, user_id, admin_message_id)
            return
        elif current_state == 'admin_awaiting_release_date':
            import re
            new_date = text.strip()
            admin_message_id = state_data.get('admin_message_id')
            
            # التحقق من صحة التنسيق
            if re.match(r'^\d{4}-\d{2}-\d{2}$', new_date):
                version_data = load_bot_version()
                version_data['release_date'] = new_date
                
                if save_bot_version(version_data):
                    send_message(chat_id, f"✅ تم تحديث تاريخ الإصدار بنجاح!\n\n📅 التاريخ الجديد: {new_date}")
                else:
                    send_message(chat_id, "❌ فشل في تحديث تاريخ الإصدار")
            else:
                send_message(chat_id, "❌ صيغة التاريخ غير صحيحة. الرجاء استخدام الصيغة: YYYY-MM-DD")
            
            show_admin_version_menu(chat_id, user_id, admin_message_id)
            return
        elif current_state == 'admin_awaiting_reminder_new_time':
            reminder_id = state_data.get('reminder_id')
            new_title = state_data.get('new_title')
            new_description = state_data.get('new_description')
            
            # Parse the time input using the intelligent parser
            success, new_time, display_time, error_msg = parse_reminder_time(text)
            
            if success:
                # Update reminder
                updates = {
                    'title': new_title,
                    'description': new_description,
                    'reminder_time': new_time
                }
                if update_reminder(reminder_id, updates):
                    send_message(chat_id, f"✅ تم تعديل التذكير بنجاح!\n\nالوقت الجديد: {display_time}")
                else:
                    send_message(chat_id, "❌ فشل في تعديل التذكير.")
                
                show_admin_reminders_menu(chat_id, user_id, admin_message_id)
            else:
                send_message(chat_id, f"❌ {error_msg}")
            return

    # --- Handle User Text Inputs ---
    if text and current_state == 'awaiting_new_pdf_name':
        try:
            file_name = text.strip()
            if not file_name:
                send_message(chat_id, "❌ اسم الملف لا يمكن أن يكون فارغًا.")
                return
            
            # Use state_data directly from process_telegram_update
            pdf_data_hex = state_data.get('pdf_data')
            
            if not pdf_data_hex:
                logging.error(f"Missing pdf_data for user {user_id} in state awaiting_new_pdf_name. State data: {state_data}")
                send_message(chat_id, "❌ لم يتم العثور على بيانات PDF. الرجاء المحاولة مرة أخرى.")
                clear_user_state(user_id)
                return
            
            # Convert hex back to bytes
            try:
                pdf_data = bytes.fromhex(pdf_data_hex)
            except ValueError as e:
                logging.error(f"Failed to convert hex to bytes for user {user_id}: {e}")
                send_message(chat_id, "❌ حدث خطأ في بيانات PDF. الرجاء المحاولة مرة أخرى.")
                clear_user_state(user_id)
                return
            
            # Upload to storage
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                file_url = loop.run_until_complete(db.upload_pdf_to_storage(file_name, pdf_data))
                
                if file_url:
                    # Save to database
                    success = loop.run_until_complete(db.save_pdf_file(user_id, file_name, file_url))
                    
                    if success:
                        send_message(chat_id, f"✅ تم حفظ الملف '{file_name}' في قاعدة البيانات بنجاح!")
                    else:
                        send_message(chat_id, "❌ فشل في حفظ الملف في قاعدة البيانات.")
                else:
                    send_message(chat_id, "❌ فشل في رفع الملف إلى التخزين.")
            finally:
                loop.close()
            
            clear_user_state(user_id)
            
        except Exception as e:
            logging.error(f"Error saving new PDF: {e}")
            send_message(chat_id, f"❌ حدث خطأ أثناء حفظ الملف: {str(e)}")
            clear_user_state(user_id)
        return

    # Handle PDF name for enhanced image
    if text and current_state == 'awaiting_enhanced_pdf_name':
        try:
            file_name = text.strip()
            if not file_name:
                send_message(chat_id, "❌ اسم الملف لا يمكن أن يكون فارغًا.")
                return
            
            # Use state_data directly from process_telegram_update
            pdf_data_hex = state_data.get('pdf_data')
            enhanced_path = state_data.get('enhanced_path')
            
            if not pdf_data_hex:
                logging.error(f"Missing pdf_data for user {user_id} in state awaiting_enhanced_pdf_name")
                send_message(chat_id, "❌ لم يتم العثور على بيانات PDF. الرجاء المحاولة مرة أخرى.")
                clear_user_state(user_id)
                return
            
            # Convert hex back to bytes
            try:
                pdf_data = bytes.fromhex(pdf_data_hex)
            except ValueError as e:
                logging.error(f"Failed to convert hex to bytes for user {user_id}: {e}")
                send_message(chat_id, "❌ حدث خطأ في بيانات PDF. الرجاء المحاولة مرة أخرى.")
                clear_user_state(user_id)
                return
            
            # Upload to storage
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                file_url = loop.run_until_complete(db.upload_pdf_to_storage(file_name, pdf_data))
                
                if file_url:
                    # Save to database
                    success = loop.run_until_complete(db.save_pdf_file(user_id, file_name, file_url))
                    
                    if success:
                        send_message(chat_id, f"✅ تم حفظ الملف '{file_name}' في قاعدة البيانات بنجاح!")
                    else:
                        send_message(chat_id, "❌ فشل في حفظ الملف في قاعدة البيانات.")
                else:
                    send_message(chat_id, "❌ فشل في رفع الملف إلى التخزين.")
            finally:
                loop.close()
            
            # Clean up enhanced image
            if enhanced_path and os.path.exists(enhanced_path):
                os.remove(enhanced_path)
            
            clear_user_state(user_id)
            
        except Exception as e:
            logging.error(f"Error saving enhanced PDF: {e}")
            send_message(chat_id, f"❌ حدث خطأ أثناء حفظ الملف: {str(e)}")
            clear_user_state(user_id)
        return

    # Handle PDF name for database save
    if text and current_state == 'awaiting_pdf_name_for_db':
        try:
            file_name = text.strip()
            if not file_name:
                send_message(chat_id, "❌ اسم الملف لا يمكن أن يكون فارغًا.")
                return
            
            # Use state_data directly from process_telegram_update
            pdf_data_hex = state_data.get('pdf_data')
            template_path = state_data.get('template_path')
            template_type = state_data.get('template_type')
            image_count = state_data.get('image_count', 0)
            
            if not pdf_data_hex:
                logging.error(f"Missing pdf_data for user {user_id} in state awaiting_pdf_name_for_db")
                send_message(chat_id, "❌ لم يتم العثور على بيانات PDF. الرجاء المحاولة مرة أخرى.")
                clear_user_state(user_id)
                return
            
            # Convert hex back to bytes
            try:
                pdf_data = bytes.fromhex(pdf_data_hex)
            except ValueError as e:
                logging.error(f"Failed to convert hex to bytes for user {user_id}: {e}")
                send_message(chat_id, "❌ حدث خطأ في بيانات PDF. الرجاء المحاولة مرة أخرى.")
                clear_user_state(user_id)
                return
            
            # Upload to storage
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                # Upload to template bucket since this is a template file
                file_url = loop.run_until_complete(db.upload_pdf_to_storage(file_name, pdf_data, is_template=True))
                
                if file_url:
                    # Save to database - ALWAYS use save_template_pdf_file for template files
                    # to ensure consistency between storage location and database table
                    success = loop.run_until_complete(db.save_template_pdf_file(
                        user_id, 
                        file_name, 
                        file_url, 
                        template_type or 'custom',
                        image_count
                    ))
                    
                    if success:
                        send_message(chat_id, f"✅ تم حفظ الملف '{file_name}' في قاعدة البيانات بنجاح!")
                    else:
                        send_message(chat_id, "❌ فشل في حفظ الملف في قاعدة البيانات.")
                else:
                    send_message(chat_id, "❌ فشل في رفع الملف إلى التخزين.")
            finally:
                loop.close()
            
            # Clean up template file
            if template_path and os.path.exists(template_path):
                os.remove(template_path)
            
            clear_user_state(user_id)
            
        except Exception as e:
            logging.error(f"Error saving PDF to database: {e}")
            send_message(chat_id, f"❌ حدث خطأ أثناء حفظ الملف: {str(e)}")
            clear_user_state(user_id)
        return

    # Handle file selection (by number or name)
    if text and current_state == 'awaiting_file_selection':
        try:
            input_text = to_english_numerals(text.strip())
            file_type = state_data.get('file_type', 'regular')
            
            # Get user files based on type
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                if file_type == "template":
                    user_files = loop.run_until_complete(db.get_user_template_pdf_files(user_id))
                elif file_type == "regular":
                    user_files = loop.run_until_complete(db.get_user_regular_pdf_files(user_id))
                else:
                    user_files = loop.run_until_complete(db.get_user_pdf_files(user_id))
            finally:
                loop.close()
            
            if not user_files:
                send_message(chat_id, "❌ لا توجد ملفات.")
                clear_user_state(user_id)
                return
            
            selected_file = None
            selected_file_index = -1
            
            # Try as number first
            try:
                file_number = int(input_text)
                if 1 <= file_number <= len(user_files):
                    selected_file = user_files[file_number - 1]
                    selected_file_index = file_number - 1
            except ValueError:
                # Try as file name
                for idx, file_info in enumerate(user_files):
                    if file_info.get('file_name', '').strip().lower() == input_text.lower():
                        selected_file = file_info
                        selected_file_index = idx
                        break
            
            if not selected_file:
                send_message(chat_id, "❌ لم يتم العثور على الملف. الرجاء إدخال رقم صحيح أو اسم الملف الكامل.")
                return
            
            # Get file details
            file_name = selected_file.get('file_name', '')
            
            # Show file editing options instead of automatically sending
            edit_buttons = [
                [{'text': '📥 تحميل الملف', 'callback_data': f'download_file_{selected_file_index}_{file_type}'}],
                [{'text': '📝 تعديل الاسم', 'callback_data': f'edit_file_name_{selected_file_index}_{file_type}'}],
                [{'text': '🗑️ حذف الملف', 'callback_data': f'delete_single_file_{selected_file_index}_{file_type}'}],
                [{'text': '⬅️ رجوع', 'callback_data': f'back_to_file_list_{file_type}'}]
            ]
            
            send_message(chat_id, f"📄 *{file_name}*\n\nماذا تريد أن تفعل بهذا الملف؟", inline_buttons=edit_buttons, parse_mode='Markdown')
            clear_user_state(user_id)
            
        except Exception as e:
            logging.error(f"Error fetching file: {e}")
            send_message(chat_id, f"❌ حدث خطأ: {str(e)}")
            clear_user_state(user_id)
        return

    # Handle file renaming
    if text and current_state == 'awaiting_new_file_name':
        try:
            new_name = text.strip()
            if not new_name:
                send_message(chat_id, "❌ اسم الملف الجديد لا يمكن أن يكون فارغًا.")
                return
            
            # Get old file name and file type from state
            current_user_state = get_user_state(user_id)
            state_data = current_user_state.get('data', {})
            old_name = state_data.get('old_file_name')
            file_type = state_data.get('file_type', 'regular')
            
            if not old_name:
                send_message(chat_id, "❌ لم يتم العثور على اسم الملف القديم.")
                clear_user_state(user_id)
                return
            
            # Update file name in database based on file type
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                if file_type == 'template':
                    success = loop.run_until_complete(db.update_template_pdf_file_name(user_id, old_name, new_name))
                else:
                    success = loop.run_until_complete(db.update_regular_pdf_file_name(user_id, old_name, new_name))
                
                if success:
                    send_message(chat_id, f"✅ تم تغيير اسم الملف بنجاح!\nمن: {old_name}\nإلى: {new_name}")
                else:
                    send_message(chat_id, "❌ فشل في تغيير اسم الملف.")
            finally:
                loop.close()
            
            clear_user_state(user_id)
            
        except Exception as e:
            logging.error(f"Error renaming file: {e}")
            send_message(chat_id, f"❌ حدث خطأ أثناء تغيير اسم الملف: {str(e)}")
            clear_user_state(user_id)
        return

    # Handle file number input for renaming
    if text and current_state == 'awaiting_file_number_for_rename':
        try:
            file_number = int(text.strip())
            file_type = state_data.get('file_type', 'all')
            
            # Get user files based on type
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                if file_type == "template":
                    user_files = loop.run_until_complete(db.get_user_template_pdf_files(user_id))
                elif file_type == "regular":
                    user_files = loop.run_until_complete(db.get_user_regular_pdf_files(user_id))
                else:
                    user_files = loop.run_until_complete(db.get_user_pdf_files(user_id))
            finally:
                loop.close()
            
            if not user_files:
                if file_type == "template":
                    send_message(chat_id, "❌ لا توجد ملفات قوالب للعرض.")
                elif file_type == "regular":
                    send_message(chat_id, "❌ لا توجد ملفات عادية للعرض.")
                else:
                    send_message(chat_id, "❌ لا توجد ملفات للعرض.")
                clear_user_state(user_id)
                return
            
            if file_number < 1 or file_number > len(user_files):
                send_message(chat_id, f"❌ رقم الملف غير صحيح. الرجاء اختيار رقم بين 1 و {len(user_files)}")
                return
            
            # Get the selected file
            selected_file = user_files[file_number - 1]
            old_name = selected_file.get('file_name', '')
            file_url = selected_file.get('file_url', '')
            
            if not old_name:
                send_message(chat_id, "❌ لم يتم العثور على اسم الملف.")
                clear_user_state(user_id)
                return
            
            # Download and send the file first
            send_chat_action(chat_id, 'upload_document')
            processing_msg = send_message(chat_id, "📥 جاري تحميل الملف للمعاينة...")
            
            if file_url:
                # Extract the storage path from full URL
                if '/public/' in file_url:
                    storage_path = file_url.split('/public/')[-1]
                    if storage_path.startswith('pdf-files/'):
                        storage_path = storage_path.replace('pdf-files/', '', 1)
                else:
                    storage_path = file_url.split('/')[-1]
                
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                try:
                    pdf_data = loop.run_until_complete(db.download_pdf_from_storage(storage_path))
                    
                    if pdf_data:
                        # Save temporarily and send
                        temp_pdf_path = os.path.join(TEMP_PDF_DIR, f"temp_preview_{user_id}.pdf")
                        with open(temp_pdf_path, 'wb') as f:
                            f.write(pdf_data)
                        
                        send_document(chat_id, temp_pdf_path, f"📄 معاينة: {old_name}")
                        os.remove(temp_pdf_path)
                finally:
                    loop.close()
            
            if processing_msg:
                delete_message(chat_id, processing_msg)
            
            # Show confirmation with cancel button
            confirm_buttons = [
                [{'text': '✅ نعم، هذا هو الملف الصحيح', 'callback_data': f'confirm_rename_{user_id}'}],
                [{'text': '❌ لا، اختيار ملف آخر', 'callback_data': f'cancel_rename_{user_id}'}],
                [{'text': '🚫 إلغاء العملية', 'callback_data': f'cancel_rename_operation_{user_id}'}]
            ]
            
            send_message(chat_id, f"📝 هل هذا هو الملف الذي تريد تغيير اسمه؟\n\n📄 اسم الملف الحالي: {old_name}", inline_buttons=confirm_buttons)
            
            # Store old name and file type in state
            set_user_state(user_id, 'awaiting_rename_confirmation', {'old_file_name': old_name, 'file_type': file_type})
            
        except ValueError:
            send_message(chat_id, "❌ الرجاء إدخال رقم صحيح.")
        except Exception as e:
            logging.error(f"Error processing file number for rename: {e}")
            send_message(chat_id, f"❌ حدث خطأ: {str(e)}")
            clear_user_state(user_id)
        return

    # Handle AI image generation prompt
    if text and current_state == 'awaiting_ai_generate_prompt':
        try:
            send_chat_action(chat_id, 'upload_photo')
            processing_msg_id = send_progress_update(chat_id, None, 10, "جاري إنشاء الصورة...")
            
            output_path, error = generate_image_gemini(text, chat_id, processing_msg_id, user_id)
            
            if output_path:
                processing_msg_id = send_progress_update(chat_id, processing_msg_id, 100, "اكتمل بنجاح")
                time.sleep(0.5)
                if processing_msg_id:
                    delete_message(chat_id, processing_msg_id)
                
                buttons = [[{'text': '🏠 العودة للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]]
                send_photo(chat_id, output_path, "✅ تم إنشاء الصورة بنجاح!", inline_buttons=buttons)
                os.remove(output_path)
            else:
                if processing_msg_id:
                    delete_message(chat_id, processing_msg_id)
                buttons = [[{'text': '🔄 محاولة مرة أخرى', 'callback_data': 'ai_generate_image'}],
                          [{'text': '🏠 العودة للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]]
                send_message(chat_id, error, inline_buttons=buttons)
            
            clear_user_state(user_id)
        except Exception as e:
            logging.error(f"Error generating AI image: {e}")
            send_message(chat_id, "❌ حدث خطأ أثناء إنشاء الصورة. يرجى المحاولة مرة أخرى.")
            clear_user_state(user_id)
        return

    # Handle AI image edit prompt (after receiving image)
    if text and current_state == 'awaiting_ai_edit_prompt':
        try:
            input_path = state_data.get('input_path')
            if not input_path or not os.path.exists(input_path):
                send_message(chat_id, "❌ لم يتم العثور على الصورة. يرجى إرسالها مرة أخرى.")
                clear_user_state(user_id)
                return
            
            send_chat_action(chat_id, 'upload_photo')
            processing_msg_id = send_progress_update(chat_id, None, 10, "جاري تعديل الصورة...")
            
            output_path, error = edit_image_gemini(input_path, text, chat_id, processing_msg_id, user_id)
            
            if output_path:
                processing_msg_id = send_progress_update(chat_id, processing_msg_id, 100, "اكتمل بنجاح")
                time.sleep(0.5)
                if processing_msg_id:
                    delete_message(chat_id, processing_msg_id)
                
                buttons = [[{'text': '🏠 العودة للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]]
                send_photo(chat_id, output_path, "✅ تم تعديل الصورة بنجاح!", inline_buttons=buttons)
                os.remove(output_path)
            else:
                if processing_msg_id:
                    delete_message(chat_id, processing_msg_id)
                buttons = [[{'text': '🔄 محاولة مرة أخرى', 'callback_data': 'ai_edit_image'}],
                          [{'text': '🏠 العودة للقائمة الرئيسية', 'callback_data': 'back_to_main_menu'}]]
                send_message(chat_id, error, inline_buttons=buttons)
            
            if os.path.exists(input_path):
                os.remove(input_path)
            clear_user_state(user_id)
        except Exception as e:
            logging.error(f"Error editing AI image: {e}")
            send_message(chat_id, "❌ حدث خطأ أثناء تعديل الصورة. يرجى المحاولة مرة أخرى.")
            clear_user_state(user_id)
        return

    # Handle file number input for deletion
    if text and current_state == 'awaiting_file_number_for_delete':
        try:
            file_number = int(text.strip())
            file_type = state_data.get('file_type', 'all')
            
            # Get user files based on type
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                if file_type == "template":
                    user_files = loop.run_until_complete(db.get_user_template_pdf_files(user_id))
                elif file_type == "regular":
                    user_files = loop.run_until_complete(db.get_user_regular_pdf_files(user_id))
                else:
                    user_files = loop.run_until_complete(db.get_user_pdf_files(user_id))
            finally:
                loop.close()
            
            if not user_files:
                if file_type == "template":
                    send_message(chat_id, "❌ لا توجد ملفات قوالب للعرض.")
                elif file_type == "regular":
                    send_message(chat_id, "❌ لا توجد ملفات عادية للعرض.")
                else:
                    send_message(chat_id, "❌ لا توجد ملفات للعرض.")
                clear_user_state(user_id)
                return
            
            if file_number < 1 or file_number > len(user_files):
                send_message(chat_id, f"❌ رقم الملف غير صحيح. الرجاء اختيار رقم بين 1 و {len(user_files)}")
                return
            
            # Get the selected file
            selected_file = user_files[file_number - 1]
            file_name = selected_file.get('file_name', '')
            file_url = selected_file.get('file_url', '')
            
            if not file_name:
                send_message(chat_id, "❌ لم يتم العثور على اسم الملف.")
                clear_user_state(user_id)
                return
            
            # Download and send the file first
            send_chat_action(chat_id, 'upload_document')
            processing_msg = send_message(chat_id, "📥 جاري تحميل الملف للمعاينة...")
            
            if file_url:
                # Extract the storage path from full URL
                if '/public/' in file_url:
                    storage_path = file_url.split('/public/')[-1]
                    if storage_path.startswith('pdf-files/'):
                        storage_path = storage_path.replace('pdf-files/', '', 1)
                else:
                    storage_path = file_url.split('/')[-1]
                
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                try:
                    pdf_data = loop.run_until_complete(db.download_pdf_from_storage(storage_path))
                    
                    if pdf_data:
                        # Save temporarily and send
                        temp_pdf_path = os.path.join(TEMP_PDF_DIR, f"temp_preview_{user_id}.pdf")
                        with open(temp_pdf_path, 'wb') as f:
                            f.write(pdf_data)
                        
                        send_document(chat_id, temp_pdf_path, f"📄 معاينة: {file_name}")
                        os.remove(temp_pdf_path)
                finally:
                    loop.close()
            
            if processing_msg:
                delete_message(chat_id, processing_msg)
            
            # Show confirmation with cancel button
            confirm_buttons = [
                [{'text': '✅ نعم، احذف هذا الملف', 'callback_data': f'confirm_delete_{user_id}'}],
                [{'text': '❌ لا، إلغاء العملية', 'callback_data': f'cancel_delete_{user_id}'}],
                [{'text': '🚫 إلغاء العملية', 'callback_data': f'cancel_delete_operation_{user_id}'}]
            ]
            
            send_message(chat_id, f"🗑️ هل تريد حذف هذا الملف؟\n\n📄 اسم الملف: {file_name}", inline_buttons=confirm_buttons)
            
            # Store file name and file type in state
            set_user_state(user_id, 'awaiting_delete_confirmation', {'file_name': file_name, 'file_type': file_type})
            
        except ValueError:
            send_message(chat_id, "❌ الرجاء إدخال رقم صحيح.")
        except Exception as e:
            logging.error(f"Error processing file number for delete: {e}")
            send_message(chat_id, f"❌ حدث خطأ: {str(e)}")
            clear_user_state(user_id)
        return

    # --- User Service Command Entry Points (existing) ---
    # Handle PDF Section button
    if text == 'قسم الملفات 📄':
        buttons = [
            [{'text': 'مـــــــلــفــات الــصــــــور', 'callback_data': 'pdf_template_files'}],
            [{'text': 'الــمـــلـــفــات الــعــاديـّـة', 'callback_data': 'pdf_regular_files'}],
            [{'text': '♻ قسم التحويل', 'callback_data': 'pdf_conversion_section'}]
        ]
        msg_id = send_message(chat_id, "📄 *قسم الملفات*\n\nاختر النوع الذي تريد العمل معه:", inline_buttons=buttons, parse_mode='Markdown')
        set_user_state(user_id, 'pdf_section', {'menu_mode': get_command_mode(user_id), 'message_id': msg_id})
        return
    
    if text == 'تعديل الصورة ✏️':
        buttons = [
            [{'text': '💫 تبييض وتنعيم', 'callback_data': 'image_edit_whitening'}],
            [{'text': '🤖 تعديل بالذكاء الاصطناعي', 'callback_data': 'image_edit_ai'}]
        ]
        msg_id = send_message(chat_id, "✏️ *تعديل الصورة*\n\nاختر نوع التعديل الذي تريده:", inline_buttons=buttons, parse_mode='Markdown')
        set_user_state(user_id, 'image_edit_menu', {'menu_mode': get_command_mode(user_id), 'message_id': msg_id})
        return
    if text == 'إزالة الخلفية 🖼️':
        set_user_state(user_id, 'remove_bg', {'menu_mode': get_command_mode(user_id)})
        buttons = [
            [{'text': 'إلغاء ✖', 'callback_data': 'cancel_remove_bg'}]
        ]
        send_message(chat_id, "🛠️ أرسل الصورة المراد إزالة خلفيتها:", inline_buttons=buttons)
        return
    if text == 'تحسين الجودة 🪄':
        set_user_state(user_id, 'enhance', {'menu_mode': get_command_mode(user_id)})
        buttons = [
            [{'text': 'إلغاء ✖', 'callback_data': 'cancel_enhance'}]
        ]
        send_message(chat_id, "✨ أرسل الصورة المراد تحسين جودتها:", inline_buttons=buttons)
        return
    if text == 'فراغ أبيض ⬜':
        set_user_state(user_id, 'awaiting_white_space_image', {'menu_mode': get_command_mode(user_id)})
        buttons = [
            [{'text': 'إلغاء ✖', 'callback_data': 'cancel_white_space'}]
        ]
        send_message(chat_id, "⬜ ضفت هذا الزر حتى يفيدكم من واحد يجيبلكم صورة، وتسوولها سكنر، بس الوجه طالع چبير جدا.\n\nأرسل الصورة المراد إضافة فراغ أبيض أعلاها:", inline_buttons=buttons)
        return
    if text == 'توزيع في القالب 🧩':
        # Show template selection with new names and pricing
        template_info = get_template_info()
        
        template_buttons = [
            [{'text': f'{template_info["original"]["name"]} 📷', 'callback_data': 'template_original'}],
            [{'text': f'{template_info["new"]["name"]} 📷', 'callback_data': 'template_new'}],
            [{'text': f'{template_info["multi_person"]["name"]} 👥', 'callback_data': 'template_multi_person'}]
        ]

        # Use custom template message
        template_info_msg = get_template_message_text('regular')

        set_user_state(user_id, 'template_selection', {'menu_mode': get_command_mode(user_id)})
        send_message(chat_id, template_info_msg, inline_buttons=template_buttons, parse_mode='Markdown')
        return
    # Handle Conversion Section button in text buttons mode
    if text == '♻ قسم التحويل':
        set_user_state(user_id, 'pdf_conversion_section', {'menu_mode': get_command_mode(user_id)})
        buttons = [
            [{'text': 'Word ➜ PDF 📄', 'callback_data': 'pdf_to_word_conversion'}],
            [{'text': 'PDF ➜ Picture 🖼️', 'callback_data': 'pdf_to_images_conversion'}],
            [{'text': '⬅️ العودة لقسم PDF', 'callback_data': 'back_to_pdf_section'}]
        ]
        send_message(chat_id, "♻ *قسم التحويل*\n\nاختر نوع التحويل الذي تريده:", inline_buttons=buttons, parse_mode='Markdown')
        return

    if text == 'المعالجة التلقائية 🤖':
        # Show template selection for auto processing with new names
        template_info = get_template_info()
        
        template_buttons = [
            [{'text': f'المعالجة التلقائية - {template_info["original"]["name"]} 🤖', 'callback_data': 'auto_template_original'}],
            [{'text': f'المعالجة التلقائية - {template_info["new"]["name"]} 🤖', 'callback_data': 'auto_template_new'}],
            [{'text': f'المعالجة التلقائية - {template_info["multi_person"]["name"]} 🤖', 'callback_data': 'auto_template_multi_person'}]
        ]

        # Use custom template message for auto processing
        template_info_msg = get_template_message_text('auto')

        set_user_state(user_id, 'auto_template_selection', {'menu_mode': 'buttons'})
        send_message(chat_id, template_info_msg, inline_buttons=template_buttons, parse_mode='Markdown')
        return

    

    # --- Handle Broadcast Messages (Admin only) ---
    if user_id == ADMIN_ID and (current_state == 'admin_awaiting_broadcast_all' or current_state == 'admin_awaiting_broadcast_user'):
        if message:
            process_broadcast_message(chat_id, user_id, message)
            return

    # --- Photo Handling Logic (when a photo is received) (existing) ---
    if photo:
        file_id = photo[-1]['file_id'] # Get the largest photo size available

        # Get file info from Telegram API
        file_info_response_obj = make_request(f"{API_URL}/getFile", method='GET', params={'file_id': file_id}) # Use params
        file_info_response = file_info_response_obj['response']

        if file_info_response_obj['error'] or file_info_response is None or not file_info_response.ok: # Added check for file_info_response being None
            send_message(chat_id, "❌ لم أتمكن من جلب معلومات الملف من تيليجرام. يرجى المحاولة مرة أخرى.")
            logging.error(f"Failed to get file info from Telegram: {file_info_response_obj['error'] or (file_info_response.text if file_info_response else 'No response')}")
            clear_user_state(user_id)
            return

        info = file_info_response.json()
        if not info.get('ok') or 'file_path' not in info.get('result', {}):
            send_message(chat_id, "❌ لم أتمكن من جلب معلومات الملف من تيليجرام. يرجى المحاولة مرة أخرى.")
            logging.error(f"Telegram getFile API error: {info.get('description', 'Unknown error')}")
            clear_user_state(user_id)
            return

        file_path_tg = info['result']['file_path']
        url = f"https://api.telegram.org/file/bot{BOT_TOKEN}/{file_path_tg}"

        extension = os.path.splitext(file_path_tg)[1] or '.jpg'
        input_local_path = os.path.join(TEMP_PDF_DIR, f"temp_input_{user_id}_{uuid.uuid4()}{extension}")

        # Download the image content
        img_content_response_obj = make_request(url, 'GET')
        img_content_response = img_content_response_obj['response']
        if img_content_response_obj['error'] or img_content_response is None or not img_content_response.ok or not img_content_response.content: # Added check for img_content_response being None
            send_message(chat_id, "❌ فشل في تنزيل الصورة من تيليجرام. يرجى المحاولة مرة أخرى.")
            logging.error(f"Failed to download image from Telegram. URL: {url}, HTTP Code: {img_content_response.status_code if img_content_response else 'N/A'}, Error: {img_content_response_obj['error']}")
            clear_user_state(user_id)
            return

        try:
            with open(input_local_path, 'wb') as f:
                f.write(img_content_response.content)
            logging.info(f"Image downloaded to {input_local_path}")
        except IOError as e:
            send_message(chat_id, "❌ فشل في حفظ الصورة مؤقتًا. يرجى المحاولة مرة أخرى.")
            logging.error(f"Failed to write image content to {input_local_path}: {e}")
            clear_user_state(user_id)
            return

        # Save image received time for elapsed time calculation
        current_user_state = get_user_state(user_id)
        current_user_state['data']['image_received_time'] = time.time()
        states = load_user_states()
        states[str(user_id)] = current_user_state
        save_user_states(states)

        processing_message_id = None

        # Process photo based on current user state
        if current_state == 'remove_bg':
            send_chat_action(chat_id, 'typing')
            # Start with progress indicator
            processing_message_id = send_progress_update(chat_id, None, 10, "إزالة الخلفية")
            out = remove_background(input_local_path, REMOVE_BG_KEY_FILE, chat_id, processing_message_id)
            if out:
                # Update to 100% before deleting the message
                processing_message_id = send_progress_update(chat_id, processing_message_id, 100, "اكتمل بنجاح")
                time.sleep(0.5)
                # Delete progress message and send result
                if processing_message_id:
                    delete_message(chat_id, processing_message_id)
                send_photo(chat_id, out, "✅ تمت إزالة الخلفية")
                os.remove(out)
                increment_operation_count('إزالة الخلفية', user_id)
            else:
                # Delete progress message
                if processing_message_id:
                    delete_message(chat_id, processing_message_id)
                send_message(chat_id, "❌ فشل في إزالة الخلفية. قد يكون هناك مشكلة في مفتاح API أو الصورة غير مناسبة.")
            os.remove(input_local_path)
            clear_user_state(user_id)
        elif current_state == 'awaiting_enhance_image_ai':
            send_chat_action(chat_id, 'typing')
            # Start with progress indicator
            processing_message_id = send_progress_update(chat_id, None, 10, "تحسين الجودة بالذكاء الاصطناعي")
            
            # Use Gemini to enhance the image with a specific prompt
            enhance_prompt = "Enhance this image quality to the highest possible resolution. Increase sharpness, clarity, and detail. Improve colors and lighting naturally. Do NOT change any details, objects, or composition of the image - only improve the quality and resolution. Output a high-quality enhanced version of the exact same image."
            
            try:
                result_path, error_msg = edit_image_gemini(input_local_path, enhance_prompt, chat_id, processing_message_id, user_id)
                if result_path:
                    # Update to 100% before deleting the message
                    processing_message_id = send_progress_update(chat_id, processing_message_id, 100, "اكتمل بنجاح")
                    time.sleep(0.5)
                    # Delete progress message
                    if processing_message_id:
                        delete_message(chat_id, processing_message_id)
                    # إضافة زر تحويل إلى PDF تحت الصورة المحسنة
                    convert_button = [
                        [{'text': '📄 تحويل إلى PDF', 'callback_data': f'convert_enhanced_to_pdf_{user_id}'}]
                    ]
                    send_photo(chat_id, result_path, "✅ تم تحسين الجودة بالذكاء الاصطناعي", inline_buttons=convert_button)
                    
                    # حفظ مسار الصورة المحسنة للاستخدام لاحقًا
                    set_user_state(user_id, 'enhanced_image_ready', {'enhanced_path': result_path})
                    increment_operation_count('تحسين الجودة', user_id)
                else:
                    # Delete progress message
                    if processing_message_id:
                        delete_message(chat_id, processing_message_id)
                    error_text = error_msg if error_msg else "❌ فشل في تحسين الجودة بالذكاء الاصطناعي. حاول مرة أخرى أو استخدم Picsart."
                    send_message(chat_id, error_text)
                    clear_user_state(user_id)
            except Exception as e:
                logging.error(f"Error enhancing image with AI: {e}")
                if processing_message_id:
                    delete_message(chat_id, processing_message_id)
                send_message(chat_id, "❌ فشل في تحسين الجودة بالذكاء الاصطناعي. حاول مرة أخرى.")
                clear_user_state(user_id)
            
            if os.path.exists(input_local_path):
                os.remove(input_local_path)
        elif current_state == 'enhance':
            send_chat_action(chat_id, 'typing')
            # Start with progress indicator
            processing_message_id = send_progress_update(chat_id, None, 10, "تحسين الجودة")
            out = enhance_image(input_local_path, PICSART_KEY_FILE, chat_id, processing_message_id)
            if out:
                # Update to 100% before deleting the message
                processing_message_id = send_progress_update(chat_id, processing_message_id, 100, "اكتمل بنجاح")
                time.sleep(0.5)
                # Delete progress message
                if processing_message_id:
                    delete_message(chat_id, processing_message_id)
                # إضافة زر تحويل إلى PDF تحت الصورة المحسنة
                convert_button = [
                    [{'text': '📄 تحويل إلى PDF', 'callback_data': f'convert_enhanced_to_pdf_{user_id}'}]
                ]
                send_photo(chat_id, out, "✅ تم تحسين الجودة", inline_buttons=convert_button)
                
                # حفظ مسار الصورة المحسنة للاستخدام لاحقًا
                set_user_state(user_id, 'enhanced_image_ready', {'enhanced_path': out})
                increment_operation_count('تحسين الجودة', user_id)
            else:
                # Delete progress message
                if processing_message_id:
                    delete_message(chat_id, processing_message_id)
                send_message(chat_id, "❌ فشل في تحسين الجودة. قد يكون هناك مشكلة في مفتاح API أو الصورة غير مناسبة.")
                os.remove(input_local_path)
                clear_user_state(user_id)
            os.remove(input_local_path)
        elif current_state == 'awaiting_whitening_image':
            method_options = [
                [{'text': '🌟 AILabAPI', 'callback_data': f'system_ailab_{user_id}'},
                 {'text': '📦 معالجة محلية', 'callback_data': f'system_pil_{user_id}'}]
            ]
            set_user_state(user_id, 'awaiting_whitening_system', {'input_path': input_local_path})
            send_message(chat_id, "✅ تم استقبال الصورة بنجاح!\n\n🔧 اختر النظام المطلوب:\n\n🌟 AILabAPI: جودة عالية احترافية\n📦 محلي: معالجة سريعة بدون رصيد", inline_buttons=method_options)
        elif current_state == 'whitening':
            user_state = get_user_state(user_id)
            selected_system = user_state.get('data', {}).get('system', 'ailab')
            
            if selected_system == 'pil':
                # Direct to local processing - show whitening degree options for PIL
                whitening_values = [0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4, 1.5]
                degree_options = []
                for i in range(0, len(whitening_values), 3):
                    row = []
                    for j in range(3):
                        if i + j < len(whitening_values):
                            val = whitening_values[i + j]
                            row.append({'text': f'🎨 {val}', 'callback_data': f'whitening_pil_{val}_{user_id}'})
                    if row:
                        degree_options.append(row)
                degree_options.append([{'text': '⏭️ تخطي التبييض', 'callback_data': f'skip_whitening_{user_id}'}])
                set_user_state(user_id, 'awaiting_whitening_degree', {'input_path': input_local_path, 'system': 'pil'})
                send_message(chat_id, "📚 *المكتبة الداخلية*\n\n🎨 اختر درجة التبييض:\n0.4 = خفيف جداً | 1.5 = قوي جداً", inline_buttons=degree_options)
            else:  # ailab
                # Direct to AI processing - show whitening degree options for AILab
                whitening_values = [0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4, 1.5]
                degree_options = []
                for i in range(0, len(whitening_values), 3):
                    row = []
                    for j in range(3):
                        if i + j < len(whitening_values):
                            val = whitening_values[i + j]
                            row.append({'text': f'🎨 {val}', 'callback_data': f'whitening_ailab_{val}_{user_id}'})
                    if row:
                        degree_options.append(row)
                degree_options.append([{'text': '⏭️ تخطي التبييض', 'callback_data': f'skip_whitening_{user_id}'}])
                set_user_state(user_id, 'awaiting_whitening_degree', {'input_path': input_local_path, 'system': 'ailab'})
                send_message(chat_id, "🤖 *الذكاء الاصطناعي*\n\n🎨 اختر درجة التبييض:\n0.7 = خفيف | 1.5 = قوي جداً\n📌 الموصى به: 1.5", inline_buttons=degree_options)
        elif current_state == 'awaiting_ai_edit_image':
            buttons = [
                [{'text': '⬅️ رجوع', 'callback_data': 'image_edit_ai'}],
                [{'text': 'إلغاء ✖', 'callback_data': 'cancel_ai_edit'}]
            ]
            set_user_state(user_id, 'awaiting_ai_edit_prompt', {'input_path': input_local_path})
            send_message(chat_id, "✅ تم استقبال الصورة!\n\nدز الوصف الي تريده، مثلا: اجعل الشخص يرتدي بدلة رسمية، والخ...", inline_buttons=buttons)
        elif current_state == 'awaiting_white_space_image':
            # Show space height options
            space_options = [
                [{'text': '1 سم ⬜', 'callback_data': f'white_space_height_1_{user_id}'}],
                [{'text': '2 سم ⬜', 'callback_data': f'white_space_height_2_{user_id}'}],
                [{'text': '3 سم ⬜', 'callback_data': f'white_space_height_3_{user_id}'}]
            ]
            set_user_state(user_id, 'awaiting_white_space_height', {'input_path': input_local_path})
            send_message(chat_id, "⬜ *اختر حجم الفراغ الأبيض المراد إضافته أعلى الصورة:*", inline_buttons=space_options)
        elif current_state == 'template3x4':
            send_chat_action(chat_id, 'upload_photo')
            # Start with progress indicator
            processing_message_id = send_progress_update(chat_id, None, 10, "إنشاء قالب المعاملات")
            processing_message_id = send_progress_update(chat_id, processing_message_id, 50, "جاري المعالجة")
            out = create_real_3x4_template(input_local_path, user_id)
            if out:
                # Update to 100% before deleting the message
                processing_message_id = send_progress_update(chat_id, processing_message_id, 100, "اكتمل بنجاح")
                time.sleep(0.5)
                # Delete progress message
                if processing_message_id:
                    delete_message(chat_id, processing_message_id)
                send_photo(chat_id, out, "🖼️ قالب المعاملات جاهز (3×4 سم)")
                send_template_png(chat_id, out)
                increment_operation_count('قالب 3x4', user_id)

                # Convert to PDF and send immediately
                send_chat_action(chat_id, 'upload_document')
                # Show PDF conversion progress
                pdf_msg_id = None
                for pdf_prog in [0, 40, 80, 100]:
                    pdf_text = create_progress_indicator(pdf_prog, "📄 جاري تحويل القالب إلى PDF...")
                    if pdf_msg_id:
                        make_request(f"{API_URL}/editMessageText", method='POST',
                                    json_data={'chat_id': chat_id, 'message_id': pdf_msg_id, 'text': pdf_text})
                    else:
                        response = make_request(f"{API_URL}/sendMessage", method='POST',
                                              json_data={'chat_id': chat_id, 'text': pdf_text})
                        if response and response.get('http_code') == 200:
                            pdf_msg_id = response['response'].json().get('result', {}).get('message_id')
                    time.sleep(0.1)
                pdf_processing_msg = pdf_msg_id

                pdf_path = convert_image_to_pdf(out, user_id, dpi=300, max_size_kb=300)

                if pdf_path:
                    file_size_kb = os.path.getsize(pdf_path) / 1024
                    
                    elapsed = get_elapsed_time(user_id)
                    time_str = f"⏱️ الزمن المستغرق: {elapsed:.1f} ثانية" if elapsed else ""
                    
                    caption = f"📄 ملف PDF جاهز!\n🔧 الحجم: {file_size_kb:.1f} كيلوبايت\n⚡ محسّن للحجم والجودة"
                    if time_str:
                        caption += f"\n{time_str}"

                    if send_document(chat_id, pdf_path, caption):
                        if pdf_processing_msg:
                            delete_message(chat_id, pdf_processing_msg)

                        # Now ask if user wants to save to database
                        save_buttons = [
                            [{'text': '💾 نعم، احفظ في قاعدة البيانات', 'callback_data': f'save_to_db_yes_{user_id}'}],
                            [{'text': '❌ لا، شكرًا', 'callback_data': f'save_to_db_no_{user_id}'}]
                        ]

                        ask_message_id = send_message(chat_id, "💾 هل تريد حفظ نسخة من هذا الملف في قاعدة البيانات للوصول إليه لاحقًا؟", inline_buttons=save_buttons)

                        # Store PDF data for potential saving
                        with open(pdf_path, 'rb') as f:
                            pdf_data = f.read()

                        set_user_state(user_id, 'awaiting_db_save_decision', {
                            'pdf_data': pdf_data.hex(),  # Store as hex string
                            'ask_message_id': ask_message_id,
                            'template_path': out,
                            'template_type': '3x4',
                            'image_count': 9
                        })

                        # Clean up PDF file after reading
                        os.remove(pdf_path)
                    else:
                        send_message(chat_id, "❌ فشل في إرسال ملف PDF.")
                        if pdf_processing_msg:
                            delete_message(chat_id, pdf_processing_msg)
                        clear_user_state(user_id)
                else:
                    send_message(chat_id, "❌ فشل في تحويل القالب إلى PDF.")
                    if pdf_processing_msg:
                        delete_message(chat_id, pdf_processing_msg)
                    clear_user_state(user_id)
            else:
                send_message(chat_id, "❌ فشل في إنشاء القالب. يرجى التأكد من أن الصورة واضحة ومناسبة.")
                clear_user_state(user_id)
            os.remove(input_local_path)
        elif current_state in ['multi_person_6x3', 'multi_person_5x4']:
            layout_type = "6x3" if current_state == 'multi_person_6x3' else "5x4"
            photos_received = state_data.get('photos_received', 0)
            photos_needed = state_data.get('photos_needed', 2)
            
            # Store the photo path
            photo_key = f'photo_{photos_received + 1}'
            state_data[photo_key] = input_local_path
            state_data['photos_received'] = photos_received + 1
            
            if photos_received + 1 < photos_needed:
                # Need more photos
                next_photo_num = photos_received + 2
                if layout_type == "6x3":
                    if next_photo_num == 2:
                        send_message(chat_id, f"📸 *تخطيط 6×3 - الصورة الثانية*\n\nأرسل الصورة الثانية (ستتم توزيعها على المواضع الـ3 المتبقية):")
                    else:
                        send_message(chat_id, f"📸 *تخطيط 6×3*\n\nأرسل الصورة رقم {next_photo_num}:")
                else:  # 5x4
                    if next_photo_num == 2:
                        send_message(chat_id, f"📸 *تخطيط 5×4 - الصورة الثانية*\n\nأرسل الصورة الثانية (ستتم توزيعها على المواضع الـ4 المتبقية):")
                    else:
                        send_message(chat_id, f"📸 *تخطيط 5×4*\n\nأرسل الصورة رقم {next_photo_num}:")
                
                set_user_state(user_id, current_state, state_data)
            else:
                # All photos received, create template
                send_chat_action(chat_id, 'upload_photo')
                # Start with progress indicator
                processing_message_id = send_progress_update(chat_id, None, 10, f"إنشاء قالب متعدد ({layout_type})")
                
                # Collect all photo paths
                photo_paths = []
                for i in range(1, photos_needed + 1):
                    photo_path = state_data.get(f'photo_{i}')
                    if photo_path and os.path.exists(photo_path):
                        photo_paths.append(photo_path)
                
                processing_message_id = send_progress_update(chat_id, processing_message_id, 50, "جاري المعالجة")
                # Create template with all photos
                template_path = create_multi_person_template(photo_paths, user_id, layout_type)
                
                if template_path:
                    # Update to 100% before deleting the message
                    processing_message_id = send_progress_update(chat_id, processing_message_id, 100, "اكتمل بنجاح")
                    time.sleep(0.5)
                    # Delete progress message
                    if processing_message_id:
                        delete_message(chat_id, processing_message_id)
                    
                    send_photo(chat_id, template_path, f"🖼️ قالب الأشخاص المتعددين جاهز ({layout_type})")
                    send_template_png(chat_id, template_path)
                    increment_operation_count('قالب متعدد', user_id)

                    # Convert to PDF and send immediately
                    send_chat_action(chat_id, 'upload_document')
                    # Show PDF conversion progress
                    pdf_msg_id = None
                    for pdf_prog in [0, 40, 80, 100]:
                        pdf_text = create_progress_indicator(pdf_prog, "📄 جاري تحويل القالب إلى PDF...")
                        if pdf_msg_id:
                            make_request(f"{API_URL}/editMessageText", method='POST',
                                        json_data={'chat_id': chat_id, 'message_id': pdf_msg_id, 'text': pdf_text})
                        else:
                            response = make_request(f"{API_URL}/sendMessage", method='POST',
                                                  json_data={'chat_id': chat_id, 'text': pdf_text})
                            if response and response.get('http_code') == 200:
                                pdf_msg_id = response['response'].json().get('result', {}).get('message_id')
                        time.sleep(0.1)
                    pdf_processing_msg = pdf_msg_id

                    pdf_path = convert_image_to_pdf(template_path, user_id, dpi=300, max_size_kb=300)

                    if pdf_path:
                        file_size_kb = os.path.getsize(pdf_path) / 1024
                        
                        elapsed = get_elapsed_time(user_id)
                        time_str = f"⏱️ الزمن المستغرق: {elapsed:.1f} ثانية" if elapsed else ""
                        
                        caption = f"📄 ملف PDF جاهز!\n🔧 الحجم: {file_size_kb:.1f} كيلوبايت\n⚡ محسّن للحجم والجودة"
                        if time_str:
                            caption += f"\n{time_str}"

                        if send_document(chat_id, pdf_path, caption):
                            if pdf_processing_msg:
                                delete_message(chat_id, pdf_processing_msg)

                            # Now ask if user wants to save to database
                            save_buttons = [
                                [{'text': '💾 نعم، احفظ في قاعدة البيانات', 'callback_data': f'save_to_db_yes_{user_id}'}],
                                [{'text': '❌ لا، شكرًا', 'callback_data': f'save_to_db_no_{user_id}'}]
                            ]

                            ask_message_id = send_message(chat_id, "💾 هل تريد حفظ نسخة من هذا الملف في قاعدة البيانات للوصول إليه لاحقًا؟", inline_buttons=save_buttons)

                            # Store PDF data for potential saving
                            with open(pdf_path, 'rb') as f:
                                pdf_data = f.read()

                            set_user_state(user_id, 'awaiting_db_save_decision', {
                                'pdf_data': pdf_data.hex(),  # Store as hex string
                                'ask_message_id': ask_message_id,
                                'template_path': template_path,
                                'template_type': layout_type,
                                'image_count': 18 if layout_type == '6x3' else 20
                            })

                            # Clean up PDF file after reading
                            os.remove(pdf_path)
                        else:
                            send_message(chat_id, "❌ فشل في إرسال ملف PDF.")
                            if pdf_processing_msg:
                                delete_message(chat_id, pdf_processing_msg)
                            clear_user_state(user_id)
                    else:
                        send_message(chat_id, "❌ فشل في تحويل القالب إلى PDF.")
                        if pdf_processing_msg:
                            delete_message(chat_id, pdf_processing_msg)
                        clear_user_state(user_id)
                else:
                    send_message(chat_id, "❌ فشل في إنشاء قالب الأشخاص المتعددين. يرجى التأكد من أن الصورة واضحة ومناسبة.")
                    clear_user_state(user_id)
                
                # Clean up photo files
                for i in range(1, photos_needed + 1):
                    photo_path = state_data.get(f'photo_{i}')
                    if photo_path and os.path.exists(photo_path):
                        os.remove(photo_path)
        elif current_state in ['auto_multi_person_6x3', 'auto_multi_person_5x4']:
            layout_type = "6x3" if current_state == 'auto_multi_person_6x3' else "5x4"
            photos_received = state_data.get('photos_received', 0)
            photos_needed = state_data.get('photos_needed', 2)
            
            # Store the photo path
            photo_key = f'photo_{photos_received + 1}'
            state_data[photo_key] = input_local_path
            state_data['photos_received'] = photos_received + 1
            
            if photos_received + 1 < photos_needed:
                # Need more photos
                next_photo_num = photos_received + 2
                if layout_type == "6x3":
                    if next_photo_num == 2:
                        send_message(chat_id, f"🤖 *المعالجة التلقائية - تخطيط 6×3 - الصورة الثانية*\n\nأرسل الصورة الثانية (ستتم معالجتها وتوزيعها على المواضع الـ3 المتبقية):")
                    else:
                        send_message(chat_id, f"🤖 *المعالجة التلقائية - تخطيط 6×3*\n\nأرسل الصورة رقم {next_photo_num}:")
                else:  # 5x4
                    if next_photo_num == 2:
                        send_message(chat_id, f"🤖 *المعالجة التلقائية - تخطيط 5×4 - الصورة الثانية*\n\nأرسل الصورة الثانية (ستتم معالجتها وتوزيعها على المواضع الـ4 المتبقية):")
                    else:
                        send_message(chat_id, f"🤖 *المعالجة التلقائية - تخطيط 5×4*\n\nأرسل الصورة رقم {next_photo_num}:")
                
                set_user_state(user_id, current_state, state_data)
            else:
                # All photos received, process automatically
                send_chat_action(chat_id, 'typing')
                processing_message_id = send_message(chat_id, f"⏳ جاري معالجة الصور تلقائيًا (إزالة الخلفية، تحسين الجودة، إنشاء قالب الأشخاص المتعددين {layout_type})...")

                # Collect all photo paths for multi-person template
                photo_paths = []
                for i in range(1, photos_needed + 1):
                    photo_path = state_data.get(f'photo_{i}')
                    if photo_path and os.path.exists(photo_path):
                        # Process each photo through the auto pipeline
                        temp_removed_bg = remove_background(photo_path, REMOVE_BG_KEY_FILE)
                        if temp_removed_bg:
                            temp_white_bg = composite_on_white_background(temp_removed_bg)
                            os.remove(temp_removed_bg)
                            if temp_white_bg:
                                temp_enhanced = enhance_image(temp_white_bg, PICSART_KEY_FILE)
                                os.remove(temp_white_bg)
                                if temp_enhanced:
                                    photo_paths.append(temp_enhanced)
                        # Clean up original photo file
                        if os.path.exists(photo_path):
                            os.remove(photo_path)
                
                # Check if we have enough photos
                if len(photo_paths) < 2:
                    if processing_message_id:
                        delete_message(chat_id, processing_message_id)
                    send_message(chat_id, f"❌ فشل في معالجة الصور. تم معالجة {len(photo_paths)} صورة فقط من أصل {photos_needed} مطلوبة.\n\nيرجى التأكد من أن الصور واضحة وذات جودة جيدة والمحاولة مرة أخرى.")
                    # Clean up any processed photos
                    for photo_path in photo_paths:
                        if os.path.exists(photo_path):
                            os.remove(photo_path)
                    # Clean up stored photo files
                    for i in range(1, photos_needed + 1):
                        photo_path = state_data.get(f'photo_{i}')
                        if photo_path and os.path.exists(photo_path):
                            os.remove(photo_path)
                    clear_user_state(user_id)
                    return
                
                # Create multi-person template with all processed photos
                template_path = create_multi_person_template(photo_paths, user_id, layout_type)
                
                # Clean up processed photos
                for photo_path in photo_paths:
                    if os.path.exists(photo_path):
                        os.remove(photo_path)

                if not template_path:
                    if processing_message_id:
                        delete_message(chat_id, processing_message_id)
                    send_message(chat_id, "❌ فشل في إنشاء قالب الأشخاص المتعددين. يرجى المحاولة مرة أخرى.")
                    clear_user_state(user_id)
                    return

                if processing_message_id:
                    delete_message(chat_id, processing_message_id)

                send_photo(chat_id, template_path, f"✅ تم معالجة الصور تلقائيًا وإنشاء قالب الأشخاص المتعددين ({layout_type})!")
                send_template_png(chat_id, template_path)
                increment_operation_count('معالجة تلقائية متعدد', user_id)

                # Convert to PDF and send immediately
                send_chat_action(chat_id, 'upload_document')
                # Show PDF conversion progress
                pdf_msg_id = None
                for pdf_prog in [0, 40, 80, 100]:
                    pdf_text = create_progress_indicator(pdf_prog, "📄 جاري تحويل القالب إلى PDF...")
                    if pdf_msg_id:
                        make_request(f"{API_URL}/editMessageText", method='POST',
                                    json_data={'chat_id': chat_id, 'message_id': pdf_msg_id, 'text': pdf_text})
                    else:
                        response = make_request(f"{API_URL}/sendMessage", method='POST',
                                              json_data={'chat_id': chat_id, 'text': pdf_text})
                        if response and response.get('http_code') == 200:
                            pdf_msg_id = response['response'].json().get('result', {}).get('message_id')
                    time.sleep(0.1)
                pdf_processing_msg = pdf_msg_id

                pdf_path = convert_image_to_pdf(template_path, user_id, dpi=300, max_size_kb=300)

                if pdf_path:
                    file_size_kb = os.path.getsize(pdf_path) / 1024
                    pdf_caption = f"📄 ملف PDF جاهز!\n🔧 الحجم: {file_size_kb:.1f} كيلوبايت\n⚡ محسّن للحجم والجودة"

                    if send_document(chat_id, pdf_path, pdf_caption):
                        if pdf_processing_msg:
                            delete_message(chat_id, pdf_processing_msg)

                        # Now ask if user wants to save to database
                        save_buttons = [
                            [{'text': '💾 نعم، احفظ في قاعدة البيانات', 'callback_data': f'save_to_db_yes_{user_id}'}],
                            [{'text': '❌ لا، شكرًا', 'callback_data': f'save_to_db_no_{user_id}'}]
                        ]

                        ask_message_id = send_message(chat_id, "💾 هل تريد حفظ نسخة من هذا الملف في قاعدة البيانات للوصول إليه لاحقًا؟", inline_buttons=save_buttons)

                        # Store PDF data for potential saving
                        with open(pdf_path, 'rb') as f:
                            pdf_data = f.read()

                        set_user_state(user_id, 'awaiting_db_save_decision', {
                            'pdf_data': pdf_data.hex(),  # Store as hex string
                            'ask_message_id': ask_message_id,
                            'template_path': template_path,
                            'template_type': f'multi_{layout_type}',
                            'image_count': 9
                        })

                        # Clean up PDF file after reading
                        os.remove(pdf_path)
                    else:
                        send_message(chat_id, "❌ فشل في إرسال ملف PDF.")
                        if pdf_processing_msg:
                            delete_message(chat_id, pdf_processing_msg)
                        clear_user_state(user_id)
                else:
                    send_message(chat_id, "❌ فشل في تحويل القالب إلى PDF.")
                    if pdf_processing_msg:
                        delete_message(chat_id, pdf_processing_msg)
                    clear_user_state(user_id)
                
                # Clean up photo files
                for i in range(1, photos_needed + 1):
                    photo_path = state_data.get(f'photo_{i}')
                    if photo_path and os.path.exists(photo_path):
                        os.remove(photo_path)
        elif current_state == 'template_new':
            send_chat_action(chat_id, 'upload_photo')
            # Start with progress indicator
            processing_message_id = send_progress_update(chat_id, None, 10, "إنشاء قالب الجوازات")
            processing_message_id = send_progress_update(chat_id, processing_message_id, 50, "جاري المعالجة")
            out = create_new_template(input_local_path, user_id)
            if out:
                # Update to 100% before deleting the message
                processing_message_id = send_progress_update(chat_id, processing_message_id, 100, "اكتمل بنجاح")
                time.sleep(0.5)
                # Delete progress message
                if processing_message_id:
                    delete_message(chat_id, processing_message_id)
                
                send_photo(chat_id, out, "🖼️ قالب الجوازات جاهز (3.5×4.5 سم)")
                send_template_png(chat_id, out)
                increment_operation_count('قالب جديد', user_id)

                # Convert to PDF and send immediately
                send_chat_action(chat_id, 'upload_document')
                # Show PDF conversion progress
                pdf_msg_id = None
                for pdf_prog in [0, 40, 80, 100]:
                    pdf_text = create_progress_indicator(pdf_prog, "📄 جاري تحويل القالب إلى PDF...")
                    if pdf_msg_id:
                        make_request(f"{API_URL}/editMessageText", method='POST',
                                    json_data={'chat_id': chat_id, 'message_id': pdf_msg_id, 'text': pdf_text})
                    else:
                        response = make_request(f"{API_URL}/sendMessage", method='POST',
                                              json_data={'chat_id': chat_id, 'text': pdf_text})
                        if response and response.get('http_code') == 200:
                            pdf_msg_id = response['response'].json().get('result', {}).get('message_id')
                    time.sleep(0.1)
                pdf_processing_msg = pdf_msg_id

                pdf_path = convert_image_to_pdf(out, user_id, dpi=300, max_size_kb=300)

                if pdf_path:
                    file_size_kb = os.path.getsize(pdf_path) / 1024
                    
                    elapsed_pdf = get_elapsed_time(user_id)
                    time_str_pdf = f"⏱️ الزمن المستغرق: {elapsed_pdf:.1f} ثانية" if elapsed_pdf else ""
                    
                    caption = f"📄 ملف PDF جاهز!\n🔧 الحجم: {file_size_kb:.1f} كيلوبايت\n⚡ محسّن للحجم والجودة"
                    if time_str_pdf:
                        caption += f"\n{time_str_pdf}"

                    if send_document(chat_id, pdf_path, caption):
                        if pdf_processing_msg:
                            delete_message(chat_id, pdf_processing_msg)

                        # Now ask if user wants to save to database
                        save_buttons = [
                            [{'text': '💾 نعم، احفظ في قاعدة البيانات', 'callback_data': f'save_to_db_yes_{user_id}'}],
                            [{'text': '❌ لا، شكرًا', 'callback_data': f'save_to_db_no_{user_id}'}]
                        ]

                        ask_message_id = send_message(chat_id, "💾 هل تريد حفظ نسخة من هذا الملف في قاعدة البيانات للوصول إليه لاحقًا؟", inline_buttons=save_buttons)

                        # Store PDF data for potential saving
                        with open(pdf_path, 'rb') as f:
                            pdf_data = f.read()

                        set_user_state(user_id, 'awaiting_db_save_decision', {
                            'pdf_data': pdf_data.hex(),  # Store as hex string
                            'ask_message_id': ask_message_id,
                            'template_path': out,
                            'template_type': '3.5x4.5',
                            'image_count': 6
                        })

                        # Clean up PDF file after reading
                        os.remove(pdf_path)
                    else:
                        send_message(chat_id, "❌ فشل في إرسال ملف PDF.")
                        if pdf_processing_msg:
                            delete_message(chat_id, pdf_processing_msg)
                        clear_user_state(user_id)
                else:
                    send_message(chat_id, "❌ فشل في تحويل القالب إلى PDF.")
                    if pdf_processing_msg:
                        delete_message(chat_id, pdf_processing_msg)
                    clear_user_state(user_id)
            else:
                send_message(chat_id, "❌ فشل في إنشاء القالب. يرجى التأكد من أن الصورة واضحة ومناسبة.")
                clear_user_state(user_id)
            os.remove(input_local_path)
        elif current_state == 'awaiting_images_for_pdf':
            # Handle images for PDF creation
            current_user_state = get_user_state(user_id)
            state_data = current_user_state.get('data', {})
            images = state_data.get('images', [])
            image_count = state_data.get('image_count', 0)
            
            # Add the new image to the list
            images.append(input_local_path)
            image_count += 1
            
            # Calculate total size of all images
            total_size_bytes = sum(os.path.getsize(img_path) for img_path in images if os.path.exists(img_path))
            total_size_kb = total_size_bytes / 1024
            
            # Update state
            set_user_state(user_id, 'awaiting_images_for_pdf', {
                'images': images,
                'image_count': image_count
            })
            
            # Show progress and options with actual size
            progress_message = f"📸 تم استلام {image_count} صورة\n📊 الحجم الفعلي: {total_size_kb:.1f} كيلوبايت\n\n"
            
            buttons = [
                [{'text': '📄 إنشاء PDF الآن', 'callback_data': f'create_pdf_now_{user_id}'}],
                [{'text': '➕ إضافة المزيد', 'callback_data': f'add_more_images_{user_id}'}],
                [{'text': '✖ إلغاء', 'callback_data': f'cancel_pdf_creation_{user_id}'}]
            ]
            
            send_message(chat_id, progress_message, inline_buttons=buttons)
            return
            
        elif current_state == 'template_selection':
            # Handle photos sent while in template selection state
            send_message(chat_id, "⚠️ الرجاء اختيار نوع القالب أولًا من الأزرار أعلاه، ثم أرسل الصورة.")
            os.remove(input_local_path)
            return
        elif current_state in ['auto_process_original', 'auto_process_new', 'auto_template_selection']:
            if current_state == 'auto_template_selection':
                # Handle photos sent while in template selection state
                send_message(chat_id, "⚠️ الرجاء اختيار نوع القالب أولًا من الأزرار أعلاه، ثم أرسل الصورة.")
                os.remove(input_local_path)
                return

            if os.path.getsize(input_local_path) > 5 * 1024 * 1024:
                send_message(chat_id, "❌ الصورة كبيرة جدًا. الحد الأقصى لحجم الصورة هو 5 ميجابايت.")
                os.remove(input_local_path)
                clear_user_state(user_id)
                return

            mime_type, _ = mimetypes.guess_type(input_local_path)
            if not mime_type or not mime_type.startswith('image/'):
                send_message(chat_id, "❌ الملف الذي أرسلته ليس صورة. الرجاء إرسال صورة صالحة.")
                os.remove(input_local_path)
                clear_user_state(user_id)
                return

            # Determine template type
            is_new_template = current_state == 'auto_process_new'
            template_name = "الجوازات" if is_new_template else "المعاملات"
            
            # بدء حساب الزمن المستغرق
            auto_start_time = time.time()

            send_chat_action(chat_id, 'typing')
            # Show auto processing progress with special indicator
            processing_message_id = None
            for auto_prog in [0, 10, 20]:
                auto_text = create_auto_processing_indicator(auto_prog, f"🤖 جاري المعالجة التلقائية - إزالة الخلفية...")
                if processing_message_id:
                    make_request(f"{API_URL}/editMessageText", method='POST',
                                json_data={'chat_id': chat_id, 'message_id': processing_message_id, 'text': auto_text})
                else:
                    response = make_request(f"{API_URL}/sendMessage", method='POST',
                                          json_data={'chat_id': chat_id, 'text': auto_text})
                    if response and response.get('http_code') == 200:
                        processing_message_id = response['response'].json().get('result', {}).get('message_id')
                time.sleep(0.2)

            removed_bg_path = remove_background(input_local_path, REMOVE_BG_KEY_FILE)
            os.remove(input_local_path)

            if not removed_bg_path:
                if processing_message_id:
                    delete_message(chat_id, processing_message_id)
                send_message(chat_id, "❌ فشل في إزالة الخلفية. يرجى المحاولة مرة أخرى.")
                clear_user_state(user_id)
                return

            # Update progress
            if processing_message_id:
                for auto_prog in [40, 50]:
                    auto_text = create_auto_processing_indicator(auto_prog, f"🤖 جاري المعالجة التلقائية - إعداد الخلفية...")
                    make_request(f"{API_URL}/editMessageText", method='POST',
                                json_data={'chat_id': chat_id, 'message_id': processing_message_id, 'text': auto_text})
                    time.sleep(0.15)
            
            white_bg_path = composite_on_white_background(removed_bg_path)
            os.remove(removed_bg_path)

            if not white_bg_path:
                if processing_message_id:
                    delete_message(chat_id, processing_message_id)
                send_message(chat_id, "❌ فشل في إعداد الصورة للخلفية البيضاء. يرجى المحاولة مرة أخرى.")
                clear_user_state(user_id)
                return

            # Update progress
            if processing_message_id:
                for auto_prog in [60, 70]:
                    auto_text = create_auto_processing_indicator(auto_prog, f"🤖 جاري المعالجة التلقائية - تحسين الجودة...")
                    make_request(f"{API_URL}/editMessageText", method='POST',
                                json_data={'chat_id': chat_id, 'message_id': processing_message_id, 'text': auto_text})
                    time.sleep(0.15)
            
            enhanced_path = enhance_image(white_bg_path, PICSART_KEY_FILE)
            os.remove(white_bg_path)

            if not enhanced_path:
                if processing_message_id:
                    delete_message(chat_id, processing_message_id)
                send_message(chat_id, "❌ فشل في تحسين الجودة. يرجى المحاولة مرة أخرى.")
                clear_user_state(user_id)
                return

            # Update progress
            if processing_message_id:
                for auto_prog in [85, 95, 100]:
                    auto_text = create_auto_processing_indicator(auto_prog, f"🤖 جاري المعالجة التلقائية - إنشاء القالب...")
                    make_request(f"{API_URL}/editMessageText", method='POST',
                                json_data={'chat_id': chat_id, 'message_id': processing_message_id, 'text': auto_text})
                    time.sleep(0.15)
            
            # Create template based on selection
            if is_new_template:
                template_path = create_new_template(enhanced_path, user_id)
                caption = "✅ تم معالجة الصورة تلقائيًا وإنشاء قالب الجوازات (3.5×4.5 سم)!"
                template_type = '3.5x4.5'
                image_count = 6
            else:
                template_path = create_real_3x4_template(enhanced_path, user_id)
                caption = "✅ تم معالجة الصورة تلقائيًا وإنشاء قالب المعاملات (3×4 سم)!"
                template_type = '3x4'
                image_count = 9

            os.remove(enhanced_path)

            if not template_path:
                if processing_message_id:
                    delete_message(chat_id, processing_message_id)
                send_message(chat_id, "❌ فشل في إنشاء القالب. يرجى المحاولة مرة أخرى.")
                clear_user_state(user_id)
                return

            if processing_message_id:
                delete_message(chat_id, processing_message_id)

            send_photo(chat_id, template_path, caption)
            send_template_png(chat_id, template_path)
            increment_operation_count('معالجة تلقائية', user_id)

            # Convert to PDF and send immediately
            send_chat_action(chat_id, 'upload_document')
            # Show PDF conversion progress with special indicator
            pdf_msg_id = None
            for pdf_prog in [0, 50, 100]:
                pdf_text = create_auto_processing_indicator(pdf_prog, "📄 جاري تحويل القالب إلى PDF...")
                if pdf_msg_id:
                    make_request(f"{API_URL}/editMessageText", method='POST',
                                json_data={'chat_id': chat_id, 'message_id': pdf_msg_id, 'text': pdf_text})
                else:
                    response = make_request(f"{API_URL}/sendMessage", method='POST',
                                          json_data={'chat_id': chat_id, 'text': pdf_text})
                    if response and response.get('http_code') == 200:
                        pdf_msg_id = response['response'].json().get('result', {}).get('message_id')
                time.sleep(0.15)
            pdf_processing_msg = pdf_msg_id

            pdf_path = convert_image_to_pdf(template_path, user_id, dpi=300, max_size_kb=300)

            if pdf_path:
                file_size_kb = os.path.getsize(pdf_path) / 1024
                # حساب الزمن المستغرق
                elapsed_time = time.time() - auto_start_time
                time_str = f"⏱️ الزمن المستغرق: {elapsed_time:.1f} ثانية"
                pdf_caption = f"📄 ملف PDF جاهز!\n🔧 الحجم: {file_size_kb:.1f} كيلوبايت\n⚡ محسّن للحجم والجودة\n{time_str}"

                if send_document(chat_id, pdf_path, pdf_caption):
                    if pdf_processing_msg:
                        delete_message(chat_id, pdf_processing_msg)

                    # Now ask if user wants to save to database
                    save_buttons = [
                        [{'text': '💾 نعم، احفظ في قاعدة البيانات', 'callback_data': f'save_to_db_yes_{user_id}'}],
                        [{'text': '❌ لا، شكرًا', 'callback_data': f'save_to_db_no_{user_id}'}]
                    ]

                    ask_message_id = send_message(chat_id, "💾 هل تريد حفظ نسخة من هذا الملف في قاعدة البيانات للوصول إليه لاحقًا؟", inline_buttons=save_buttons)

                    # Store PDF data for potential saving
                    with open(pdf_path, 'rb') as f:
                        pdf_data = f.read()

                    set_user_state(user_id, 'awaiting_db_save_decision', {
                        'pdf_data': pdf_data.hex(),  # Store as hex string
                        'ask_message_id': ask_message_id,
                        'template_path': template_path,
                        'template_type': template_type,
                        'image_count': image_count
                    })

                    # Clean up PDF file after reading
                    os.remove(pdf_path)
                else:
                    send_message(chat_id, "❌ فشل في إرسال ملف PDF.")
                    if pdf_processing_msg:
                        delete_message(chat_id, pdf_processing_msg)
                    clear_user_state(user_id)
            else:
                send_message(chat_id, "❌ فشل في تحويل القالب إلى PDF.")
                if pdf_processing_msg:
                    delete_message(chat_id, pdf_processing_msg)
                clear_user_state(user_id)
        else:
            send_message(chat_id, "🤔 أرسلت صورة في غير وقتها. الرجاء اختيار الخدمة أولًا من القائمة أو استخدام /start.")
            os.remove(input_local_path)
            clear_user_state(user_id)

        if processing_message_id:
            delete_message(chat_id, processing_message_id)
        return

    # --- Handle Document Upload for PDF Backup Restoration ---
    if document and current_state == 'awaiting_pdf_backup_file' and user_id == ADMIN_ID:
        # Delete user's document input message
        if current_message_id:
            delete_message(chat_id, current_message_id)

        if document['mime_type'] != 'application/zip':
            send_message(chat_id, "❌ الرجاء إرسال ملف ZIP فقط للنسخة الاحتياطية.")
            clear_user_state(user_id)
            return

        file_id = document['file_id']
        file_info_response_obj = make_request(f"{API_URL}/getFile", method='GET', params={'file_id': file_id})
        file_info_response = file_info_response_obj['response']

        if file_info_response_obj['error'] or file_info_response is None or not file_info_response.ok:
            send_message(chat_id, "❌ لم أتمكن من جلب معلومات الملف من تيليجرام. يرجى المحاولة مرة أخرى.")
            logging.error(f"Failed to get file info for PDF backup restore from Telegram: {file_info_response_obj['error'] or (file_info_response.text if file_info_response else 'No response')}")
            clear_user_state(user_id)
            return

        info = file_info_response.json()
        if not info.get('ok') or 'file_path' not in info.get('result', {}):
            send_message(chat_id, "❌ لم أتمكن من جلب معلومات الملف من تيليجرام. يرجى المحاولة مرة أخرى.")
            logging.error(f"Telegram getFile API error for PDF backup restore: {info.get('description', 'Unknown error')}")
            clear_user_state(user_id)
            return

        file_path_tg = info['result']['file_path']
        url = f"https://api.telegram.org/file/bot{BOT_TOKEN}/{file_path_tg}"

        backup_local_path = f"pdf_backup_{uuid.uuid4()}.zip"

        file_content_response_obj = make_request(url, 'GET')
        file_content_response = file_content_response_obj['response']
        if file_content_response_obj['error'] or file_content_response is None or not file_content_response.ok or not file_content_response.content:
            send_message(chat_id, "❌ فشل في تنزيل ملف النسخة الاحتياطية. يرجى المحاولة مرة أخرى.")
            logging.error(f"Failed to download PDF backup file from Telegram. URL: {url}, HTTP Code: {file_content_response.status_code if file_content_response else 'N/A'}, Error: {file_content_response_obj['error']}")
            clear_user_state(user_id)
            return

        try:
            with open(backup_local_path, 'wb') as f:
                f.write(file_content_response.content)
            logging.info(f"PDF backup file downloaded to {backup_local_path}")
        except IOError as e:
            send_message(chat_id, "❌ فشل في حفظ ملف النسخة الاحتياطية مؤقتًا. يرجى المحاولة مرة أخرى.")
            logging.error(f"Failed to write PDF backup content to {backup_local_path}: {e}")
            clear_user_state(user_id)
            return

        send_message(chat_id, "⏳ جاري استعادة ملفات PDF من النسخة الاحتياطية...")

        try:
            # استخدام asyncio لتشغيل الدالة غير المتزامنة
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            success, report = loop.run_until_complete(restore_pdf_backup(backup_local_path))
            loop.close()
            
            if success:
                send_message(chat_id, f"✅ تم استعادة النسخة الاحتياطية بنجاح!\n\n{report}")
            else:
                send_message(chat_id, f"❌ فشل في استعادة النسخة الاحتياطية.\n\n{report}")
        except Exception as e:
            logging.error(f"Error restoring PDF backup: {e}")
            send_message(chat_id, f"❌ حدث خطأ أثناء استعادة النسخة الاحتياطية: {str(e)}")

        os.remove(backup_local_path)
        clear_user_state(user_id)
        # After restoration, return admin to database menu
        show_admin_database_menu(chat_id, user_id, admin_message_id)
        return

    # --- Handle Document Upload for PDF Storage ---
    if document and current_state == 'awaiting_pdf_file':
        # Delete user's document input message
        if current_message_id:
            delete_message(chat_id, current_message_id)

        if document['mime_type'] != 'application/pdf':
            send_message(chat_id, "❌ الرجاء إرسال ملف PDF فقط.")
            clear_user_state(user_id)
            return

        file_id = document['file_id']
        file_name = document.get('file_name', f'document_{uuid.uuid4()}.pdf')
        
        # Get file info from Telegram
        file_info_response_obj = make_request(f"{API_URL}/getFile", method='GET', params={'file_id': file_id})
        file_info_response = file_info_response_obj['response']

        if file_info_response_obj['error'] or file_info_response is None or not file_info_response.ok:
            send_message(chat_id, "❌ لم أتمكن من جلب معلومات الملف من تيليجرام. يرجى المحاولة مرة أخرى.")
            logging.error(f"Failed to get file info for PDF storage from Telegram: {file_info_response_obj['error'] or (file_info_response.text if file_info_response else 'No response')}")
            clear_user_state(user_id)
            return

        info = file_info_response.json()
        if not info.get('ok') or 'file_path' not in info.get('result', {}):
            send_message(chat_id, "❌ لم أتمكن من جلب معلومات الملف من تيليجرام. يرجى المحاولة مرة أخرى.")
            logging.error(f"Telegram getFile API error for PDF storage: {info.get('description', 'Unknown error')}")
            clear_user_state(user_id)
            return

        file_path_tg = info['result']['file_path']
        url = f"https://api.telegram.org/file/bot{BOT_TOKEN}/{file_path_tg}"

        pdf_local_path = os.path.join(TEMP_PDF_DIR, f"temp_pdf_{user_id}_{uuid.uuid4()}.pdf")

        # Download the PDF file
        file_content_response_obj = make_request(url, 'GET')
        file_content_response = file_content_response_obj['response']
        if file_content_response_obj['error'] or file_content_response is None or not file_content_response.ok or not file_content_response.content:
            send_message(chat_id, "❌ فشل في تنزيل ملف PDF. يرجى المحاولة مرة أخرى.")
            logging.error(f"Failed to download PDF file from Telegram. URL: {url}, HTTP Code: {file_content_response.status_code if file_content_response else 'N/A'}, Error: {file_content_response_obj['error']}")
            clear_user_state(user_id)
            return

        try:
            # Save PDF file temporarily
            with open(pdf_local_path, 'wb') as f:
                f.write(file_content_response.content)
            logging.info(f"PDF file downloaded to {pdf_local_path}")
        except IOError as e:
            send_message(chat_id, "❌ فشل في حفظ ملف PDF مؤقتًا. يرجى المحاولة مرة أخرى.")
            logging.error(f"Failed to write PDF content to {pdf_local_path}: {e}")
            clear_user_state(user_id)
            return

        send_message(chat_id, "⏳ جاري حفظ ملف PDF في قاعدة البيانات...")

        try:
            # Read PDF data
            with open(pdf_local_path, 'rb') as f:
                pdf_data = f.read()
            
            # Remove .pdf extension from file name if present
            clean_file_name = file_name
            if clean_file_name.endswith('.pdf'):
                clean_file_name = clean_file_name[:-4]
            
            # Upload to Supabase Storage
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                file_url = loop.run_until_complete(db.upload_pdf_to_storage(f"{clean_file_name}.pdf", pdf_data))

                if file_url:
                    # Save file info to database
                    success = loop.run_until_complete(db.save_pdf_file(user_id, clean_file_name, file_url))

                    if success:
                        file_size_kb = len(pdf_data) / 1024
                        send_message(chat_id, f"✅ تم حفظ الملف في قاعدة البيانات بنجاح!\n\n📝 الاسم: {clean_file_name}\n🔧 الحجم: {file_size_kb:.1f} كيلوبايت\n🔍 يمكنك البحث عنه لاحقًا باستخدام زر 'البحث في ملفات PDF'")
                    else:
                        send_message(chat_id, "❌ فشل في حفظ معلومات الملف في قاعدة البيانات.")
                else:
                    send_message(chat_id, "❌ فشل في رفع الملف إلى التخزين السحابي.")
            finally:
                loop.close()

            # Clean up temporary file
            os.remove(pdf_local_path)
            clear_user_state(user_id)

        except Exception as e:
            logging.error(f"Error saving PDF to database: {e}")
            send_message(chat_id, f"❌ حدث خطأ أثناء حفظ الملف: {str(e)}")
            if os.path.exists(pdf_local_path):
                os.remove(pdf_local_path)
            clear_user_state(user_id)

        return
    
    # --- Handle Template PDF Upload ---
    if document and current_state == 'awaiting_template_pdf_upload':
        # Delete user's document input message
        if current_message_id:
            delete_message(chat_id, current_message_id)
        
        if document['mime_type'] != 'application/pdf':
            send_message(chat_id, "❌ الرجاء إرسال ملف PDF فقط.")
            clear_user_state(user_id)
            return
        
        file_id = document['file_id']
        file_name = document.get('file_name', f'template_{uuid.uuid4()}.pdf')
        
        file_info_response_obj = make_request(f"{API_URL}/getFile", method='GET', params={'file_id': file_id})
        file_info_response = file_info_response_obj['response']
        
        if file_info_response_obj['error'] or file_info_response is None or not file_info_response.ok:
            send_message(chat_id, "❌ لم أتمكن من جلب معلومات الملف من تيليجرام. يرجى المحاولة مرة أخرى.")
            logging.error(f"Failed to get file info from Telegram: {file_info_response_obj['error']}")
            clear_user_state(user_id)
            return
        
        info = file_info_response.json()
        if not info.get('ok') or 'file_path' not in info.get('result', {}):
            send_message(chat_id, "❌ لم أتمكن من جلب معلومات الملف من تيليجرام. يرجى المحاولة مرة أخرى.")
            logging.error(f"Telegram getFile API error: {info.get('description', 'Unknown error')}")
            clear_user_state(user_id)
            return
        
        file_path_tg = info['result']['file_path']
        url = f"https://api.telegram.org/file/bot{BOT_TOKEN}/{file_path_tg}"
        
        pdf_local_path = os.path.join(TEMP_PDF_DIR, f"template_upload_{uuid.uuid4()}.pdf")
        
        file_content_response_obj = make_request(url, 'GET')
        file_content_response = file_content_response_obj['response']
        if file_content_response_obj['error'] or file_content_response is None or not file_content_response.ok:
            send_message(chat_id, "❌ فشل في تنزيل الملف. يرجى المحاولة مرة أخرى.")
            logging.error(f"Failed to download PDF from Telegram. URL: {url}")
            clear_user_state(user_id)
            return
        
        try:
            with open(pdf_local_path, 'wb') as f:
                f.write(file_content_response.content)
            logging.info(f"Template PDF downloaded to {pdf_local_path}")
        except IOError as e:
            send_message(chat_id, "❌ فشل في حفظ الملف مؤقتًا. يرجى المحاولة مرة أخرى.")
            logging.error(f"Failed to write PDF content to {pdf_local_path}: {e}")
            clear_user_state(user_id)
            return
        
        send_message(chat_id, "⏳ جاري حفظ ملف القالب في قاعدة البيانات...")
        
        try:
            # Read PDF data
            with open(pdf_local_path, 'rb') as f:
                pdf_data = f.read()
            
            # Remove .pdf extension from file name if present
            clean_file_name = file_name
            if clean_file_name.endswith('.pdf'):
                clean_file_name = clean_file_name[:-4]
            
            # Upload to Supabase Storage
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                file_url = loop.run_until_complete(db.upload_pdf_to_storage(f"{clean_file_name}.pdf", pdf_data))
                
                if file_url:
                    # Save file info to database as template
                    success = loop.run_until_complete(db.save_template_pdf_file(user_id, clean_file_name, file_url, template_type="uploaded"))
                    
                    if success:
                        file_size_kb = len(pdf_data) / 1024
                        send_message(chat_id, f"✅ تم حفظ القالب في قاعدة البيانات بنجاح!\n\n📝 الاسم: {clean_file_name}\n🔧 الحجم: {file_size_kb:.1f} كيلوبايت\n🔍 يمكنك الوصول إليه من قسم 'ملفات الصور'")
                    else:
                        send_message(chat_id, "❌ فشل في حفظ معلومات القالب في قاعدة البيانات.")
                else:
                    send_message(chat_id, "❌ فشل في رفع الملف إلى التخزين السحابي.")
            finally:
                loop.close()
            
            # Clean up temporary file
            os.remove(pdf_local_path)
            clear_user_state(user_id)
        
        except Exception as e:
            logging.error(f"Error saving template PDF to database: {e}")
            send_message(chat_id, f"❌ حدث خطأ أثناء حفظ القالب: {str(e)}")
            if os.path.exists(pdf_local_path):
                os.remove(pdf_local_path)
            clear_user_state(user_id)
        
        return

    # --- Handle Document Upload for Backup Restoration (existing) ---
    if document and current_state == 'awaiting_backup_file' and user_id == ADMIN_ID:
        # Delete user's document input message
        if current_message_id:
            delete_message(chat_id, current_message_id)

        if document['mime_type'] != 'application/zip':
            send_message(chat_id, "❌ الرجاء إرسال ملف ZIP فقط للنسخة الاحتياطية.")
            clear_user_state(user_id)
            return

        file_id = document['file_id']
        file_info_response_obj = make_request(f"{API_URL}/getFile", method='GET', params={'file_id': file_id}) # Use params
        file_info_response = file_info_response_obj['response']

        if file_info_response_obj['error'] or file_info_response is None or not file_info_response.ok: # Added check for file_info_response being None
            send_message(chat_id, "❌ لم أتمكن من جلب معلومات الملف من تيليجرام. يرجى المحاولة مرة أخرى.")
            logging.error(f"Failed to get file info for backup restore from Telegram: {file_info_response_obj['error'] or (file_info_response.text if file_info_response else 'No response')}")
            clear_user_state(user_id)
            return

        info = file_info_response.json()
        if not info.get('ok') or 'file_path' not in info.get('result', {}):
            send_message(chat_id, "❌ لم أتمكن من جلب معلومات الملف من تيليجرام. يرجى المحاولة مرة أخرى.")
            logging.error(f"Telegram getFile API error for backup restore: {info.get('description', 'Unknown error')}")
            clear_user_state(user_id)
            return

        file_path_tg = info['result']['file_path']
        url = f"https://api.telegram.org/file/bot{BOT_TOKEN}/{file_path_tg}"

        backup_local_path = f"uploaded_backup_{uuid.uuid4()}.zip"

        file_content_response_obj = make_request(url, 'GET')
        file_content_response = file_content_response_obj['response']
        if file_content_response_obj['error'] or file_content_response is None or not file_content_response.ok or not file_content_response.content: # Added check for file_content_response being None
            send_message(chat_id, "❌ فشل في تنزيل ملف النسخة الاحتياطية. يرجى المحاولة مرة أخرى.")
            logging.error(f"Failed to download backup file from Telegram. URL: {url}, HTTP Code: {file_content_response.status_code if file_content_response else 'N/A'}, Error: {file_content_response_obj['error']}")
            clear_user_state(user_id)
            return

        try:
            with open(backup_local_path, 'wb') as f:
                f.write(file_content_response.content)
            logging.info(f"Backup file downloaded to {backup_local_path}")
        except IOError as e:
            send_message(chat_id, "❌ فشل في حفظ ملف النسخة الاحتياطية مؤقتًا. يرجى المحاولة مرة أخرى.")
            logging.error(f"Failed to write backup content to {backup_local_path}: {e}")
            clear_user_state(user_id)
            return

        send_message(chat_id, "⏳ جاري استعادة البيانات من النسخة الاحتياطية...")

        if restore_from_backup(backup_local_path):
            send_message(chat_id, "✅ تم استعادة البيانات بنجاح! قد تحتاج لإعادة تشغيل البوت لتطبيق التغييرات.")
        else:
            send_message(chat_id, "❌ فشل في استعادة البيانات من النسخة الاحتياطية. يرجى التأكد من أن الملف سليم.")

        os.remove(backup_local_path)
        clear_user_state(user_id)
        # After restoration, return admin to backup menu
        show_admin_backup_menu(chat_id, user_id, admin_message_id)
        return

    # --- Handle Word to PDF Conversion (Sequential Queue) ---
    if document and current_state == 'awaiting_docx_for_pdf_conversion':
        # Delete user's document input message
        if current_message_id:
            delete_message(chat_id, current_message_id)

        # Check file extension instead of MIME type for more compatibility
        file_name_check = document.get('file_name', '').lower()
        if not (file_name_check.endswith('.docx') or file_name_check.endswith('.doc')):
            send_message(chat_id, "❌ الرجاء إرسال ملف وورد (DOCX أو DOC) فقط.")
            return

        file_id = document['file_id']
        file_name = document.get('file_name', f'document_{uuid.uuid4()}.docx')
        
        # Get file info from Telegram
        file_info_response_obj = make_request(f"{API_URL}/getFile", method='GET', params={'file_id': file_id})
        file_info_response = file_info_response_obj['response']

        if file_info_response_obj['error'] or file_info_response is None or not file_info_response.ok:
            send_message(chat_id, "❌ لم أتمكن من جلب معلومات الملف من تيليجرام.")
            clear_user_state(user_id)
            return

        info = file_info_response.json()
        if not info.get('ok') or 'file_path' not in info.get('result', {}):
            send_message(chat_id, "❌ لم أتمكن من جلب معلومات الملف من تيليجرام.")
            clear_user_state(user_id)
            return

        file_path_tg = info['result']['file_path']
        url = f"https://api.telegram.org/file/bot{BOT_TOKEN}/{file_path_tg}"

        docx_local_path = os.path.join(WORD_FILES_DIR, f"temp_docx_{uuid.uuid4()}.docx")

        # Download the DOCX file
        file_content_response_obj = make_request(url, 'GET')
        file_content_response = file_content_response_obj['response']
        if file_content_response_obj['error'] or file_content_response is None or not file_content_response.ok:
            send_message(chat_id, "❌ فشل في تنزيل ملف وورد.")
            clear_user_state(user_id)
            return

        try:
            with open(docx_local_path, 'wb') as f:
                f.write(file_content_response.content)
            logging.info(f"DOCX file downloaded to {docx_local_path}, size: {len(file_content_response.content)} bytes")
            
            # Verify the downloaded content is not an error page or empty
            if len(file_content_response.content) < 1000:  # DOCX files are typically > 1KB
                logging.warning(f"Downloaded file suspiciously small: {len(file_content_response.content)} bytes")
                # Check if it's HTML error page
                content_str = file_content_response.content.decode('utf-8', errors='ignore')
                if '<html' in content_str.lower() or 'error' in content_str.lower():
                    send_message(chat_id, "❌ حدث خطأ في تنزيل الملف من تيليجرام. الرجاء محاولة إرسال الملف مرة أخرى.")
                    logging.error(f"Downloaded content appears to be error page: {content_str[:200]}")
                    clear_user_state(user_id)
                    return
        except IOError as e:
            send_message(chat_id, "❌ فشل في حفظ الملف مؤقتًا.")
            logging.error(f"Failed to write DOCX: {e}")
            clear_user_state(user_id)
            return

        # أضف الملف للقائمة المؤقتة (لم نبدأ التحويل بعد)
        if chat_id not in pending_docx_files:
            pending_docx_files[chat_id] = []
        
        pending_docx_files[chat_id].append((docx_local_path, file_name))
        file_count = len(pending_docx_files[chat_id])
        
        file_count_text = "ملف واحد" if file_count == 1 else f"{file_count} ملفات"
        
        # بناء الرسالة
        message_text = f"📥 تم استقبال {file_count_text}\n\n"
        message_text += f"📝 الملفات المستقبلة:\n"
        for i, (_, fname) in enumerate(pending_docx_files[chat_id], 1):
            message_text += f"  {i}. {fname}\n"
        message_text += f"\n❓ هل تريد:\n• تحويل هذا الملف فقط؟\n• أم سترسل ملفات أخرى؟"
        
        buttons = [
            [{'text': '🚀 بدء التحويل', 'callback_data': f'start_docx_conversion_{chat_id}'}],
            [{'text': '➕ إضافة ملفات أخرى', 'callback_data': 'continue_docx_upload'}]
        ]
        
        # احصل على معرف الرسالة السابقة
        previous_msg_id = pending_docx_message_ids.get(chat_id)
        
        # استخدم send_message مع message_id للتعديل التلقائي
        msg_id = send_message(chat_id, message_text, inline_buttons=buttons, message_id=previous_msg_id)
        
        if msg_id:
            pending_docx_message_ids[chat_id] = msg_id
            if previous_msg_id and msg_id == previous_msg_id:
                logging.info(f"✏️ Updated DOCX message {msg_id} for chat {chat_id} (total: {file_count})")
            else:
                logging.info(f"📨 Created DOCX message {msg_id} for chat {chat_id} (total: {file_count})")
        else:
            logging.error(f"❌ Failed to send/edit DOCX message for chat {chat_id}")
        
        return

    # --- Handle PDF to Images Conversion - Initial File Reception ---
    if document and current_state == 'awaiting_pdf_for_images_conversion':
        # Delete user's document input message
        if current_message_id:
            delete_message(chat_id, current_message_id)

        if document['mime_type'] != 'application/pdf':
            send_message(chat_id, "❌ الرجاء إرسال ملف PDF فقط.")
            return

        file_id = document['file_id']
        file_name = document.get('file_name', f'document_{uuid.uuid4()}.pdf')
        
        # Get file info from Telegram
        file_info_response_obj = make_request(f"{API_URL}/getFile", method='GET', params={'file_id': file_id})
        file_info_response = file_info_response_obj['response']

        if file_info_response_obj['error'] or file_info_response is None or not file_info_response.ok:
            send_message(chat_id, "❌ لم أتمكن من جلب معلومات الملف من تيليجرام.")
            clear_user_state(user_id)
            return

        info = file_info_response.json()
        if not info.get('ok') or 'file_path' not in info.get('result', {}):
            send_message(chat_id, "❌ لم أتمكن من جلب معلومات الملف من تيليجرام.")
            clear_user_state(user_id)
            return

        file_path_tg = info['result']['file_path']
        url = f"https://api.telegram.org/file/bot{BOT_TOKEN}/{file_path_tg}"

        pdf_local_path = os.path.join(TEMP_PDF_DIR, f"temp_pdf_{uuid.uuid4()}.pdf")

        # Download the PDF file
        file_content_response_obj = make_request(url, 'GET')
        file_content_response = file_content_response_obj['response']
        if file_content_response_obj['error'] or file_content_response is None or not file_content_response.ok:
            send_message(chat_id, "❌ فشل في تنزيل ملف PDF.")
            clear_user_state(user_id)
            return

        try:
            with open(pdf_local_path, 'wb') as f:
                f.write(file_content_response.content)
            logging.info(f"PDF file downloaded to {pdf_local_path}")
        except IOError as e:
            send_message(chat_id, "❌ فشل في حفظ الملف مؤقتًا.")
            logging.error(f"Failed to write PDF: {e}")
            clear_user_state(user_id)
            return

        # Get page count
        try:
            import pypdfium2 as pdfium
            pdf_document = pdfium.PdfDocument(pdf_local_path)
            page_count = len(pdf_document)
            pdf_document.close()
        except Exception as e:
            send_message(chat_id, f"❌ فشل في قراءة ملف PDF: {str(e)}")
            try:
                os.remove(pdf_local_path)
            except:
                pass
            clear_user_state(user_id)
            return

        if page_count == 0:
            send_message(chat_id, "❌ فشل في استخراج الصور من ملف PDF.")
            try:
                os.remove(pdf_local_path)
            except:
                pass
            clear_user_state(user_id)
            return

        # Ask user what they want to do
        choice_text = f"📄 *الملف الأصلي:* `{file_name}`\n🔢 *عدد الصفحات:* `{page_count}`\n\n💬 كيف تريد تحويل الملف؟"
        choice_buttons = [
            [{'text': '📄 ملف كامل', 'callback_data': 'pdf_convert_all'}],
            [{'text': '🔢 صفحة واحدة محددة', 'callback_data': 'pdf_convert_single'}],
            [{'text': '📊 نطاق من الصفحات', 'callback_data': 'pdf_convert_range'}]
        ]
        
        send_message(chat_id, choice_text, inline_buttons=choice_buttons, parse_mode='Markdown')
        
        # Save PDF path and file name in user state
        set_user_state(user_id, 'awaiting_pdf_conversion_choice', {
            'pdf_path': pdf_local_path,
            'file_name': file_name,
            'page_count': page_count
        })
        return


    # --- Handle Single Page Number Input ---
    if text and current_state == 'awaiting_pdf_single_page':
        user_state = get_user_state(user_id)
        pdf_path = user_state.get('data', {}).get('pdf_path')
        page_count = user_state.get('data', {}).get('page_count', 1)
        
        try:
            page_num = int(text.strip())
            if 1 <= page_num <= page_count:
                set_user_state(user_id, 'pdf_converting_single', {**user_state.get('data', {}), 'page_num': page_num})
                handle_pdf_conversion('single', user_id, chat_id, current_state, page_num)
            else:
                send_message(chat_id, f"❌ الرجاء إدخال رقم بين 1 و {page_count}")
        except ValueError:
            send_message(chat_id, "❌ الرجاء إدخال رقم صفحة صحيح")
        return

    # --- Handle Page Range Input ---
    if text and current_state == 'awaiting_pdf_page_range':
        user_state = get_user_state(user_id)
        pdf_path = user_state.get('data', {}).get('pdf_path')
        page_count = user_state.get('data', {}).get('page_count', 1)
        
        try:
            parts = text.strip().split('-')
            start_page = int(parts[0].strip())
            end_page = int(parts[1].strip()) if len(parts) > 1 else start_page
            
            if 1 <= start_page <= page_count and 1 <= end_page <= page_count and start_page <= end_page:
                set_user_state(user_id, 'pdf_converting_range', {**user_state.get('data', {}), 'start_page': start_page, 'end_page': end_page})
                handle_pdf_conversion('range', user_id, chat_id, current_state, start_page, end_page)
            else:
                send_message(chat_id, f"❌ الرجاء إدخال نطاق صحيح (من 1 إلى {page_count})")
        except (ValueError, IndexError):
            send_message(chat_id, "❌ الصيغة خاطئة. استخدم: 1-5")
        return


    # --- Handle PDF name input for database saving ---
    if current_state == 'awaiting_pdf_name_for_db' and text is not None:
        # Check for forbidden commands
        forbidden_texts = {
            '/start', 'إزالة الخلفية 🖼️', 'تحسين الجودة 🪄',
            'توزيع في القالب 🧩', 'المعالجة التلقائية 🤖', '/admin', 'البحث عن ملف PDF 🔍'
        }
        if text in forbidden_texts:
            send_message(chat_id, "الرجاء إدخال اسم للملف، وليس أمرًا من القائمة.")
            return # Keep user in current state, waiting for prompt

        current_user_state = get_user_state(user_id)
        pdf_data_hex = current_user_state.get('data', {}).get('pdf_data')
        template_path = current_user_state.get('data', {}).get('template_path')

        if pdf_data_hex:
            send_chat_action(chat_id, 'typing')
            processing_message_id = send_message(chat_id, "💾 جاري حفظ الملف في قاعدة البيانات...")

            try:
                # Convert hex back to bytes
                pdf_data = bytes.fromhex(pdf_data_hex)

                # Save to database
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)

                # Upload to Supabase Storage with sanitized filename
                file_url = loop.run_until_complete(db.upload_pdf_to_storage(f"{text}.pdf", pdf_data))

                if file_url:
                    # Save file info to database with original filename
                    success = loop.run_until_complete(db.save_pdf_file(user_id, text, file_url))

                    if success:
                        file_size_kb = len(pdf_data) / 1024

                        if processing_message_id:
                            delete_message(chat_id, processing_message_id)

                        send_message(chat_id, f"✅ تم حفظ الملف في قاعدة البيانات بنجاح!\n📝 الاسم: {text}\n🔧 الحجم: {file_size_kb:.1f} كيلوبايت\n🔍 يمكنك البحث عنه لاحقًا باستخدام زر 'البحث عن ملف PDF'")

                        # Clean up template file
                        if template_path and os.path.exists(template_path):
                            os.remove(template_path)

                        clear_user_state(user_id)
                    else:
                        send_message(chat_id, "❌ فشل في حفظ معلومات الملف في قاعدة البيانات.")
                        if processing_message_id:
                            delete_message(chat_id, processing_message_id)
                else:
                    send_message(chat_id, "❌ فشل في رفع الملف إلى التخزين السحابي. تحقق من اسم الملف.")
                    if processing_message_id:
                        delete_message(chat_id, processing_message_id)

                loop.close()

            except Exception as e:
                logging.error(f"Error saving PDF to database: {e}")
                send_message(chat_id, "❌ حدث خطأ أثناء حفظ الملف في قاعدة البيانات.")
                if processing_message_id:
                    delete_message(chat_id, processing_message_id)
        else:
            send_message(chat_id, "❌ لم يتم العثور على بيانات الملف. يرجى محاولة مرة أخرى.")
            clear_user_state(user_id)
        return

    # --- Handle PDF search input ---
    if current_state == 'awaiting_pdf_search' and text is not None:
        # Check for forbidden commands
        forbidden_texts = {
            '/start', 'إزالة الخلفية 🖼️', 'تحسين الجودة 🪄',
            'توزيع في القالب 🧩', 'المعالجة التلقائية 🤖', '/admin', 'البحث عن ملف PDF 🔍'
        }
        if text in forbidden_texts:
            send_message(chat_id, "الرجاء إدخال اسم الملف للبحث، وليس أمرًا من القائمة.")
            return

        send_chat_action(chat_id, 'typing')
        processing_message_id = send_message(chat_id, "🔍 جاري البحث عن الملف...")

        try:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

            # Search for the file in database using the original file name
            pdf_file = loop.run_until_complete(db.get_pdf_file_by_name(user_id, text))

            if pdf_file:
                file_url = pdf_file.get('file_url', '')
                created_at = pdf_file.get('created_at', '')

                if file_url:
                    # Extract the actual storage file name from the URL
                    storage_file_name = file_url.split('/')[-1]
                    logging.info(f"Downloading file from storage: {storage_file_name}")
                    
                    # Download file from storage using the correct storage filename
                    pdf_data = loop.run_until_complete(db.download_pdf_from_storage(storage_file_name))

                    if pdf_data:
                        # Save temporarily and send
                        temp_pdf_path = os.path.join(TEMP_PDF_DIR, f"temp_downloaded_{user_id}_{uuid.uuid4()}.pdf")
                        with open(temp_pdf_path, 'wb') as f:
                            f.write(pdf_data)

                        file_size_kb = len(pdf_data) / 1024
                        caption = f"📄 تم العثور على الملف!\n📝 الاسم: {text}\n📅 تاريخ الحفظ: {created_at[:10] if created_at else 'غير متوفر'}\n🔧 الحجم: {file_size_kb:.1f} كيلوبايت"

                        if send_document(chat_id, temp_pdf_path, caption):
                            send_message(chat_id, "✅ تم إرسال الملف بنجاح!")
                        else:
                            send_message(chat_id, "❌ تم العثور على الملف لكن فشل في إرساله.")

                        # Clean up temporary file
                        os.remove(temp_pdf_path)
                    else:
                        send_message(chat_id, f"❌ تم العثور على معلومات الملف لكن فشل تحميله من التخزين السحابي.\n🔗 URL: {storage_file_name}")
                        logging.error(f"Failed to download file from storage: {storage_file_name}")
                else:
                    send_message(chat_id, f"❌ تم العثور على الملف '{text}' لكن لا يوجد رابط تحميل صالح في قاعدة البيانات.")
            else:
                send_message(chat_id, f"❌ لم يتم العثور على ملف بالاسم '{text}'.\n💡 تأكد من كتابة الاسم بالضبط كما حفظته.")
                
                # Show user's files for reference
                all_files = loop.run_until_complete(db.get_user_pdf_files(user_id))
                if all_files:
                    files_list = "\n".join([f"• {file.get('file_name', 'غير معروف')}" for file in all_files[:5]])
                    send_message(chat_id, f"📋 ملفاتك المحفوظة:\n{files_list}")

            loop.close()

        except Exception as e:
            logging.error(f"Error searching for PDF: {e}")
            send_message(chat_id, f"❌ حدث خطأ أثناء البحث عن الملف: {str(e)}")

        if processing_message_id:
            delete_message(chat_id, processing_message_id)

        clear_user_state(user_id)
        return

    # --- Fallback for Unrecognized Text Commands ---
    if text and current_state not in [
        'auto_process_original', # Expects photo
        'auto_process_new', # Expects photo
        'auto_template_selection', # Expects photo after selection
        'awaiting_backup_file', # Expects document
        'admin_awaiting_start_message', # Expects new start message text
        'admin_awaiting_maintenance_message', # Expects maintenance message
        'admin_awaiting_summary_user_add', # Expects user ID to add to summary
        'admin_awaiting_summary_user_remove', # Expects user ID to remove from summary
        'admin_awaiting_broadcast_all', # Expects broadcast message for all users
        'admin_awaiting_broadcast_user', # Expects broadcast message for specific user
        'admin_awaiting_broadcast_user_id', # Expects user ID for targeted broadcast
        'admin_awaiting_user_id_for_mode_toggle', # Expects user ID for mode toggle
        'admin_awaiting_summary_hour', # Expects hour for summary
        'admin_awaiting_summary_minute', # Expects minute for summary
        'admin_awaiting_summary_ampm', # Expects AM/PM for summary
        'admin_awaiting_scheduled_content', # Expects scheduled reminder content
        'admin_awaiting_add_user_id', # Expects user ID
        'admin_awaiting_delete_user_id', # Expects user ID
        'admin_awaiting_ban_user_id', # Expects user ID
        'admin_awaiting_unban_user_id', # Expects user ID
        'template_ready', # Has template ready for PDF conversion
        'awaiting_db_save_decision', # Waiting for database save decision
        'awaiting_pdf_name_for_db', # Expects PDF file name for database
        'awaiting_pdf_search' # Expects PDF search query
    ] and not current_state.startswith('add_primary_key_') \
      and not current_state.startswith('add_backup_key_') \
      and not current_state.startswith('awaiting_backup_key_index_') \
      and not current_state.startswith('awaiting_expired_key_index_'):
        # رسالة بسيطة بدون قائمة للأوامر غير المفهومة
        send_message(chat_id, "🤔 أمر غير مفهوم. الرجاء استخدام /start للبدء من جديد.")
        clear_user_state(user_id) # Clear state to ensure user starts fresh
        return

# --- Admin Panel Functions ---

def show_admin_panel(chat_id, user_id, message_id=None):
    """Shows the main admin panel with all available sections."""
    text = "*🔧 لوحة تحكم المالك*\n\nاختر القسم الذي تريد إدارته:"
    
    buttons = [
        [{'text': 'اعدادات جانبية ⚙️', 'callback_data': 'admin_section_side_settings'}],
        [{'text': 'قسم الأعضاء 👤', 'callback_data': 'admin_section_members'}],
        [{'text': 'إحصائيات البوت 📊', 'callback_data': 'admin_section_stats'}, {'text': 'النسخ الاحتياطية 💾', 'callback_data': 'admin_section_backup'}],
        [{'text': 'إدارة قواعد البيانات 🗄️', 'callback_data': 'admin_section_database'}],
        [{'text': 'إدارة التذكيرات 🔔', 'callback_data': 'admin_section_reminders'}, {'text': 'إدارة الإصدار 🔢', 'callback_data': 'admin_section_version'}],
        [{'text': 'إدارة المفاتيح 🔐', 'callback_data': 'admin_section_keys'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, text, buttons, message_id, 'admin_main_panel')

def show_side_settings_menu(chat_id, user_id, message_id=None):
    """Shows the side settings menu."""
    text = "*⚙️ الإعدادات الجانبية*\n\nاختر الإعداد الذي تريد إدارته:"
    
    buttons = [
        [{'text': '📝 رسالة البدء', 'callback_data': 'admin_section_start_message'}],
        [{'text': '🧩 رسالة القوالب', 'callback_data': 'admin_section_template_message'}],
        [{'text': '🔧 وضع الصيانة', 'callback_data': 'admin_section_maintenance'}],
        [{'text': '📊 وضع الموجز', 'callback_data': 'admin_section_summary'}],
        [{'text': '📢 قسم الإذاعة', 'callback_data': 'admin_section_broadcast'}],
        [{'text': '⚙️ إدارة أوضاع المستخدمين', 'callback_data': 'admin_section_command_modes'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_back_to_main'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, text, buttons, message_id, 'admin_side_settings_menu')

def show_maintenance_menu(chat_id, user_id, message_id=None):
    """Shows the maintenance mode management menu."""
    mode_data = load_maintenance_mode()
    current_status = "✅ مفعل" if mode_data.get('enabled', False) else "❌ معطل"
    current_message = mode_data.get('message', '')
    
    text = f"*🔧 وضع الصيانة*\n\nالحالة: {current_status}\n\nالرسالة الحالية:\n{current_message}\n\nاختر العملية:"
    
    buttons = [
        [{'text': '🔄 تفعيل/تعطيل', 'callback_data': 'admin_toggle_maintenance'}],
        [{'text': '✏️ تعديل الرسالة', 'callback_data': 'admin_edit_maintenance_message'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_section_side_settings'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, text, buttons, message_id, 'admin_maintenance_menu')

def show_summary_menu(chat_id, user_id, message_id=None):
    """Shows the summary mode management menu."""
    summary_data = load_summary_mode()
    enabled_users = summary_data.get('enabled_users', {})
    send_time = summary_data.get('send_time', '20:00')
    
    user_count = len(enabled_users)
    user_list = ", ".join(enabled_users.keys()) if enabled_users else "لا يوجد"
    
    text = f"*📊 وضع الموجز*\n\n"
    text += f"👥 المستخدمون المفعلون: {user_count}\n"
    text += f"🆔 IDs: {user_list}\n"
    text += f"⏰ وقت الإرسال: {send_time}\n\n"
    text += "اختر العملية:"
    
    buttons = [
        [{'text': '➕ إضافة مستخدم', 'callback_data': 'admin_summary_add_user'}],
        [{'text': '➖ إزالة مستخدم', 'callback_data': 'admin_summary_remove_user'}],
        [{'text': '⏰ تحديد وقت الإرسال', 'callback_data': 'admin_summary_set_time'}],
        [{'text': '👁️ عرض المستخدمين', 'callback_data': 'admin_summary_view_users'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_section_side_settings'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, text, buttons, message_id, 'admin_summary_menu')

def show_start_message_menu(chat_id, user_id, message_id=None):
    """Shows the start message management menu."""
    message_data = load_start_message()
    current_status = "✅ مفعلة" if message_data.get('enabled', True) else "❌ معطلة"
    current_message = message_data.get('message', '')
    
    text = f"*📝 إدارة رسالة البدء*\n\nالحالة: {current_status}\n\nالرسالة الحالية:\n{current_message}\n\nاختر العملية:"
    
    buttons = [
        [{'text': '✏️ تعديل الرسالة', 'callback_data': 'admin_edit_start_message'}],
        [{'text': '🔄 تفعيل/تعطيل', 'callback_data': 'admin_toggle_start_message'}],
        [{'text': '♻️ إعادة تعيين للافتراضية', 'callback_data': 'admin_reset_start_message'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_section_side_settings'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, text, buttons, message_id, 'admin_start_message_menu')

def show_template_message_menu(chat_id, user_id, message_id=None):
    """Shows the template message management menu."""
    message_data = load_template_message()
    current_status = "✅ مفعلة" if message_data.get('enabled', True) else "❌ معطلة"
    
    text = f"*🧩 إدارة رسالة القوالب*\n\nالحالة: {current_status}\n\nاختر نوع الرسالة للتعديل:"
    
    buttons = [
        [{'text': '📝 تعديل رسالة التوزيع العادي', 'callback_data': 'admin_edit_regular_template_message'}],
        [{'text': '🤖 تعديل رسالة المعالجة التلقائية', 'callback_data': 'admin_edit_auto_template_message'}],
        [{'text': '🔄 تفعيل/تعطيل', 'callback_data': 'admin_toggle_template_message'}],
        [{'text': '♻️ إعادة تعيين للافتراضية', 'callback_data': 'admin_reset_template_message'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_section_side_settings'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, text, buttons, message_id, 'admin_template_message_menu')

def show_admin_members_menu(chat_id, user_id, message_id=None):
    """Shows the members section menu combining users, bans, and lists."""
    text = "*👤 قسم الأعضاء*\n\nاختر العملية التي تريد تنفيذها:"
    
    buttons = [
        [{'text': '👥 إدارة المستخدمين', 'callback_data': 'admin_section_users'}, {'text': '🚫 إدارة الحظر', 'callback_data': 'admin_section_ban'}],
        [{'text': '📋 عرض القوائم', 'callback_data': 'admin_section_lists'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_back_to_main'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, text, buttons, message_id, 'admin_members_menu')

def show_admin_users_menu(chat_id, user_id, message_id=None):
    """Shows the users management menu."""
    text = "*👥 إدارة المستخدمين*\n\nاختر العملية التي تريد تنفيذها:"
    
    buttons = [
        [{'text': '➕ إضافة مستخدم', 'callback_data': 'admin_add_user'}],
        [{'text': '🗑️ حذف مستخدم', 'callback_data': 'admin_delete_user'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_back_to_main'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, text, buttons, message_id, 'admin_users_menu')

def show_admin_ban_menu(chat_id, user_id, message_id=None):
    """Shows the ban management menu."""
    text = "*🚫 إدارة الحظر*\n\nاختر العملية التي تريد تنفيذها:"
    
    buttons = [
        [{'text': '🚫 حظر مستخدم', 'callback_data': 'admin_ban_user'}],
        [{'text': '✅ إلغاء حظر مستخدم', 'callback_data': 'admin_unban_user'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_back_to_main'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, text, buttons, message_id, 'admin_ban_menu')

def show_admin_lists_menu(chat_id, user_id, message_id=None):
    """Shows the lists viewing menu."""
    text = "*📋 عرض القوائم*\n\nاختر القائمة التي تريد عرضها:"
    
    buttons = [
        [{'text': '✅ المستخدمون المسموح لهم', 'callback_data': 'admin_view_allowed'}],
        [{'text': '🚫 المستخدمون المحظورون', 'callback_data': 'admin_view_banned'}],
        [{'text': '⏳ الطلبات المعلقة', 'callback_data': 'admin_view_pending'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_back_to_main'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, text, buttons, message_id, 'admin_lists_menu')

def show_admin_backup_menu(chat_id, user_id, message_id=None):
    """Shows the backup management menu."""
    text = "*💾 النسخ الاحتياطية*\n\nإدارة النسخ الاحتياطية للبوت:"
    
    buttons = [
        [{'text': '💾 إنشاء نسخة احتياطية فورية', 'callback_data': 'admin_perform_backup'}],
        [{'text': '📤 استعادة من نسخة احتياطية', 'callback_data': 'admin_restore_backup'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_back_to_main'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, text, buttons, message_id, 'admin_backup_menu')

def show_admin_keys_menu_OLD(chat_id, user_id, message_id=None):
    """Shows the API keys management menu."""
    text = "*🔐 إدارة المفاتيح*\n\nاختر نوع المفتاح الذي تريد إدارته:"
    
    buttons = [
        [{'text': '🖼️ مفاتيح Remove.bg', 'callback_data': 'admin_keys_removebg'}],
        [{'text': '🪄 مفاتيح Picsart', 'callback_data': 'admin_keys_picsart'}],
        [{'text': '📄 مفاتيح ConvertAPI', 'callback_data': 'admin_keys_convertapi'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_back_to_main'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, text, buttons, message_id, 'admin_keys_menu')

def show_admin_database_menu(chat_id, user_id, message_id=None):
    """Shows the database management menu with real-time information."""
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        # Get database statistics with detailed file counts from S3
        db_size_info = loop.run_until_complete(db.get_database_size())
        
        # Extract file counts
        template_count = db_size_info.get('template_count', 0)
        regular_count = db_size_info.get('regular_count', 0)
        total_files = db_size_info.get('file_count', 0)
        
        # Extract storage information
        used_storage_bytes = db_size_info.get('size_bytes', 0)
        used_storage_mb = db_size_info.get('size_mb', 0)
        max_storage_mb = db_size_info.get('max_size_mb', 500)
        remaining_mb = db_size_info.get('remaining_mb', 500)
        usage_percentage = db_size_info.get('usage_percent', 0)
        
        # Test connection
        connection_status = "🟢 متصل" if loop.run_until_complete(db.test_connection()) else "🔴 غير متصل"
        
        loop.close()
        
        # Calculate storage in KB for better display
        used_storage_kb = used_storage_bytes / 1024
        
        # Supabase free tier limits
        max_storage_gb = max_storage_mb / 1024
        
        # Format storage display based on size
        if used_storage_mb >= 1:
            storage_display = f"{used_storage_mb:.2f} MB"
        elif used_storage_kb >= 1:
            storage_display = f"{used_storage_kb:.1f} KB"
        else:
            storage_display = f"{used_storage_bytes} Bytes"
        
        # Determine status emoji and message
        if usage_percentage > 90:
            status_emoji = "🔴"
            status_msg = "تحذير: مساحة التخزين ممتلئة تقريبًا!"
        elif usage_percentage > 75:
            status_emoji = "🟠"
            status_msg = "تنبيه: أكثر من 75% من المساحة مستخدمة"
        elif usage_percentage > 50:
            status_emoji = "🟡"
            status_msg = "متوسط: أكثر من نصف المساحة مستخدمة"
        else:
            status_emoji = "🟢"
            status_msg = "جيد: مساحة كافية متاحة"
        
        text = (f"*🗄️ إدارة قواعد البيانات*\n\n"
                f"📊 *إحصائيات التخزين:*\n"
                f"📁 إجمالي الملفات: `{total_files}` ملف\n"
                f"📄 عدد الملفات العادية: `{regular_count}` ملف\n"
                f"📋 عدد ملفات القوالب: `{template_count}` ملف\n"
                f"💾 المساحة المستخدمة: `{storage_display}`\n"
                f"📈 نسبة الاستخدام: `{usage_percentage:.2f}%`\n"
                f"📊 المساحة المتبقية: `{remaining_mb:.1f} MB`\n"
                f"🗂️ الحد الأقصى: `{max_storage_gb:.1f} GB` (Supabase مجاني)\n"
                f"{status_emoji} الحالة: {status_msg}\n\n"
                f"🔗 *معلومات الاتصال:*\n"
                f"📡 حالة الاتصال: {connection_status}\n"
                f"🏷️ اسم المشروع: `Lbot1-db`\n"
                f"🆔 معرف المشروع: `bxfsjgiishddzfozknpd`")
        
        buttons = [
            [{'text': '📊 جلب مساحة التخزين', 'callback_data': 'admin_db_storage_info'}],
            [{'text': '📋 جلب جميع ملفات القاعدة', 'callback_data': 'admin_db_all_files'}],
            [{'text': '📥 استعادة نسخة', 'callback_data': 'admin_restore_pdf_backup'}, {'text': '💾 نسخة احتياطية', 'callback_data': 'admin_create_pdf_backup'}],
            [{'text': '🗑️ حذف جميع الملفات', 'callback_data': 'admin_db_delete_menu'}],
            [{'text': '🟢 Keep-Alive', 'callback_data': 'admin_db_keepalive'}],
            [{'text': '⬅️ رجوع', 'callback_data': 'admin_back_to_main'}]
        ]
        
    except Exception as e:
        logging.error(f"Error getting database info: {e}")
        text = (f"*🗄️ إدارة قواعد البيانات*\n\n"
                f"❌ خطأ في الاتصال بقاعدة البيانات\n"
                f"🔗 حالة الاتصال: 🔴 غير متصل\n"
                f"🏷️ اسم المشروع: `Lbot1-db`\n"
                f"🆔 معرف المشروع: `bxfsjgiishddzfozknpd`")
        
        buttons = [
            [{'text': '🟢 Keep-Alive', 'callback_data': 'admin_db_keepalive'}],
            [{'text': '🔄 محاولة الاتصال مرة أخرى', 'callback_data': 'admin_section_database'}],
            [{'text': '⬅️ رجوع', 'callback_data': 'admin_back_to_main'}]
        ]
    
    update_admin_message_and_state(chat_id, user_id, text, buttons, message_id, 'admin_database_menu')

def handle_key_admin_actions(chat_id, user_id, action, key_file_info, message_id):
    """Handle key administration actions."""
    key_file = key_file_info['file']
    display_name = key_file_info['display_name']
    
    # Determine key type from file name
    key_type_raw = None
    for k, v in KEY_TYPE_MAP.items():
        if v['file'] == key_file:
            key_type_raw = k
            break
    
    if not key_type_raw:
        logging.error(f"Could not determine key type for file: {key_file}")
        send_message(chat_id, "❌ خطأ في تحديد نوع المفتاح.")
        show_admin_keys_menu(chat_id, user_id, message_id)
        return
    
    # Handle view keys action specifically
    if action.startswith('view_keys_btn_'):
        data = get_key_data(key_file)
        current_key = data.get('current_key', 'غير محدد')
        backup_keys = data.get('backup_keys', [])
        expired_keys = data.get('expired_keys', [])
        usage_count = data.get('used_count', 0)
        
        # Build detailed view message
        text = f"*🔐 عرض مفاتيح {display_name}*\n\n"
        
        # Current key
        if current_key and current_key != 'غير محدد':
            text += f"🔑 *المفتاح الحالي:*\n`{current_key}`\n📊 استخدم `{usage_count}` مرة\n\n"
        else:
            text += f"🔑 *المفتاح الحالي:* غير محدد\n\n"
        
        # Backup keys
        text += f"📦 *المفاتيح الاحتياطية ({len(backup_keys)}):*\n"
        if backup_keys:
            for i, key in enumerate(backup_keys, 1):
                text += f"{i}. `{key}`\n"
        else:
            text += "لا توجد مفاتيح احتياطية\n"
        text += "\n"
        
        # Expired keys
        text += f"❌ *المفاتيح منتهية الصلاحية ({len(expired_keys)}):*\n"
        if expired_keys:
            for i, key in enumerate(expired_keys, 1):
                text += f"{i}. `{key}`\n"
        else:
            text += "لا توجد مفاتيح منتهية الصلاحية\n"
        
        buttons = [
            [{'text': '⬅️ رجوع لإدارة المفاتيح', 'callback_data': f'back_to_key_admin_{key_type_raw}'}],
            [{'text': '⬅️ رجوع لقائمة المفاتيح', 'callback_data': 'admin_back_to_keys_menu'}]
        ]
        
        # Send as new message to avoid edit conflicts
        send_message(chat_id, text, inline_buttons=buttons, parse_mode='Markdown')
        return
    
    # Handle initial display and other actions
    if action == 'initial_display':
        data = get_key_data(key_file)
        current_key = data.get('current_key', 'غير محدد')
        backup_count = len(data.get('backup_keys', []))
        expired_count = len(data.get('expired_keys', []))
        usage_count = data.get('used_count', 0)
        
        text = (f"*🔐 إدارة مفاتيح {display_name}*\n\n"
                f"🔑 المفتاح الحالي: `{current_key}`\n"
                f"📦 المفاتيح الاحتياطية: `{backup_count}`\n"
                f"❌ المفاتيح منتهية الصلاحية: `{expired_count}`\n"
                f"📊 مرات الاستخدام: `{usage_count}`")
        
        buttons = [
            [{'text': '➕ إضافة مفتاح رئيسي', 'callback_data': f'add_primary_key_btn_{key_type_raw}'}],
            [{'text': '📦 إضافة مفتاح احتياطي', 'callback_data': f'add_backup_key_btn_{key_type_raw}'}],
            [{'text': '👀 عرض المفاتيح', 'callback_data': f'view_keys_btn_{key_type_raw}'}],
            [{'text': '🔄 تدوير المفتاح', 'callback_data': f'rotate_key_btn_{key_type_raw}'}],
            [{'text': '🗑️ حذف المفاتيح', 'callback_data': f'delete_keys_btn_{key_type_raw}'}],
            [{'text': '⬅️ رجوع لقائمة المفاتيح', 'callback_data': 'admin_back_to_keys_menu'}]
        ]
        
        update_admin_message_and_state(chat_id, user_id, text, buttons, message_id, f'{key_type_raw}_keys_admin', {'key_type_raw': key_type_raw})
    
    elif action.startswith('add_primary_key_btn_'):
        key_type_from_action = action.replace('add_primary_key_btn_', '')
        if key_type_from_action == key_type_raw:
            set_user_state(user_id, f'add_primary_key_{key_type_raw}', {'admin_message_id': message_id, 'key_type_raw': key_type_raw})
            send_message(chat_id, f"➕ أرسل المفتاح الرئيسي الجديد لـ {display_name}:")
    
    elif action.startswith('add_backup_key_btn_'):
        key_type_from_action = action.replace('add_backup_key_btn_', '')
        if key_type_from_action == key_type_raw:
            set_user_state(user_id, f'add_backup_key_{key_type_raw}', {'admin_message_id': message_id, 'key_type_raw': key_type_raw})
            send_message(chat_id, f"📦 أرسل المفتاح الاحتياطي الجديد لـ {display_name}:")
    
    elif action.startswith('rotate_key_btn_'):
        key_type_from_action = action.replace('rotate_key_btn_', '')
        if key_type_from_action == key_type_raw:
            new_key = rotate_active_key(key_file)
            if new_key:
                send_message(chat_id, f"🔄 تم تدوير المفتاح لـ {display_name} بنجاح!\nالمفتاح الجديد: `{new_key}`", parse_mode='Markdown')
            else:
                send_message(chat_id, f"❌ لا توجد مفاتيح احتياطية متاحة لـ {display_name}.")
            # Refresh the key admin display
            handle_key_admin_actions(chat_id, user_id, 'initial_display', key_file_info, message_id)
    
    elif action.startswith('delete_keys_btn_'):
        key_type_from_action = action.replace('delete_keys_btn_', '')
        if key_type_from_action == key_type_raw:
            delete_options_buttons = [
                [{'text': '🗑️ حذف مفتاح رئيسي', 'callback_data': f'delete_primary_{key_type_raw}'}],
                [{'text': '🗑️ حذف جميع المفاتيح الاحتياطية', 'callback_data': f'delete_all_backup_{key_type_raw}'}],
                [{'text': '🗑️ حذف مفتاح احتياطي محدد', 'callback_data': f'delete_specific_backup_{key_type_raw}'}],
                [{'text': '🗑️ حذف جميع المفاتيح منتهية الصلاحية', 'callback_data': f'clear_expired_{key_type_raw}'}],
                [{'text': '↩️ استعادة مفتاح منتهي الصلاحية', 'callback_data': f'restore_expired_{key_type_raw}'}],
                [{'text': '⬅️ رجوع لإدارة المفاتيح', 'callback_data': f'back_to_key_admin_{key_type_raw}'}],
                [{'text': '⬅️ رجوع لقائمة المفاتيح', 'callback_data': 'admin_back_to_keys_menu'}]
            ]
            update_admin_message_and_state(chat_id, user_id, f"🗑️ اختر خيار الحذف لمفاتيح {display_name}:", delete_options_buttons, message_id, f'delete_keys_{key_type_raw}', {'key_type_raw': key_type_raw})

def handle_add_key_input(chat_id, user_id, key_text, key_file_info, is_primary, admin_message_id, input_message_id):
    """Handle adding a new API key."""
    key_file = key_file_info['file']
    display_name = key_file_info['display_name']
    
    # Delete the input message
    if input_message_id:
        delete_message(chat_id, input_message_id)
    
    if len(key_text.strip()) < 10:
        send_message(chat_id, "❌ المفتاح قصير جدًا. يجب أن يكون المفتاح صالحًا.")
        handle_key_admin_actions(chat_id, user_id, 'initial_display', key_file_info, admin_message_id)
        return
    
    add_key_to_pool(key_file, key_text.strip(), is_primary)
    key_type = "رئيسي" if is_primary else "احتياطي"
    send_message(chat_id, f"✅ تم إضافة المفتاح ال{key_type} لـ {display_name} بنجاح!")
    
    # Return to key admin menu
    handle_key_admin_actions(chat_id, user_id, 'initial_display', key_file_info, admin_message_id)

def handle_awaiting_key_index_input(chat_id, user_id, index_text, state_data, input_message_id, key_type):
    """Handle index input for key operations."""
    # Delete the input message
    if input_message_id:
        delete_message(chat_id, input_message_id)
    
    try:
        index = int(index_text.strip()) - 1  # Convert to 0-based index
        key_type_raw = state_data.get('key_type_raw')
        key_file_info = KEY_TYPE_MAP.get(key_type_raw)
        admin_message_id = state_data.get('admin_message_id')
        
        if not key_file_info:
            send_message(chat_id, "❌ خطأ في تحديد نوع المفتاح.")
            return
        
        display_name = key_file_info['display_name']
        
        if key_type == 'backup':
            backup_keys = get_key_data(key_file_info['file']).get('backup_keys', [])
            if 0 <= index < len(backup_keys):
                deleted_key = backup_keys[index]
                success = delete_specific_backup_key(key_file_info['file'], index)
                if success:
                    send_message(chat_id, f"✅ تم حذف المفتاح الاحتياطي لـ {display_name} بنجاح!\nالمفتاح المحذوف: `{deleted_key}`", parse_mode='Markdown')
                else:
                    send_message(chat_id, f"❌ فشل في حذف المفتاح الاحتياطي لـ {display_name}.")
            else:
                send_message(chat_id, "❌ رقم المفتاح غير صالح.")
                
        elif key_type == 'expired':
            expired_keys = get_key_data(key_file_info['file']).get('expired_keys', [])
            if 0 <= index < len(expired_keys):
                restored_key = expired_keys[index]
                success = restore_specific_expired_key(key_file_info['file'], index)
                if success:
                    send_message(chat_id, f"✅ تم استعادة المفتاح منتهي الصلاحية لـ {display_name} بنجاح!\nالمفتاح المستعاد: `{restored_key}`", parse_mode='Markdown')
                else:
                    send_message(chat_id, f"❌ فشل في استعادة المفتاح منتهي الصلاحية لـ {display_name}.")
            else:
                send_message(chat_id, "❌ رقم المفتاح غير صالح.")
        
        # Return to delete keys menu
        delete_options_buttons = [
            [{'text': '🗑️ حذف مفتاح رئيسي', 'callback_data': f'delete_primary_{key_type_raw}'}],
            [{'text': '🗑️ حذف جميع المفاتيح الاحتياطية', 'callback_data': f'delete_all_backup_{key_type_raw}'}],
            [{'text': '🗑️ حذف مفتاح احتياطي محدد', 'callback_data': f'delete_specific_backup_{key_type_raw}'}],
            [{'text': '🗑️ حذف جميع المفاتيح منتهية الصلاحية', 'callback_data': f'clear_expired_{key_type_raw}'}],
            [{'text': '↩️ استعادة مفتاح منتهي الصلاحية', 'callback_data': f'restore_expired_{key_type_raw}'}],
            [{'text': '⬅️ رجوع لإدارة المفاتيح', 'callback_data': f'back_to_key_admin_{key_type_raw}'}],
            [{'text': '⬅️ رجوع لقائمة المفاتيح', 'callback_data': 'admin_back_to_keys_menu'}]
        ]
        update_admin_message_and_state(chat_id, user_id, f"🗑️ اختر خيار الحذف لمفاتيح {display_name}:", delete_options_buttons, admin_message_id, f'delete_keys_{key_type_raw}', {'key_type_raw': key_type_raw})
        
    except ValueError:
        send_message(chat_id, "❌ يرجى إدخال رقم صالح.")

def process_key_deletion_callback(chat_id, user_id, data, key_file_info, message_id):
    """Process key deletion callbacks."""
    key_file = key_file_info['file']
    display_name = key_file_info['display_name']
    
    # Extract key type from data
    key_type_raw = None
    for k in KEY_TYPE_MAP.keys():
        if data.endswith(f'_{k}'):
            key_type_raw = k
            break
    
    if data.startswith('delete_primary_'):
        old_key = get_key_data(key_file).get('current_key', 'غير محدد')
        delete_primary_key(key_file)
        send_message(chat_id, f"✅ تم حذف المفتاح الرئيسي لـ {display_name}!\nالمفتاح المحذوف: `{old_key}`", parse_mode='Markdown')
        # Return to delete keys menu
        delete_options_buttons = [
            [{'text': '🗑️ حذف مفتاح رئيسي', 'callback_data': f'delete_primary_{key_type_raw}'}],
            [{'text': '🗑️ حذف جميع المفاتيح الاحتياطية', 'callback_data': f'delete_all_backup_{key_type_raw}'}],
            [{'text': '🗑️ حذف مفتاح احتياطي محدد', 'callback_data': f'delete_specific_backup_{key_type_raw}'}],
            [{'text': '🗑️ حذف جميع المفاتيح منتهية الصلاحية', 'callback_data': f'clear_expired_{key_type_raw}'}],
            [{'text': '↩️ استعادة مفتاح منتهي الصلاحية', 'callback_data': f'restore_expired_{key_type_raw}'}],
            [{'text': '⬅️ رجوع لإدارة المفاتيح', 'callback_data': f'back_to_key_admin_{key_type_raw}'}],
            [{'text': '⬅️ رجوع لقائمة المفاتيح', 'callback_data': 'admin_back_to_keys_menu'}]
        ]
        update_admin_message_and_state(chat_id, user_id, f"🗑️ اختر خيار الحذف لمفاتيح {display_name}:", delete_options_buttons, message_id, f'delete_keys_{key_type_raw}', {'key_type_raw': key_type_raw})
    
    elif data.startswith('delete_all_backup_'):
        backup_count = len(get_key_data(key_file).get('backup_keys', []))
        delete_all_backup_keys(key_file)
        send_message(chat_id, f"✅ تم حذف جميع المفاتيح الاحتياطية لـ {display_name}! ({backup_count} مفاتيح)")
        # Return to delete keys menu
        delete_options_buttons = [
            [{'text': '🗑️ حذف مفتاح رئيسي', 'callback_data': f'delete_primary_{key_type_raw}'}],
            [{'text': '🗑️ حذف جميع المفاتيح الاحتياطية', 'callback_data': f'delete_all_backup_{key_type_raw}'}],
            [{'text': '🗑️ حذف مفتاح احتياطي محدد', 'callback_data': f'delete_specific_backup_{key_type_raw}'}],
            [{'text': '🗑️ حذف جميع المفاتيح منتهية الصلاحية', 'callback_data': f'clear_expired_{key_type_raw}'}],
            [{'text': '↩️ استعادة مفتاح منتهي الصلاحية', 'callback_data': f'restore_expired_{key_type_raw}'}],
            [{'text': '⬅️ رجوع لإدارة المفاتيح', 'callback_data': f'back_to_key_admin_{key_type_raw}'}],
            [{'text': '⬅️ رجوع لقائمة المفاتيح', 'callback_data': 'admin_back_to_keys_menu'}]
        ]
        update_admin_message_and_state(chat_id, user_id, f"🗑️ اختر خيار الحذف لمفاتيح {display_name}:", delete_options_buttons, message_id, f'delete_keys_{key_type_raw}', {'key_type_raw': key_type_raw})
    
    elif data.startswith('delete_specific_backup_'):
        backup_keys = get_key_data(key_file).get('backup_keys', [])
        if backup_keys:
            msg = f"🗑️ اختر رقم المفتاح الاحتياطي المراد حذفه لـ {display_name}:\n\n"
            for i, key in enumerate(backup_keys, 1):
                msg += f"{i}. `{key}`\n"
            
            set_user_state(user_id, f'awaiting_backup_key_index_{key_type_raw}', {'admin_message_id': message_id, 'key_type_raw': key_type_raw})
            send_message(chat_id, msg, parse_mode='Markdown')
        else:
            send_message(chat_id, f"❌ لا توجد مفاتيح احتياطية لـ {display_name}.")
    
    elif data.startswith('clear_expired_'):
        expired_count = len(get_key_data(key_file).get('expired_keys', []))
        clear_expired_keys(key_file)
        send_message(chat_id, f"✅ تم حذف جميع المفاتيح منتهية الصلاحية لـ {display_name}! ({expired_count} مفاتيح)")
        # Return to delete keys menu
        delete_options_buttons = [
            [{'text': '🗑️ حذف مفتاح رئيسي', 'callback_data': f'delete_primary_{key_type_raw}'}],
            [{'text': '🗑️ حذف جميع المفاتيح الاحتياطية', 'callback_data': f'delete_all_backup_{key_type_raw}'}],
            [{'text': '🗑️ حذف مفتاح احتياطي محدد', 'callback_data': f'delete_specific_backup_{key_type_raw}'}],
            [{'text': '🗑️ حذف جميع المفاتيح منتهية الصلاحية', 'callback_data': f'clear_expired_{key_type_raw}'}],
            [{'text': '↩️ استعادة مفتاح منتهي الصلاحية', 'callback_data': f'restore_expired_{key_type_raw}'}],
            [{'text': '⬅️ رجوع لإدارة المفاتيح', 'callback_data': f'back_to_key_admin_{key_type_raw}'}],
            [{'text': '⬅️ رجوع لقائمة المفاتيح', 'callback_data': 'admin_back_to_keys_menu'}]
        ]
        update_admin_message_and_state(chat_id, user_id, f"🗑️ اختر خيار الحذف لمفاتيح {display_name}:", delete_options_buttons, message_id, f'delete_keys_{key_type_raw}', {'key_type_raw': key_type_raw})
    
    elif data.startswith('restore_expired_'):
        expired_keys = get_key_data(key_file).get('expired_keys', [])
        if expired_keys:
            msg = f"↩️ اختر رقم المفتاح منتهي الصلاحية المراد استعادته لـ {display_name}:\n\n"
            for i, key in enumerate(expired_keys, 1):
                msg += f"{i}. `{key}`\n"
            
            set_user_state(user_id, f'awaiting_expired_key_index_{key_type_raw}', {'admin_message_id': message_id, 'key_type_raw': key_type_raw})
            send_message(chat_id, msg, parse_mode='Markdown')
        else:
            send_message(chat_id, f"❌ لا توجد مفاتيح منتهية الصلاحية لـ {display_name}.")




async def restore_pdf_backup(backup_zip_path):
    """استعادة ملفات PDF من نسخة احتياطية (يدعم كلا النوعين: القوالب والعادية)"""
    try:
        import zipfile
        import json
        import uuid
        
        # التحقق من صحة ملف ZIP
        if not os.path.exists(backup_zip_path):
            return False, "ملف النسخة الاحتياطية غير موجود"
        
        # استخراج الملفات
        extract_dir = f"restore_{uuid.uuid4()}"
        os.makedirs(extract_dir, exist_ok=True)
        
        try:
            with zipfile.ZipFile(backup_zip_path, 'r') as zipf:
                zipf.extractall(extract_dir)
        except Exception as e:
            import shutil
            shutil.rmtree(extract_dir, ignore_errors=True)
            return False, f"فشل في استخراج النسخة الاحتياطية: {str(e)}"
        
        # قراءة metadata النسخة الاحتياطية
        metadata_path = os.path.join(extract_dir, "backup_metadata.json")
        if not os.path.exists(metadata_path):
            # Try legacy format
            metadata_path = os.path.join(extract_dir, "backup_summary.json")
            if not os.path.exists(metadata_path):
                import shutil
                shutil.rmtree(extract_dir, ignore_errors=True)
                return False, "ملف metadata النسخة الاحتياطية غير موجود"
        
        try:
            with open(metadata_path, 'r', encoding='utf-8') as f:
                metadata = json.load(f)
        except Exception as e:
            import shutil
            shutil.rmtree(extract_dir, ignore_errors=True)
            return False, f"فشل في قراءة metadata النسخة الاحتياطية: {str(e)}"
        
        restored_regular = 0
        restored_template = 0
        failed_count = 0
        
        # Restore regular PDF files
        regular_files = metadata.get('regular_files', [])
        for file_info in regular_files:
            try:
                user_id = file_info.get('user_id')
                file_name = file_info.get('file_name')
                zip_path = f"regular_files/{user_id}/{file_name}"
                file_path = os.path.join(extract_dir, zip_path)
                
                if os.path.exists(file_path):
                    with open(file_path, 'rb') as f:
                        pdf_data = f.read()
                    
                    # Upload to storage (regular bucket)
                    file_url = await db.upload_pdf_to_storage(file_name, pdf_data, is_template=False)
                    
                    if file_url:
                        # Save to database (pdf_files table)
                        success = await db.save_regular_pdf_file(
                            user_id=int(user_id),
                            file_name=file_name,
                            file_url=file_url,
                            file_type='restored'
                        )
                        
                        if success:
                            restored_regular += 1
                            logging.info(f"Restored regular PDF: {file_name} for user {user_id}")
                        else:
                            failed_count += 1
                            logging.error(f"Failed to save regular PDF metadata: {file_name}")
                    else:
                        failed_count += 1
                        logging.error(f"Failed to upload regular PDF: {file_name}")
                else:
                    failed_count += 1
                    logging.error(f"File not found in backup: {zip_path}")
                    
            except Exception as e:
                failed_count += 1
                logging.error(f"Error restoring regular file {file_info.get('file_name', 'unknown')}: {e}")
        
        # Restore template PDF files
        template_files = metadata.get('template_files', [])
        for file_info in template_files:
            try:
                user_id = file_info.get('user_id')
                file_name = file_info.get('file_name')
                template_type = file_info.get('template_type', 'unknown')
                image_count = file_info.get('image_count', 0)
                zip_path = f"template_files/{user_id}/{file_name}"
                file_path = os.path.join(extract_dir, zip_path)
                
                if os.path.exists(file_path):
                    with open(file_path, 'rb') as f:
                        pdf_data = f.read()
                    
                    # Upload to storage (template bucket)
                    file_url = await db.upload_pdf_to_storage(file_name, pdf_data, is_template=True)
                    
                    if file_url:
                        # Save to database (template_pdf_files table)
                        success = await db.save_template_pdf_file(
                            user_id=int(user_id),
                            file_name=file_name,
                            file_url=file_url,
                            template_type=template_type,
                            image_count=image_count
                        )
                        
                        if success:
                            restored_template += 1
                            logging.info(f"Restored template PDF: {file_name} for user {user_id}")
                        else:
                            failed_count += 1
                            logging.error(f"Failed to save template PDF metadata: {file_name}")
                    else:
                        failed_count += 1
                        logging.error(f"Failed to upload template PDF: {file_name}")
                else:
                    failed_count += 1
                    logging.error(f"File not found in backup: {zip_path}")
                    
            except Exception as e:
                failed_count += 1
                logging.error(f"Error restoring template file {file_info.get('file_name', 'unknown')}: {e}")
        
        # تنظيف مجلد الاستخراج
        import shutil
        shutil.rmtree(extract_dir, ignore_errors=True)
        
        total_restored = restored_regular + restored_template
        total_files = metadata.get('total_files', len(regular_files) + len(template_files))
        
        # تجهيز التقرير
        report = (f"📊 تقرير استعادة النسخة الاحتياطية:\n\n"
                 f"📁 إجمالي الملفات في النسخة: {total_files}\n"
                 f"📄 ملفات عادية: {len(regular_files)}\n"
                 f"📋 ملفات قوالب: {len(template_files)}\n\n"
                 f"✅ تم استعادة الملفات العادية: {restored_regular}\n"
                 f"✅ تم استعادة ملفات القوالب: {restored_template}\n"
                 f"✅ إجمالي المستعاد: {total_restored}\n"
                 f"❌ فشل في الاستعادة: {failed_count}\n\n"
                 f"📅 تاريخ إنشاء النسخة: {metadata.get('backup_date', 'غير متوفر')}")
        
        success = total_restored > 0
        return success, report
        
    except Exception as e:
        logging.error(f"Error restoring PDF backup: {e}")
        return False, f"خطأ أثناء استعادة النسخة الاحتياطية: {str(e)}"

# --- Broadcast Functions ---

def show_broadcast_menu(chat_id, user_id, message_id=None):
    """Shows the broadcast menu."""
    text = "*📢 قسم الإذاعة*\n\nمن خلال هذا القسم يمكنك إرسال رسائل جماعية لجميع أعضاء البوت، أو رسالة محددة لشخص معين.\n\n*المميزات:*\n• دعم جميع أنواع الملفات (صور، فيديو، ملفات، نصوص)\n• تقرير كامل بالنجاح والفشل\n\nاختر العملية:"
    
    buttons = [
        [{'text': '📣 إرسال رسالة جماعية', 'callback_data': 'admin_broadcast_all'}],
        [{'text': '👤 إرسال لشخص معين', 'callback_data': 'admin_broadcast_user'}],
        [{'text': '⬅️ رجوع', 'callback_data': 'admin_section_side_settings'}]
    ]
    
    update_admin_message_and_state(chat_id, user_id, text, buttons, message_id, 'admin_broadcast_menu')

def send_broadcast_message(target_user_id, message_type, content, caption=''):
    """
    Send a broadcast message to a specific user.
    
    Args:
        target_user_id: The user to send to
        message_type: 'text', 'photo', 'video', 'document', 'audio', 'voice', 'animation'
        content: The content (text or file_id for media)
        caption: Caption for media messages
        
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        if message_type == 'text':
            send_message(target_user_id, content)
            return True
        elif message_type == 'photo':
            payload = {
                'chat_id': target_user_id,
                'photo': content,
                'caption': to_english_numerals(caption) if caption else ''
            }
            response = make_request(f"{API_URL}/sendPhoto", 'POST', json_data=payload)
            return response.get('http_code') == 200
        elif message_type == 'video':
            payload = {
                'chat_id': target_user_id,
                'video': content,
                'caption': to_english_numerals(caption) if caption else ''
            }
            response = make_request(f"{API_URL}/sendVideo", 'POST', json_data=payload)
            return response.get('http_code') == 200
        elif message_type == 'document':
            payload = {
                'chat_id': target_user_id,
                'document': content,
                'caption': to_english_numerals(caption) if caption else ''
            }
            response = make_request(f"{API_URL}/sendDocument", 'POST', json_data=payload)
            return response.get('http_code') == 200
        elif message_type == 'audio':
            payload = {
                'chat_id': target_user_id,
                'audio': content,
                'caption': to_english_numerals(caption) if caption else ''
            }
            response = make_request(f"{API_URL}/sendAudio", 'POST', json_data=payload)
            return response.get('http_code') == 200
        elif message_type == 'voice':
            payload = {
                'chat_id': target_user_id,
                'voice': content,
                'caption': to_english_numerals(caption) if caption else ''
            }
            response = make_request(f"{API_URL}/sendVoice", 'POST', json_data=payload)
            return response.get('http_code') == 200
        elif message_type == 'animation':
            payload = {
                'chat_id': target_user_id,
                'animation': content,
                'caption': to_english_numerals(caption) if caption else ''
            }
            response = make_request(f"{API_URL}/sendAnimation", 'POST', json_data=payload)
            return response.get('http_code') == 200
        else:
            return False
    except Exception as e:
        logging.error(f"Error sending broadcast message to {target_user_id}: {e}")
        return False

async def broadcast_to_all_users_async(message_type, content, caption=''):
    """
    Broadcast a message to all bot users (allowed, pending, and banned).
    
    Args:
        message_type: Type of message
        content: Message content or file_id
        caption: Caption for media
        
    Returns:
        dict: Report with success and failure counts
    """
    try:
        # Get all users from database
        all_users = []
        allowed_users = await db.get_allowed_users()
        pending_users = await db.get_pending_users()
        banned_users = await db.get_banned_users()
        
        all_users.extend(allowed_users)
        all_users.extend(pending_users)
        all_users.extend(banned_users)
        
        # Add admin/owner to broadcast list if not already included
        user_ids = [int(user.get('user_id', 0)) for user in all_users]
        if ADMIN_ID not in user_ids:
            all_users.append({'user_id': str(ADMIN_ID)})
        
        total = len(all_users)
        success_count = 0
        failed_count = 0
        failed_users = []
        
        for user in all_users:
            user_id = int(user.get('user_id', 0))
            if user_id > 0:
                if send_broadcast_message(user_id, message_type, content, caption):
                    success_count += 1
                else:
                    failed_count += 1
                    failed_users.append(user_id)
                time.sleep(0.05)
        
        return {
            'total': total,
            'success': success_count,
            'failed': failed_count,
            'failed_users': failed_users
        }
    except Exception as e:
        logging.error(f"Error in broadcast_to_all_users_async: {e}")
        return {
            'total': 0,
            'success': 0,
            'failed': 0,
            'failed_users': []
        }

def broadcast_to_all_users(message_type, content, caption=''):
    """
    Synchronous wrapper for broadcast_to_all_users_async.
    """
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        result = loop.run_until_complete(broadcast_to_all_users_async(message_type, content, caption))
        loop.close()
        return result
    except Exception as e:
        logging.error(f"Error in broadcast_to_all_users: {e}")
        return {
            'total': 0,
            'success': 0,
            'failed': 0,
            'failed_users': []
        }

def process_broadcast_message(chat_id, user_id, message):
    """
    Process a broadcast message from admin and send to all users or specific user.
    
    Args:
        chat_id: Admin's chat ID
        user_id: Admin's user ID
        message: The message object containing the broadcast content
    """
    try:
        current_user_state = get_user_state(user_id)
        state = current_user_state.get('state', '')
        state_data = current_user_state.get('data', {})
        
        admin_message_id = state_data.get('admin_message_id')
        
        message_type = None
        content = None
        caption = message.get('caption', '')
        
        # Determine message type and content
        if 'text' in message:
            message_type = 'text'
            content = message['text']
        elif 'photo' in message:
            message_type = 'photo'
            photo_sizes = message['photo']
            content = photo_sizes[-1]['file_id']
        elif 'video' in message:
            message_type = 'video'
            content = message['video']['file_id']
        elif 'document' in message:
            message_type = 'document'
            content = message['document']['file_id']
        elif 'audio' in message:
            message_type = 'audio'
            content = message['audio']['file_id']
        elif 'voice' in message:
            message_type = 'voice'
            content = message['voice']['file_id']
        elif 'animation' in message:
            message_type = 'animation'
            content = message['animation']['file_id']
        else:
            send_message(chat_id, "❌ نوع الرسالة غير مدعوم. الرجاء إرسال نص أو صورة أو فيديو أو ملف.")
            return
        
        if state == 'admin_awaiting_broadcast_all':
            # Send to all users
            send_message(chat_id, "⏳ جاري إرسال الإذاعة لجميع الأعضاء...")
            
            report = broadcast_to_all_users(message_type, content, caption)
            
            # Prepare report message
            report_text = f"📊 *تقرير الإذاعة الجماعية*\n\n"
            report_text += f"👥 إجمالي الأعضاء: {report['total']}\n"
            report_text += f"✅ نجح الإرسال: {report['success']}\n"
            report_text += f"❌ فشل الإرسال: {report['failed']}\n\n"
            
            if report['failed'] > 0 and len(report['failed_users']) > 0:
                failed_list = ', '.join([str(uid) for uid in report['failed_users'][:10]])
                if len(report['failed_users']) > 10:
                    failed_list += f" ... و {len(report['failed_users']) - 10} آخرين"
                report_text += f"🚫 *المستخدمون الذين فشل الإرسال لهم:*\n{failed_list}"
            
            send_message(chat_id, report_text, parse_mode='Markdown')
            show_broadcast_menu(chat_id, user_id, admin_message_id)
            clear_user_state(user_id)
            
        elif state == 'admin_awaiting_broadcast_user':
            # Send to specific user
            target_user_id = state_data.get('target_user_id')
            
            if not target_user_id:
                send_message(chat_id, "❌ خطأ: لم يتم العثور على معرف المستخدم المستهدف.")
                clear_user_state(user_id)
                return
            
            send_message(chat_id, f"⏳ جاري إرسال الرسالة للمستخدم {target_user_id}...")
            
            success = send_broadcast_message(target_user_id, message_type, content, caption)
            
            if success:
                send_message(chat_id, f"✅ تم إرسال الرسالة بنجاح للمستخدم {target_user_id}")
            else:
                send_message(chat_id, f"❌ فشل إرسال الرسالة للمستخدم {target_user_id}")
            
            show_broadcast_menu(chat_id, user_id, admin_message_id)
            clear_user_state(user_id)
            
    except Exception as e:
        logging.error(f"Error processing broadcast message: {e}")
        send_message(chat_id, f"❌ حدث خطأ أثناء معالجة الإذاعة: {str(e)}")
        clear_user_state(user_id)

# --- Entry Point for the Script (Polling Loop) ---
if __name__ == '__main__':
    # بدء معالج قائمة DOCX
    docx_worker_thread = threading.Thread(target=docx_queue_worker, daemon=False)
    docx_worker_thread.start()
    logging.info("✅ تم بدء معالج قائمة انتظار DOCX")
    
    # Start the reminder checker
    start_reminder_checker()
    
    # Start the daily cleanup thread (backup cleanup system)
    start_daily_cleanup_thread()

    # Ensure KA.pdf exists (auto-generate from embedded data if missing)
    ensure_ka_pdf_exists()

    # Start XKA Keep-Alive scheduler (daily Supabase storage ping)
    start_xka_keepalive_thread()
    
    # Perform daily backup check at the start of every script execution
    perform_daily_backup(ADMIN_ID)

    offset = 0 # Start with offset 0 to get all pending updates
    logging.info("Starting Telegram bot in long polling mode...")

    while True:
        try:
            # Request updates from Telegram API with correct params
            response_obj = make_request(f"{API_URL}/getUpdates", method='GET', params={'offset': offset, 'timeout': 30}, timeout=35) # Corrected: Use params
            response = response_obj['response']

            if response_obj['error'] or response is None: # Added check for response being None
                logging.error(f"Network or API error during long polling: {response_obj['error'] or 'No response object'}. Retrying in 5 seconds...")
                time.sleep(1) # Reduced sleep for faster response
                continue

            if not response.ok:
                logging.error(f"getUpdates API returned non-OK status: {response.status_code}. Response: {response.text}. Retrying in 5 seconds...")
                time.sleep(1) # Reduced sleep for faster response
                continue

            try:
                response_data = response.json()
            except json.JSONDecodeError:
                logging.error(f"Invalid JSON response from Telegram getUpdates: {response.text}. Retrying in 5 seconds...")
                time.sleep(1) # Reduced sleep for faster response
                continue

            if response_data.get('ok') and response_data.get('result'):
                for update_obj in response_data['result']:
                    try:
                        process_telegram_update(update_obj)
                        # Update offset to acknowledge this update and get newer ones next time
                        offset = update_obj['update_id'] + 1
                    except Exception as e:
                        logging.error(f"Error processing update {update_obj.get('update_id', 'unknown')}: {e}")
                        # Still update offset to avoid processing the same broken update repeatedly
                        offset = update_obj.get('update_id', offset) + 1

            # Clean up temp files periodically (every 50 updates for frequent cleanup)
            if offset % 50 == 0:
                cleanup_temp_files()

        except requests.exceptions.RequestException as e:
            logging.error(f"General requests exception in long polling: {e}. Retrying in 3 seconds...")
            time.sleep(3)
        except KeyboardInterrupt:
            logging.info("Bot stopped by user.")
            break
        except Exception as e:
            logging.error(f"An unexpected error occurred in polling loop: {e}. Retrying in 3 seconds...")
            time.sleep(3)