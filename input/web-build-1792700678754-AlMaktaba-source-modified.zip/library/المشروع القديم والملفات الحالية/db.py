import os
import httpx
import json
import logging
import re
import uuid
from datetime import datetime
from typing import Optional, Dict, List, Any
import asyncio
import boto3
from botocore.exceptions import ClientError
from supabase import create_client, Client
import pytz

# Iraq timezone
IRAQ_TZ = pytz.timezone('Asia/Baghdad')

def to_english_numerals(text):
    """Convert Arabic numerals to English numerals"""
    if not isinstance(text, str):
        text = str(text)
    arabic_to_english = str.maketrans('٠١٢٣٤٥٦٧٨٩', '0123456789')
    return text.translate(arabic_to_english)

def get_iraq_time():
    """Get current time in Iraq timezone"""
    return datetime.now(IRAQ_TZ)

# Supabase configuration
SUPABASE_URL = os.environ.get("SUPABASE_URL")  # REDACTED in archival copy; do not use legacy integrations
SUPABASE_ANON_KEY = os.environ.get("SUPABASE_ANON_KEY")  # REDACTED in archival copy; do not use legacy integrations
SUPABASE_SERVICE_KEY = os.environ.get("SUPABASE_SERVICE_KEY")  # REDACTED in archival copy; do not use legacy integrations

# S3 configuration for Supabase Storage
S3_ACCESS_KEY = os.environ.get("S3_ACCESS_KEY")  # REDACTED in archival copy; do not use legacy integrations
S3_SECRET_KEY = os.environ.get("S3_SECRET_KEY")  # REDACTED in archival copy; do not use legacy integrations
S3_ENDPOINT = os.environ.get("S3_ENDPOINT")  # REDACTED in archival copy; do not use legacy integrations
S3_BUCKET = os.environ.get("S3_BUCKET")  # REDACTED in archival copy; do not use legacy integrations

# Create Supabase clients
supabase: Client = create_client(SUPABASE_URL, SUPABASE_SERVICE_KEY)

# Create S3 client
s3_client = boto3.client(
    's3',
    aws_access_key_id=S3_ACCESS_KEY,
    aws_secret_access_key=S3_SECRET_KEY,
    endpoint_url=S3_ENDPOINT,
    region_name='eu-north-1'
)

class SupabaseDB:
    def __init__(self):
        self.url = "https://bxfsjgiishddzfozknpd.supabase.co"
        self.anon_key = ""
        self.service_key = ""
        self.headers = {
            "apikey": self.anon_key,
            "Authorization": f"Bearer {self.anon_key}",
            "Content-Type": "application/json"
        }
        self.storage_headers = {
            "apikey": self.service_key,
            "Authorization": f"Bearer {self.service_key}",
        }

    async def _make_request(self, method: str, endpoint: str, data: Optional[Dict] = None, headers: Optional[Dict] = None, max_retries: int = 3) -> Optional[Dict]:
        """Make HTTP request to Supabase with error handling, retries, and fallback"""
        if headers is None:
            headers = self.headers

        url = f"{self.url}/rest/v1/{endpoint}"

        for attempt in range(max_retries):
            try:
                async with httpx.AsyncClient(timeout=30.0) as client:
                    if method == "GET":
                        response = await client.get(url, headers=headers)
                    elif method == "POST":
                        response = await client.post(url, headers=headers, json=data)
                    elif method == "PATCH":
                        response = await client.patch(url, headers=headers, json=data)
                    elif method == "DELETE":
                        response = await client.delete(url, headers=headers)

                    if response.status_code in [200, 201, 204]:
                        if response.status_code == 204:
                            return {"success": True}
                        try:
                            return response.json()
                        except json.JSONDecodeError:
                            return {"success": True}
                    else:
                        logging.error(f"Supabase API error (attempt {attempt + 1}/{max_retries}): {response.status_code} - {response.text}")
                        if attempt < max_retries - 1:
                            await asyncio.sleep(1 * (attempt + 1))  # Exponential backoff
                            continue
                        return None
            except (httpx.TimeoutException, httpx.ConnectError) as e:
                logging.error(f"Database connection error (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    await asyncio.sleep(1 * (attempt + 1))
                    continue
                return None
            except Exception as e:
                logging.error(f"Unexpected database error: {e}")
                return None
        
        return None

    # User Management Functions
    async def get_user(self, user_id: int) -> Optional[Dict]:
        """Get user data from database"""
        endpoint = f"users?user_id=eq.{user_id}&select=*"
        result = await self._make_request("GET", endpoint)
        return result[0] if result and len(result) > 0 else None

    async def create_user(self, user_id: int, user_data: Dict) -> bool:
        """Create new user in database"""
        data = {
            "user_id": str(user_id),
            "first_name": user_data.get("first_name", ""),
            "last_name": user_data.get("last_name", ""),
            "username": user_data.get("username", ""),
            "join_date": datetime.now().isoformat(),
            "is_allowed": False,
            "is_banned": False,
            "is_pending": True,
            "entry_time": user_data.get("entry_time", datetime.now().isoformat())
        }
        result = await self._make_request("POST", "users", data)
        return result is not None

    async def update_user(self, user_id: int, updates: Dict) -> bool:
        """Update user data"""
        endpoint = f"users?user_id=eq.{user_id}"
        result = await self._make_request("PATCH", endpoint, updates)
        return result is not None

    async def get_allowed_users(self) -> List[Dict]:
        """Get all allowed users"""
        endpoint = "users?is_allowed=eq.true&select=*"
        result = await self._make_request("GET", endpoint)
        return result or []

    async def get_banned_users(self) -> List[Dict]:
        """Get all banned users"""
        endpoint = "users?is_banned=eq.true&select=*"
        result = await self._make_request("GET", endpoint)
        return result or []

    async def get_pending_users(self) -> List[Dict]:
        """Get all pending users"""
        endpoint = "users?is_pending=eq.true&select=*"
        result = await self._make_request("GET", endpoint)
        return result or []

    async def approve_user(self, user_id: int) -> bool:
        """Approve a pending user"""
        updates = {"is_allowed": True, "is_pending": False, "is_banned": False}
        return await self.update_user(user_id, updates)

    async def ban_user(self, user_id: int) -> bool:
        """Ban a user"""
        updates = {"is_banned": True, "is_allowed": False, "is_pending": False}
        return await self.update_user(user_id, updates)

    async def unban_user(self, user_id: int) -> bool:
        """Unban a user"""
        updates = {"is_banned": False}
        return await self.update_user(user_id, updates)

    # API Key Management Functions
    async def get_api_keys(self, key_type: str) -> Optional[Dict]:
        """Get API keys for a specific service"""
        endpoint = f"api_keys?key_type=eq.{key_type}&select=*"
        result = await self._make_request("GET", endpoint)
        return result[0] if result and len(result) > 0 else None

    async def update_api_keys(self, key_type: str, key_data: Dict) -> bool:
        """Update API keys for a service"""
        # First check if record exists
        existing = await self.get_api_keys(key_type)

        data = {
            "key_type": key_type,
            "current_key": key_data.get("current_key"),
            "backup_keys": json.dumps(key_data.get("backup_keys", [])),
            "expired_keys": json.dumps(key_data.get("expired_keys", [])),
            "used_count": key_data.get("used_count", 0)
        }

        if existing:
            endpoint = f"api_keys?key_type=eq.{key_type}"
            result = await self._make_request("PATCH", endpoint, data)
        else:
            result = await self._make_request("POST", "api_keys", data)

        return result is not None

    # User State Management
    async def get_user_state(self, user_id: int) -> Dict:
        """Get user state"""
        endpoint = f"user_states?user_id=eq.{user_id}&select=*"
        result = await self._make_request("GET", endpoint)
        if result and len(result) > 0:
            state_data = result[0]
            return {
                "state": state_data.get("state", "main"),
                "data": json.loads(state_data.get("data", "{}"))
            }
        return {"state": "main", "data": {}}

    async def set_user_state(self, user_id: int, state: str, data: Dict = None) -> bool:
        """Set user state"""
        if data is None:
            data = {}

        # Check if state exists
        existing = await self.get_user_state(user_id)

        state_data = {
            "user_id": str(user_id),
            "state": state,
            "data": json.dumps(data)
        }

        if existing and existing.get("state") != "main":
            endpoint = f"user_states?user_id=eq.{user_id}"
            result = await self._make_request("PATCH", endpoint, state_data)
        else:
            result = await self._make_request("POST", "user_states", state_data)

        return result is not None

    async def clear_user_state(self, user_id: int) -> bool:
        """Clear user state"""
        endpoint = f"user_states?user_id=eq.{user_id}"
        result = await self._make_request("DELETE", endpoint)
        return result is not None

    # Statistics Management
    async def get_statistics(self) -> Dict:
        """Get bot statistics"""
        endpoint = "statistics?id=eq.1&select=*"
        result = await self._make_request("GET", endpoint)
        if result and len(result) > 0:
            stats = result[0]
            return {
                "total_users": stats.get("total_users", 0),
                "operations": json.loads(stats.get("operations", "{}")),
                "last_service_time": stats.get("last_service_time")
            }
        return {"total_users": 0, "operations": {}, "last_service_time": None}

    async def update_statistics(self, stats: Dict) -> bool:
        """Update bot statistics"""
        data = {
            "id": 1,
            "total_users": stats.get("total_users", 0),
            "operations": json.dumps(stats.get("operations", {})),
            "last_service_time": stats.get("last_service_time")
        }

        # Try to update first, if not exists, create
        endpoint = "statistics?id=eq.1"
        result = await self._make_request("PATCH", endpoint, data)

        if not result:
            result = await self._make_request("POST", "statistics", data)

        return result is not None

    # Template PDF Files Management
    async def save_template_pdf_file(self, user_id: int, file_name: str, file_url: str, template_type: str, image_count: int = 0) -> bool:
        """Save template-based PDF file information to database"""
        try:
            import pytz
            iraq_tz = pytz.timezone('Asia/Baghdad')
            iraq_time = datetime.now(iraq_tz).isoformat()
            
            data = {
                "user_id": str(user_id),
                "file_name": file_name,
                "file_url": file_url,
                "template_type": template_type,
                "image_count": image_count,
                "created_at": iraq_time,
                "updated_at": iraq_time
            }

            result = await self._make_request("POST", "template_pdf_files", data)
            return result is not None
        except Exception as e:
            logging.error(f"Error saving template PDF file: {e}")
            return False

    async def get_user_template_pdf_files(self, user_id: int) -> List[Dict]:
        """Get all template PDF files for a user sorted by creation date (oldest first)"""
        endpoint = f"template_pdf_files?user_id=eq.{user_id}&select=*&order=created_at.asc"
        result = await self._make_request("GET", endpoint)
        return result or []

    async def get_template_pdf_file_by_name(self, user_id: int, file_name: str) -> Optional[Dict]:
        """Get specific template PDF file by name"""
        endpoint = f"template_pdf_files?user_id=eq.{user_id}&file_name=eq.{file_name}&select=*"
        result = await self._make_request("GET", endpoint)
        return result[0] if result and len(result) > 0 else None

    async def update_template_pdf_file_name(self, user_id: int, old_name: str, new_name: str) -> bool:
        """Update template PDF file name in database."""
        try:
            import pytz
            iraq_tz = pytz.timezone('Asia/Baghdad')
            iraq_time = datetime.now(iraq_tz).isoformat()
            
            endpoint = f"template_pdf_files?user_id=eq.{user_id}&file_name=eq.{old_name}"
            updates = {"file_name": new_name, "updated_at": iraq_time}
            result = await self._make_request("PATCH", endpoint, updates)
            return result is not None
        except Exception as e:
            logging.error(f"Error updating template PDF file name: {e}")
            return False

    async def delete_template_pdf_file(self, user_id: int, file_name: str) -> bool:
        """Delete template PDF file from storage first, then from database"""
        try:
            # Get file info first to extract storage path
            file_info = await self.get_template_pdf_file_by_name(user_id, file_name)
            
            if not file_info:
                logging.warning(f"Template file not found in database: {file_name}")
                return False
            
            storage_deleted = False
            
            # Delete from storage FIRST if file info exists
            if file_info.get('file_url'):
                file_url = file_info.get('file_url', '')
                # Extract full storage path from URL (template-files/xxx.pdf)
                url_parts = file_url.split('/public/pdf-files/')
                if len(url_parts) > 1:
                    file_path = url_parts[1]
                    try:
                        # Delete from storage using full path and global supabase client
                        # Supabase storage.remove() returns a list on success
                        supabase.storage.from_('pdf-files').remove([file_path])
                        logging.info(f"✓ Deleted from storage: {file_path}")
                        storage_deleted = True
                    except Exception as e:
                        logging.error(f"✗ Failed to delete from storage {file_path}: {e}")
                        return False
            
            # Only delete from database after successful storage deletion
            if storage_deleted or not file_info.get('file_url'):
                endpoint = f"template_pdf_files?user_id=eq.{user_id}&file_name=eq.{file_name}"
                result = await self._make_request("DELETE", endpoint)
                if result is not None:
                    logging.info(f"✓ Deleted from database: {file_name}")
                    return True
                else:
                    logging.error(f"✗ Failed to delete from database: {file_name}")
                    return False
            
            return False
        except Exception as e:
            logging.error(f"Error deleting template PDF file: {e}")
            return False

    # Regular PDF Files Management (now using pdf_files table)
    async def save_regular_pdf_file(self, user_id: int, file_name: str, file_url: str, file_type: str = 'user_created', file_size: int = 0) -> bool:
        """Save regular PDF file information to database (uses pdf_files table)"""
        try:
            import pytz
            iraq_tz = pytz.timezone('Asia/Baghdad')
            iraq_time = datetime.now(iraq_tz).isoformat()
            
            data = {
                "user_id": str(user_id),
                "file_name": file_name,
                "file_url": file_url,
                "file_type": file_type,
                "file_size_bytes": file_size,
                "created_at": iraq_time,
                "updated_at": iraq_time
            }

            result = await self._make_request("POST", "pdf_files", data)
            return result is not None
        except Exception as e:
            logging.error(f"Error saving regular PDF file: {e}")
            return False

    async def get_user_regular_pdf_files(self, user_id: int) -> List[Dict]:
        """Get all regular PDF files for a user sorted by creation date (oldest first)"""
        endpoint = f"pdf_files?user_id=eq.{user_id}&select=*&order=created_at.asc"
        result = await self._make_request("GET", endpoint)
        return result or []

    async def get_regular_pdf_file_by_name(self, user_id: int, file_name: str) -> Optional[Dict]:
        """Get specific regular PDF file by name"""
        endpoint = f"pdf_files?user_id=eq.{user_id}&file_name=eq.{file_name}&select=*"
        result = await self._make_request("GET", endpoint)
        return result[0] if result and len(result) > 0 else None

    async def update_regular_pdf_file_name(self, user_id: int, old_name: str, new_name: str) -> bool:
        """Update regular PDF file name in database."""
        try:
            import pytz
            iraq_tz = pytz.timezone('Asia/Baghdad')
            iraq_time = datetime.now(iraq_tz).isoformat()
            
            endpoint = f"pdf_files?user_id=eq.{user_id}&file_name=eq.{old_name}"
            updates = {"file_name": new_name, "updated_at": iraq_time}
            result = await self._make_request("PATCH", endpoint, updates)
            return result is not None
        except Exception as e:
            logging.error(f"Error updating regular PDF file name: {e}")
            return False

    async def delete_regular_pdf_file(self, user_id: int, file_name: str) -> bool:
        """Delete regular PDF file from storage first, then from database"""
        try:
            # Get file info first to extract storage path
            file_info = await self.get_regular_pdf_file_by_name(user_id, file_name)
            
            if not file_info:
                logging.warning(f"File not found in database: {file_name}")
                return False
            
            storage_deleted = False
            
            # Delete from storage FIRST if file info exists
            if file_info.get('file_url'):
                file_url = file_info.get('file_url', '')
                # Extract full storage path from URL (regular-files/xxx.pdf)
                url_parts = file_url.split('/public/pdf-files/')
                if len(url_parts) > 1:
                    file_path = url_parts[1]
                    try:
                        # Delete from storage using full path and global supabase client
                        # Supabase storage.remove() returns a list on success
                        supabase.storage.from_('pdf-files').remove([file_path])
                        logging.info(f"✓ Deleted from storage: {file_path}")
                        storage_deleted = True
                    except Exception as e:
                        logging.error(f"✗ Failed to delete from storage {file_path}: {e}")
                        return False
            
            # Only delete from database after successful storage deletion
            if storage_deleted or not file_info.get('file_url'):
                endpoint = f"pdf_files?user_id=eq.{user_id}&file_name=eq.{file_name}"
                result = await self._make_request("DELETE", endpoint)
                if result is not None:
                    logging.info(f"✓ Deleted from database: {file_name}")
                    return True
                else:
                    logging.error(f"✗ Failed to delete from database: {file_name}")
                    return False
            
            return False
        except Exception as e:
            logging.error(f"Error deleting regular PDF file: {e}")
            return False

    # Legacy PDF Files Management (for backward compatibility)
    async def save_pdf_file(self, user_id: int, file_name: str, file_url: str) -> bool:
        """Save PDF file information to database (legacy method - redirects to regular PDF)"""
        return await self.save_regular_pdf_file(user_id, file_name, file_url)

    async def get_user_pdf_files(self, user_id: int) -> List[Dict]:
        """Get all PDF files for a user sorted by creation date (oldest first)"""
        endpoint = f"pdf_files?user_id=eq.{user_id}&select=*&order=created_at.asc"
        result = await self._make_request("GET", endpoint)
        return result or []

    async def get_all_pdf_files_count(self) -> int:
        """Get total count of all PDF files in database"""
        endpoint = "pdf_files?select=file_name"
        result = await self._make_request("GET", endpoint)
        if result and isinstance(result, list):
            return len(result)
        return 0

    async def get_pdf_file_by_name(self, user_id: int, file_name: str) -> Optional[Dict]:
        """Get specific PDF file by name"""
        endpoint = f"pdf_files?user_id=eq.{user_id}&file_name=eq.{file_name}&select=*"
        result = await self._make_request("GET", endpoint)
        return result[0] if result and len(result) > 0 else None

    async def update_pdf_file_name(self, user_id: int, old_name: str, new_name: str) -> bool:
        """Update PDF file name in database."""
        try:
            endpoint = f"pdf_files?user_id=eq.{user_id}&file_name=eq.{old_name}"
            updates = {"file_name": new_name}
            result = await self._make_request("PATCH", endpoint, updates)
            return result is not None
        except Exception as e:
            logging.error(f"Error updating PDF file name: {e}")
            return False

    async def get_pdf_file_by_id(self, user_id: int, file_id: int) -> Optional[Dict]:
        """Get PDF file by ID for a specific user."""
        try:
            endpoint = f"pdf_files?user_id=eq.{user_id}&id=eq.{file_id}&select=*"
            result = await self._make_request("GET", endpoint)
            return result[0] if result and len(result) > 0 else None
        except Exception as e:
            logging.error(f"Error getting PDF file by ID: {e}")
            return None

    # Storage Operations for PDF files
    def _sanitize_filename(self, filename: str) -> str:
        """Sanitize filename to be compatible with Supabase Storage"""
        # Always use UUID-based filename for storage to avoid encoding issues
        # Original name will be stored in database
        name, ext = os.path.splitext(filename)
        sanitized = f"file_{uuid.uuid4().hex[:12]}{ext or '.pdf'}"

        return sanitized

    async def upload_pdf_to_storage(self, file_name: str, file_data: bytes, is_template: bool = False) -> Optional[str]:
        """Upload PDF file to Supabase Storage
        
        Args:
            file_name: Name of the file
            file_data: Binary PDF data
            is_template: If True, upload to template-files/ folder, else regular-files/ folder
        
        Returns:
            Public URL of uploaded file or None on error
        """
        try:
            # Sanitize the filename
            sanitized_name = self._sanitize_filename(file_name)

            # Use single bucket with folder organization
            bucket_name = "pdf-files"
            folder_prefix = "template-files/" if is_template else "regular-files/"
            file_path = f"{folder_prefix}{sanitized_name}"

            # First, try to create the bucket if it doesn't exist
            bucket_url = f"{self.url}/storage/v1/bucket"
            bucket_data = {
                "id": bucket_name,
                "name": bucket_name,
                "public": True
            }

            async with httpx.AsyncClient(timeout=60.0) as client:
                # Try to create bucket (will fail if exists, which is fine)
                await client.post(bucket_url, headers=self.storage_headers, json=bucket_data)

                # Upload the file
                url = f"{self.url}/storage/v1/object/{bucket_name}/{file_path}"
                headers = self.storage_headers.copy()
                headers["Content-Type"] = "application/pdf"

                response = await client.post(url, headers=headers, content=file_data)

                if response.status_code in [200, 201]:
                    # Return the public URL
                    return f"https://bxfsjgiishddzfozknpd.supabase.co/storage/v1/object/public/{bucket_name}/{file_path}"
                else:
                    logging.error(f"Storage upload error: {response.status_code} - {response.text}")
                    return None
        except Exception as e:
            logging.error(f"Storage upload error: {e}")
            return None

    async def download_pdf_from_storage(self, file_name: str, is_template: bool = False) -> Optional[bytes]:
        """Download PDF file from Supabase Storage
        
        Args:
            file_name: Name of the file in storage (can include folder prefix)
            is_template: If True, add template-files/ prefix if not already present
        
        Returns:
            Binary PDF data or None on error
        """
        try:
            # Use single bucket with folder organization
            bucket_name = "pdf-files"
            
            # Add folder prefix if needed and not already present
            if is_template and not file_name.startswith("template-files/"):
                file_path = f"template-files/{file_name}"
            elif not is_template and not file_name.startswith("regular-files/"):
                file_path = f"regular-files/{file_name}"
            else:
                file_path = file_name
            
            url = f"{self.url}/storage/v1/object/public/{bucket_name}/{file_path}"

            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.get(url)

                if response.status_code == 200:
                    return response.content
                else:
                    logging.error(f"Storage download error: {response.status_code} - {response.text}")
                    return None
        except Exception as e:
            logging.error(f"Storage download error: {e}")
            return None

    async def execute_sql_direct(self, query: str) -> bool:
        """Execute raw SQL query using direct PostgreSQL connection"""
        try:
            import psycopg2
            connection_string = f"postgresql://postgres.bxfsjgiishddzfozknpd:{self.service_key}@aws-0-us-east-2.pooler.supabase.com:6543/postgres"

            conn = psycopg2.connect(connection_string)
            conn.autocommit = True
            cur = conn.cursor()

            try:
                cur.execute(query)
                return True
            finally:
                cur.close()
                conn.close()

        except Exception as e:
            logging.error(f"Direct SQL execution error: {e}")
            return False

    async def get_database_size(self) -> Optional[Dict]:
        """Get database size information from Supabase using actual file sizes"""
        try:
            # Get actual file sizes from pdf_files table (regular files)
            regular_endpoint = "pdf_files?select=file_size_bytes"
            regular_result = await self._make_request("GET", regular_endpoint)
            
            # Calculate actual size from regular PDF files
            regular_size_bytes = 0
            regular_count = 0
            
            if regular_result and isinstance(regular_result, list):
                regular_count = len(regular_result)
                for file_data in regular_result:
                    file_size = file_data.get('file_size_bytes', 0)
                    regular_size_bytes += file_size if file_size else 0
            
            # Get template files count and size
            template_count = 0
            template_size_bytes = 0
            try:
                template_endpoint = "template_pdf_files?select=file_name"
                template_result = await self._make_request("GET", template_endpoint)
                if template_result and isinstance(template_result, list):
                    # Estimate for template files (typically larger, avg 500KB)
                    template_count = len(template_result)
                    template_size_bytes = template_count * 500 * 1024  # 500KB estimate for template files
            except:
                pass  # If template table doesn't exist, that's fine
            
            # Calculate totals
            total_count = regular_count + template_count
            actual_size_bytes = regular_size_bytes + template_size_bytes
            size_mb = actual_size_bytes / (1024 * 1024)

            # حساب النسبة المئوية (افتراض الحد الأقصى 500 MB)
            max_size_mb = 500
            usage_percent = (size_mb / max_size_mb) * 100

            # تحديد حالة الاستخدام
            if usage_percent > 90:
                status = "🔴 حرج: أكثر من 90% مستخدم!"
                status_color = "🔴"
            elif usage_percent > 75:
                status = "🟠 تحذير: أكثر من 75% مستخدم"
                status_color = "🟠"
            elif usage_percent > 50:
                status = "🟡 متوسط: أكثر من 50% مستخدم"
                status_color = "🟡"
            else:
                status = "🟢 طبيعي"
                status_color = "🟢"

            return {
                "size_bytes": actual_size_bytes,
                "size_mb": round(size_mb, 6),
                "size_gb": round(size_mb / 1024, 6),
                "usage_percent": round(usage_percent, 8),
                "status": status,
                "status_color": status_color,
                "max_size_mb": max_size_mb,
                "remaining_mb": round(max_size_mb - size_mb, 6),
                "file_count": total_count,
                "regular_count": regular_count,
                "template_count": template_count
            }
        except Exception as e:
            logging.error(f"Error getting database size: {e}")
            return {
                "size_bytes": 0,
                "size_mb": 0.0,
                "size_gb": 0.0,
                "usage_percent": 0.0,
                "status": "🟢 طبيعي",
                "status_color": "🟢",
                "max_size_mb": 500,
                "remaining_mb": 500.0,
                "file_count": 0,
                "regular_count": 0,
                "template_count": 0
            }

    async def get_storage_usage(self) -> Optional[Dict]:
        """Get storage bucket usage information"""
        try:
            url = f"{self.url}/storage/v1/bucket/pdf-files"
            headers = {
                "apikey": self.service_key,
                "Authorization": f"Bearer {self.service_key}"
            }

            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(url, headers=headers)

                if response.status_code == 200:
                    bucket_info = response.json()
                    file_size_limit = bucket_info.get('file_size_limit', 52428800)  # 50MB default

                    # الحصول على قائمة الملفات لحساب الحجم الإجمالي
                    files_url = f"{self.url}/storage/v1/object/list/pdf-files"
                    files_response = await client.post(files_url, headers=headers, json={})

                    if files_response.status_code == 200:
                        files = files_response.json()
                        total_size = sum(file.get('metadata', {}).get('size', 0) for file in files)
                        total_files = len(files)

                        total_size_mb = total_size / (1024 * 1024)
                        max_size_mb = 1000  # افتراض حد أقصى 1GB للتخزين
                        usage_percent = (total_size_mb / max_size_mb) * 100

                        return {
                            "total_size_bytes": total_size,
                            "total_size_mb": round(total_size_mb, 2),
                            "total_files": total_files,
                            "usage_percent": round(usage_percent, 2),
                            "max_size_mb": max_size_mb,
                            "remaining_mb": round(max_size_mb - total_size_mb, 2)
                        }
                    else:
                        return {"error": "Could not retrieve files list"}
                else:
                    return {"error": f"Storage API error: {response.status_code}"}
        except Exception as e:
            logging.error(f"Error getting storage usage: {e}")
            return None

class DatabaseManager:
    def __init__(self):
        self.supabase = supabase

    async def test_connection(self):
        """Test database connection."""
        try:
            response = self.supabase.table('pdf_files').select('file_name').limit(1).execute()
            return True
        except Exception as e:
            logging.error(f"Database connection test failed: {e}")
            return False

    async def get_user(self, user_id: int):
        """Get user data from database."""
        try:
            response = self.supabase.table('users').select('*').eq('user_id', str(user_id)).execute()
            return response.data[0] if response.data else None
        except Exception as e:
            logging.error(f"Error getting user {user_id}: {e}")
            return None

    async def get_allowed_users(self):
        """Get all allowed users from allowed_users.json file."""
        try:
            # Read from local file as fallback
            from main import load_allowed_users
            user_data = load_allowed_users()
            allowed_user_ids = user_data.get('allowed', [])
            
            # Return list of user dictionaries
            allowed_users = []
            for user_id in allowed_user_ids:
                allowed_users.append({'user_id': user_id})
            
            return allowed_users
        except Exception as e:
            logging.error(f"Error getting allowed users: {e}")
            return []

    async def get_pending_users(self):
        """Get all pending users from allowed_users.json file."""
        try:
            # Read from local file
            from main import load_allowed_users
            user_data = load_allowed_users()
            pending_users_dict = user_data.get('pending', {})
            
            # Convert pending users dict to list format
            pending_users = []
            for user_id, user_info in pending_users_dict.items():
                pending_users.append({
                    'user_id': user_id,
                    **user_info
                })
            
            return pending_users
        except Exception as e:
            logging.error(f"Error getting pending users: {e}")
            return []

    async def get_banned_users(self):
        """Get all banned users from allowed_users.json file."""
        try:
            # Read from local file
            from main import load_allowed_users
            user_data = load_allowed_users()
            banned_user_ids = user_data.get('banned', [])
            
            # Return list of user dictionaries
            banned_users = []
            for user_id in banned_user_ids:
                banned_users.append({'user_id': user_id})
            
            return banned_users
        except Exception as e:
            logging.error(f"Error getting banned users: {e}")
            return []

    async def get_all_template_pdf_files(self):
        """Get all template PDF files from database."""
        try:
            response = self.supabase.table('template_pdf_files').select('*').order('created_at', desc=True).execute()
            return response.data if response.data else []
        except Exception as e:
            logging.error(f"Error getting all template PDF files: {e}")
            return []

    async def get_all_regular_pdf_files(self):
        """Get all regular PDF files from database (pdf_files table only)."""
        try:
            response = self.supabase.table('pdf_files').select('*').order('created_at', desc=True).execute()
            return response.data if response.data else []
        except Exception as e:
            logging.error(f"Error getting all regular PDF files: {e}")
            return []

    # Template PDF Methods
    async def save_template_pdf_file(self, user_id, file_name, file_url, template_type='3x3', image_count=0):
        """Save template-based PDF file information to database."""
        try:
            iraq_time = to_english_numerals(get_iraq_time().strftime('%Y-%m-%d %H:%M:%S'))
            file_name = to_english_numerals(file_name)
            
            data = {
                'user_id': str(user_id),
                'file_name': file_name,
                'file_url': file_url,
                'template_type': template_type,
                'image_count': image_count,
                'created_at': iraq_time,
                'updated_at': iraq_time
            }

            response = self.supabase.table('template_pdf_files').insert(data).execute()

            if response.data:
                logging.info(f"Template PDF file saved: {file_name} ({template_type}) for user {user_id}")
                return True
            else:
                logging.error(f"Failed to save template PDF file: {response}")
                return False

        except Exception as e:
            logging.error(f"Error saving template PDF file: {e}")
            return False

    async def get_user_template_pdf_files(self, user_id):
        """Get all template PDF files for a specific user."""
        try:
            response = self.supabase.table('template_pdf_files').select('*').eq('user_id', str(user_id)).order('created_at', desc=False).execute()
            return response.data if response.data else []
        except Exception as e:
            logging.error(f"Error getting user template PDF files: {e}")
            return []

    async def get_template_pdf_file_by_name(self, user_id, file_name):
        """Get template PDF file by name for a specific user."""
        try:
            response = self.supabase.table('template_pdf_files').select('*').eq('user_id', str(user_id)).eq('file_name', file_name).execute()
            return response.data[0] if response.data else None
        except Exception as e:
            logging.error(f"Error getting template PDF file by name: {e}")
            return None

    async def update_template_pdf_file_name(self, user_id, old_name, new_name):
        """Update template PDF file name."""
        try:
            iraq_time = to_english_numerals(get_iraq_time().strftime('%Y-%m-%d %H:%M:%S'))
            new_name = to_english_numerals(new_name)
            
            response = self.supabase.table('template_pdf_files').update({
                'file_name': new_name,
                'updated_at': iraq_time
            }).eq('user_id', str(user_id)).eq('file_name', old_name).execute()
            
            return bool(response.data)
        except Exception as e:
            logging.error(f"Error updating template PDF file name: {e}")
            return False

    async def delete_template_pdf_file(self, user_id, file_name):
        """Delete template PDF file from storage first, then from database."""
        try:
            # Get file info first to extract storage path
            file_info = await self.get_template_pdf_file_by_name(user_id, file_name)
            
            if not file_info:
                logging.warning(f"Template file not found in database: {file_name}")
                return False
            
            storage_deleted = False
            
            # Delete from storage FIRST if file info exists
            if file_info and file_info.get('file_url'):
                file_url = file_info.get('file_url', '')
                # Extract full storage path from URL (template-files/xxx.pdf)
                url_parts = file_url.split('/public/pdf-files/')
                if len(url_parts) > 1:
                    file_path = url_parts[1]
                    try:
                        # Delete from storage using full path
                        # Supabase storage.remove() returns a list on success
                        self.supabase.storage.from_('pdf-files').remove([file_path])
                        logging.info(f"✓ Deleted from storage: {file_path}")
                        storage_deleted = True
                    except Exception as e:
                        logging.error(f"✗ Failed to delete from storage {file_path}: {e}")
                        return False
            
            # Only delete from database after successful storage deletion
            if storage_deleted or not file_info.get('file_url'):
                response = self.supabase.table('template_pdf_files').delete().eq('user_id', str(user_id)).eq('file_name', file_name).execute()
                if response.data:
                    logging.info(f"✓ Deleted from database: {file_name}")
                    return True
                else:
                    logging.error(f"✗ Failed to delete from database: {file_name}")
                    return False
            
            return False
        except Exception as e:
            logging.error(f"Error deleting template PDF file: {e}")
            return False

    # Regular PDF Methods
    async def save_regular_pdf_file(self, user_id, file_name, file_url, file_type='user_created', file_size=0):
        """Save regular PDF file information to database."""
        try:
            iraq_time = to_english_numerals(get_iraq_time().strftime('%Y-%m-%d %H:%M:%S'))
            file_name = to_english_numerals(file_name)
            
            data = {
                'user_id': str(user_id),
                'file_name': file_name,
                'file_url': file_url,
                'created_at': iraq_time
            }

            response = self.supabase.table('pdf_files').insert(data).execute()

            if response.data:
                logging.info(f"Regular PDF file saved: {file_name} for user {user_id}")
                return True
            else:
                logging.error(f"Failed to save regular PDF file: {response}")
                return False

        except Exception as e:
            logging.error(f"Error saving regular PDF file: {e}")
            return False

    async def get_user_regular_pdf_files(self, user_id):
        """Get all regular PDF files for a specific user."""
        try:
            response = self.supabase.table('pdf_files').select('*').eq('user_id', str(user_id)).order('created_at', desc=False).execute()
            return response.data if response.data else []
        except Exception as e:
            logging.error(f"Error getting user regular PDF files: {e}")
            return []

    async def get_regular_pdf_file_by_name(self, user_id, file_name):
        """Get regular PDF file by name for a specific user (uses pdf_files table)."""
        try:
            response = self.supabase.table('pdf_files').select('*').eq('user_id', str(user_id)).eq('file_name', file_name).execute()
            return response.data[0] if response.data else None
        except Exception as e:
            logging.error(f"Error getting regular PDF file by name: {e}")
            return None

    async def update_regular_pdf_file_name(self, user_id, old_name, new_name):
        """Update regular PDF file name."""
        try:
            new_name = to_english_numerals(new_name)
            
            response = self.supabase.table('pdf_files').update({
                'file_name': new_name
            }).eq('user_id', str(user_id)).eq('file_name', old_name).execute()
            
            return bool(response.data)
        except Exception as e:
            logging.error(f"Error updating regular PDF file name: {e}")
            return False

    async def delete_regular_pdf_file(self, user_id, file_name):
        """Delete regular PDF file from storage first, then from database."""
        try:
            # Get file info first to extract storage path
            file_info = await self.get_regular_pdf_file_by_name(user_id, file_name)
            
            if not file_info:
                logging.warning(f"File not found in database: {file_name}")
                return False
            
            storage_deleted = False
            
            # Delete from storage FIRST if file info exists
            if file_info and file_info.get('file_url'):
                file_url = file_info.get('file_url', '')
                # Extract full storage path from URL (regular-files/xxx.pdf)
                url_parts = file_url.split('/public/pdf-files/')
                if len(url_parts) > 1:
                    file_path = url_parts[1]
                    try:
                        # Delete from storage using full path
                        # Supabase storage.remove() returns a list on success
                        self.supabase.storage.from_('pdf-files').remove([file_path])
                        logging.info(f"✓ Deleted from storage: {file_path}")
                        storage_deleted = True
                    except Exception as e:
                        logging.error(f"✗ Failed to delete from storage {file_path}: {e}")
                        return False
            
            # Only delete from database after successful storage deletion
            if storage_deleted or not file_info.get('file_url'):
                response = self.supabase.table('pdf_files').delete().eq('user_id', str(user_id)).eq('file_name', file_name).execute()
                if response.data:
                    logging.info(f"✓ Deleted from database: {file_name}")
                    return True
                else:
                    logging.error(f"✗ Failed to delete from database: {file_name}")
                    return False
            
            return False
        except Exception as e:
            logging.error(f"Error deleting regular PDF file: {e}")
            return False

    # Legacy method for backward compatibility
    async def save_pdf_file(self, user_id, file_name, file_url):
        """Save PDF file information to database (legacy - redirects to regular PDF)."""
        return await self.save_regular_pdf_file(user_id, file_name, file_url)

    async def delete_pdf_file(self, user_id, file_name):
        """Delete PDF file from database (legacy - redirects to regular PDF)."""
        try:
            # Try to delete from pdf_files table first
            response = self.supabase.table('pdf_files').delete().eq('user_id', str(user_id)).eq('file_name', file_name).execute()
            
            if response.data:
                # Also try to delete from storage if URL exists
                file_info = await self.get_pdf_file_by_name(user_id, file_name)
                if file_info and file_info.get('file_url'):
                    storage_file_name = file_info['file_url'].split('/')[-1]
                    try:
                        self.supabase.storage.from_('pdf-files').remove([storage_file_name])
                        logging.info(f"Deleted file from storage: {storage_file_name}")
                    except Exception as e:
                        logging.warning(f"Failed to delete from storage: {e}")
                
                logging.info(f"PDF file deleted: {file_name} for user {user_id}")
                return True
            else:
                logging.error(f"Failed to delete PDF file: {file_name}")
                return False
        except Exception as e:
            logging.error(f"Error deleting PDF file: {e}")
            return False

    async def get_pdf_file_by_name(self, user_id, file_name):
        """Get PDF file by name for a specific user."""
        try:
            response = self.supabase.table('pdf_files').select('*').eq('user_id', str(user_id)).eq('file_name', file_name).execute()

            if response.data:
                return response.data[0]
            else:
                return None

        except Exception as e:
            logging.error(f"Error getting PDF file by name: {e}")
            return None

    async def get_pdf_file_by_name_from_url(self, storage_file_name):
        """Get PDF file by storage file name from URL."""
        try:
            # Search for file by URL pattern containing the storage file name
            response = self.supabase.table('pdf_files').select('*').like('file_url', f'%{storage_file_name}%').execute()

            if response.data:
                return response.data[0]
            else:
                return None

        except Exception as e:
            logging.error(f"Error getting PDF file by storage name: {e}")
            return None

    async def update_pdf_file_name(self, user_id, old_name, new_name):
        """Update PDF file name in database."""
        try:
            response = self.supabase.table('pdf_files').update({'file_name': new_name}).eq('user_id', str(user_id)).eq('file_name', old_name).execute()
            
            if response.data:
                logging.info(f"PDF file name updated: {old_name} -> {new_name} for user {user_id}")
                return True
            else:
                logging.error(f"Failed to update PDF file name: {response}")
                return False
                
        except Exception as e:
            logging.error(f"Error updating PDF file name: {e}")
            return False

    async def get_pdf_file_by_id(self, user_id, file_id):
        """Get PDF file by ID for a specific user."""
        try:
            response = self.supabase.table('pdf_files').select('*').eq('user_id', str(user_id)).eq('id', file_id).execute()
            
            if response.data:
                return response.data[0]
            else:
                return None
                
        except Exception as e:
            logging.error(f"Error getting PDF file by ID: {e}")
            return None

    async def get_user_pdf_files(self, user_id):
        """Get all PDF files for a specific user sorted by creation date (oldest first)."""
        try:
            response = self.supabase.table('pdf_files').select('*').eq('user_id', str(user_id)).order('created_at', desc=False).execute()

            return response.data if response.data else []

        except Exception as e:
            logging.error(f"Error getting user PDF files: {e}")
            return []

    def get_user_stats(self, user_id):
        """Get user statistics from user_daily_stats.json file."""
        try:
            # Load statistics from the JSON file
            from main import load_user_daily_stats
            stats = load_user_daily_stats()
            
            # Get today's date in Iraq timezone
            from main import get_iraq_time
            today = get_iraq_time().strftime('%Y-%m-%d')
            
            user_key = str(user_id)
            if user_key not in stats or today not in stats[user_key]:
                return {
                    'images_processed': 0,
                    'pdfs_created': 0,
                    'templates_created': 0,
                    'api_calls': 0
                }
            
            day_stats = stats[user_key][today]
            services = day_stats.get('services', {})
            
            # Calculate statistics from services
            images_processed = services.get('remove_background', 0) + services.get('enhance_image', 0)
            templates_created = services.get('create_template', 0)
            pdfs_created = services.get('convert_to_pdf', 0)
            api_calls = day_stats.get('total_activities', 0)
            
            return {
                'images_processed': images_processed,
                'pdfs_created': pdfs_created,
                'templates_created': templates_created,
                'api_calls': api_calls
            }
            
        except Exception as e:
            logging.error(f"Error getting user stats: {e}")
            return {
                'images_processed': 0,
                'pdfs_created': 0,
                'templates_created': 0,
                'api_calls': 0
            }

    async def get_all_pdf_files(self):
        """Get all PDF files from database (both regular and template files)."""
        try:
            # Get regular PDF files
            regular_response = self.supabase.table('pdf_files').select('*').order('created_at', desc=True).execute()
            regular_files = regular_response.data if regular_response.data else []
            
            # Get template PDF files
            template_response = self.supabase.table('template_pdf_files').select('*').order('created_at', desc=True).execute()
            template_files = template_response.data if template_response.data else []
            
            # Combine both lists
            all_files = regular_files + template_files
            
            # Sort by creation date (newest first)
            all_files.sort(key=lambda x: x.get('created_at', ''), reverse=True)
            
            return all_files

        except Exception as e:
            logging.error(f"Error getting all PDF files: {e}")
            return []

    async def get_all_template_pdf_files(self):
        """Get all template PDF files from database."""
        try:
            response = self.supabase.table('template_pdf_files').select('*').order('created_at', desc=True).execute()

            return response.data if response.data else []

        except Exception as e:
            logging.error(f"Error getting all template PDF files: {e}")
            return []

    async def get_total_files_count(self):
        """Get total count of PDF files in database (both template and regular)."""
        try:
            # Use select('*') with count to ensure accurate count
            template_response = self.supabase.table('template_pdf_files').select('*', count='exact').execute()
            template_count = len(template_response.data) if template_response.data else 0
            
            regular_response = self.supabase.table('pdf_files').select('*', count='exact').execute()
            regular_count = len(regular_response.data) if regular_response.data else 0

            total_count = template_count + regular_count
            logging.info(f"Total files count: {total_count} (regular: {regular_count}, template: {template_count})")
            
            return total_count

        except Exception as e:
            logging.error(f"Error getting total files count: {e}")
            return 0

    async def get_storage_info(self):
        """Get storage information from Supabase with actual file sizes from S3."""
        try:
            # First try to get S3 storage info for actual sizes
            s3_info = await self.get_s3_storage_info()
            
            if s3_info:
                return s3_info
            
            # Fallback: Get actual file count from both tables
            regular_response = self.supabase.table('pdf_files').select('*').execute()
            regular_count = len(regular_response.data) if regular_response.data else 0
            
            template_response = self.supabase.table('template_pdf_files').select('*').execute()
            template_count = len(template_response.data) if template_response.data else 0
            
            file_count = regular_count + template_count
            
            logging.info(f"Storage info - Total files: {file_count} (regular: {regular_count}, template: {template_count})")
            
            # Estimate storage based on file count (300KB average per file)
            estimated_storage = file_count * 300 * 1024  # 300KB average per file
            
            # Supabase free tier has 500MB for database
            total_storage = 500 * 1024 * 1024  # 500MB in bytes
            usage_percentage = (estimated_storage / total_storage) * 100 if total_storage > 0 else 0
            
            # Determine status based on usage
            if usage_percentage > 90:
                status = "🔴 حرج: أكثر من 90% مستخدم!"
            elif usage_percentage > 75:
                status = "🟠 تحذير: أكثر من 75% مستخدم"
            elif usage_percentage > 50:
                status = "🟡 متوسط: أكثر من 50% مستخدم"
            else:
                status = "🟢 طبيعي"

            return {
                'used_storage': estimated_storage,
                'total_storage': total_storage,
                'file_count': file_count,
                'usage_percentage': round(usage_percentage, 8),
                'size_mb': round(estimated_storage / (1024 * 1024), 6),
                'total_mb': 500,
                'remaining_mb': round((total_storage - estimated_storage) / (1024 * 1024), 6),
                'status': status,
                'usage_percentage_display': f"{usage_percentage:.8f}%",
                'size_mb_display': f"{estimated_storage / (1024 * 1024):.6f} MB"
            }

        except Exception as e:
            logging.error(f"Error getting storage info: {e}")
            return {
                'used_storage': 0,
                'total_storage': 500 * 1024 * 1024,  # Default 500MB
                'file_count': 0,
                'usage_percentage': 0.0,
                'size_mb': 0.0,
                'total_mb': 500,
                'remaining_mb': 500.0,
                'status': '🟢 طبيعي',
                'usage_percentage_display': "0.00000000%",
                'size_mb_display': "0.000000 MB"
            }

    async def upload_pdf_to_storage(self, file_name, pdf_data, is_template=False):
        """Upload PDF file to Supabase Storage.
        
        Args:
            file_name: Original file name
            pdf_data: Binary PDF data
            is_template: If True, upload to template-files/ folder, else regular-files/ folder
        
        Returns:
            Public URL of uploaded file or None on error
        """
        try:
            # Use SupabaseDB method for consistent sanitization
            supabase_db = SupabaseDB()
            safe_filename = supabase_db._sanitize_filename(file_name)
            
            # Use single bucket with folder organization
            bucket_name = "pdf-files"
            folder_prefix = "template-files/" if is_template else "regular-files/"
            file_path = f"{folder_prefix}{safe_filename}"
            
            logging.info(f"Uploading PDF: original='{file_name}', sanitized='{safe_filename}', path='{file_path}'")

            # Upload to Supabase Storage
            response = self.supabase.storage.from_(bucket_name).upload(file_path, pdf_data)

            if response:
                # Construct the public URL manually for consistency
                public_url = f"https://bxfsjgiishddzfozknpd.supabase.co/storage/v1/object/public/{bucket_name}/{file_path}"
                
                logging.info(f"PDF uploaded to storage successfully: {file_path}")
                logging.info(f"Generated public URL: {public_url}")
                
                return public_url
            else:
                logging.error(f"Failed to upload PDF to storage. Response: {response}")
                return None

        except Exception as e:
            logging.error(f"Error uploading PDF to storage: {e}")
            return None

    async def download_pdf_from_storage(self, storage_path, is_template=False):
        """Download PDF file from Supabase Storage using storage path.
        
        Args:
            storage_path: Path to file in storage (can be 'template-files/file_xxx.pdf' or just 'file_xxx.pdf' or full URL)
            is_template: If True and storage_path doesn't include folder, try template-files/ folder
        
        Returns:
            Binary PDF data or None on error
        """
        try:
            import httpx
            
            # Extract file name from URL if full URL was passed
            if storage_path.startswith('http'):
                if '/public/' in storage_path:
                    # Extract everything after /public/pdf-files/
                    after_public = storage_path.split('/public/')[-1]
                    if after_public.startswith('pdf-files/'):
                        storage_path = after_public.replace('pdf-files/', '', 1)
                    else:
                        storage_path = after_public
                else:
                    storage_path = storage_path.split('/')[-1]
            
            # Build download URL
            bucket_name = "pdf-files"
            
            # Try multiple possible paths
            possible_paths = []
            
            # If path already includes folder prefix, use as-is
            if '/' in storage_path:
                possible_paths.append(storage_path)
            else:
                # Try with appropriate folder prefix
                folder_prefix = "template-files/" if is_template else "regular-files/"
                possible_paths.append(f"{folder_prefix}{storage_path}")
                
                # Also try the opposite folder as fallback
                opposite_prefix = "regular-files/" if is_template else "template-files/"
                possible_paths.append(f"{opposite_prefix}{storage_path}")
                
                # Try without any prefix (old format)
                possible_paths.append(storage_path)
            
            # Try each possible path
            for file_path in possible_paths:
                download_url = f"https://bxfsjgiishddzfozknpd.supabase.co/storage/v1/object/public/{bucket_name}/{file_path}"
                
                logging.info(f"Trying to download from: {download_url}")
                
                async with httpx.AsyncClient(timeout=60.0) as client:
                    response = await client.get(download_url)

                    if response.status_code == 200:
                        content_length = len(response.content)
                        logging.info(f"✓ PDF downloaded successfully from {file_path}, size: {content_length} bytes")
                        return response.content
                    elif response.status_code == 400:
                        logging.warning(f"✗ Bad request for path: {file_path}")
                        continue
                    elif response.status_code == 404:
                        logging.warning(f"✗ File not found at path: {file_path}")
                        continue
                    else:
                        logging.warning(f"✗ HTTP {response.status_code} for path: {file_path}")
                        continue
            
            # If all paths failed
            logging.error(f"Failed to download PDF from all possible paths for: {storage_path}")
            return None

        except Exception as e:
            logging.error(f"Error downloading PDF from storage '{storage_path}': {e}")
            return None

    async def download_pdf_by_original_name(self, user_id, original_file_name):
        """Download PDF file by original file name."""
        try:
            # Get file info from database
            file_info = await self.get_pdf_file_by_name(user_id, original_file_name)
            
            if not file_info:
                logging.error(f"File not found in database: {original_file_name}")
                return None
            
            # Extract storage file name from URL
            file_url = file_info.get('file_url', '')
            if not file_url:
                logging.error(f"No file URL found for: {original_file_name}")
                return None
            
            # Extract the actual file name from the URL
            # URL format: https://...supabase.co/storage/v1/object/public/pdf-files/file_xxxxxxxxx.pdf
            storage_file_name = file_url.split('/')[-1]
            
            # Download using storage file name
            return await self.download_pdf_from_storage(storage_file_name)
            
        except Exception as e:
            logging.error(f"Error downloading PDF by original name: {e}")
            return None

    async def delete_user_files(self, user_id):
        """Delete all PDF files for a specific user from database and storage."""
        try:
            # Get all user files first
            user_files = await self.get_user_pdf_files(user_id)
            
            if not user_files:
                logging.info(f"No files found for user {user_id}")
                return True
            
            deleted_count = 0
            for file_info in user_files:
                file_url = file_info.get('file_url', '')
                if file_url:
                    # Extract full storage path from URL (regular-files/xxx.pdf or template-files/xxx.pdf)
                    url_parts = file_url.split('/public/pdf-files/')
                    if len(url_parts) > 1:
                        file_path = url_parts[1]
                        
                        try:
                            # Delete from storage using full path
                            delete_response = self.supabase.storage.from_('pdf-files').remove([file_path])
                            if delete_response:
                                logging.info(f"✓ Deleted from storage: {file_path}")
                        except Exception as e:
                            logging.warning(f"✗ Failed to delete from storage {file_path}: {e}")
                
                deleted_count += 1
            
            # Delete all records from database
            response = self.supabase.table('pdf_files').delete().eq('user_id', str(user_id)).execute()
            
            if response:
                logging.info(f"Deleted {deleted_count} files for user {user_id} from database and storage")
                return True
            else:
                logging.error(f"Failed to delete files from database for user {user_id}")
                return False
                
        except Exception as e:
            logging.error(f"Error deleting user files for user {user_id}: {e}")
            return False

    async def delete_all_template_files(self):
        """Delete all template PDF files from database and storage (Admin only)."""
        try:
            logging.info("Starting template files deletion")
            
            # Step 1: Get all template files
            template_files = await self.get_all_template_pdf_files()
            total_files = len(template_files) if template_files else 0
            logging.info(f"Found {total_files} template files to delete")
            
            # Step 2: Delete from storage
            deleted_storage_count = 0
            try:
                folder_files = self.supabase.storage.from_('pdf-files').list('template-files')
                if folder_files:
                    file_paths = [f"template-files/{obj['name']}" for obj in folder_files if obj.get('name')]
                    if file_paths:
                        self.supabase.storage.from_('pdf-files').remove(file_paths)
                        logging.info(f"✓ Deleted {len(file_paths)} template files from storage")
                        deleted_storage_count = len(file_paths)
            except Exception as e:
                logging.error(f"Error deleting template files from storage: {e}")
            
            # Step 3: Delete from database
            template_deleted = False
            try:
                response = self.supabase.table('template_pdf_files').delete().gte('user_id', '0').execute()
                if response.data is not None:
                    template_deleted = True
                    logging.info("✓ Deleted all template file records from database")
            except Exception as e:
                logging.warning(f"Template deletion failed: {e}")
            
            if template_deleted:
                logging.info(f"✓ Successfully deleted all template files: {total_files} from database + {deleted_storage_count} from storage")
                return True
            else:
                logging.error("Failed to delete template files from database")
                return False
                
        except Exception as e:
            logging.error(f"Error deleting template files: {e}")
            return False

    async def delete_all_regular_files(self):
        """Delete all regular PDF files from database and storage (Admin only)."""
        try:
            logging.info("Starting regular files deletion")
            
            # Step 1: Get all regular files
            regular_response = self.supabase.table('pdf_files').select('*').execute()
            regular_files = regular_response.data if regular_response.data else []
            total_files = len(regular_files)
            logging.info(f"Found {total_files} regular files to delete")
            
            # Step 2: Delete from storage
            deleted_storage_count = 0
            try:
                folder_files = self.supabase.storage.from_('pdf-files').list('regular-files')
                if folder_files:
                    file_paths = [f"regular-files/{obj['name']}" for obj in folder_files if obj.get('name')]
                    if file_paths:
                        self.supabase.storage.from_('pdf-files').remove(file_paths)
                        logging.info(f"✓ Deleted {len(file_paths)} regular files from storage")
                        deleted_storage_count = len(file_paths)
            except Exception as e:
                logging.error(f"Error deleting regular files from storage: {e}")
            
            # Step 3: Delete from database
            regular_deleted = False
            try:
                response = self.supabase.table('pdf_files').delete().gte('user_id', '0').execute()
                if response.data is not None:
                    regular_deleted = True
                    logging.info("✓ Deleted all regular file records from database")
            except Exception as e:
                logging.warning(f"Regular files deletion failed: {e}")
            
            if regular_deleted:
                logging.info(f"✓ Successfully deleted all regular files: {total_files} from database + {deleted_storage_count} from storage")
                return True
            else:
                logging.error("Failed to delete regular files from database")
                return False
                
        except Exception as e:
            logging.error(f"Error deleting regular files: {e}")
            return False

    async def delete_all_files(self):
        """Delete all PDF files from database and storage completely (Admin only)."""
        try:
            logging.info("Starting complete file deletion (all tables and storage)")
            
            # Step 1: Get all files from both tables
            all_files = await self.get_all_pdf_files()
            
            total_files = len(all_files) if all_files else 0
            logging.info(f"Found {total_files} total files to delete")
            
            # Step 2: Delete ALL files from storage buckets (both folders)
            deleted_storage_count = 0
            
            try:
                for folder in ['regular-files', 'template-files']:
                    folder_files = self.supabase.storage.from_('pdf-files').list(folder)
                    if folder_files:
                        file_paths = [f"{folder}/{obj['name']}" for obj in folder_files if obj.get('name')]
                        if file_paths:
                            self.supabase.storage.from_('pdf-files').remove(file_paths)
                            logging.info(f"✓ Deleted {len(file_paths)} files from storage folder: {folder}/")
                            deleted_storage_count += len(file_paths)
            except Exception as e:
                logging.error(f"Error cleaning storage folders: {e}")
            
            logging.info(f"Total files deleted from storage: {deleted_storage_count}")
            
            # Step 3: Delete ALL records from pdf_files table
            pdf_files_deleted = False
            
            # Try different methods to delete from pdf_files
            try:
                response = self.supabase.table('pdf_files').delete().gte('user_id', '0').execute()
                if response.data is not None:
                    pdf_files_deleted = True
                    logging.info("✓ Deleted all records from pdf_files table (method 1)")
            except Exception as e:
                logging.warning(f"pdf_files deletion method 1 failed: {e}")
            
            if not pdf_files_deleted:
                try:
                    response = self.supabase.table('pdf_files').delete().neq('user_id', '').execute()
                    if response.data is not None:
                        pdf_files_deleted = True
                        logging.info("✓ Deleted all records from pdf_files table (method 2)")
                except Exception as e:
                    logging.warning(f"pdf_files deletion method 2 failed: {e}")
            
            # Step 4: Delete ALL records from template_pdf_files table
            template_files_deleted = False
            
            try:
                response = self.supabase.table('template_pdf_files').delete().gte('user_id', '0').execute()
                if response.data is not None:
                    template_files_deleted = True
                    logging.info("✓ Deleted all records from template_pdf_files table (method 1)")
            except Exception as e:
                logging.warning(f"template_pdf_files deletion method 1 failed: {e}")
            
            if not template_files_deleted:
                try:
                    response = self.supabase.table('template_pdf_files').delete().neq('user_id', '').execute()
                    if response.data is not None:
                        template_files_deleted = True
                        logging.info("✓ Deleted all records from template_pdf_files table (method 2)")
                except Exception as e:
                    logging.warning(f"template_pdf_files deletion method 2 failed: {e}")
            
            # Step 5: Verification for both tables
            try:
                # Check pdf_files
                pdf_verification = self.supabase.table('pdf_files').select('file_name', count='exact').execute()
                remaining_pdf = pdf_verification.count if pdf_verification.count is not None else 0
                
                # Check template_pdf_files
                template_verification = self.supabase.table('template_pdf_files').select('file_name', count='exact').execute()
                remaining_template = template_verification.count if template_verification.count is not None else 0
                
                total_remaining = remaining_pdf + remaining_template
                
                if total_remaining > 0:
                    logging.warning(f"Verification: {total_remaining} files still remain (pdf_files: {remaining_pdf}, template_pdf_files: {remaining_template})")
                    
                    # Force delete remaining files from pdf_files
                    if remaining_pdf > 0:
                        try:
                            remaining_data = self.supabase.table('pdf_files').select('*').execute()
                            if remaining_data.data:
                                for remaining_file in remaining_data.data:
                                    self.supabase.table('pdf_files').delete().eq('id', remaining_file.get('id')).execute()
                                logging.info(f"Force deleted {len(remaining_data.data)} remaining files from pdf_files")
                        except Exception as e:
                            logging.error(f"Force deletion from pdf_files failed: {e}")
                    
                    # Force delete remaining files from template_pdf_files
                    if remaining_template > 0:
                        try:
                            remaining_data = self.supabase.table('template_pdf_files').select('*').execute()
                            if remaining_data.data:
                                for remaining_file in remaining_data.data:
                                    self.supabase.table('template_pdf_files').delete().eq('id', remaining_file.get('id')).execute()
                                logging.info(f"Force deleted {len(remaining_data.data)} remaining files from template_pdf_files")
                        except Exception as e:
                            logging.error(f"Force deletion from template_pdf_files failed: {e}")
                else:
                    logging.info("✓ Verification: All files successfully removed from both database tables")
            except Exception as e:
                logging.warning(f"Verification failed: {e}")
            
            # Final status
            deletion_success = pdf_files_deleted or template_files_deleted
            
            if deletion_success:
                logging.info(f"✓ Successfully deleted all data: {total_files} files from database + {deleted_storage_count} files from storage")
                return True
            else:
                logging.error("Failed to delete all files from database")
                return False
                
        except Exception as e:
            logging.error(f"Error deleting all files: {e}")
            return False

    async def _delete_files_from_s3(self, file_paths):
        """Delete multiple files from S3 storage using full paths"""
        try:
            # Prepare objects for deletion with full paths (regular-files/xxx.pdf or template-files/xxx.pdf)
            objects_to_delete = [{'Key': filepath} for filepath in file_paths]
            
            # Delete in batches of 1000 (S3 limit)
            batch_size = 1000
            for i in range(0, len(objects_to_delete), batch_size):
                batch = objects_to_delete[i:i + batch_size]
                
                delete_request = {
                    'Objects': batch,
                    'Quiet': True
                }
                
                response = s3_client.delete_objects(
                    Bucket=S3_BUCKET,
                    Delete=delete_request
                )
                
                if 'Errors' in response:
                    logging.warning(f"Some files failed to delete: {response['Errors']}")
                else:
                    logging.info(f"✓ S3: Deleted batch of {len(batch)} files")
                
        except Exception as e:
            logging.error(f"Error deleting files from S3: {e}")
            raise

    async def get_s3_storage_info(self):
        """Get storage information using S3 API"""
        try:
            # List all objects in bucket
            response = s3_client.list_objects_v2(Bucket=S3_BUCKET)
            
            total_size = 0
            file_count = 0
            
            if 'Contents' in response:
                for obj in response['Contents']:
                    total_size += obj['Size']
                    file_count += 1
            
            # Handle pagination if there are more than 1000 objects
            while response.get('IsTruncated'):
                response = s3_client.list_objects_v2(
                    Bucket=S3_BUCKET,
                    ContinuationToken=response['NextContinuationToken']
                )
                if 'Contents' in response:
                    for obj in response['Contents']:
                        total_size += obj['Size']
                        file_count += 1
            
            # Convert to MB
            total_size_mb = total_size / (1024 * 1024)
            max_size_mb = 500  # Supabase free tier limit
            usage_percent = (total_size_mb / max_size_mb) * 100
            
            return {
                'used_storage': total_size,
                'total_storage': max_size_mb * 1024 * 1024,
                'file_count': file_count,
                'usage_percentage': round(usage_percent, 8),
                'size_mb': round(total_size_mb, 6),
                'total_mb': max_size_mb,
                'remaining_mb': round(max_size_mb - total_size_mb, 6),
                'status': '🟢 طبيعي' if usage_percent < 50 else '🟡 متوسط' if usage_percent < 75 else '🟠 تحذير' if usage_percent < 90 else '🔴 حرج',
                'usage_percentage_display': f"{usage_percent:.8f}%",
                'size_mb_display': f"{total_size_mb:.6f} MB"
            }
            
        except Exception as e:
            logging.error(f"Error getting S3 storage info: {e}")
            return None

    async def get_database_size(self):
        """Get database size information with actual file counts from database tables."""
        try:
            # Get file counts from database tables
            regular_response = self.supabase.table('pdf_files').select('file_name', count='exact').execute()
            regular_count = len(regular_response.data) if regular_response.data else 0
            
            template_response = self.supabase.table('template_pdf_files').select('file_name', count='exact').execute()
            template_count = len(template_response.data) if template_response.data else 0
            
            # Calculate total file count
            file_count = regular_count + template_count
            
            # Try to get actual size from S3 storage
            total_size = 0
            try:
                response = s3_client.list_objects_v2(Bucket=S3_BUCKET)
                
                if 'Contents' in response:
                    for obj in response['Contents']:
                        total_size += obj['Size']
                
                # Handle pagination if there are more than 1000 objects
                while response.get('IsTruncated'):
                    response = s3_client.list_objects_v2(
                        Bucket=S3_BUCKET,
                        ContinuationToken=response['NextContinuationToken']
                    )
                    if 'Contents' in response:
                        for obj in response['Contents']:
                            total_size += obj['Size']
            except Exception as s3_error:
                logging.warning(f"Could not get S3 storage size, using estimate: {s3_error}")
                # Estimate storage based on file count (300KB average per file)
                total_size = file_count * 300 * 1024
            
            # Convert to MB
            size_mb = total_size / (1024 * 1024)
            
            # Calculate usage percentage (assuming 500MB max)
            max_size_mb = 500
            usage_percent = (size_mb / max_size_mb) * 100
            
            # Determine status
            if usage_percent > 90:
                status = "🔴 حرج: أكثر من 90% مستخدم!"
            elif usage_percent > 75:
                status = "🟠 تحذير: أكثر من 75% مستخدم"
            elif usage_percent > 50:
                status = "🟡 متوسط: أكثر من 50% مستخدم"
            else:
                status = "🟢 جيد: مساحة كافية متاحة"
            
            return {
                "size_bytes": total_size,
                "size_mb": round(size_mb, 6),
                "size_gb": round(size_mb / 1024, 6),
                "usage_percent": round(usage_percent, 8),
                "status": status,
                "max_size_mb": max_size_mb,
                "remaining_mb": round(max_size_mb - size_mb, 6),
                "file_count": file_count,
                "regular_count": regular_count,
                "template_count": template_count
            }
            
        except Exception as e:
            logging.error(f"Error getting database size: {e}")
            return {
                "size_bytes": 0,
                "size_mb": 0.0,
                "size_gb": 0.0,
                "usage_percent": 0.0,
                "status": "🟢 طبيعي",
                "max_size_mb": 500,
                "remaining_mb": 500.0,
                "file_count": 0,
                "regular_count": 0,
                "template_count": 0
            }

# Create global database manager instance
db = DatabaseManager()
